# Grindstone Wrestling - Quick Coaching Cues, Ages 11-14

Use these reminders with the shared Coach Moves Reference. Full teaching steps, prerequisites, corrections and research are organized there by move ID. Follow the current practice task; an entry-only lesson does not authorize a finish.

## Inside Control

**Full instruction:** B04: Wrist and Inside Tie, p. 13

**B04 cues:** Wrist on one side, inside on the other. / Elbows down; feet move.

**Coach check:** Reaching across to the wrist-controlled arm or pulling with straight elbows.

**Fix:** Reset closer; identify their opposite upper arm and keep your elbows bent.

**Original practice links:** 7, 8, 19

## Double Leg

**Full instruction:** B07: Double Leg Takedown, p. 15

**B07 cues:** Chest up, trail foot up. / Drive right; knees left.

**Coach check:** Attacker circles left around the head side or keeps driving straight.

**Fix:** Freeze at entry; point out the right-hand corner, then step across it.

**Original practice links:** 10, 12, 19, 20, 24, 25, 26, 27, 28, 29, 30

## Sprawl and Go-Behind

**Full instruction:** B11: Sprawl and Go-Behind, p. 17

**B11 cues:** Clear the legs first. / Block the arm; circle to the hips.

**Coach check:** Defender circles early or lifts the chest, allowing another leg grab.

**Fix:** Pause with legs free and chest connected; establish the arm block before stepping around.

**Original practice links:** 11, 12, 19, 20, 24, 27, 28, 29, 30

## Go-Behind Finish

**Full instruction:** B11: Sprawl and Go-Behind, p. 17

**B11 cues:** Clear the legs first. / Block the arm; circle to the hips.

**Coach check:** Defender circles early or lifts the chest, allowing another leg grab.

**Fix:** Pause with legs free and chest connected; establish the arm block before stepping around.

**Original practice links:** 21, 24, 25, 28, 29, 30

## Stand-Up

**Full instruction:** B17: Inside-Leg Stand-Up, p. 20

**B17 cues:** Foot and chest up together. / Control the hand; hips clear, face.

**Coach check:** Turning while the rider's arm still hugs your waist.

**Fix:** Rehearse from standing: isolate the hand, create hip space, then turn.

**Original practice links:** 14, 22, 24, 25, 26, 27, 28, 29, 30

## Sit-Out and Hip-Heist

**Full instruction:** B18: Sit-Out, p. 20 / B19: Hip-Heist Escape, p. 21

**B18 cues:** Foot out, leg through. / Elbows in, chest up.

**B19 cues:** Clear hands, then heist. / One leg under, one over.

**Coach check:** Reaching back with a straight arm while falling into the seat.

**Fix:** Shorten the step and lower slowly; return the posting hand to your side once balanced.

**Original practice links:** 15, 22, 23, 24, 27, 28, 30

## Tight Waist and Chop

**Full instruction:** B22: Tight Waist Chop, p. 22

**B22 cues:** Drive forward as the elbow folds. / Chop, catch the wrist, follow.

**Coach check:** Top pulls the elbow sideways while sitting back.

**Fix:** Reset; use a small arm fold with forward toe pressure and the rear knee moving the hips.

**Original practice links:** 16, 17, 22, 23, 24, 27, 28, 29, 30

## Half Nelson and Defense

**Full instruction:** B26: Half Nelson, p. 24 / B27: Early Half Nelson Defense, p. 25

**B26 cues:** Elbow up; feet to the head. / Chest across; hips down.

**B27 cues:** Elbow in; look away early. / Same hand peels; then build.

**Coach check:** Top stays parallel and tries to win by pushing harder on the head.

**Fix:** Reset the half, step out to a T, and move the torso with chest pressure.

**Original practice links:** 18, 23, 24, 25, 27, 28, 29, 30
