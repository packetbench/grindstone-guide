# Grindstone Wrestling 30 Practice Plans Ages 11-14

Mat Rats | Wrestling skills and decisions | 75 minutes

Thirty practices for ages 11 to 14 that connect foundational wrestling skills with decisions and controlled positional work. Every practice includes a route for newer wrestlers and a challenge for experienced partners.

Two practices each week make a fifteen-week sequence. Use the simpler route for first-year athletes and adjust the total load around school sport, other clubs and events. Repetition is part of learning.

All times are elapsed minutes. Demonstration, rest, rotations and feedback are included within each block. Water remains available throughout.

## Coach operating guide

### Choose the right pace

Two practices each week make a fifteen-week sequence. Use the simpler route for first-year athletes and adjust the total load around school sport, other clubs and events. Repetition is part of learning.

### Prepare the space

Have a clean wrestling mat, clear margins, timer, personal water bottles and the listed equipment ready. Flat markers must not slide. Confirm staffing, emergency contacts, medical restrictions and the venue emergency plan before arrivals.

### Read the clock

The left column shows elapsed time from the start of practice. Demonstration, turns, rest and feedback belong inside each block. Short rounds repeat only while both partners remain controlled. Water is available throughout, beyond the planned break.

### Give a clear task

Read the focus and prerequisite first. Demonstrate briefly, give one cue, let athletes try and offer one correction. Tell partners exactly which actions are allowed. Rehearse stopping and releasing before increasing resistance.

### Match and supervise

Pair by size, maturity, skill, confidence and control. Coaches assign and observe partners. Stop for pain, distress, unsafe pressure, loss of control or crowding. Reduce simultaneous activity if every pair cannot be supervised.

### Adjust without excluding

The easier and harder options change the task, not the child's place on the team. Offer observation, individual movement or cooperative rehearsal. Children may ask to stop at any time. Breaks remain supervised.

### Progress the wrestling

Teach receiving, legal position and release before each new finish or turn. Progress from cooperative repetitions to the stated positional resistance after both partners show control. Entry-only drills stop at entry. Use only taught finishes and turns; no lifts, throws or mat returns. Stop at the task objective or signal.

## Practice 01 Start Safe, Move Together

**Goal:** Establish immediate stopping, personal space, stable stance, and dependable partner behavior.

**Set up:** Wrestling mat, cones marking separate lanes, timer, individual bottles; one coach oversees each active partner area.

**Before you begin:** Athletes can follow a stop cue and move without pain; use solo tasks until ready.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Use cone lanes for walking, side steps, and easy direction changes. On the coach's signal, freeze with bent knees and balanced feet. Partners observe from outside the lane, naming one stable position before switching after four short trips. |

| 15-27 | Learn | Demonstrate a comfortable wrestling stance with bent knees, balanced feet, and eyes forward. Show small steps without crossing feet. Partners alternate twenty-second leader and mirror roles, stopping immediately on either athlete's call; begin without any contact between partners. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse stance, three small steps, and a controlled stop inside their marked area. The observer checks balance and space, then becomes mover. Complete four attempts each, rest briefly, and repeat with a different direction called before starting. |

| 45-60 | Apply | Play Mirror and Freeze: one athlete moves slowly while the other matches distance without touching. Either athlete may call stop; both freeze. Switch leadership every thirty seconds, discuss one adjustment, and repeat with coach-approved pairs in separate marked spaces. |

| 60-70 | Team finish | Setup: 2 minutes; 8 rounds of 30-second mirroring and 30-second rest. Use simultaneous pairs in marked squares; alternate leaders. Coaches call unpredictable stops. During rests, recognize balanced movement, clear spacing, and immediate responses. All pairs work together. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use walking and individual freeze games before partner mirroring.

**Add challenge:** Returners demonstrate a mastered grounded skill, then use matched twenty-second positional rounds after coach approval.

**Stop or change:** Stop for collisions, crossed lanes, discomfort, or delayed response to the signal.

**Look for:** Both athletes stop immediately and maintain balance during three direction changes.

**Ask:** What makes a partner feel safe enough to learn?

## Practice 02 Move Without Crossing Feet

**Goal:** Maintain stance and personal space while moving forward, backward, sideways, and around a partner.

**Set up:** Mat, cones forming small squares, timer, individual bottles; matched pairs occupy separate squares.

**Before you begin:** Athletes stop promptly and can hold a comfortable stance during slow movement.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with easy skipping, side steps, and forward walking around cones. Finish each trip in a balanced stance. Partners take turns pointing toward the next cone; move at walking speed first and keep neighboring squares clearly separated throughout. |

| 15-27 | Learn | Demonstrate moving the nearest foot first, then bringing the other foot back to comfortable spacing. Show forward, backward, and sideways steps. Athletes rehearse each direction alone, then mirror a partner for four brief rounds with a reset between directions. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Place four cones around each pair. The leader points to a cone and takes two controlled steps; the follower maintains spacing. Alternate leadership after four cues. Pause to check crossed feet, upright balance, and whether either athlete needs more room. |

| 45-60 | Apply | Play Keep the Window: partners maintain a comfortable gap while one travels around the square. No touching, racing, or sudden lunges. Change leader every thirty seconds, rest while naming the hardest direction, then repeat at a pace both control. |

| 60-70 | Team finish | Setup: 2 minutes; 8 rounds of 30-second activity and 30-second rest. Use simultaneous pairs in separate squares. Mover chooses one of two flat gates; noncontact defender shadows. Alternate roles; discuss balanced direction changes and clear spacing during rests. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Shorten steps and use only forward and sideways directions.

**Add challenge:** Returners add controlled hand clearing to the angle game after coaches verify safe contact and release.

**Stop or change:** Stop when athletes collide, race backward, or leave their assigned square.

**Look for:** An athlete completes a four-direction route without crossing feet or losing the shared gap.

**Ask:** Which direction needed the smallest steps today?

## Practice 03 Balance Before Contact

**Goal:** Build stable bases and learn to accept light partner contact without pushing contests.

**Set up:** Mat, cones, timer, individual bottles; separate standing lanes and kneeling practice spaces.

**Before you begin:** Athletes control footwork and willingly accept light open-hand contact; otherwise remain with mirroring.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Move through controlled squats, short forward steps, and gentle single-leg balances near a clear wall-free space. Partners observe rather than hold each other. Repeat each pattern slowly, then finish with stance movement and a prompt freeze on the signal. |

| 15-27 | Learn | Demonstrate light palm contact to a partner's upper arms while both stand balanced. The receiver stays upright and comfortable; the mover tests only gentle contact, without shoving. Practice touching, releasing, and resetting, with explicit permission before each new attempt. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs alternate three light upper-arm touches followed by complete release. Receivers name whether contact felt predictable. After switching roles, add one small sideways step together. Coaches reduce pressure immediately if either athlete stiffens, leans heavily, or stops communicating clearly. |

| 45-60 | Apply | Play Touch and Recover: the mover lightly touches an upper arm, releases, and changes position one step. The receiver adjusts stance without pushing back. Rotate roles after four attempts, rest, then repeat with the direction announced only just before moving. |

| 60-70 | Team finish | Run simultaneous touch-and-angle games: one light open-hand upper-arm touch, complete release, then one angle step. Alternate roles every twenty seconds and rest between rounds. Partners stay balanced; coaches stop shoving, head contact, or chasing immediately. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Replace contact with a hand held nearby as a visual direction cue.

**Add challenge:** Returners use light legal wrist control and footwork while partners defend within agreed limits.

**Stop or change:** Stop if contact becomes a shove, either athlete leans onto a partner, or balance becomes uncontrolled.

**Look for:** Partners keep independent balance and release immediately on every request.

**Ask:** How could you tell that the contact was manageable?

## Practice 04 Receive With Control And Reset

**Goal:** Learn controlled low receiving, immediate release, and independent recovery before completed takedown practice.

**Set up:** Mat, flat markers, timer, bottles; qualified coaches supervise separated low-receiving stations.

**Before you begin:** Athletes comfortably sit, kneel, and control head position; qualified coaches verify each receiving progression.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Begin with easy walking, stance steps, and individual transitions from standing to kneeling and seated positions. Use hands for comfortable support, without dropping. Partners watch from clear space, then switch after three transitions and share one sign of good control. |

| 15-27 | Learn | Demonstrate lowering from side-sitting onto the side with bent supporting arm and head clear, then returning to base. Progress individually to a kneeling side descent under qualified supervision. Receivers move themselves first; no standing fall, push, or surprise contact. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs alternate three low side descents and controlled recoveries while coaches check bent-arm support, head clearance, and comfort. Partner observes before adding agreed gentle guidance. Each receiver announces readiness and may remain at the seated version throughout. |

| 45-60 | Apply | Use individually coached receiving stations: seated lowering, kneeling side descent, and recovery to base. Repeat three controlled attempts, rest, then advance only with coach approval. Coaches record readiness for the particular finish, not a blanket clearance for every takedown. |

| 60-70 | Team finish | Pairs rehearse low receiving and independent recovery while qualified coaches observe each active station. Partners alternate three controlled repetitions, then rest upright. Waiting athletes practice solo stance steps nearby; nobody pushes a receiver or attempts a surprise fall. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Practice side-sitting and hand-supported lowering without any partner contact.

**Add challenge:** Returners rehearse receiving for a previously mastered low finish with direct qualified coaching and no lifts.

**Stop or change:** Stop for head contact, stiff-arm posting, sudden dropping, joint pain, or any unannounced push.

**Look for:** Receiver controls a low side descent and returns to base without head impact or a rigid arm.

**Ask:** How did you receive the movement without using your head or a stiff arm?

## Practice 05 Change Level With Control

**Goal:** Coordinate stance, level changes, and entry footwork without colliding with a partner.

**Set up:** Mat, floor dots or cones, timer, individual bottles; individual entry lanes and adjacent observer spots.

**Before you begin:** Athletes tolerate kneeling comfortably and can lower themselves without dropping.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance walking, shallow squats, and controlled steps toward floor dots. Add slow kneeling and standing only where comfortable. Partners count smooth transitions rather than speed, switch roles after four repetitions, and leave recovery time between sets. |

| 15-27 | Learn | Demonstrate bending at the knees and hips while keeping eyes forward and balance underneath the body. Step toward a floor marker, optionally lower one knee softly, then recover. Athletes try the standing version first before choosing the kneeling version. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | One athlete performs four slow level-change entries toward a floor dot while the partner checks spacing and controlled knee placement. Switch roles, rest, then repeat from the opposite lead. Keep the target empty; nobody enters toward another athlete's body yet. |

| 45-60 | Apply | Play Choose Your Level: a partner shows a high or low hand target outside the movement lane. The mover adjusts height, steps toward a floor dot, and returns to stance. Change roles every four cues; targets never require reaching or diving. |

| 60-70 | Team finish | Run simultaneous floor-target games in separate lanes. A partner indicates one of two dots; the mover changes level, steps, and recovers. Alternate thirty-second turns with short rests. Returning athletes add a coach-verified entry shape without increasing collision risk. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use standing level changes and shorten the forward step.

**Add challenge:** Returners link level change, entry, and recovery against one coach-approved defensive response.

**Stop or change:** Stop for knee impact, diving, painful bending, or entry lanes overlapping.

**Look for:** An athlete changes level, steps, and returns to balanced stance without falling forward.

**Ask:** How did you lower your body without losing balance?

## Practice 06 Recognize Safe Starting Positions

**Goal:** Distinguish neutral, top, and bottom starts while preserving stopping and cooperative receiving habits.

**Set up:** Mat, cones, three position cards, timer, bottles; pairs use spaced stations with a supervising coach.

**Before you begin:** Review B14-B15 and the event rules. Distinguish a comfortable training base from the exact marked referee start.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Use a movement circuit of stance steps, comfortable crawling, kneeling, and independent standing. Perform each for short controlled intervals with walking between stations. Partners observe space and smooth transitions; any uncomfortable position has a standing movement alternative available throughout practice. |

| 15-27 | Learn - Starting Positions | Show neutral stance, then B14 bottom: knees behind the rear line, heels of both hands beyond the front line, elbows off the mat. Show B15 top on the left: left knee outside, right foot behind, legs clear; light left palm at elbow and right palm at belly button. Bottom sets first; top follows the referee cue. Both wait for the whistle. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs draw a position card, independently arrange themselves, and ask a coach to check alignment and legal contact. Hold only briefly, release, and stand separately. Switch top and bottom roles each turn; use four repetitions before resting and changing cards. |

| 45-60 | Apply | Play Position Detective: the coach names a position and one safety requirement. Partners arrange only that start, freeze for observation, then release on cue. Rotate the explaining role so every athlete describes where hands belong and how to request a stop. |

| 60-70 | Team finish | Run simultaneous position challenges in spaced pairs. Coach names neutral, top, or bottom; partners set the checked start, hold briefly, then release. Switch roles each round and rest between sets. Coaches check actual hand placement rather than judging speed. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Identify positions verbally and demonstrate them solo.

**Add challenge:** Returners add twenty-second top-bottom rounds using already-mastered legal control and an announced escape.

**Stop or change:** Stop for weight placed on the neck, trapped fingers, uncertain contact, or discomfort in kneeling.

**Look for:** An athlete recognizes three positions and resets each without pulling a partner.

**Ask:** Which starting position still needs more explanation?

## Practice 07 Clear Hands And Find Space

**Goal:** Use gentle hand clearing and footwork to create an entry opportunity without yanking.

**Set up:** Mat, cones, floor dots, timer, bottles; matched pairs have separate standing and entry areas.

**Before you begin:** Athletes maintain stance, accept light upper-arm contact, and release promptly.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance circles, short retreat steps, and individual level changes toward floor dots. Add gentle hand opening and closing with relaxed arms. Partners mirror movement without contact, switching leadership frequently and checking that their entry lanes remain clear. |

| 15-27 | Learn | Demonstrate light contact at an upper arm, then clearing the contact with an open hand while stepping away. Avoid fingers, forceful wrist twists, and neck contact. The receiver supplies only gentle contact; both finish balanced before repeating from the other side. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Partners alternate offering a light upper-arm touch and clearing it while taking one small angle step. Perform four repetitions each side, then rest. After switching roles, add a level change toward an empty floor dot once the contact has fully released. |

| 45-60 | Apply | Play Clear the Gate: the receiver offers one predictable arm contact. The mover clears gently, steps to space, and freezes in stance. Switch after three successful resets; experienced pairs may vary the offered side, but nobody grabs, resists, or drives forward. |

| 60-70 | Team finish | Teams connect three actions into a demonstration: clear contact, move to space, and recover stance. Observers identify the opening rather than choosing a winner. Rotate performers after each sequence and let every athlete explain one adjustment that made the contact gentler. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use a partner's nearby hand as a visual gate without actual contact.

**Add challenge:** Vary the offered side and choose the corresponding angle step.

**Stop or change:** Stop for grabbing fingers, twisting wrists, pulling hard, or pushing a partner off balance.

**Look for:** An athlete clears contact and creates space while both partners remain balanced.

**Ask:** What created the opening: your hands, your feet, or both?

## Practice 08 Make An Angle First

**Goal:** Create an angle with balanced footwork before committing to an entry.

**Set up:** Mat, cones forming partner squares, floor dots, timer, bottles; separate lanes for entry rehearsal.

**Before you begin:** Athletes can circle without crossing feet and complete a controlled solo level change.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Move around cones with short stance steps, changing direction only after a balanced stop. Add a level change at each second cone. Partners mirror outside touching distance, switch leadership after thirty seconds, and walk briefly between rounds to reset attention. |

| 15-27 | Learn | Demonstrate moving one step toward the outside of a stationary partner's shoulder line, then checking balance before a level change. Keep hands relaxed and avoid body contact. Partners take turns receiving the movement, with no reaching, pulling, or entry finish. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs use three floor dots beside a receiver to compare straight and angled approaches. The mover chooses a dot, circles into position, and freezes before entering. Complete three approaches each side, switch roles, and discuss which start provided clearer space safely. |

| 45-60 | Apply | Play Open Door: the receiver turns slightly to offer a visible side, then remains still. The mover circles toward that opening and performs an entry step into empty space. Switch after four attempts; novices omit kneeling and keep the entire task standing. |

| 60-70 | Team finish | Teams build a short angle course using cones and one stationary volunteer receiver. Each athlete approaches, identifies open space aloud, and moves to it without contact. Rotate receivers regularly; teammates recognize balanced foot placement rather than awarding points for speed. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use only a cone as the receiver and walk through the angle.

**Add challenge:** Let the receiver choose between two small turns before becoming stationary.

**Stop or change:** Stop for crossing feet, chasing a moving receiver, reaching across the body, or crowded lanes.

**Look for:** An athlete creates a useful angle and pauses balanced before an entry.

**Ask:** What told you that an angle was available?

## Practice 09 Single Leg Entry, No Finish

**Goal:** Introduce a controlled single-leg entry and an orderly return to stance.

**Set up:** Mat, floor dots, cones, timer, bottles; one spaced pair per entry lane.

**Before you begin:** Athletes lower one knee softly, recover stance, and accept cooperative leg contact.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance steps, level changes, and slow knee-down entries toward an empty floor dot. Recover independently after each attempt. Partners observe knee placement and space; switch after four repetitions, rest briefly, and repeat using the other comfortable lead. |

| 15-27 | Learn | Demonstrate approaching one leg with a level change and controlled step, keeping the head upright beside the partner's body. Touch the outer calf without pulling or lifting. The receiver stands still with both feet grounded; release before recovering to stance. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse the entry three times each side, pausing before contact so the receiver can confirm readiness. The mover touches lightly, releases, and recovers independently. Switch roles, rest, and repeat; first-year athletes use a floor dot instead of a leg. |

| 45-60 | Apply | Play Find the Near Leg: the receiver chooses a comfortable staggered stance and remains stationary. The mover identifies the nearer leg, makes the taught entry, and releases. Switch every three attempts; the challenge is appropriate choice and control, never completing a takedown. |

| 60-70 | Team finish | Teams demonstrate a single-leg entry checkpoint sequence: balanced start, level change, soft entry, light contact, full release, recovery. Observers name one checkpoint each while a pair works slowly. Rotate roles frequently and allow a solo floor-dot demonstration for any athlete. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use an empty floor dot and finish before any partner contact.

**Add challenge:** Have the receiver change the lead leg before becoming completely still.

**Stop or change:** Stop if a foot leaves the mat, the leg twists, the head lowers, or the receiver loses balance.

**Look for:** An athlete enters toward the near leg and releases with the receiver's feet still grounded.

**Ask:** Which checkpoint kept your receiver most comfortable?

## Practice 10 Double Leg Takedown

**Goal:** Complete a low double-leg corner finish with controlled receiving and no lifting.

**Set up:** Mat, cones, two floor dots per lane, timer, bottles; matched pairs work in clear lanes.

**Before you begin:** Review B07 and confirm side-hip receiving. The low finish uses no standing lift.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance steps, soft entries to floor markers, and coach-approved low receiving. Alternate three entries and three receiving repetitions with rest. Use individual stations so everyone moves while coaches verify head position, knee alignment, and controlled descent. |

| 15-27 | Learn - B07 | Demonstrate a right-foot entry, head on your left at their right ribs, hands behind both knees. Step your left trail foot outside their right foot. Drive diagonally right across their stance while gathering knees left. Receiver lowers onto their left hip and side; follow above the hips without dropping weight. Rehearse low before a standing entry. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three cooperative finishes from a low entry position, then switch and rest. Receiver follows the taught descent without rigid-arm posting. Attacker keeps knees aligned and guides rather than dumps. Standing starts require qualified coach approval for both athletes. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Attacker uses double and corner finish; defender retreats or angles. Stop at control, closed entry, or unsafe alignment. Novices remain cooperative and low. |

| 60-70 | Team finish | Use simultaneous pairs for a finish-and-control challenge. Alternate one attack each, release completely, and reset with rest. Credit a balanced entry, controlled corner descent, and legal top control; no lifts, speed contests, or continued wrestling after the finish signal. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Stop at entry and rehearse receiving separately until the coach approves a completed finish.

**Add challenge:** Receiver offers one controlled retreat or angle response; attacker finishes only while position and receiving stay safe.

**Stop or change:** Stop for head-down impact, lifting, slamming, trapped knees, twisting, stiff-arm posting, or loss of receiving control.

**Look for:** Attacker turns the corner, guides a controlled descent, and establishes top control without lifting.

**Ask:** How did changing your angle help you finish without lifting?

## Practice 11 Sprawl And Go Behind

**Goal:** Defend a leg attack with a controlled sprawl and circle into legal top control.

**Set up:** Mat, cones, floor dots, timer, bottles; broad lanes with separate mover and defender starts.

**Before you begin:** Review B11 Sprawl and Go-Behind. Partners can receive low entries and stop; demonstrate leg clearance, arm block and rear control.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance retreats, hand support, and slow solo sprawls: legs back, hips low briefly, knees off; then bring feet underneath and recover to stance. Keep the head clear. Alternate short sets with walking rests; offer upright steps if floor support is uncomfortable. |

| 15-27 | Learn - B11 | Demonstrate B11: legs back and hips low, chest over the shoulders; scoot back until both legs clear. To circle right, use the right hand to block their left triceps, keep chest contact, and reach the left hand to their left thigh. Continue behind before settling knees and separate waist-and-arm control. Show from both sides. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Alternate three slow entries and B11 responses, then rest. Shooter releases the legs and builds a base. Defender pauses with legs free before the arm block and circle; knees come underneath after reaching the rear. Coach checks chest contact, head clearance and separate waist-and-arm control. Reset if alignment is lost. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Attacker uses one double entry; defender sprawls and circles behind. Attacker may rebuild base. Stop at control or unsafe alignment; never cling to a twisting leg. |

| 60-70 | Team finish | In simultaneous pairs, alternate attack-defense challenges with a full reset after each outcome. One partner seeks a controlled double finish; the other seeks a sprawl and go-behind. Coaches approve readiness, maintain receiving standards, and use cooperative versions for newer wrestlers. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Practice a solo sprawl and circle around a marker before adding a cooperative attacker.

**Add challenge:** Attacker chooses entry timing; defender sprawls and circles against a permitted attempt to rebuild base.

**Stop or change:** Stop for dropping onto the neck, head pulling, knee collisions, uncontrolled dives, or trapped limbs.

**Look for:** Defender moves hips and legs away, clears the attack, and circles into checked top control.

**Ask:** What did your hips and feet do before you moved behind?

## Practice 12 Peek-Out Recovery

**Goal:** Clear the head from a light front cover and recover a useful attacking position.

**Set up:** Mat, cones, floor dots, timer, bottles; generous space behind each entry lane.

**Before you begin:** Review B13 and the mirrored B07 finish. Confirm the supporting post, rightward head exit and controlled side landing before linking them.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance steps and soft entries, then solo left-hand posts and right-foot steps from base. Draw the right elbow back beside the hip without swinging it at anyone; slide the left knee underneath and reset. Keep the head clear and alternate brief rehearsals with standing rests. |

| 15-27 | Learn - B13 | Demonstrate a light, unlocked front cover over the shoulder blades. Bottom posts the left hand, steps the right foot outside the right elbow, draws that elbow back, and slides the left knee underneath as the head exits right. Lift chest only after clearance. Show B07 mirrored: head right, drive left, knees right; receiver lands on the right hip. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Use B13 for three cooperative repetitions each from the stationary front cover, then rest. Pause after the head clears to check hand support and hips underneath. Add the mirrored B07 finish only when both athletes show the entry and landing. The covering partner stays mobile, uses separate hands, and never locks a front headlock. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles. Partner adds one announced light sprawl and follows the B13 recovery. Shooter clears the head and finishes only if alignment remains sound. Reset if clearance closes; do not force upward through the neck or add a new counter. |

| 60-70 | Team finish | In pairs, complete one controlled recovery at a time, then rest and swap. Coach signals either clearance-only or clearance plus the approved mirrored finish. Partners identify the supporting hand and direction before starting. Count accurate resets together; no fastest-pair contest, locked front headlocks or surprise reactions. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use a stationary, light front cover; rehearse only the post, step and head clearance before resetting.

**Add challenge:** Partner adds one announced light sprawl, then follows the peek-out into the mirrored double finish.

**Stop or change:** Stop for trapped legs, neck pressure, head-down driving, twisting, or a finish attempted without receiving readiness.

**Look for:** Athlete shortens the base, clears the head sideways before rising, and uses the correct finish direction.

**Ask:** What had to clear before you lifted your chest?

## Practice 13 Build A Reliable Bottom Base

**Goal:** Establish a comfortable hands-and-knees base and reset it after small self-directed movements.

**Set up:** Mat, cones, timer, bottles; separate kneeling spaces with observers outside arm reach.

**Before you begin:** Athletes tolerate hands-and-knees positions comfortably and can stop without collapsing.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with walking, comfortable crawling, and independent kneeling-to-standing transitions. Use short distances and frequent posture resets. Partners observe free space and comfort, switching after each trip; standing balance work remains available whenever wrists or knees dislike the floor position. |

| 15-27 | Learn | Demonstrate a bottom base with hands beneath shoulders and knees beneath hips, adjusting spacing for the athlete. Show a small hand or knee movement followed by a stable reset. Partners observe first; no one applies pressure or supports weight on another athlete. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | One athlete holds a comfortable base while the partner names a hand or knee to move slightly, then replace. Complete four controlled cues before switching. Rest upright between sets; the task is independent stability rather than resisting a partner's weight. |

| 45-60 | Apply | Play Keep Your Table: the bottom athlete chooses three small movements while maintaining a stable base. The observer identifies whether each movement ended balanced, without touching. Switch after each sequence; experienced athletes vary the order, while beginners repeat one comfortable movement. |

| 60-70 | Team finish | Use simultaneous base challenges. Newer athletes follow a partner's movement cues without contact; coach-approved returners rebuild base against a legal waist-and-wrist ride. Alternate twenty-second turns with rest. Partners identify one useful support adjustment; coaches prevent neck pressure and trapped arms. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use a shorter hands-and-knees hold or substitute standing balance steps.

**Add challenge:** Returners rebuild base against a coach-verified legal waist-and-wrist ride without joint force, neck pressure, or lifting.

**Stop or change:** Stop for wrist or knee pain, collapsing support, or any partner pressure on the back or neck.

**Look for:** An athlete moves one support point and returns to a comfortable stable base.

**Ask:** What helped your base feel steady without tensing everything?

## Practice 14 Inside-Leg Stand-Up

**Goal:** Use hand control and an inside-leg rise, then clear the hips and face when ready.

**Set up:** Mat, cones, timer, bottles; pairs have clear space above and behind their kneeling start.

**Before you begin:** Review B17. With rider on the left, use left foot and right hand; teach the right turn only after balanced standing and hip clearance.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with walking, shallow squats, and controlled kneeling-to-standing transitions. Begin with one foot planted and rise without using a partner for support. Alternate comfortable lead legs, take short rests, and let observers notice which version preserves balance best. |

| 15-27 | Learn - B17 | Start with rider left. Plant the left foot beside the right knee and lift the chest; right hand captures their right hand near the wrist. Rise on bent knees, holding the hand away while hips move forward. Stop here first. Once balanced, retain hand control and turn right to face. Top follows without pulling backward or returning to the mat. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs complete three stand-ups with a cooperative follower, then switch and rest. Bottom keeps elbows close, controls the wrist, and rises under their own balance. Progress to gentle positional opposition only after the coach verifies both athletes can stop safely while standing. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Bottom seeks hand control and balanced standing; top follows using legal waist/wrist control. Stop on standing, escape, or imbalance. No lifts, returns, finger grips, or compression. |

| 60-70 | Team finish | Use simultaneous stand-up challenges in matched pairs. Alternate one attempt each, reset fully, and rest. Partners identify whether hand control, foot placement, or hip position helped. Newer athletes retain the release-first version; returners work against a coach-approved follower. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Rise alone or have top release before movement; add following only after both show control.

**Add challenge:** Top maintains controlled legal contact while bottom clears the wrist and chooses either lead foot.

**Stop or change:** Stop for trapped arms, wrist twisting, backward pulling, loss of balance, or any lift or mat-return attempt.

**Look for:** Bottom controls the hands, plants a foot, and reaches balanced standing against an appropriate follower.

**Ask:** How did hand control help you rise with balance?

## Practice 15 Sit-Out and Hip-Heist Escape

**Goal:** Create space with a sit-out, clear waist contact, then heist to face and separate.

**Set up:** Mat, floor dots, cones, timer, bottles; generous space beside each bottom starting position.

**Before you begin:** Review B18-B19. Confirm the solo heist and whole-hand clearing first; a seated position alone is not an escape.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Rehearse P09 sit-outs solo, then B19 heist footwork from a short sit. For a left heist, support on the left palm and right foot; lift hips just enough for the left leg to sweep under and right leg to step over. Turn chest toward the mat, knees under, then reset. Use short sets with rest; keep the head off the mat. |

| 15-27 | Learn - B18 to B19 | Show B18 with rider left: left cross-post, right foot out, left leg through, low seat and right-hand wrist control. Then B19: clear the whole waist hand, release, post left palm and plant right foot. Sweep left leg under and step right leg over while turning left. Face, separate from contact, then rise. Demonstrate each stage slowly before linking. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Take three B18 sit-outs each and reset. Then begin seated for three B19 clear-and-heist escapes each. Rider follows on knees, hands separate, allowing clear hand and hip space. Link the two only after both stages are controlled. Coach checks the leg path, free head, and actual separation before the athlete stands. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles. Top follows on knees with light waist contact; bottom creates a short sit, clears hands and heists to face. If control remains, bottom rebuilds base and both reset. No chops, pullbacks, rolls or new counters. |

| 60-70 | Team finish | Partners take one cooperative attempt, name the checkpoint they achieved, then rest and swap: short sit, hands clear, or facing and free. Coach varies whether the task stops seated or continues through B19. Reaching the correct checkpoint is success; no points for forcing a blocked turn or rolling over the head. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Rehearse B18 to a balanced short sit and reset. Practice B19 separately from a loose seated start.

**Add challenge:** Top follows on knees with light waist contact; bottom clears and heists, or rebuilds base if contact remains.

**Stop or change:** Stop for trapped arms, shoulder torque, backward falls, neck pressure, or a partner forcing the turn.

**Look for:** Athlete clears the waist hand before the heist, turns without head support, and separates before rising.

**Ask:** What must happen before your sit-out becomes an escape?

## Practice 16 Tight Waist Chop

**Goal:** Break a stable base using coordinated waist control and near-arm guidance, then establish a safe ride.

**Set up:** Mat, position cards, cones, timer, bottles; coaches can directly observe each top-bottom pair.

**Before you begin:** Review B22. Confirm bent-elbow receiving, coordinated forward drive and the cross-wrist endpoint before adding resistance.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with comfortable crawling, kneeling side steps, and controlled standing transitions in separate lanes. Finish with a stable bottom base or a standing alternative. Partners observe balance and spacing, switching roles regularly and resting upright between short sets of movement. |

| 15-27 | Learn - B22 | From the left-side start, snug the right waist arm. Use the left forearm to fold their left elbow toward the belly while toes and rear right knee drive hips forward. Bottom lowers through forearms to belly. Catch their left wrist with the right waist hand and control the upper arm with the left. Follow without strikes, straight-arm collapse or wrist twisting. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three cooperative breakdowns, then switch and rest upright. Bottom lowers onto comfortable forearm and chest support with head clear; top follows beside the hips without collapsing onto the neck. Coaches check wrist and elbow alignment before adding opposition. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Top attempts tight-waist/chop breakdown; bottom maintains or rebuilds base without stiff-arm posting. Stop at controlled breakdown, recovered base, or unsafe arm alignment. |

| 60-70 | Team finish | Use simultaneous base-versus-breakdown challenges with equal turns. Top earns the task outcome through coordinated waist control and arm guidance; bottom earns it by preserving or rebuilding base. Reset and rest after every attempt. Coaches keep contact appropriate to each matched pair. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Rehearse the legal start and a voluntary bottom descent without applying the breakdown.

**Add challenge:** Bottom tries to retain base while top coordinates one legal chop and waist action.

**Stop or change:** Stop for striking the elbow, twisting a joint, locked hands, body squeezing, neck loading, or uncontrolled collapse.

**Look for:** Top coordinates waist and near-arm action, guides a controlled breakdown, and follows the hips.

**Ask:** How did moving the waist and arm together change the base?

## Practice 17 Follow The Base, Then Release

**Goal:** Connect a controlled breakdown with hip tracking while bottom rebuilds base or begins an escape.

**Set up:** Mat, cones, timer, bottles; each matched pair has a roomy kneeling practice zone.

**Before you begin:** Partners demonstrate safe tight-waist/chop mechanics, base recovery, and controlled stopping before any mat return. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with kneeling side steps, comfortable crawling, and small standing circles. Partners copy one another without touching, alternating leadership after short sequences. Rehearse a shared freeze frequently, and give athletes upright rest whenever knees or wrists need a break. |

| 15-27 | Learn | Demonstrate a controlled tight-waist/chop breakdown, then follow the hips as bottom rebuilds base. Keep knees off the partner and adjust legal waist-and-wrist contact without twisting. Bottom may initiate a taught escape; stop at facing or balanced standing before any return. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs alternate three breakdown-to-base-recovery sequences, then switch and rest. Bottom rebuilds deliberately while top tracks the hips, avoiding a repeated chop when the arm is trapped. Coaches add controlled opposition only after both athletes maintain safe alignment through the whole sequence. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Top seeks breakdown and ride; bottom seeks base, sit-out, or stand-up. Stop at facing, balanced standing, or unsafe alignment. No lifts, returns, or squeezing. |

| 60-70 | Team finish | Run matched pairs simultaneously. Each pair demonstrates one useful choice during an active top-bottom round, then pauses to explain it briefly. Swap roles, rest, and retry with the same permitted actions. Coaches reward decisions and technical control rather than exhaustion. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Bottom voluntarily lowers and rebuilds base while top follows cooperatively without applying the chop.

**Add challenge:** Bottom chooses base recovery or a taught escape; top selects breakdown or tracking within the same safe limits.

**Stop or change:** Stop for neck loading, knee pressure on a partner, joint twisting, body compression, or any lift or return.

**Look for:** Top maintains legal position through footwork while bottom actively rebuilds base or seeks an escape.

**Ask:** When was following the hips more useful than repeating the breakdown?

## Practice 18 Half Nelson and Early Defense

**Goal:** Introduce a controlled half-nelson turn, safe shoulder control, and an early clearing defense.

**Set up:** Mat, spaced top-bottom stations, timer, bottles; qualified coaches closely supervise turning and receiving.

**Before you begin:** Review B26-B27. Confirm the cooperative turn and teach defense separately against a loose insertion while the neck is free.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with comfortable shoulder movement, base recovery, and voluntary side-to-back turns without using the head for support. Alternate short sets with upright rests. Coaches observe each athlete's comfortable range and readiness; turning is never forced to match a partner. |

| 15-27 | Learn - B26 | From the left side, thread the left arm under their left armpit, palm on the back of the head. Right hand blocks the far elbow beneath the chest. Lift the half elbow and walk feet left toward the head to a T. Drive through the chest to turn shoulders and torso together onto their right side, then settle chest to chest. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse B26 and B27 Separately | Take three cooperative B26 turns each. Then practice B27 against a loose left half: left elbow closes, that shoulder and hip stay low, and the head looks right while free. Left hand clears the whole hand from the head; recover base after the threading arm clears. Release any tight hold rather than forcing the neck to turn. |

| 45-60 | Apply - Turn or Clear | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles. Coach calls a cooperative B26 turn or a loose B27 insertion with early defense. The Clear task stops before turning pressure; the Turn task uses a willing receiver. Reset at the outcome or any blocked shoulder, pain or neck restriction. |

| 60-70 | Team finish | Use simultaneous supervised turn-defense challenges with matched partners. Alternate short attempts and full releases, naming one technical cue before restarting. The coach confirms controlled shoulder contact using the actual rule standard; no forced hold through pain, neck strain, or restricted breathing. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Rehearse the arm pathway without turning; receiver voluntarily moves onto the side before any partner pressure.

**Add challenge:** Bottom keeps the elbow close and clears the wrist while top seeks a controlled legal turn.

**Stop or change:** Stop for neck cranking, throat or face pressure, shoulder pain, trapped arms, restricted breathing, or uncontrolled turning.

**Look for:** Top guides a controlled half-nelson turn; bottom demonstrates an early elbow-close and wrist-clearing defense.

**Ask:** What made the turn controlled, and what helped the early defense?

## Practice 19 Clear, Angle, And Enter

**Goal:** Connect hand clearing and an angle step to a controlled double-leg finish against a permitted defense.

**Set up:** Mat, cones, floor dots, timer, bottles; matched pairs have separate approach lanes.

**Before you begin:** Both athletes show the double finish and its receiving safely; defender knows the taught retreat or sprawl. Use B07 for the double-leg finish.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up in parallel pairs with stance movement, open-hand clearing, level changes, and separate low-receiving repetitions. Alternate three controlled sequences and short rests. Coaches check receiver readiness and preserve an entry-only option for anyone not ready to complete the finish. |

| 15-27 | Learn | Demonstrate clearing a upper-arm touch, stepping to an angle, and entering the double with head upright. Turn the corner into the taught controlled descent and top control. Defender first cooperates, then offers one approved retreat or sprawl; never force a closed position. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs complete three cooperative clear-angle-finish sequences each, rest, then add one announced defensive response. Attacker chooses a safe finish or recovery; defender may circle behind only after clearing the attack. Coaches stop leg twisting and maintain matched receiving ability throughout. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Attacker uses clear-angle-double; defender retreats or sprawls and circles behind. Stop at established control, safe separation, or unsafe alignment. Simplify the next round when needed. |

| 60-70 | Team finish | All pairs run attack-defense challenges in parallel, resetting after each outcome and taking a brief rest. Partners identify the opening or defensive action that mattered, then swap. Newer athletes use cooperative finishes; ready athletes apply the same skills against genuine permitted opposition. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Complete the clear and angle, then rehearse a cooperative low finish or stop at entry.

**Add challenge:** Defender chooses retreat or controlled sprawl; attacker decides whether to finish, recover, or release.

**Stop or change:** Stop for neck pressure, trapped legs, lifting, uncontrolled descent, or forcing a finish after alignment is lost.

**Look for:** Athlete creates space and completes a controlled finish or appropriate recovery against an actual defensive response.

**Ask:** Which action created the usable opening rather than merely touching the target?

## Practice 20 Choose Attack Or Counter

**Goal:** Read a leg attack and choose a controlled double finish, sprawl-go-behind counter, or safe recovery.

**Set up:** Mat, cones, paired floor dots, timer, bottles; clear entry lanes with waiting observers beside them.

**Before you begin:** Pairs demonstrate controlled double receiving and sprawl-go-behind mechanics before opposed rounds. Use B07 for the double-leg finish.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance movement, solo level changes, controlled sprawls, and low-receiving repetitions. Work in separate lanes with short rests after each set. Partners alternate demonstrations and give one observation about head position, balanced recovery, or the space needed to receive. |

| 15-27 | Learn | Demonstrate two connected outcomes: an attacker turns the corner for a controlled double finish; a defender clears the legs with a controlled sprawl and circles behind. Both end in checked top control. Rehearse each slowly before allowing a choice of response. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse an announced double finish, then an announced sprawl-go-behind counter. Complete two of each, swap roles, and rest. Attacker releases a closed entry rather than clinging to a twisting leg; defender never drives weight through the head or neck. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. One initiates double; opponent retreats or sprawls and counters. Stop at control or stalled unsafe shape. Returners may switch the initiating role after each full reset. |

| 60-70 | Team finish | Use simultaneous decision games in matched pairs. Each pair alternates one attack and one counter opportunity, pausing to explain the choice. Count controlled technical outcomes, not rushed attempts; coaches supply a cooperative version for athletes still learning either response. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Announce who attacks and which defensive response will occur; rehearse cooperatively.

**Add challenge:** Either wrestler may initiate one taught double; the opponent chooses defense and a safe counter.

**Stop or change:** Stop for blind diving, trapped legs, neck pressure, lifting, or continuing after the coach calls an unsafe position.

**Look for:** Athlete chooses a taught attack or counter based on the opponent's actual movement.

**Ask:** What information helped you choose the attack or the counter?

## Practice 21 Circle To Safe Top Control

**Goal:** Earn legal top control from a grounded go-behind against an opponent trying to regain facing position.

**Set up:** Mat, cones, timer, bottles; matched pairs have generous clear space around a hands-and-knees receiver.

**Before you begin:** Pairs control base, knee movement, legal waist-and-arm contact, and the permitted grounded pivot.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with comfortable crawling, kneeling side steps, and circles around an empty floor marker. Keep hands available for balance and take small steps. Partners observe clear space, switch after each short route, and rest upright between sets of movement. |

| 15-27 | Learn | Start with bottom in a comfortable base and mover kneeling in front at an angle. Circle outside the arms toward the hip, establish legal waist-and-arm control, and follow the hips. Receiver first cooperates, then uses a small pivot to regain facing position. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three go-behinds each direction with an announced receiver pivot. Mover stays clear of the head and arms, using footwork rather than pulling limbs. Pause on established control, release, switch, and rest; novices begin against a stationary base. |

| 45-60 | Apply | Setup/demo: 3 minutes; 12 rounds of 20-second work and 40-second rest. Alternate roles; give feedback during rests. Mover seeks grounded top control; receiver pivots or takes small base steps to regain facing. Stop at either outcome or unsafe crowding. Keep turns controlled. |

| 60-70 | Team finish | All pairs practice the grounded control game simultaneously. Alternate roles after each short attempt and rest between sets. Partners explain one route or pivot that worked; coaches verify actual control rather than awarding success for merely touching the hip. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Receiver holds base while mover circles a wide outside route and establishes cooperative control.

**Add challenge:** Receiver chooses a small pivot or base adjustment while mover seeks and maintains legal control.

**Stop or change:** Stop for head pulling, forceful limb twisting, climbing across arms, knee collisions, or uncontrolled spinning.

**Look for:** Mover reaches and maintains checked top control while receiver actively tries to regain facing position.

**Ask:** How did your route change when the receiver moved?

## Practice 22 Choose An Escape Pathway

**Goal:** Choose a stand-up, sit-out, or base recovery against legal top control and a responsive opponent.

**Set up:** Mat, cones, timer, bottles; spacious matched-pair zones with coaches observing every active round.

**Before you begin:** Review B16-B19. Offer only demonstrated choices: rebuild base, B17 stand-up, or B18 sit-out into B19 hip-heist escape.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with solo bottom-base resets, comfortable sit-outs, and independent stand-ups. Perform one of each, then walk and rest before repeating. Partners identify which pathway looked most controlled, switch observing roles, and keep every supporting hand free during floor movement. |

| 15-27 | Learn - Choose an Escape | From a stable base, demonstrate B17 inside-leg stand-up with hand control and hip clearance. Then show B18 sit-out followed by B19: clear the waist hand before the heist, face and separate before rising. Use B16 first if flattened. Top follows with light, separate-hand contact. Stop at the stated checkpoint or lost alignment. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse one announced stand-up and one sit-out against a follower, then switch and rest. Add positional opposition after the coach checks wrist alignment and balance. Bottom may rebuild base between attempts; top cannot lift or force an arm behind the body. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Bottom seeks taught escape; top maintains legal control or attempts taught breakdown. Stop at facing, balanced standing, or unsafe alignment. Simplify the next round when needed. |

| 60-70 | Team finish | Use simultaneous escape-versus-control rounds in matched pairs. After each attempt, partners name whether hand control, hip position, or base recovery changed the outcome. Rest, swap roles, and retry with one adjustment; no athlete is kept in repeatedly because they win. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Announce the escape and use cooperative following or complete top release before movement.

**Add challenge:** Bottom chooses without announcing; top responds with legal tracking or a taught controlled breakdown.

**Stop or change:** Stop for trapped arms, backward pulling, wrist twisting, imbalance, neck strain, or any lift or mat return.

**Look for:** Bottom creates facing space or balanced standing against appropriate control; top responds through legal position and hand control.

**Ask:** What did the opponent's control tell you about which escape to try?

## Practice 23 Break Down Turn Or Keep Control

**Goal:** Choose a breakdown, maintained ride, or taught half-nelson turn while bottom defends and seeks recovery.

**Set up:** Mat, cones, timer, bottles; pair zones large enough for three controlled base steps.

**Before you begin:** Both athletes demonstrate the breakdown, half-nelson receiving and early defense, and reliable release under coaching. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with base recovery, kneeling hip tracking, solo sit-outs, and voluntary side turns. Use short sets in separate spaces with upright rests. Coaches check comfortable shoulder range and review the immediate stop before any half-nelson receiving or defense. |

| 15-27 | Learn | Demonstrate the choice: use tight-waist/chop against stable base, follow the hips during recovery, or apply the taught half when the near arm is safely available. Bottom keeps the elbow close and clears the half's wrist early; never force a blocked shoulder. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three announced pictures: base retained, base rebuilt, and near arm available. Top selects breakdown, tracking, or a cooperative half turn. Bottom rehearses the matching safe defense. Switch and rest; coaches approve turning readiness separately from ordinary top-control readiness. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Top uses breakdown, ride, or half turn; bottom rebuilds base, clears half early, or escapes. Stop at controlled shoulder contact, facing, standing, or unsafe pressure. |

| 60-70 | Team finish | All matched pairs run short top-bottom challenges simultaneously under qualified supervision. Each athlete gets equal turns attacking and defending. Pause after a meaningful outcome, identify the decision, and rest. Newer pairs omit turns and continue the base-versus-breakdown task. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Work only on cooperative breakdown and base recovery; omit the turn until individually ready.

**Add challenge:** Bottom chooses base recovery, wrist-clearing defense, or a taught escape while top chooses the appropriate response.

**Stop or change:** Stop for neck cranking, trapped arms, joint torque, squeezing, painful turning, lifting, or a mat-return attempt.

**Look for:** Top chooses an appropriate taught action while bottom actively defends without unsafe pressure or scrambling.

**Ask:** When was keeping your position wiser than forcing the turn?

## Practice 24 Connect Positions Without Scrambling

**Goal:** Connect a taught takedown or go-behind to legal top-bottom wrestling with clear safety and outcome stops.

**Set up:** Mat, cones, position cards, timer, bottles; roomy matched-pair zones and a separate observation edge.

**Before you begin:** Each pair is approved for its starting position, receiving, escapes, and any permitted turn. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance movement, empty-marker knee circles, comfortable bottom-base resets, and independent standing. Use short sequences separated by walking rests. Partners name the next movement before it begins, and both confirm there is enough space for every change of position. |

| 15-27 | Learn | Demonstrate a controlled double finish or grounded go-behind, establish legal top control, then continue to one taught breakdown, half turn, or bottom escape. Rehearse with pauses first. Coaches specify the permitted follow-up for each pair and check receiving before combining phases. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three chains with an announced follow-up: takedown-to-ride, go-behind-to-escape, or breakdown-to-turn. Switch roles and rest. Novices keep a full pause between positions; returners shorten the pause only while receiving, hand control, and safe alignment remain dependable. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Start neutral or grounded; novices start grounded. Use named attack, defense, and follow-up. Stop at controlled shoulder contact, escape, standing, or unsafe position. No lifts/returns. |

| 60-70 | Team finish | Use simultaneous two-position challenges. Partners choose a taught connection, complete one opposed attempt, reset, and rest before switching. Coach checks both phases instead of rewarding speed through the transition. If control deteriorates, separate the phases and rebuild the connection cooperatively. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Start grounded, pause after control, and rehearse the next action cooperatively.

**Add challenge:** After safe control, continue directly into one taught breakdown, turn, or escape against an appropriate opponent.

**Stop or change:** Stop for uncontrolled transitions, trapped limbs, neck strain, lifting, mat returns, or any action outside the taught set.

**Look for:** Pair connects control to a purposeful taught top-bottom action while preserving balance, receiving, and immediate stopping.

**Ask:** Which transition became easier when you anticipated the next wrestling position?

## Practice 25 Understand The Official's Job

**Goal:** Apply an actual event rule card to starts, stops, legal positions, and respectful communication.

**Set up:** Mat, cones, current event rule card, timer, bottles; trios rotate wrestler and observer roles.

**Before you begin:** Coaches verify the current rule card and each pair's readiness for the taught attack, defense, escape, or turn.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance movement and solo transitions among comfortable standing, kneeling, and seated positions. Use the practice stop signal frequently. Partners alternate caller and mover roles, checking immediate response and clear spacing rather than copying official signals from memory. |

| 15-27 | Learn | Use the verified event card to explain starts, takedown control, escapes, and shoulder-control criteria. Demonstrate each with cooperative pairs using taught skills. Separate official scoring from practice safety stops; do not invent values or assume balanced standing alone automatically earns an escape. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Trios rotate two athletes and an observer while a coach supervises. Demonstrate a controlled double or go-behind, a cleared-hand escape, and a taught turn. Observer checks one rule at a time. Swap roles, rest, and resolve uncertainty before opposed work. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Pairs use approved taught skills. Coaches confirm outcomes using current rule card. Stop for standing before any return, unsafe position, or uncertainty. Observers defer to coach. |

| 60-70 | Team finish | All trios work simultaneously in supervised areas. Each demonstrates one actual scoring outcome and one practice-only stop, explains the difference, then rotates. Athletes may point or speak. Follow with a short restricted round and rest; only coaches resolve disputed interpretations. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use cooperative demonstrations and only the start-stop procedure while an adult handles the rule card.

**Add challenge:** Apply the checked scoring criteria during a thirty-second round restricted to the taught skill set.

**Stop or change:** Stop for uncertain legality, delayed release, unsafe pressure, lifts, mat returns, or actions outside the demonstrated skill set.

**Look for:** Athlete follows checked procedures and connects an actual wrestling outcome to the applicable event rule.

**Ask:** Which part of the rule helped you understand what happened in the round?

## Practice 26 Use Boundaries Without Chasing

**Goal:** Recognize training boundaries and reset before movement reaches unsafe space.

**Set up:** Mat, cones or flat boundary markers, event rule card, timer, bottles; clear buffers around every partner zone.

**Before you begin:** Partners know the practice boundary and are approved for the specific taught attacks, escapes, and turns used.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance circles inside clearly marked squares, stopping before reaching the buffer. Partners point toward a boundary and the mover chooses a balanced direction change. Switch roles often, keep movement slow, and never use backward running to escape the square. |

| 15-27 | Learn | Demonstrate noticing the training edge, stopping, releasing, and returning independently to the center. Compare this procedure with the checked event rule card. Show the same reset from standing and grounded positions; neither athlete drags, lifts, or pursues a partner across the edge. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse a controlled finish, escape, or turn near an inner practice line while preserving the full safety buffer. Either athlete may call edge; both release and reset independently. Alternate roles and rest. Coaches choose the permitted task for each matched pair. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Start neutral or grounded. Use taught attacks, defenses, escapes; turns require readiness. Stop before buffer, at agreed outcome, or unsafe position. No lifts, returns, or chasing. |

| 60-70 | Team finish | Use simultaneous boundary-awareness rounds with matched partners. After each short attempt, name the decision that kept wrestling central, release, reset, and rest. Coaches recognize controlled attacks and timely resets equally; stepping into unsafe space never becomes the price of finishing a move. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Rehearse movement and clean boundary resets without contact.

**Add challenge:** Use a taught attack-defense or top-bottom round while both athletes track the same protected boundary.

**Stop or change:** Stop before the buffer, neighboring pairs, unsafe pressure, lifting, mat returns, or any pursuit beyond the boundary.

**Look for:** Athletes wrestle purposefully within the agreed area and release before entering the protected buffer.

**Ask:** How did awareness of the boundary change your next wrestling decision?

## Practice 27 Manage A Short Practice Round

**Goal:** Apply a process goal using taught attacks, defenses, escapes, and turns.

**Set up:** Mat, cones, timer, process-goal cards, verified event rule card, bottles; matched pairs and nearby observers.

**Before you begin:** Coach verifies each pair's receiving, hand control, and readiness for the specific skills permitted in the round. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with each athlete's familiar sequence of stance steps, base reset, sit-out, and independent stand-up. Choose comfortable versions and pause between movements. Partners observe one self-selected checkpoint, then switch roles and discuss whether the warm-up supports today's intended process goal. |

| 15-27 | Learn | Demonstrate a controllable goal: finish the corner before following on top, control the waist hand during the rise and clear it before turning, or defend the half early. Coach names permitted skills and outcome stops for each pair. Show one cooperative example, then one opposed example without adding new techniques. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse their chosen goal three times against an announced response, then switch and rest. Observer identifies whether the technical action occurred rather than judging effort alone. Coaches adjust opposition to readiness and verify safe receiving before any completed takedown or turn. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Start neutral or top-bottom. Use taught skills toward the chosen goal. Stop at agreed outcome, balanced standing before any return, or unsafe position. Keep feedback brief. |

| 60-70 | Team finish | All pairs use a short round, feedback, and retry cycle. Athlete names what happened; partner offers one useful observation; athlete chooses an adjustment. Rest before the next round and switch roles. Coaches keep advice specific to taught mechanics and appropriate opposition. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Use a fifteen-second round with one announced attack or escape and a cooperative response.

**Add challenge:** Opponent chooses among the taught defenses or escapes while the athlete pursues the same technical goal.

**Stop or change:** Stop for rushed receiving, neck strain, trapped limbs, unsafe pressure, lifts, mat returns, or actions outside the taught set.

**Look for:** Athlete pursues a specific technical goal against appropriate opposition and explains the result.

**Ask:** What did your opponent do that helped you choose an adjustment?

## Practice 28 Optional Coached Practice Meet

**Goal:** Apply taught folkstyle skills in an optional supervised practice meet with matched opponents and appropriate rules.

**Set up:** Mat, cones, timer, role cards, verified rule card, bottles; separate warm-up and observer spaces.

**Before you begin:** Athletes opt in; coaches verify receiving, safe defense, technique control, and suitable opponents for the permitted format. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with familiar stance movement, empty-space entries, and comfortable grounded transitions. Let each athlete choose the movements needed for the upcoming task. Partners observe control, then rest; athletes choosing the skills-showcase alternative receive equal preparation time and coaching attention. |

| 15-27 | Learn | Explain the format: coach-approved double finishes, sprawls, go-behinds, breakdowns, escapes, and half turns using the checked rules. No lifts, throws, mat returns, or untrained moves. Demonstrate check-in, start, stop, and respectful closure; participation alone does not certify tournament readiness. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse their assigned start and one attack-defense exchange at cooperative pace, then switch and rest. Coach checks receiving and safe release for each permitted move. Observers practice recording verified outcomes; athletes may choose a one-position round or skills demonstration instead. |

| 45-60 | Apply | Run short supervised bouts at the duration and format selected for readiness, beginning with thirty-second rounds and full rests. Use matched opponents and checked scoring. Stop at balanced standing before returns or any unsafe position; coaches retain control over every active pair. |

| 60-70 | Team finish | Use simultaneous supervised showcase stations and optional short rounds. Athletes choose a taught attack, escape, or turn they can demonstrate safely, then explain one decision. Rotate equally with rest. Celebrate technical progress and partner care without pressuring anyone into another bout. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Choose a cooperative skills showcase or one-position round with an announced response.

**Add challenge:** Use the taught attack-defense-escape-turn set under checked scoring while retaining the same no-lift and no-return limits.

**Stop or change:** Stop for unsafe mismatch, coercion, uncontrolled receiving, neck strain, lifting, mat returns, or untrained maneuvers.

**Look for:** Athlete applies taught skills against appropriate opposition and follows the checked procedures and safety limits.

**Ask:** Which wrestling decision would you like to practice again after this meet?

## Practice 29 Repair One Important Difficulty

**Goal:** Improve one technical detail in a taught attack, defense, escape, breakdown, or turn.

**Set up:** Mat, cones, floor dots, timer, four station cards, bottles; coaches oversee contact stations directly.

**Before you begin:** Athlete and coach identify a taught skill, a safe simpler version, and an appropriate defensive response. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up with stance steps, empty-space entries, knee circles around markers, and comfortable bottom-base resets. Athletes identify one movement that needs attention. Partners observe without correcting immediately, then exchange one clear observation and choose a suitable station together with the coach. |

| 15-27 | Learn | Demonstrate four repairs: turn the corner before following a double, move hips back before circling from a sprawl, control the waist hand while rising, and coordinate waist with the chop. Athletes choose one repair; coaches use the half only where turning readiness is confirmed. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse three deliberate attempts against an announced response, exchange one observation, then rest and switch. Coaches change one feature at a time. Include the receiver's experience in the feedback; technical improvement must preserve controlled descent, safe joint alignment, and dependable release. |

| 45-60 | Apply | Setup/demo: 3 minutes; 8 rounds of 30-second work and 60-second rest. Alternate roles; give feedback during rests. Start in the repair's position; opponent supplies a taught response. Stop at agreed outcome or unsafe position. Compare attempts; coach checks control before changing challenge. |

| 60-70 | Team finish | Use parallel repair-and-retest stations. Each pair explains one useful adjustment briefly, demonstrates it cooperatively, then tests it in a short opposed round with rest. Athletes never mock the earlier error; coaches verify that the adjustment improves technique rather than merely adding force. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Keep the skill cooperative and change only one small technical feature.

**Add challenge:** Test the improvement against an opponent choosing among the already-taught legal responses.

**Stop or change:** Stop for pain, forced receiving, joint torque, neck strain, lifting, returns, or a move outside the taught progression.

**Look for:** Athlete explains one technical adjustment and applies it more effectively against an appropriate response.

**Ask:** Which small change improved the actual wrestling outcome?

## Practice 30 Show Progress, Choose What Follows

**Goal:** Demonstrate improved folkstyle skills and decision-making, then choose the next appropriate development goal.

**Set up:** Mat, cones, floor dots, timer, station cards, reflection cards, bottles; clear viewing and activity areas.

**Before you begin:** Coaches verify each athlete's receiving and control for selected tasks; demonstration and competition roles remain voluntary. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Arrival | Welcome athletes and privately check readiness and comfort. Review the stop signal. Pair by size, experience, maturity, and control. Begin cooperatively, confirming that both athletes can immediately stop and release. |

| 05-15 | Movement | Warm up through a shared sequence of stance movement, balance freezes, comfortable base resets, and independent standing. Athletes suggest one familiar movement each while the coach keeps the sequence manageable. Partners observe space and control, then rest before selecting their showcase stations. |

| 15-27 | Learn | Demonstrate showcase choices: controlled double and sprawl defense, grounded go-behind, stand-up or sit-out to B19 hip heist against light control, and breakdown-to-half with early defense. Coaches assign suitable versions. Explain each outcome and safety stop; no athlete must demonstrate a move beyond verified readiness. |

| 27-30 | Water | Pause, release partners, and collect personal water bottles. Athletes may drink whenever needed. Check whether the task felt controlled, adjust spacing or partners, and explain the next permitted reaction together. |

| 30-45 | Rehearse | Pairs rehearse two chosen skills, three attempts per role with rest. Start cooperatively, then add an appropriate announced response. Observer notes one visible improvement; coaches confirm safe receiving and hand control before any completed finish, turning sequence, or resisted escape. |

| 45-60 | Apply | Offer cooperative demonstrations or short opposed rounds at each station. Use only the taught skill set with matched partners and rest between attempts. Stop at the agreed outcome, balanced standing before returns, or unsafe position. Rotate roles so everyone receives useful practice. |

| 60-70 | Team finish | Run parallel partner challenges for the first half of the block, using one familiar goal and regular rests. Finish in small celebration circles: name a learned skill, thank a partner, and choose a next interest. Include noncompetitive participants without requiring public performance. |

| 70-75 | Reflect | Walk slowly and settle breathing. Each athlete identifies one successful action and one next step. Invite private concerns after discussion, preview the next session, and confirm the agreed pickup arrangement. |

**Make it easier:** Choose a familiar cooperative station, solo skill, or supported observation role.

**Add challenge:** Apply a taught attack-to-control or control-to-escape sequence against an opponent choosing a familiar response.

**Stop or change:** Stop for performance pressure, unsuitable partners, uncontrolled receiving, unsafe turning, lifting, returns, or untrained maneuvers.

**Look for:** Athlete shows technical progress against an appropriate task and chooses a realistic next wrestling goal.

**Ask:** Which skill or decision would you like to develop next?

## References

These are original coaching designs. Use the current rules for your actual league or event, qualified instruction, and the club's medical and safeguarding procedures. Practice numbers do not certify tournament readiness.

[Grindstone Wrestling Club and Mat Rats](https://www.grindstonewrestling.org/mat-rats)

[Westminster Mat Rats Wrestling on Facebook](https://www.facebook.com/WestminsterMatRats/)

[USA Wrestling Folkstyle Level 1 technique demonstrations](https://www.usawmembership.com/usa_wrestling_core_curriculum/1)

[NFHS folkstyle rules resources; confirm youth event modifications](https://www.nfhs.org/sports/wrestling/rules)

[American Academy of Pediatrics sports readiness](https://www.healthychildren.org/English/healthy-living/sports/Pages/Is-Your-Child-Ready-for-Sports.aspx)

[CDC concussion response](https://www.cdc.gov/heads-up/response/index.html)

[CDC infection prevention for athletes](https://www.cdc.gov/mrsa/prevention/athletes.html)

## Coach reminders

Keep water available. Children participate at their normally nourished and hydrated weight. Remove suspected concussion from activity and obtain medical evaluation; no same-day return. Suspected contagious skin concerns need evaluation before contact. Follow actual club reporting and emergency procedures.

## After practice

Which task helped the group learn? Who needs a different partner or an easier version? What should be repeated? Record private health or safeguarding matters through the club's secure process.
