# Youth wrestling: research and program blueprint

Prepared September 26, 2026. Designed for ages 4–6, 7–10, and 11–14.

**Working assumptions:** a U.S. beginner-to-intermediate folkstyle club, a flexible 12-week season, and two weekly sessions for ages 7–14. No state, facility, roster, budget, or competitive calendar was supplied. The youngest group is an optional movement/play offering. These assumptions can be changed without changing the program's central principles.

**Companion:** the [coach toolkit](<C:/Users/Thoma/OneDrive/Documents/ChatGPT/practice/youth-wrestling-coach-toolkit.md>) contains session plans, a game bank, readiness records, parent orientation, and operational templates.

## 1. What the research supports

A strong youth program develops children who want to return, move with increasing competence, care for their partners, and gradually learn to solve wrestling problems. Competition can serve that development when the child is ready and interested.

Three research agents investigated curriculum and practice design; development, engagement and inclusion; and health and safeguarding. The coordinating research added club operations, current insurance, source checking, and synthesis. This is a structured research synthesis, not a systematic review or a clinical protocol.

The sources serve different purposes:

| Evidence type | Appropriate use | What it does not establish |
|---|---|---|
| Current federation rules and safeguarding policies | Determine requirements for covered participants and activities | The ideal way to teach every child |
| Pediatric, public-health and sports-medicine guidance | Establish health precautions and development principles | Individual medical clearance |
| Original youth-sport research | Inform motivation and coaching approaches | That results automatically generalize to wrestling |
| Federation coaching curricula and development models | Supply technical resources and organizing principles | Universal age cutoffs, workloads or technique order |
| Proposed program design in this report | Make those principles usable in a club | A validated prescription or mandatory standard |

**Five program decisions follow from the research.**

1. Give the youngest children movement play and a gradual, voluntary introduction to mat activities. Most children under six are not ready for conventional organized sport; AAP guidance favors exploration and brief demonstrations without competition. [AAP sports readiness][S01]
2. Group by age for administration, then adapt instruction and contact partners to individual readiness. Development stages overlap; maturation and motivation matter. [USOPC development stages][S02]
3. Teach a small connected skill set and revisit it under gradually changing conditions. USA Wrestling provides useful skill and practice libraries, but the coach must select age-appropriate content. [USAW curriculum][S03], [sample practices][S04]
4. Build enjoyment into instruction, relationships and progress. Research on fun and mastery-oriented coaching supports looking beyond wins, although the studies cited here were conducted in other sports. [FUN MAPS][S05], [coach-training study][S06]
5. Put health, safeguarding, parent communication and operating capacity in writing. Good technical coaching alone does not constitute a complete program.

## 2. Three connected participation pathways

The time ranges below are **proposed starting points**, not federation requirements or research-established maximums. Reduce demands when participation, control or recovery deteriorates. All sessions include transitions, rest, water and conversation.

| Program group | Purpose | Suggested starting format | What success looks like |
|---|---|---|---|
| **4–6: discover and play** | Enjoy moving, share space, stop, take turns and feel comfortable on a mat | Optional 30–40-minute gathering, once weekly initially; flexible arrival/participation within supervision arrangements | Child joins willingly, tries activities, stops with support, and wants to return |
| **7–10: learn foundations** | Learn positions, safe partner habits and a few useful skills | About 45–60 minutes, twice weekly | Child explains the task, practices with control, attempts skills and treats partners well |
| **11–14: develop and choose** | Refine foundations, connect actions and make decisions | About 60–75 minutes, twice weekly initially | Athlete selects goals, adapts to reactions, manages effort and chooses a suitable participation pathway |

For 4–5-year-olds, keep the offering play-based and parent-supported, with observation and movement-only options. Around age six, introduce more structure individually. There is no required takedown syllabus or tournament expectation for this band.

Parents may help with settling, transitions and agreed activities under staff direction. Being a parent does not automatically authorize supervising other children or coaching on the mat; confirm any participation against the club's credential, safeguarding and insurance arrangements.

For the two older bands, offer both a **foundation route** and an **optional competition route**. A first-year 13-year-old belongs in an age-respectful beginner group, not an advanced class simply because of age. An experienced 9-year-old can receive more difficult choices within a safe peer group without automatically moving into contact with substantially larger athletes.

Athletes may change routes. Missing a tournament, playing another sport, or returning after a break should not make them second-class members. This follows the USOPC emphasis on athlete interests, varied participation and development before competition. [USOPC development stages][S02]

## 3. How to coach a practice

### Before athletes arrive

Write one main learning problem, a simpler version, a harder version, and the behavior that will show progress. Assign coaches to specific stations or pairs. Prepare the space so children spend their time moving rather than waiting for equipment or instructions.

Example: “Today we learn to regain a stable position after an unsuccessful attempt.” Beginners rehearse the recovery with a cooperative partner; experienced athletes respond to one of two familiar reactions. Both practice the same underlying problem.

### A repeatable teaching cycle

1. **Explain the purpose:** one short sentence.
2. **Show:** demonstrate with a willing partner or another coach; explain necessary instructional contact.
3. **Try:** give athletes an achievable first version.
4. **Observe:** look for one important feature.
5. **Adjust:** offer one usable correction or a simpler task.
6. **Apply:** add a choice or limited resistance when safe.
7. **Reflect:** ask what worked, then move on.

This cycle is a proposed coaching routine. A ten-minute learning block means repeated attempts and feedback, not ten minutes of explanation. USAW's sample practice plans support combining review, technical work, activities and reflection. [USAW sample practices][S04]

For 4–5-year-olds, these steps are brief invitations within child-directed movement play. Completing a cycle, station or skill is not required.

### Define resistance by actions

“Go 50 percent” is ambiguous, particularly for children. Specify what the partner may do: “Hold your starting position; do not counter,” or “You may give either of these two practiced reactions.” Confirm both athletes understand the roles before starting. End the attempt if intensity rises beyond the task.

Use cooperative work before limited resistance, then short situations before broader live wrestling. A child may be ready for resistance in one position and need cooperative practice in another. Progress is specific to the task.

### Manage the whole room

Assign partners deliberately, considering size, maturity, experience, control and confidence. Reassign if either athlete cannot participate meaningfully. Use planned rotations so the same child is not always the winner, loser, demonstrator or last chosen.

Every pair needs usable space, a visible supervising coach, clear permitted actions and a practiced stop signal. Any athlete may stop. If staffing or space is inadequate, reduce simultaneous contact, change to noncontact stations or split the session. A child resting at the edge still needs supervision.

## 4. What to teach and when to advance

The following is a **proposed selection framework**, not a manual for performing techniques. A qualified wrestling coach must demonstrate and supervise physical skills in person, with the current rules for the athlete and activity.

| Learning area | Ages 4–6 | Ages 7–10 | Ages 11–14 |
|---|---|---|---|
| Safety and belonging | Space, stop, ask for help, turn-taking | Immediate stop/release, safe partner roles | Apply safety under uncertainty; support peers without policing them |
| Movement | Balance, direction changes, comfortable crawling, getting up | Stance, motion, level changes and controlled transitions | Efficient movement while reacting and recovering |
| Neutral | Noncontact mirroring; optional simple partner activities | One coach-selected attack pathway and initial defense | Better setups, recovery and a second familiar option |
| Bottom | Movement exploration, without compulsory contact skills | Starting position and one escape pathway | Connect attempts and respond to changing control |
| Top | Cooperation and release, without compulsory pinning | Legal positioning and controlled release; add safe turn only when ready | Control-to-turn decisions using taught, appropriate skills |
| Rules and decisions | Stop, boundaries and taking turns | Recognize positions, basic objectives and restarts | Actual event scoring, time, boundaries and tactical choices |
| Personal skills | Name a feeling; choose to participate | Ask for help; retry; identify one improvement | Set a process goal; reflect; communicate load and concerns |

Use the [USAW folkstyle curriculum][S03] as a technical reference. Its “Level 1” designation does not mean every item is appropriate for a preschooler or novice. The broader games library also contains activities requiring skills or neck loading that this proposed introductory program does not adopt. [USAW games library][S07]

**Proposed contact progression:** solo movement → cooperative partner activity → controlled rehearsal → restricted resistance → short positional wrestling → broader live wrestling. Before each step, observe stopping, control, comfort, space awareness and willingness. Move back a step whenever needed; this is instruction, not punishment.

The complete progression applies to ready older children. Under-six participation remains movement play and voluntary cooperative activities, without a route to competitive live wrestling in this program.

Before partner takedowns, both athletes must demonstrate the body control and safe receiving skills required for that specific task under qualified supervision.

For this introductory program, exclude uncontrolled throws, lifts and mat returns; forced neck bridges; head-first landings; painful joint pressure; and fatigue challenges that degrade control. More advanced content requires a separate readiness decision and qualified instruction, even if it appears in a published library.

## 5. A flexible 12-week season

This is an original planning proposal for two weekly sessions. **Weeks are teaching themes, not deadlines for mastery.** Session A introduces or clarifies a problem; session B retrieves it and applies it in a slightly different setting. The youngest group echoes the movement theme through play and does not follow the contact syllabus.

| Week | Session A | Session B | Extension for experienced athletes |
|---|---|---|---|
| 1 | Welcome, boundaries, stop/release and movement observation | Stance/motion and cooperative habits | Respond to changing movement cues |
| 2 | Balance and recognition of neutral/top/bottom | Controlled transitions among familiar positions | Make a simple choice while preserving position |
| 3 | One coach-selected neutral attack pathway | Same pathway with a predictable reaction | Choose between two familiar setups |
| 4 | Initial defense and recovery | Restricted attack/defense problem | Recover and attempt a familiar second action |
| 5 | Bottom position and an escape pathway | Repeat with suitable partner resistance | Connect familiar escape attempts |
| 6 | Safe top position, control and release | Review and private midpoint observation | Improve control without unnecessary force |
| 7 | Connect two learned skills | Practice the connection from varied starts | Add one reaction-dependent option |
| 8 | Recognize a familiar opening or defensive cue | Choose among previously taught solutions | Increase uncertainty while keeping control |
| 9 | Boundaries, scoring and restarts for the actual rules used | Short situations; recheck competition interest | Manage a simple time/score problem |
| 10 | Prepare for an optional mock meet or skills festival | Run the chosen experience with safe pairings | Apply an individual process goal |
| 11 | Repair common difficulties | Athlete-selected improvement stations | Target a personal technical problem |
| 12 | Cooperative skills showcase | Celebrate growth, collect feedback and explain next options | Demonstrate learning and constructive peer support |

Repeat earlier themes for late joiners and athletes needing more time. Offer the full learning experience to children who do not compete. Week ten does not establish tournament readiness.

For a shorter season, reduce the number of themes and preserve repetition. For a longer season, revisit problems with different partners and decisions before adding more techniques. Between seasons, welcome other sports and free play; do not turn optional extras into an attendance requirement.

## 6. Engagement, motivation and behavior

The FUN MAPS study used youth soccer players, parents and coaches to map the many contributors to enjoyment. It supports asking athletes what makes participation rewarding; it does not prove that a particular wrestling game improves retention. [Visek and colleagues, 2015][S05]

A youth-basketball coach-training study found reduced performance anxiety with a mastery-oriented coaching intervention. This supports a climate focused on learning and improvement, while leaving uncertainty about the size of the effect in wrestling. [Smith and colleagues, 2007][S06]

**Proposed daily habits:** greet everyone by name, give each athlete an attainable challenge, offer two acceptable choices, explain a drill's purpose, recognize specific progress, and invite a brief response at the end. Make partner care visible: “You stopped as soon as your partner asked. That helped them trust you.”

Use learning goals rather than outcome promises. “Try your practiced setup twice” is controllable; “win every match” is not. Praise effort when it is connected to an effective strategy, adjustment or persistence, rather than praising exhaustion for its own sake.

| Situation | Useful coach response |
|---|---|
| Child is afraid of contact | “Thanks for telling me. Let's choose a version you can control.” |
| Child makes an error | “You found the right idea. Try changing this one part.” |
| Athlete loses | “How are you feeling? We can discuss the match when you're ready.” |
| Athlete becomes frustrated | “It's okay to be frustrated. We still keep our partner safe. Let's reset.” |
| Athlete succeeds easily | “Which part could you make more precise?” |
| Older athlete wants more autonomy | “Choose one goal for this round. What feedback would help?” |

Teach three expectations: **stop promptly, protect your partner, speak respectfully**. Rehearse them. For unsafe conduct, end contact, calmly name the action, provide a supervised reset, and teach the replacement. Persistent difficulty calls for a private support plan with the family. A reset is not isolation or public shaming.

SafeSport guidance supports positive discipline and identifies humiliation and deprivation of water as misconduct concerns. Adopt a club prohibition on belittling, body comments, hazing and exercise used as punishment. [SafeSport coaching guidance][S08]

Intervene in bullying regardless of the athlete's talent or the parent's influence. Protect the harmed child, hear accounts separately and follow the reporting policy. Do not require immediate reconciliation as the price of returning to practice. [SafeSport bullying handbook][S09]

## 7. Inclusion, parents and access

### Individual accommodations

Use predictable routines, visual schedules, demonstrations and consistent cues. Ask families which supports already help. Offer a quieter explanation area, transition warnings and an agreed visual stop signal when needed. Do not require eye contact as proof of attention. Adapt the activity while retaining a meaningful role. These suggestions draw on Special Olympics coaching guidance; individual preferences matter more than diagnostic stereotypes. [Athlete-centered coaching guide][S10]

Invite the athlete to explain what feels useful or uncomfortable. Collect only necessary health/support information and share it with staff who need it. Arrange an individual plan for medical or disability-related needs with the family and appropriate professionals.

### Girls and other underrepresented participants

Actively recruit girls, recruit and support women coaches, provide suitable clothing options and private changing arrangements, and distribute coaching attention fairly. Ask about partner comfort without abandoning safe matching. Provide menstrual supplies discreetly. Do not infer an athlete's motives, temperament or ability from gender. USAW's coaching resource encourages welcoming messaging, peer recruitment and adult women role models. [USAW recruiting and coaching women][S11]

Competition eligibility and categories must be checked separately with the current event authority. Every participant should receive respectful treatment and protection from harassment.

### Parent partnership

A study of 723 athletes and their parents associated supportive parent behavior with enjoyment and pressure with amotivation. It was correlational and involved other team sports; it is useful guidance, not proof of a wrestling-specific causal effect. [Sánchez-Miguel and colleagues, 2013][S12]

Use a preseason orientation to explain goals, contact progression, optional competition, expected costs, health rules, conduct and reporting. During practice, coaches supply technical instruction; parents support participation and alert staff to concerns. Afterward, suggest “What did you enjoy?” and “What did you learn?” before technical criticism.

Make the program's full cost visible, including membership, equipment, events and travel. Offer equipment loans, payment plans and discreet scholarships where feasible. Keep a local participation option so travel is not the gateway to belonging. Track scheduling and transportation barriers rather than interpreting every absence as lack of commitment. AAP organized-sport guidance emphasizes developmentally appropriate opportunities and access. [AAP organized-sport report][S13]

## 8. Health and recovery policies

These are operational precautions supported by health guidance. Coaches teach and observe; qualified clinicians evaluate illness, injury and individualized health concerns.

### Weight, hydration and nutrition

**Proposed club policy:** athletes participate at their normally nourished, hydrated weight. Coaches do not prescribe weight loss or ask a child to reach a lower class. Growth-related movement to another class is expected. Necessary weight information is private.

This policy is deliberately protective across ages 4–14; it is not presented as a universal federation ban on every weight change. AAP warns about inappropriate weight loss in young athletes and notes that most junior-high wrestlers should not lose weight for wrestling. [AAP weight guidance][S14], [AAP wrestling guidance][S15]

Provide labeled personal water bottles and unrestricted access, with planned pauses. Never use fluid restriction, extra clothing, fasting or punishment exercise to make weight. Encourage ordinary varied meals, familiar tournament food and allergy planning. Avoid coach-prescribed calories or supplements. Water is the default drink. [AAP hydration guidance][S16] Stimulant-containing energy drinks are inappropriate for children. [AAP caffeine guidance][S38]

### Skin and mat hygiene

Teach prompt reporting of rashes and sores, showering after participation, clean clothing after use and no shared towels. Staff observe visible concerns without intrusive examinations; medical professionals diagnose suspected infections. [CDC athlete guidance][S17]

Assign and log cleaning. Use surface-compatible products according to their labels, including contact time, and allow surfaces to dry. Clean shared equipment after use, repair damaged surfaces and keep chemicals away from children. [CDC facility guidance][S18]

**Proposed club rule:** a suspicious potentially contagious lesion means no contact pending evaluation. Return requires the relevant medical documentation and event/federation criteria. Covering a contagious lesion is not a workaround. [NFHS inspected 2024 model form][S39] The current NFHS form landing page was checked, but its newest PDF could not be retrieved during research; no treatment-time table is reproduced here. [NFHS current form][S19]

### Concussion and emergency response

For suspected concussion, remove the athlete immediately, check for danger signs, notify the guardian and obtain medical evaluation. Seek emergency care immediately for danger signs. No same-day return. Coaches do not grant medical clearance. [CDC concussion response][S20]

Return follows healthcare-provider approval and supervision through a graduated process. CDC states that each step typically takes at least 24 hours; recurrent symptoms require stopping and contacting the provider. Do not promise a fixed return date or use a completed checklist as medical clearance. [CDC return to sport][S21]

Write and rehearse a venue-specific emergency action plan. Assign first response, emergency calling, AED retrieval, EMS access, guardian contact and supervision of the remaining children. Post the exact address and entrance. NATA recommends annual review and rehearsal and an AED on site or retrievable for use within three minutes. [NATA emergency planning statement, 2024][S22]

### Total load, sleep and strength

Ask about school teams, other clubs, tournaments and family demands. Respond to recurrent pain, fatigue, declining enjoyment or deteriorating control by reducing demands and seeking appropriate evaluation. AAP recommends 1–2 weekly rest days and 2–3 months away from a specific sport annually. These are general guidance, not a guarantee that a particular schedule is safe. [AAP overtraining guidance][S23]

CDC sleep ranges cross the program's age bands: ages 3–5 need 10–13 hours including naps; 6–12 need 9–12; 13–17 need 8–10. Schedule practice endings and travel accordingly. [CDC sleep guidance][S24]

For introductory physical preparation, use enjoyable movement and carefully coached balance and strength patterns. Any formal resistance-training component should be designed and supervised by a qualified coach, emphasize technique, and account for the total workload. Do not use maximal lifting contests or exhaustion tests to rank children. Persistent food anxiety, fatigue, recurring injury or menstrual concerns call for confidential clinical referral, not coach diagnosis. [IOC REDs consensus, 2023][S25]

## 9. Safeguarding and reporting

For a USA Wrestling affiliate, implement the applicable federation policy, including its **2025 MAAPP**. It addresses observable and interruptible adult/minor interactions, transparent communications, individual training, changing areas, transport, lodging and treatment. Required consent and exceptions are context-specific; a general parental waiver does not replace the policy. [USAW MAAPP][S26]

Operationally, designate a safeguarding contact outside the head coach's direct authority, establish approved communication channels, record pickup authorization, and make reporting routes visible to children and families. Teach children how to say stop and identify an adult they can approach.

For **Adult Participants under the 2026 SafeSport Code**, reporting is an individual obligation; telling a supervisor is insufficient. Victims are not required to self-report. Known or suspected child abuse must be reported immediately to law enforcement and the Center, with additional recipients as state law requires. Sexual misconduct must be reported to the Center immediately and no later than 24 hours; child-abuse duties also apply where relevant. Do not investigate credibility before reporting. Other misconduct and policy violations also carry reporting duties. [2026 SafeSport Code, section X][S27]

Use the [SafeSport reporting portal][S28] and the [USA Wrestling misconduct portal][S29] as applicable. Immediate danger calls for emergency services. A club complaint process must never delay required external reporting. Train staff on the full policy and local law before they begin work with children.

## 10. Staffing, facilities, finances and administration

### Roles and supervision

Assign responsibility for coaching/curriculum, safeguarding, emergency preparation, registration, family communication, finances and equipment/cleaning. In a small club, one person may cover several roles, but concerns about a coach need a route outside that coach.

**Proposed operating minimum:** two appropriately screened/trained adults present, with at least one qualified coach directing each active contact group. This is a club safeguard, not a verified universal USAW practice ratio. More adults may be necessary. Record a session's capacity based on age, needs, mat layout, contact intensity and whether every pair can actually be observed and interrupted. Do not enroll to a number that exceeds that capacity.

For a USAW club, check current leader membership, required screening and SafeSport completion for applicable personnel. USAW recommends Copper coaching certification for ages 12 and under and Bronze for 13 and older, while actual state/event credential requirements vary. Certification should be accompanied by practical mentoring, observation and feedback. [USAW membership types][S30], [coach certification][S31]

Hold a short pre-practice staff huddle and a post-practice review. Once a month, observe a coach for clarity, engagement, safe pairing, correction quality and equitable attention. Review difficult situations without exposing children's private information unnecessarily.

### Facility and equipment

Arrange suitable wrestling mats with secure seams, clear run-off space and protected hazards; usable toilets/changing arrangements; ventilation; water access; storage; first-aid supplies; and emergency access. Confirm the facility's rules for mat installation, cleaning, occupancy, AED access and supervision. Keep spectators and loose equipment outside activity areas.

Publish a simple equipment list: clean safe practice clothing, properly fitted wrestling shoes where appropriate, personal bottle, and protective equipment required by the activity or event. As a proposed club policy, use correctly fitted wrestling ear guards for partner contact and live practice. Confirm mouthguard, braces, clothing and other equipment requirements under the rules used. Protective equipment does not replace controlled technique and pairing.

### Charter and insurance

Use the current [USAW club-charter guidance][S32]. Verify the organization's actual coverage with the insurer or USAW, including introductory sessions, visitors, events and all practice sites, before advertising covered activities.

The **2026–27 USAW insurance summary** makes coverage conditional: chartered practice provisions include leader supervision and participating member requirements. It also identifies liability exclusions involving residential settings and multisport/multi-activity entities and gaps such as club property, auto and directors/officers coverage. The summary is not the insurance contract. Do not assume a charter covers every setting or a free trial participant. [2026–27 insurance information][S33]

Adding a practice address is separate from adding an additional insured entity. Confirm the facility's required documentation. Encouraging children to play other sports does not mean the wrestling club is automatically insured to operate other sports. [USAW practice-address guidance][S34]

### Budget and records

Build a local budget from actual quotations; no national fee estimate is supplied. Include facility hire, mats/storage, staffing and training, charter/membership administration, insurance, cleaning, equipment loans, first aid, registration services, scholarships and a reserve. Keep optional event/travel charges separate from core participation.

Proposed fee formula: **(fixed seasonal costs + planned reserve − committed subsidy) ÷ conservative paying enrollment + variable cost per athlete**. Model lower-than-expected enrollment before committing to a facility. Explain refunds and cancellations in advance.

Keep attendance, emergency contacts, authorized pickup, staff credentials, cleaning logs, incident records and any medical restrictions securely. Limit access and establish retention/deletion rules appropriate to the organization and jurisdiction. Obtain specific media permission; avoid publishing children's health, weights or identifiable schedules unnecessarily.

## 11. Competition and style adaptation

Competition readiness requires athlete interest, safe participation in the relevant positions, reliable stop/release behavior, a supported practice or mock-match experience the athlete willingly chooses, and an appropriate opponent opportunity. The athlete needs sufficient control and confidence to participate safely. The family's understanding of the event also matters. A practice win is not a readiness test.

Preparation includes recognizing pinning situations and practicing an appropriate, controlled response with qualified instruction. A tournament should not be the athlete's first encounter with that experience.

Start with a local, well-run, developmentally suitable event when desired. Confirm division eligibility, novice rules, pairing, permitted techniques, bout format, medical/skin procedures, equipment, rest provisions and coach credentials. Decline or withdraw from an unsafe mismatch through the event's procedures.

The requested age bands are program groupings, **not official competition divisions**. The USAW rolling rulebook identified itself as the **2027 edition, updated September 13, 2026**, when checked. It primarily addresses international styles and contains folkstyle modifications; the actual folkstyle event may combine NFHS, USAW and state rules. Do not apply freestyle scoring to folkstyle. [USAW rulebook][S35], [NFHS rules portal][S36]

For freestyle or Greco-Roman, retain the developmental approach and replace technical/scoring content with instruction from a qualified style coach. Freestyle adds style-specific exposure and par-terre decisions. Greco changes allowable attacks and prohibits active use of the legs against an opponent. Use the appropriate curriculum and current event rules. [USAW Olympic styles curriculum][S37]

## 12. Measure quality and improve the program

Use a private early/mid/late-season observation with “needs support,” “emerging,” and “independent in this task.” Record the next teaching action. Do not publish a league table of children.

For the youngest children, these are informal adult planning notes, not testing days or pass/fail graduation. Accept gestures, pictures, demonstrations and pointing as communication; verbally naming a feeling is not an admission requirement.

| Measure | How to collect it | How to use it |
|---|---|---|
| Enjoyment and willingness to return | One age-appropriate question after practice | Look for recurring low responses and ask privately why |
| Belonging | Ask whether the child has a trusted adult and a comfortable partner | Repair isolation and partner selection |
| Skill progress | Observe the few skills currently taught | Adjust task difficulty and repetition |
| Safety behavior | Stop/release, controlled partnering, incident and near-miss records | Change supervision, space or task design |
| Attendance and continuation | Separate temporary absences, completion and next-season return | Identify access barriers without blaming families |
| Family experience | Brief midpoint and end-season feedback | Adjust communication, costs and logistics |
| Coach practice | Peer observation using a few agreed behaviors | Select a specific improvement for the next month |

Track novice retention and the experience of smaller or underrepresented groups where numbers permit privacy. Do not set a target of “zero reports”: that can discourage reporting. Reward prompt reporting and corrective action.

## 13. Launch sequence and unresolved local decisions

**Before registration:** define pathways, identify the governing organization, secure qualified staff and venue, verify coverage, price the program, and publish the purpose and full costs.

**Before the first session:** verify credentials; complete local rules, medical and safeguarding procedures; rehearse the emergency plan; assign capacity; collect essential family information; run parent orientation; and prepare the first two sessions.

**During the first two weeks:** observe readiness, stabilize routines, adjust groupings and confirm every child has an appropriate activity and partner. Avoid promising a fixed tournament schedule to every beginner.

**Midseason:** review enjoyment, attendance, skills, incidents, family concerns and coaching quality. Change the plan where evidence from the room indicates a problem.

**End of season:** celebrate learning, invite honest feedback, explain continued recreation and competition options, reconcile finances, and plan a genuine break from the sport.

The owner must still resolve: state and event rules; reporting law and recipients; concussion clearance rules; participation/category requirements; staff availability; actual mat capacity; facility/AED access; medical referral and event coverage; insurance exclusions; travel/changing arrangements; local fees; and record-handling requirements. These are configuration decisions for a real club, not reasons to postpone curriculum development.

## 14. Evidence register and limitations

All sources below were checked by the research team on September 26, 2026. An undated page is not assumed to have been newly published. Search-engine crawl dates were not treated as publication dates. Some USAW pages intermittently rejected direct retrieval; indexed official text and accessible federation documents were used. The current NFHS skin-form landing page was verified, but its newest attachment was inaccessible.

| Sources | Date/status | Evidence and limitation |
|---|---|---|
| [AAP readiness][S01]; [USOPC stages][S02] | AAP updated June 28, 2024; USOPC page undated | Development guidance and framework; not trials of the proposed age groups |
| [USAW curriculum][S03], [practice plans][S04], [games][S07] | Undated current resources | Technical and coaching examples; require individual selection |
| [Visek et al.][S05] | Online 2014; journal issue 2015 | Original soccer concept-mapping research; not an intervention proving retention |
| [Smith et al.][S06] | 2007 | Original youth-basketball coaching intervention; anxiety outcome |
| [SafeSport coaching][S08], [bullying handbook][S09] | Coaching page undated; handbook 2016 | Practitioner safeguarding guidance |
| [Special Olympics guide][S10]; [USAW girls resource][S11] | Dates not established; girls resource references 2015 team | Useful inclusion approaches; individualize and avoid dated stereotypes |
| [Sánchez-Miguel et al.][S12] | 2013 | Original questionnaire research; association does not prove causation |
| [AAP organized sports][S13] | 2019; reaffirmed 2023 | Clinical report on development and participation |
| [AAP weight][S14], [wrestling][S15], [hydration][S16] | Weight page updated 2012; other page dates not relied on | Family health guidance; no individualized diet prescribed |
| [CDC athletes][S17], [facilities][S18] | June 27, 2025 | Infection-prevention guidance |
| [NFHS skin form][S19] | Landing page September 2, 2026 | Current document locator; new PDF not inspected |
| [CDC response][S20], [return][S21] | September 15, 2025 | Concussion precautions and clinician-led return framework |
| [NATA emergency plan][S22] | June 2024 statement | Professional position statement; local implementation required |
| [AAP overtraining][S23]; [CDC sleep][S24] | July 26, 2024; May 15, 2024 | General recovery guidance, not individual load thresholds |
| [IOC REDs][S25] | 2023 | Clinical consensus; referral awareness, not coach diagnosis |
| [USAW MAAPP][S26]; [SafeSport Code][S27] | 2025 policy; 2026 Code | Governing requirements within their jurisdiction; consult full text |
| [Reporting portals][S28], [USAW portal][S29] | Current pages | Reporting routes; local legal duties also apply |
| [Membership][S30], [certification][S31], [charter][S32] | Current undated guidance | Administrative information; event requirements vary |
| [Insurance][S33], [practice address][S34] | 2026–27 summary; current FAQ | Summary and administrative guidance; contract determines coverage |
| [USAW rules][S35], [NFHS rules][S36], [Olympic curriculum][S37] | USAW 2027 edition; NFHS 2026–27 resources; undated curriculum | Rule authority and technical resource; check actual event |
| [AAP caffeine][S38]; [NFHS inspected model][S39] | August 11, 2025; April 2024 | Supports caffeine guidance and no covering workaround; use current event skin criteria |

**What remains uncertain:** this research did not establish one optimal practice duration, child-to-coach ratio, number of annual matches, or compulsory week-by-week progression. Older USAW development posters contain differing age brackets and workload suggestions; those numbers were not converted into requirements. Specific games, templates, time budgets, season sequence and staffing proposals here are original design choices. Broader youth-sport findings should be evaluated against feedback from this wrestling program rather than treated as guarantees.

[S01]: https://www.healthychildren.org/English/healthy-living/sports/Pages/Is-Your-Child-Ready-for-Sports.aspx
[S02]: https://www.usopc.org/coaching-education/adm/american-development-model-stages
[S03]: https://www.usawmembership.com/usa_wrestling_core_curriculum
[S04]: https://assets.contentstack.io/v3/assets/blteb7d012fc7ebef7f/blt60b6b81d96aec8e9/665a3a926330abb9c1345c87/Folkstyle_Level1_Practice_Plans.pdf
[S05]: https://pubmed.ncbi.nlm.nih.gov/24770788/
[S06]: https://pubmed.ncbi.nlm.nih.gov/17556775/
[S07]: https://www.usawmembership.com/usa_wrestling_core_curriculum/7
[S08]: https://uscenterforsafesport.org/positivity-and-understanding-define-next-gen-coaching-practices/
[S09]: https://uscenterforsafesport.org/wp-content/uploads/2019/11/US-Center-for-SafeSport-Preventing-Bullying-What-Great-Coaches-Need-to-Know.pdf
[S10]: https://media.specialolympics.org/resources/sports-essentials/general/AthleteCentered_CoachingGuide.pdf
[S11]: https://content.themat.com/CoachesCorner/Recruiting-and-Coaching-Women.pdf
[S12]: https://pubmed.ncbi.nlm.nih.gov/23717366/
[S13]: https://publications.aap.org/pediatrics/article/143/6/e20190997/37135/Organized-Sports-for-Children-Preadolescents-and
[S14]: https://www.healthychildren.org/English/healthy-living/sports/Pages/Safe-Weight-Loss-and-Weight-Gain-for-Young-Athletes.aspx
[S15]: https://www.healthychildren.org/English/healthy-living/sports/Pages/Wrestling.aspx
[S16]: https://www.healthychildren.org/English/healthy-living/nutrition/Pages/Choose-Water-for-Healthy-Hydration.aspx
[S17]: https://www.cdc.gov/mrsa/prevention/athletes.html
[S18]: https://www.cdc.gov/mrsa/prevention/coaches-athletic-directors.html
[S19]: https://www.nfhs.org/resources/sports/nfhs-wrestling-skin-lesion-form
[S20]: https://www.cdc.gov/heads-up/response/index.html
[S21]: https://www.cdc.gov/heads-up/guidelines/returning-to-sports.html
[S22]: https://www.nata.org/sites/default/files/2025-08/emergency_action_plan_development.pdf
[S23]: https://www.healthychildren.org/English/health-issues/injuries-emergencies/sports-injuries/Pages/Too-Much-Too-Soon-Overtraining.aspx
[S24]: https://www.cdc.gov/sleep/about/
[S25]: https://pubmed.ncbi.nlm.nih.gov/37752011/
[S26]: https://maapp.uscenterforsafesport.org/wp-content/uploads/2022/02/Wrestling_2025MAAPP_09.01.24_Final.pdf
[S27]: https://uscenterforsafesport.org/wp-content/uploads/2025/12/2026-Safesport-Code_1225.pdf
[S28]: https://uscenterforsafesport.org/report-a-concern/
[S29]: https://www.usawmembership.com/misconduct
[S30]: https://www.themat.com/membership/membership-levels
[S31]: https://www.themat.com/coaches/ncep-certification
[S32]: https://www.usawmembership.com/help/category/4/question/16
[S33]: https://usaw-public.s3.us-east-2.amazonaws.com/insurance_forms/Insuranceinfo.pdf
[S34]: https://www.usawmembership.com/help/category/4/question/63
[S35]: https://www.usawmembership.com/usa_wrestling_rule_book
[S36]: https://www.nfhs.org/sports/wrestling/rules
[S37]: https://www.usawmembership.com/usa_wrestling_core_curriculum/4
[S38]: https://www.healthychildren.org/English/healthy-living/nutrition/Pages/the-effects-of-caffeine-on-kids-a-parents-guide.aspx
[S39]: https://assets.nfhs.org/umbraco/media/882323/2024-25-nfhs-wrestling-skin-lesion-form-final-5-1-24.pdf
