# Youth wrestling coach toolkit

Prepared September 26, 2026. Companion to the [research and program blueprint](<C:/Users/Thoma/OneDrive/Documents/ChatGPT/practice/youth-wrestling-program-blueprint.md>).

These are original, editable planning tools for a U.S. beginner/intermediate folkstyle program. Durations, game formats, observation scales and staffing choices are proposals. They do not replace qualified instruction, medical decisions, the club's actual safeguarding policy or event rules. Complete local operating fields before using the relevant template.

## 1. A child's first visit

Before arrival, send the start/end time, what to wear, where to enter, how pickup works and a contact for support needs. Resolve registration, participation permission and applicable coverage first; a “free trial” does not automatically satisfy membership or insurance conditions.

At arrival, greet the child by name, introduce the supervising adult, show the water/rest area and demonstrate the stop signal. Offer a familiar, low-demand activity. Let the child observe before joining. Explain partner selection without making them find a partner publicly.

For ages 4–6, begin with a choice such as stepping between markers or copying the coach. For older beginners, first explain what they will actually practice; do not introduce them with a surprise live match.

If overwhelmed: stop contact, provide a supervised quiet space, offer a familiar movement activity or break, and support rejoining without pressure. Ask the family what usually helps. Keep the child within safeguarding arrangements; a break does not mean leaving them alone.

At pickup, give one specific positive observation and the next practical step. Avoid promising talent, scholarships or tournament success after one visit.

## 2. Three ready-to-adapt session plans

All water breaks are additional to freely available water throughout. Blocks include rest, demonstration, feedback and rotation. End or simplify contact when control declines. “Live” work means only appropriate, taught actions with safe pairings and active supervision.

### Ages 4–6: 35-minute play menu

**Theme:** moving safely in shared space. **Equipment:** flat, nonslip markers and a visual stop cue. **Success:** voluntary participation and a positive goodbye.

| Time | Minutes | Invitation |
|---|---:|---|
| 0–5 | 5 | Welcome and choose a simple movement activity; observation is welcome |
| 5–10 | 5 | Traffic lights: move, slow and stop inside personal spaces |
| 10–18 | 8 | Choose between stepping islands, comfortable crawling and balance play |
| 18–20 | 2 | Water and reset |
| 20–27 | 7 | Mirror the coach or a willing partner without contact |
| 27–32 | 5 | Children choose a familiar activity; adults follow their interests |
| 32–35 | 3 | Point to or describe a favorite activity, then supervised pickup |
| **Total** | **35** | **A flexible gathering, not a required sequence** |

Children may remain at a preferred activity, observe, pause or finish early with an authorized adult. There are no required takedowns, live matches or conditioning finishers. An older, ready six-year-old may receive an individual introductory task without changing the play focus for younger children.

### Ages 7–10: 60-minute foundation practice

**Example theme:** recognizing and using one already selected escape pathway. Qualified coaches choose the actual skill and demonstrate it. First-week sessions instead use stopping, movement and positions.

| Time | Minutes | Activity |
|---|---:|---|
| 0–5 | 5 | Welcome, comfort/health check and one simple goal |
| 5–13 | 8 | Movement warm-up through mirror or compass games |
| 13–21 | 8 | Recall familiar movement and starting position |
| 21–31 | 10 | Brief demonstrations alternating with attempts at the day's skill |
| 31–33 | 2 | Water and reset |
| 33–40 | 7 | Cooperative pairs; roles defined and swapped |
| 40–47 | 7 | Short restricted tasks for ready athletes; rehearsal for others |
| 47–55 | 8 | Cooperative group game or skill collection |
| 55–60 | 5 | Name one improvement, recognize safe partnering and preview next time |
| **Total** | **60** | |

**Beginner version:** predictable partner, one cue, no counter. **Extension:** respond to one of two familiar reactions. Example rounds can be 20–30 seconds with at least enough rest and feedback to reset safely; this is a starting format, not a required work/rest ratio. Never turn the seven-minute application block into uninterrupted hard wrestling.

### Ages 11–14: 75-minute development practice

**Example theme:** recovering after an initial attack is stopped. Newcomers learn the component positions while experienced athletes link familiar actions.

| Time | Minutes | Activity |
|---|---:|---|
| 0–5 | 5 | Check-in and athlete-selected process goal |
| 5–15 | 10 | Movement preparation and an engaging reaction game |
| 15–25 | 10 | Retrieve familiar skills; identify the problem to solve |
| 25–37 | 12 | Learn or refine one response through short demonstrations and attempts |
| 37–40 | 3 | Water and reset |
| 40–55 | 15 | Restricted practice with clear roles, choices, rests and feedback |
| 55–67 | 12 | Short positional situations or broader live work when ready |
| 67–72 | 5 | Enjoyable group finish with controlled movement |
| 72–75 | 3 | Reflect on the goal and choose a next step |
| **Total** | **75** | |

Use shorter sessions for new or fatigued groups. If adding a qualified strength component, replace an existing block and recalculate the total rather than automatically extending practice. Review school, club and tournament demands before offering extra weekly sessions.

## 3. Ten games with a purpose and a stop condition

These are proposed formats, not copies of a federation game manual. Use marked spaces, no elimination and multiple small groups where staffing permits. Check that markers cannot slide or trip athletes. The contact game is only for ready older participants.

| Game | Suggested group and purpose | How to run it | Stop or change when |
|---|---|---|---|
| Traffic lights | 4–10; stopping and space | Green means comfortable movement, yellow slow, red freeze | Children collide, sprint blindly or cannot stop |
| Mirror movement | All; balance and response | A leader changes direction while a follower mirrors at a safe distance; swap | Distance collapses or speed exceeds control |
| Stance statues | 6–14; stable movement | Move briefly, then freeze in a comfortable balanced position | Repeated loss of balance or discomfort appears |
| Animal choices | 4–10; movement variety | Choose a comfortable walk, crawl or small hop between nearby markers | Wrist/knee pain, head-first movement or collisions develop |
| Island stepping | 4–10; balance and control | Step among flat markers; pause briefly on an island | Markers move or children race into shared space |
| Compass coach | 6–14; direction changes | Follow direction cues within individual areas | Athletes cross lanes or become confused at speed |
| Shadow level change | 7–14; matching movement | Follow a partner's comfortable up/down movement without contact | Diving, knee impact or loss of balance occurs |
| Rule-card walk | 7–14; rules and vocabulary | Walk to a picture showing a position or boundary and explain it | Too many converge; add stations or stagger turns |
| Movement puzzle | All; cooperation | Partners reproduce a short no-contact sequence, such as step, stop, turn | A partner feels pressured or cannot follow safely |
| Light shoulder touch | Ready 7–14; distance and reactions | One light open-hand shoulder touch, then reset; no grab, shove or takedown | Head contact, chasing, grabbing, anger or loss of control occurs |

For a child who cannot comfortably do a movement, offer an equivalent choice immediately. The goal is participation and learning, not “earning” access to the rest of practice.

## 4. Four wrestling learning cards

Use only movements already demonstrated safely by a qualified coach. These cards define learning constraints, not physical technique instructions.

Before partner takedowns, verify both athletes' body control and safe receiving skills for the particular task under qualified supervision.

| Card | Task and roles | Easier version | Extension | End the attempt when |
|---|---|---|---|---|
| Position recognition | Coach names a familiar position; athletes identify or assume the taught start | Use a picture and individual demonstration | Athlete explains the objective from that position | Confusion creates unsafe contact |
| One-path rehearsal | One athlete practices the day's pathway; partner provides a prescribed cooperative response | Practice components without a partner | Add one allowed defensive reaction | Either partner improvises outside the task |
| Read the reaction | Partner gives one of two familiar cues; athlete chooses a taught response | Announce the cue first | Vary its timing while retaining control | Speed prevents controlled execution |
| One-objective situation | Start in a taught position with one limited objective; swap roles | Cooperative rehearsal | Add one familiar option or a simple time/score problem | Stop signal, pain, fear, boundary hazard or unsafe pressure |

Keep score only when it serves the learning objective. A cooperative “both partners did the task well” outcome is often more useful than keeping a winner in and sending others out.

## 5. Reusable practice planner

**Date / group / expected attendance:** ____________________

**Lead coach / assistants / assigned areas:** ____________________

**One main learning problem:** ____________________

**What progress will look like:** ____________________

**Simpler version / more challenging version:** ____________________

**Known restrictions and supports, shared only with relevant staff:** ____________________

| Block | Minutes | Task / cue | Pairing and supervision | Alternative |
|---|---:|---|---|---|
| Welcome and check-in | | | | |
| Movement | | | | |
| Review | | | | |
| Learning | | | | |
| Water/reset | | | | |
| Application | | | | |
| Enjoyable finish | | | | |
| Reflection/pickup | | | | |
| **Total** | | | | |

**After practice:** Who engaged? Who struggled or appeared isolated? Which task had too much waiting? Were any pairings unsafe? What changes next time? Record incidents through the separate secure process.

## 6. Private learning and readiness record

**Athlete / date / observer:** ____________________

Use **S = needs support, E = emerging, I = independent in this specific task**. No combined score or ranking. For preschoolers, use informal observations during play and omit contact/technical items. Accept gestures and pictures.

| Observation | S / E / I / not applicable | What was observed | Next teaching action |
|---|---|---|---|
| Stops and releases on signal | | | |
| Maintains space and control | | | |
| Communicates discomfort or seeks help | | | |
| Cooperates with an appropriate partner | | | |
| Recognizes current starting positions | | | |
| Performs the current taught task | | | |
| Responds safely to the permitted resistance | | | |
| Rejoins or retries with appropriate support | | | |

**Athlete's view:** favorite part ______; difficult part ______; wish for next time ______.

**Current practice level, by task:** movement / cooperative / rehearsed skill / restricted resistance / positional / broader live.

**Next review:** ______. An athlete can use different levels for different tasks.

### Optional competition decision

Record the child's interest, relevant readiness observations, chosen event/rules, suitability of opponents, family understanding, required documents and who made the decision. Include a plan for opting out or withdrawing if circumstances change. A “not yet” decision must include the next learning opportunity; it is not removal from the club.

Include recognition of pinning situations and an appropriate, controlled response learned under qualified coaching. The athlete should encounter that experience in supported practice before a tournament.

## 7. Parent orientation and welcome message

**Suggested 20-minute meeting:** five minutes on age-group goals, five on daily logistics and health practices, five on conduct/safeguarding/reporting, five for questions. Provide the information in writing for families who cannot attend.

Suggested message, to customize:

> Our goal is for every child to feel welcome, improve their movement and wrestling skills, and learn to care for a partner. The youngest group focuses on play. Older groups learn through repeated practice and gradually increasing challenge. Tournaments are optional and depend on readiness and interest.
>
> Please tell us about support needs, relevant medical restrictions, schedule conflicts and concerns. Bring the listed equipment and a personal water bottle. Encourage your child to report pain, skin concerns or uncomfortable interactions. Our program does not ask children to cut weight.
>
> During practice, let coaches give technical direction. Afterward, ask what your child enjoyed or learned. Cheer respectfully and help us make new families feel included. You may raise ordinary program concerns with [contact]; safeguarding concerns can go directly to [independent contact and external reporting routes].
>
> Practice times: [ ]. Full core fee and what it covers: [ ]. Optional costs: [ ]. Equipment assistance: [ ]. Cancellation/refund rules: [ ]. Pickup arrangements: [ ].

Provide a separate, clear media-consent choice. Avoid bundling optional photography into permission to participate.

## 8. Pre-practice operating card

Complete by an assigned adult. This is a proposed club routine, not a substitute for the facility or governing body's requirements.

- Attendance, essential emergency information and authorized pickup are accessible to relevant staff.
- Staff present meet the club's credential and supervision plan; activity capacity is appropriate.
- Mats, seams, margins, hazards, lighting and ventilation are checked.
- Cleaning has been completed correctly; equipment and surfaces are ready for use.
- Phone, emergency access, first-aid supplies and AED arrangements are verified.
- Coaches know restrictions, suitable pairings, learning goals and simpler alternatives.
- Athletes know the stop signal and can access water.
- A supervised plan covers arrivals, breaks, toilets/changing and departures.

If something is inadequate, change the activity or attendance arrangement before starting. Record who will fix the issue and when.

## 9. Emergency action plan worksheet

Complete with appropriate facility and medical/emergency input, then rehearse. This is a planning worksheet, not instructions for administering medical treatment. The source framework is the [NATA emergency planning statement](https://www.nata.org/sites/default/files/2025-08/emergency_action_plan_development.pdf).

| Field | Local plan |
|---|---|
| Facility, exact address, room and entrance | |
| Emergency number and reliable phone | |
| Lead first responder and backup | |
| Person calling emergency services | |
| AED location, access and retrieval person | |
| First-aid kit and other approved equipment | |
| Person meeting responders and clearing access | |
| Person supervising remaining children | |
| Guardian notification and emergency-contact access | |
| Relevant individual action plans | |
| Rehearsal date / attendees / changes needed | |
| Review owner and next review date | |

For suspected concussion, use immediate removal and medical evaluation, with no same-day return. Emergency danger signs require urgent care. Return decisions follow healthcare guidance and applicable rules. Keep the [CDC response guidance](https://www.cdc.gov/heads-up/response/index.html) available to staff.

## 10. Incident, cleaning and credential records

### Incident / near-miss record

Record date/time/location; activity; people involved; objective observations; the child's own words where relevant; immediate actions; notifications and times; external reporting where required; restrictions; and follow-up owner/date. Store securely. Do not diagnose, speculate about blame, or investigate a safeguarding disclosure in place of reporting it. A club record does not replace any medical, insurance or mandatory external report.

### Cleaning log

| Date/time | Surface/equipment | Product and label instructions followed | Completed by | Defect or follow-up |
|---|---|---|---|---|
| | | | | |

Use the [CDC athletic-facility guidance](https://www.cdc.gov/mrsa/prevention/coaches-athletic-directors.html) and actual product instructions. Keep cleaning materials secured.

### Staff credential tracker

| Staff member / role | Membership if applicable | Screening status | Safeguarding training | Coaching training | CPR/AED/first aid as assigned | Expiry / owner |
|---|---|---|---|---|---|---|
| | | | | | | |

Keep sensitive background-screening details out of shared rosters; record verified eligibility/status and renewal needs with controlled access.

## 11. Program dashboard

Review these monthly and at season end. Choose improvements from patterns, not a single bad day.

| Question | Simple measure | Action if a concern appears |
|---|---|---|
| Do children want to come back? | Age-appropriate enjoyment response | Ask privately; adjust tasks or relationships |
| Is everyone included? | Trusted adult and comfortable-partner check | Change partner/station arrangements |
| Are they learning? | Current task observations | Reteach or increase challenge individually |
| Are practices controlled? | Stop/release, incidents and near misses | Modify supervision, space or activity |
| Can families participate? | Absence/exit reasons, cost and timing feedback | Address practical barriers |
| Are coaches improving? | One peer-observed behavior per month | Set a specific coaching goal |

For return rate, define the cohort and denominator: returning eligible athletes divided by prior-season athletes eligible to return. Separately record aging out, moving away and choosing another activity. Do not pressure families to return to improve the metric.

## 12. Questions to finalize the local program

1. Which state, governing organization and wrestling style apply?
2. How many athletes are expected in each age and experience group?
3. What mat space, practice times and facility arrangements are available?
4. Which screened, trained coaches and assistants will actually attend each session?
5. Is the main purpose recreation, beginner development, optional competition, or a combination?
6. What season length, family costs and scholarship resources are realistic?
7. What medical, emergency, safeguarding, insurance and transport arrangements have been verified?

The blueprint supplies a flexible curriculum while these details are resolved. The finished local handbook should name responsible people, insert actual contacts and rules, and replace planning placeholders with approved operating arrangements.
