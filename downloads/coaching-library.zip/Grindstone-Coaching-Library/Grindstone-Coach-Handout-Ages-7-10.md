# Grindstone Wrestling - Quick Coaching Cues, Ages 7-10

Use these reminders with the shared Coach Moves Reference. Full teaching steps, prerequisites, corrections and research are organized there by move ID. Follow the current practice task; an entry-only lesson does not authorize a finish.

## Stance and Footwork

**Full instruction:** B01: Wrestling Stance, p. 12 / B02: Motion and Level Change, p. 12

**B01 cues:** Knees bent, eyes ahead. / Hands forward, elbows in.

**B02 cues:** Step, follow, keep your base. / Hips down; eyes forward.

**Coach check:** Athlete folds at the waist, rocks onto heels, or narrows the feet.

**Fix:** Reset the foot spacing, bend knees and hips less, then test one small step and stop.

**Original practice links:** 2, 3, 4, 7, 9, 10, 12, 26

## Double Leg

**Full instruction:** B07: Double Leg Takedown, p. 15

**B07 cues:** Chest up, trail foot up. / Drive right; knees left.

**Coach check:** Attacker circles left around the head side or keeps driving straight.

**Fix:** Freeze at entry; point out the right-hand corner, then step across it.

**Original practice links:** 7, 9, 12, 21, 27, 28, 29, 30

## Single-Leg Entry

**Full instruction:** B08: Single Leg Run the Pipe, p. 15

**B08 cues:** Head inside; leg close. / Collect, pause, release.

**Coach check:** Starting the finish during entry-only work.

**Fix:** Pause at the coached leg collection, then release and reset.

**Original practice links:** 8

## Go-Behind Finish

**Full instruction:** B11: Sprawl and Go-Behind, p. 17

**B11 cues:** Clear the legs first. / Block the arm; circle to the hips.

**Coach check:** Defender circles early or lifts the chest, allowing another leg grab.

**Fix:** Pause with legs free and chest connected; establish the arm block before stepping around.

**Original practice links:** 11, 19, 22, 24, 26

## Bottom Base

**Full instruction:** B14: Referee's Bottom Start, p. 18 / B16: Belly to Base, p. 19

**B14 cues:** Knees behind; hand heels ahead. / Still until the whistle.

**B16 cues:** Outside knee up. / Hips back; knees underneath.

**Coach check:** Fingertips cross the line but the heels of the hands stay behind it, or bottom rocks before the whistle.

**Fix:** Check the base of each palm, then rehearse a still pause with an unpredictable whistle.

**Original practice links:** 6, 13, 14, 16, 17, 18, 23

## Stand-Up

**Full instruction:** B17: Inside-Leg Stand-Up, p. 20

**B17 cues:** Foot and chest up together. / Control the hand; hips clear, face.

**Coach check:** Turning while the rider's arm still hugs your waist.

**Fix:** Rehearse from standing: isolate the hand, create hip space, then turn.

**Original practice links:** 15, 18, 20, 23, 24, 27, 28, 29, 30

## Tight Waist and Chop

**Full instruction:** B22: Tight Waist Chop, p. 22

**B22 cues:** Drive forward as the elbow folds. / Chop, catch the wrist, follow.

**Coach check:** Top pulls the elbow sideways while sitting back.

**Fix:** Reset; use a small arm fold with forward toe pressure and the rear knee moving the hips.

**Original practice links:** 17, 18, 23, 24, 28, 29, 30

## Half Nelson and Defense

**Full instruction:** B26: Half Nelson, p. 24 / B27: Early Half Nelson Defense, p. 25

**B26 cues:** Elbow up; feet to the head. / Chest across; hips down.

**B27 cues:** Elbow in; look away early. / Same hand peels; then build.

**Coach check:** Top stays parallel and tries to win by pushing harder on the head.

**Fix:** Reset the half, step out to a T, and move the torso with chest pressure.

**Original practice links:** 25, 26, 28, 29, 30
