# Grindstone Wrestling - End-of-Practice Games

Thirty original coaching games. Choose by readiness and space; teach the stop signal and allowed contact before play. Everyone stays involved.

## G01 Traffic Light Trails

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Everyone moves; shared score | **Equipment:** Flat boundary dots

**Set up:** Use one minute to mark a roomy travel area and demonstrate three signals.

**Play:** Run three 40-second rounds with 20-second resets. Green means short walking steps; yellow means tiny steps; red means freeze in balance. Add one team point when everyone freezes inside their own space. Nobody leaves the game after a mistake.

**Change it:** Let an athlete call the final round while moving with the group.

**Coach watch:** Travel one direction; no racing, touching, or sudden backward steps into others.

## G02 Rocket Landing Pads

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Solo missions; team celebration | **Equipment:** One flat spot per athlete

**Set up:** Spend one minute giving each astronaut a pad with two arm-lengths of clearance.

**Play:** Play three 40-second missions with 20-second rests. Coach calls launch: rise onto toes; orbit: circle your pad; meteor: crouch; land: stop with two feet beside the pad. Award a shared star for each mission completed with quiet feet and clear spacing.

**Change it:** Older athletes remember a three-command sequence before beginning their mission.

**Coach watch:** Feet stay on or near the mat; no jumping toward another landing pad.

## G03 Animal Passport

**Group:** Pup / all ages | **Duration:** 5 minutes | **Format:** Individual explorers; shared challenge | **Equipment:** Flat spots; optional animal pictures

**Set up:** Use one minute to give each explorer a small travel lane and model three animals.

**Play:** Complete four 40-second journeys with 20-second rests. Travel like penguins with small steps, giants with careful long steps, or mice in a comfortable crouch. On safari, each athlete chooses an animal for others to copy inside their lanes. Collect one imaginary passport stamp each round.

**Change it:** Older groups switch animals when the coach silently raises a picture.

**Coach watch:** Keep separate lanes; no animal tackles, partner climbing, or jumping across lanes.

## G04 Statue Museum

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Everyone creates; group guesses | **Equipment:** One flat spot per athlete

**Set up:** Spend one minute assigning roomy spots and demonstrating a balanced two-foot statue.

**Play:** Run three 40-second exhibits with 20-second rests. Coach names a theme such as superhero, robot, or tall tree. Everyone makes a statue, then walks around their own spot until freeze. Choose two athletes to name the next themes; the whole museum stays involved.

**Change it:** Older athletes add a slow level change before returning to the same statue.

**Coach watch:** Statues balance independently; no standing on partners, headstands, or touching other exhibits.

## G05 Treasure Trail

**Group:** Pup / all ages | **Duration:** 5 minutes | **Format:** Parallel treasure collectors | **Equipment:** Flat picture cards and home spots

**Set up:** Use one minute to give every athlete a short lane, home spot, and three cards.

**Play:** Play four 40-second rounds with 20-second resets. Walk to the far end, collect one card, return home, and place it in a row. Once all three arrive, arrange the treasure into a story. Everyone completes their own trail; no winner takes another athlete's cards.

**Change it:** Older athletes travel sideways in stance and retell the story during the reset.

**Coach watch:** One athlete per lane; cards stay flat and nobody dives to collect them.

## G06 Team Shape Factory

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Small crews; cooperative puzzle | **Equipment:** Flat dots outlining separate work areas

**Set up:** Spend one minute forming crews of three in widely separated work areas.

**Play:** Use three 40-second builds with 20-second resets. Coach names a line, triangle, or curve. Crews walk into positions that make the shape, leaving space between bodies, then change who chooses the next shape. Award one factory point whenever everyone has a clear place.

**Change it:** Older crews build a letter or number and let another crew guess.

**Coach watch:** Make shapes using standing positions only; no linked arms, pulling, or human pyramids.

## G07 Robot Remote Control

**Group:** Pup / all ages | **Duration:** 5 minutes | **Format:** Noncontact pairs; rotating leaders | **Equipment:** Separate flat-marked squares

**Set up:** Use one minute to pair athletes across a generous gap and demonstrate robot commands.

**Play:** Run four 40-second rounds with 20-second rests, switching controller each round. Controller shows slow side steps, tiny forward steps, or a level change; robot copies while maintaining the gap. Each pair earns a battery when both freeze together on the coach's beep.

**Change it:** Older robots copy the opposite direction instead of matching the controller.

**Coach watch:** Hands stay to yourself; shorten steps whenever the gap or boundary becomes small.

## G08 Adventure Story Quest

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Whole group; personal movement spaces | **Equipment:** One spot per athlete

**Set up:** Spend one minute assigning clear spaces and showing the story's three movement choices.

**Play:** Tell three 40-second chapters with 20-second rests. Cross the swamp with careful steps, pass under branches with a level change, and guard the castle with a balanced freeze. Athletes vote on the next destination during rests. Everyone acts in place or around their own spot.

**Change it:** Let older athletes narrate a chapter using the same three safe movements.

**Coach watch:** Imaginary obstacles only; no crawling beneath partners or jumping into another person's space.

## G09 Rhythm Crew

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Everyone follows; shared pattern score | **Equipment:** None beyond personal mat space

**Set up:** Use one minute to spread athletes out and teach clap, step, and freeze.

**Play:** Play three 40-second music sets with 20-second rests. Coach performs a short pattern, such as clap-step-freeze, and everyone echoes it together. Add one action only after the crew repeats the pattern. Give a shared point for staying together, then let an athlete lead.

**Change it:** Older crews insert stance, level change, or a direction change into the rhythm.

**Coach watch:** No jumping into neighbors or slapping partners; sounds come from your own hands.

## G10 Invisible Balloon Keep-Up

**Group:** Pup / all ages | **Duration:** 4 minutes | **Format:** Solo imagination; cooperative count | **Equipment:** One personal floor spot each

**Set up:** Spend one minute spacing athletes and showing gentle imaginary balloon taps without leaving their spot.

**Play:** Run three 40-second flights with 20-second rests. Tap an imaginary balloon using alternating open hands, then catch it in balanced stance when the coach calls catch. Change the imagined balloon from tiny to enormous. The group counts consecutive controlled catches, restarting cheerfully after a wobble.

**Change it:** Older athletes change level between taps while keeping eyes forward.

**Coach watch:** Stay in your own space; no real balls, head taps, or jumping after balloons.

## G11 Hands Only Tag

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched pairs; shared total | **Equipment:** One marked square per pair

**Set up:** Use one minute to match partners and demonstrate gentle open-palm contact to hands only.

**Play:** Run four 40-second rounds with 20-second rests. Partners stay in stance and try to touch the back of the other's hand while protecting their own. Count clean touches together; restart in the center after each. Everyone plays simultaneously, and pairs try to improve their shared total.

**Change it:** Allow only the lead hand to tag, then switch hands next round.

**Coach watch:** No gripping, slapping, head contact, or chasing outside the square.

## G12 Knee Window Tag

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched pairs; alternating attacker | **Equipment:** Flat square markers

**Set up:** Spend one minute matching size and skill and showing a gentle touch above the kneecap.

**Play:** Use four 40-second rounds with 20-second rests, alternating attacker. Attacker changes level to touch the front of either knee; defender retreats or circles while staying in stance. A clean touch earns one point and a center reset. Defender earns a point for ten balanced seconds without a touch.

**Change it:** Limit the target to the lead knee before offering both knees.

**Coach watch:** Touch only; no knee grabbing, diving, stiff-arm pushing, or contact to the head.

## G13 Gate Guardian

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Noncontact pairs; attacker and guardian | **Equipment:** Two flat gates per pair

**Set up:** Use one minute to create separated squares, each with two wide gates on one edge.

**Play:** Play four 40-second rounds with 20-second rests, swapping roles. Attacker uses stance motion to cross either gate; guardian mirrors from a step away and closes a gate by standing in its lane. Attacker chooses the other opening. Each clean crossing scores; reset centrally after each attempt.

**Change it:** Give older attackers one silent level-change fake before choosing a gate.

**Coach watch:** No touching or blocking with arms; stop instead of squeezing through a closed gap.

## G14 Wrist Key Rescue

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched partners; alternating rescuer | **Equipment:** Separate pair squares

**Set up:** Spend one minute demonstrating a loose whole-wrist grip and a release that never bends fingers.

**Play:** Run four 40-second rounds with 20-second rests, swapping roles. Holder lightly controls one wrist; rescuer uses the free hand and a step to clear that contact and recover stance. Each clear earns the pair a key. Regrip only after both reset. Progress from cooperative release to light hand-following.

**Change it:** Alternate the captured wrist every attempt so both sides collect keys.

**Coach watch:** No finger peeling, wrist twisting, pulling straight arms, or dragging a partner.

## G15 Base Island Delivery

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Cooperative pairs; alternating traveler | **Equipment:** Two flat spots per pair

**Set up:** Use one minute to place each pair's islands a short knee-slide apart and review stable base.

**Play:** Complete four 40-second rounds with 20-second rests. Traveler moves from one island to the other on hands and knees. Follower stays beside the hips with light, separate waist-and-upper-arm contact. Earn one delivery when both arrive balanced. Swap roles each round; progress to traveler choosing either island.

**Change it:** Ready travelers add a pause and reverse direction while followers maintain spacing.

**Coach watch:** No breakdowns, squeezing, locked hands around the torso, or weight on the neck.

## G16 Circle The Castle

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched pairs; grounded angle contest | **Equipment:** Separate marked circles

**Set up:** Spend one minute showing a compact base, safe grounded pivots, and legal hip control.

**Play:** Run four 40-second rounds with 20-second rests, alternating attacker. Castle starts on hands and knees; attacker starts beside a shoulder with hands off the head. Attacker circles behind to control the hips for two seconds. Castle pivots to keep facing. Score the outcome, release, and reset together.

**Change it:** Start cooperatively; ready castles may take one knee-step instead of pivoting in place.

**Coach watch:** No head pulls, fast spins over trapped legs, standing, or dropping weight onto the back.

## G17 Escape Ticket Booth

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched partners; alternating bottom | **Equipment:** One square per pair

**Set up:** Use one minute to rehearse the taught hand-controlled stand-up and standing stop with each pair.

**Play:** Play four 40-second rounds with 20-second rests. Bottom controls the waist wrist and rises with balance; top follows using legal separate waist-and-wrist contact. Each controlled rise earns the pair a ticket. Stop at standing, release, and restart. Alternate bottom each round; increase following pressure only after clean repetitions.

**Change it:** Tickets count only when bottom can name the hand-control cue during the reset.

**Coach watch:** No lifts, mat returns, finger grips, squeezing, or pulling a rising partner backward.

## G18 Entry Parking Garage

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Cooperative pairs; rotating driver | **Equipment:** Flat entry-line markers

**Set up:** Spend one minute matching partners and checking each athlete's taught double-leg entry and stopping position.

**Play:** Use four 40-second rounds with 20-second rests. Receiver offers a stable stance; driver changes level, steps into a balanced entry, and parks without finishing. Receiver says parked when head and knee position remain controlled. Recover stance and swap driver after each attempt. Collect clean parks rather than racing.

**Change it:** Receiver may take one slow retreat before becoming stationary; driver chooses entry or reset.

**Coach watch:** No takedown finish, lifting, head-first contact, or driving through the receiver.

## G19 Breakdown Builders

**Group:** Ready beginners 7-14 | **Duration:** 5 minutes | **Format:** Matched pairs; cooperative construction | **Equipment:** Separate pair squares

**Set up:** Use one minute to verify the taught tight-waist/chop breakdown and controlled forearm-and-belly receiving.

**Play:** Run four 40-second rounds with 20-second rests, alternating top. Top completes the taught breakdown with separate hands, then eases pressure while bottom rebuilds base. One controlled down-and-up cycle builds one tower level. Pairs announce their tower height during rests. Add light base recovery only after smooth cooperative cycles.

**Change it:** Require both athletes to identify one balance cue before the next tower level.

**Coach watch:** No striking the elbow, stiff-arm posting, torso squeezing, or pressure through the head.

## G20 Coach's Photo Album

**Group:** Ready beginners 7-14 | **Duration:** 4 minutes | **Format:** Cooperative pairs; position challenge | **Equipment:** Optional picture cards

**Set up:** Spend one minute reviewing three known pictures: neutral stance, bottom base, and legal top start.

**Play:** Use three 40-second rounds with 20-second rests. Coach calls a picture; pairs move into that position without rushing and freeze for a pretend photo. Coach calls swap or new picture. Each correctly set photo earns a shared sticker. Top and bottom roles alternate at every grounded picture.

**Change it:** Coach silently shows position cards while pairs explain the needed hand placement.

**Coach watch:** Separate before changing positions; never jump onto a partner or force a rushed top start.

## G21 Two Door Escape

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Matched pairs; bottom chooses | **Equipment:** Separate pair squares

**Set up:** Use one minute to approve stand-up and sit-out mechanics and demonstrate each round's stop points.

**Play:** Run four 40-second rounds with 20-second rests, alternating bottom. Bottom chooses hand-controlled standing or sit-out facing; top follows with legal waist-and-wrist control. Balanced standing or facing earns bottom a door; maintaining control until time earns top one. Reset after each outcome and keep totals.

**Change it:** Bottom announces the chosen door first, then keeps the choice secret in later rounds.

**Coach watch:** No lifts, returns, neck holds, forced shoulders, or locked hands around a grounded torso.

## G22 Coach Corner Trios

**Group:** Ready older athletes; skills verified | **Duration:** 4 minutes | **Format:** Trios; rapid role rotation | **Equipment:** One square per trio

**Set up:** Spend one minute assigning bottom, top, and coach and confirming the taught escape objective.

**Play:** Run six 20-second rounds with 10-second resets. Bottom seeks hand-controlled standing; top follows legally. Third athlete coaches one cue and records balanced standing or maintained control. Rotate bottom to coach, coach to top, top to bottom after every round. Each trio earns points for the outcome and a useful cue.

**Change it:** Use a taught sit-out-to-face objective for the second rotation.

**Coach watch:** Coach stays outside the square; no shouting over stop, pulling fingers, lifting, or returns.

## G23 Hidden Mission Match

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Matched pairs; secret process goals | **Equipment:** Three simple mission cards per pair

**Set up:** Use one minute to rehearse belly-down starts under light, separate waist-and-wrist control.

**Play:** Play four 40-second rounds with 20-second rests, alternating bottom. Bottom secretly chooses base rebuild, wrist clear, or sit-out facing; top follows legally. Bottom scores on mission completion and names it at reset. Top scores if the mission remains incomplete at time. Reset after each outcome.

**Change it:** Choose a different mission each round; explain one useful response during rests.

**Coach watch:** Use taught grounded positions only; no neck holds, joint forcing, lifts, or mat returns.

## G24 Team Toolbox Bingo

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Simultaneous pairs; collective bingo | **Equipment:** Team chart with four named skills

**Set up:** Spend one minute listing double-leg entry, grounded go-behind, base rebuild, and hand-controlled stand-up.

**Play:** Use four 40-second rounds with 20-second rests. Each pair chooses a different chart skill each round and completes it twice cooperatively with roles reversed. Report a checked square during rest. The team wins bingo when every pair completes all four skills with controlled stops.

**Change it:** Ready pairs add the named skill's previously taught limited defensive response.

**Coach watch:** Entries stop before finishing; grounded control stays clear of head and neck; stand-ups stop before returns.

## G25 Pick The Puzzle

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Matched pairs; tactical choice | **Equipment:** Cards marked neutral and grounded

**Set up:** Use one minute to review hands-only tag and grounded sit-out-to-face against legal waist control.

**Play:** Run four 40-second rounds with 20-second rests. Chooser picks neutral or grounded; partner chooses a role. Neutral attacker lightly tags the back of defender's hand; defender evades. Grounded bottom starts in base and seeks sit-out facing; top follows with separate waist-and-wrist contact. Success scores one; reset. Swap chooser each round.

**Change it:** Explain why the chosen puzzle suits a practiced skill.

**Coach watch:** No head contact, takedowns, lifts, mat returns, or switching to unlisted techniques.

## G26 Boundary Detectives

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Matched pairs; awareness challenge | **Equipment:** Flat inner-square and buffer markers

**Set up:** Spend one minute marking each wrestling square and a clearly separated outer safety buffer.

**Play:** Use four 40-second rounds with 20-second rests. Partners play hands-only tag in stance. Either may call edge before a foot reaches the inner boundary; both freeze, identify the safe reset direction, and return centrally. Earn team points for clean touches and correct edge calls, never for forcing someone outward.

**Change it:** Older athletes identify the reset direction without the coach's cue.

**Coach watch:** Stop at the inner boundary; no pushing, blind retreat, grabbing, or crossing into another square.

## G27 Problem Solver League

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Pairs; cooperative improvement | **Equipment:** One score slip per pair

**Set up:** Use one minute to choose a taught problem: regain base or circle behind.

**Play:** Play four 40-second rounds with 20-second rests, alternating solver. Opponent supplies the agreed response: light waist following against base, or a grounded pivot against go-behind. Count controlled successes. During each rest, pair selects one adjustment and tries again. Award league points for explaining an improvement, not merely winning.

**Change it:** Pairs share their best cue with the neighboring pair after the final round.

**Coach watch:** Keep the agreed response; no head pulling, forced joints, unexpected takedowns, or escalating resistance.

## G28 Color Call Decision Game

**Group:** Ready older athletes; skills verified | **Duration:** 4 minutes | **Format:** Simultaneous pairs; reaction choices | **Equipment:** Red and blue cards

**Set up:** Spend one minute rehearsing belly-down starts under light, separate waist-and-wrist control.

**Play:** Use three 40-second rounds with 20-second rests. From belly-down, blue means rebuild base; red means rebuild then sit out to face. Top follows with legal waist-and-wrist contact. Coach shows a card; stop on the outcome, reset, and swap roles. Earn one point for choosing correctly and one for controlled execution.

**Change it:** Show the card briefly after two clear rounds; partners remember the choice.

**Coach watch:** No switching mid-turn, neck pressure, lifting, returns, or twisting a trapped arm.

## G29 Captain's Challenge Cards

**Group:** Ready older athletes; skills verified | **Duration:** 5 minutes | **Format:** Small teams; everyone active | **Equipment:** Cards for three taught objectives

**Set up:** Use one minute to review wrist clear, grounded go-behind, and hand-controlled standing.

**Play:** Run four 40-second rounds with 20-second rests. Each team captain chooses one objective for all its pairs; partners alternate roles after each attempt. Teams earn one point per pair completing both roles with control. Rotate captain during every rest, and use that rest to explain the next challenge.

**Change it:** Let the other team pick your objective from the same approved cards.

**Coach watch:** Use matched pairs; no head holds, body lifts, returns, or resistance beyond the agreed level.

## G30 Rock Paper Wrestling

**Group:** Ready older athletes; skills verified | **Duration:** 4 minutes | **Format:** Matched pairs; quick choice rounds | **Equipment:** Separate pair squares

**Set up:** Spend one minute reviewing rock-paper-scissors, choosing first roles, and rehearsing grounded go-behind versus facing.

**Play:** Play six 20-second rounds with 10-second rests. During each rest, play rock-paper-scissors; winner chooses attacker or defender. Start the next round beside a compact base. Attacker circles behind to control hips; defender pivots to face. Each outcome scores one point, then reset. Everyone plays simultaneously.

**Change it:** Use a taught sit-out-to-face contest with the winner choosing top or bottom.

**Coach watch:** Hands stay off head and neck; no lifts, fast spins, or forcing trapped joints.
