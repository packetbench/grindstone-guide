# Grindstone Wrestling - Move Research and Teaching Review

72 individual move reviews | Pup / Beginner / Advanced | September 26, 2026

Each move received its own research-agent assignment. This report records the inspected sources, the specific variant chosen, corrections, teaching progression, and evidence limits. The compact coach cards are a practical summary; use this report to prepare demonstrations and understand the reasoning.

The proposed rehearsal counts, game formats, and simplified progressions are coaching designs unless an entry says otherwise. A source listing a move is not evidence for every grip or direction. See each entry's source coverage before treating a detail as verified.

## Find a move

| ID | Tier | Coach-friendly name | Previous name |
|---|---|---|---|
| P01 | Pup | [Wrestling Stance](#p01) | Ready Wrestling Stance |
| P02 | Pup | [Stance Steps](#p02) | Small Stance Steps |
| P03 | Pup | [Level Change](#p03) | Comfortable Level Change |
| P04 | Pup | [Level Change and Step](#p04) | Step-In Entry Pattern |
| P05 | Pup | [Bottom Base](#p05) | Hands and Knees Base |
| P06 | Pup | [Solo Belly to Base](#p06) | Base Travel and Recovery |
| P07 | Pup | [Solo Sprawl](#p07) | Solo Sprawl Shape |
| P08 | Pup | [Solo Stand-Up](#p08) | Solo Stand-Up Movement |
| P09 | Pup | [Solo Sit-Out](#p09) | Solo Sit-Out Movement |
| P10 | Pup | [Hip-Heist Preparation](#p10) | Low Hip-Heist Preparation |
| P11 | Pup | [Go-Behind Footwork](#p11) | Circle to the Hip Marker |
| P12 | Pup | [Side Breakfall Prep](#p12) | Low Side Receiving |
| B01 | Beginner | [Wrestling Stance](#b01) | Balanced Wrestling Stance |
| B02 | Beginner | [Motion and Level Change](#b02) | Motion And Level Change |
| B03 | Beginner | [Penetration Step](#b03) | Penetration Step And Recovery |
| B04 | Beginner | [Wrist and Inside Tie](#b04) | Wrist Tie To Inside Control |
| B05 | Beginner | [Arm Drag to Go Behind](#b05) | Arm Drag To Rear Position |
| B06 | Beginner | [Elbow Pop](#b06) | Pop And Go |
| B07 | Beginner | [Double Leg Takedown](#b07) | Double Leg Corner Finish |
| B08 | Beginner | [Single Leg Run the Pipe](#b08) | Head-Inside Single Circle Finish |
| B09 | Beginner | [Sweep Single](#b09) | Sweep Single To Cover |
| B10 | Beginner | [Snap-Down Go-Behind](#b10) | Snap And Spin |
| B11 | Beginner | [Sprawl and Go-Behind](#b11) | Sprawl And Go Behind |
| B12 | Beginner | [Down Block and Circle](#b12) | Down Block And Circle |
| B13 | Beginner | [Peek-Out Recovery](#b13) | Recover A Stopped Shot |
| B14 | Beginner | [Referee's Bottom Start](#b14) | Referee's Bottom Start |
| B15 | Beginner | [Referee's Top Start](#b15) | Referee's Top Start |
| B16 | Beginner | [Belly to Base](#b16) | Build Base From Belly |
| B17 | Beginner | [Inside-Leg Stand-Up](#b17) | Stand Up With Hand Control |
| B18 | Beginner | [Sit-Out](#b18) | Sit Out And Turn In |
| B19 | Beginner | [Hip-Heist Escape](#b19) | Hip Heist To Face |
| B20 | Beginner | [Switch](#b20) | Switch Reversal |
| B21 | Beginner | [Stand-Up Finish](#b21) | Standing Cutaway Escape |
| B22 | Beginner | [Tight Waist Chop](#b22) | Tight Waist And Chop |
| B23 | Beginner | [Near Ankle Breakdown](#b23) | Near Ankle Breakdown |
| B24 | Beginner | [Spiral Breakdown](#b24) | Spiral Breakdown |
| B25 | Beginner | [Near Wrist Ride](#b25) | Near Wrist Ride |
| B26 | Beginner | [Half Nelson](#b26) | Half Nelson Turn |
| B27 | Beginner | [Early Half Nelson Defense](#b27) | Early Half Nelson Defense |
| B28 | Beginner | [Half Nelson Pin Finish](#b28) | Chest-To-Chest Pin Finish |
| B29 | Beginner | [Near-Side Cradle](#b29) | Near-Side Cradle |
| B30 | Beginner | [Early Cradle Defense](#b30) | Early Cradle Defense |
| A01 | Advanced | [Russian Tie to Single Leg](#a01) | Russian Two On One To Single |
| A02 | Advanced | [Underhook Knee Pick](#a02) | Underhook Cross Knee Pick |
| A03 | Advanced | [Underhook Duck Under](#a03) | Underhook Duck Under |
| A04 | Advanced | [High Crotch to Double](#a04) | High Crotch To Double |
| A05 | Advanced | [Single Leg to Double](#a05) | Run The Pipe To Double |
| A06 | Advanced | [Backside Single Finish](#a06) | Backside Shelf To Cover |
| A07 | Advanced | [Sweep Single Recovery](#a07) | Sweep Single Rebuild Against Sprawl |
| A08 | Advanced | [Down Block to Ankle Reattack](#a08) | Down Block To Re Shot |
| A09 | Advanced | [Standing Whizzer Defense](#a09) | Whizzer And Hip Defense |
| A10 | Advanced | [Limp Arm](#a10) | Limp Arm From The Whizzer |
| A11 | Advanced | [Single Leg Kickout](#a11) | Single Leg Hand And Hip Clear |
| A12 | Advanced | [Front Headlock Drag-Out](#a12) | Front Headlock Elbow Drag |
| A13 | Advanced | [Russian Tie Clear to Underhook](#a13) | Two On One To Underhook Chain |
| A14 | Advanced | [Stand-Up Hand Fighting](#a14) | Stand Up Clear And Reclear |
| A15 | Advanced | [Sit-Out to Stand-Up](#a15) | Short Sit To Stand Up |
| A16 | Advanced | [Short Sit to Switch](#a16) | Short Sit To Switch |
| A17 | Advanced | [Reswitch](#a17) | Switch And Re Switch |
| A18 | Advanced | [Quad-Pod Stand-Up](#a18) | Tripod To Hand Controlled Stand Up |
| A19 | Advanced | [Spiral Ride to Near Wrist](#a19) | Spiral Ride To Wrist Control |
| A20 | Advanced | [Claw Breakdown to Near Wrist](#a20) | Claw Control To Wrist Ride |
| A21 | Advanced | [Near Wrist Tilt](#a21) | Near Wrist Tilt |
| A22 | Advanced | [Two-on-One Tilt](#a22) | Near Side Two On One Tilt |
| A23 | Advanced | [Arm Bar Turn](#a23) | Short Bar Arm Walking Turn |
| A24 | Advanced | [Near Wrist to Half Nelson](#a24) | Cross Wrist To Half Nelson |
| A25 | Advanced | [Far-Side Cradle](#a25) | Far Side Cradle |
| A26 | Advanced | [Near-Side Cradle Decision Drill](#a26) | Cradle Finish And Early Defense Chain |
| A27 | Advanced | [Half Nelson Settle Drill](#a27) | Pinning Control Angle Adjustment |
| A28 | Advanced | [Cross-Wrist Clear](#a28) | Two On One Clear To Base |
| A29 | Advanced | [Double Leg to Tight Waist Chop](#a29) | Takedown To Breakdown Chain |
| A30 | Advanced | [Near Wrist Tilt or Half](#a30) | Wrist Tilt Or Half Decision |

<a id="p01"></a>

## P01 - Wrestling Stance

**Tier:** Pup | **Previous name:** Ready Wrestling Stance

### Technical review

The original correctly introduced a modest stagger, knee and hip flexion, forward attention, relaxed hands, and brief practice rather than a prolonged crouch. Its main problem was under-specification: feet 'comfortably apart' can become a narrow tightrope, hands 'loosely in front' can leave the elbows spread, and choosing a taller version can become nearly straight-legged standing. These are repairable omissions, not a need to replace the activity. The revised card keeps the welcoming solo format while giving the coach visible checkpoints and a repeatable start and reset.

### Selected variant

A shallow staggered neutral stance, initially with the child's own right foot leading, then mirrored after standing to reset. This preserves the original variant and leads naturally into P02 stance steps and P03 level change. The card does not mix a square stance into the same repetition. Shoulder-width is an adjustable demonstration starting point, not a required anatomical measurement or a universal competition stance.

### Mechanics and evidence

- USA Wrestling distinguishes staggered and square stances. Its staggered version has a broad foot spread, flexed legs, hands ahead, elbows inside, head raised, and the chest forward over the knee. These features support the chosen stance; the shallow depth is the Pup adaptation. [S1]
- The club syllabus reinforces flexed knees, inward hand/elbow position, and aligned shoulders and hips. Facing the demonstrator discourages an exaggerated sideways fighting stance. Its movement section also requires preserving stance as the feet move. [S2]
- USA Wrestling includes forefoot pressure in its positional principles. The card translates this into light pressure toward the balls of both feet without demanding elevated heels or an exact weight split. Keeping the back long and looking forward avoids interpreting head-up as throwing the chin back. [S1]

### Teaching progression

- Demonstrate once from the front for foot spacing and elbows, then from the side for knee bend and trunk position. Let the child copy one feature at a time. Coach-adjusted stance width and depth should permit an easy standing reset.
- Begin with three unresisted solo repetitions, each followed by standing rest. No receiver, grip, release, or partner pressure is involved. Do not test balance by pushing a child.
- After copying is reliable, use the defined raised-hand/lowered-hand signal. The response is to build the stance or release it, not to freeze for endurance. Mirroring the lead foot comes after success, without requiring a jump-switch.
- Readiness for P02 is independent rebuilding of the stance with bent knees, hands forward, and stable foot spacing. Stance practice should recur alongside later skills; Kolat makes stance and motion a recurring foundational focus and treats advancement as demonstrated understanding rather than elapsed time. [S3]

### Common mistakes and corrections

- If the feet become a tightrope, place two flat foot targets with sideways separation and a small stagger. If the stagger becomes a lunge, shorten it until the child can stand without taking a recovery step.
- If only the trunk folds, return to standing and lower less through knees and hips. If elbows flare or hands hang down, briefly copy the coach's compact arm position before rebuilding the whole stance. These are teaching corrections for the positional checkpoints, not additional techniques.

### Readiness and rules

Pup is a readiness tier. This solo stance lesson does not establish readiness for live wrestling, contact, or competition. It has no grip or scoring-rule dependency. Children who cannot maintain balance with a small bend should practice ordinary standing and copying first; discomfort is not a reason to force greater depth.

### What changed

- Renamed Ready Wrestling Stance to Wrestling Stance.
- Specified a modest stagger, lateral foot spacing, elbows-in position, and balance over both feet.
- Added a defined visual response and standing reset while retaining brief, playful solo rehearsal.
- Made the original accommodating stance height a smaller knee/hip bend rather than an unrestricted upright substitute.

### Evidence limits

Inspected the written USA Wrestling study guide, the club syllabus text, and Kolat's curriculum text; no linked videos were watched. S1 and S2 verify basic mechanics, while S3 supports curriculum placement and readiness-based progression rather than exact limb positions. Kolat's '4-6 Year' title refers to a multi-year curriculum, not an endorsement of wrestling instruction for ages four to six. Foot markers, the shallow initial bend, the three-repetition rehearsal, and the hand-signal game are original coaching design, not research-established doses.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF extracted text, page 1: Skill 1 Position and the separate staggered/square stance descriptions; page 2: Skill 2 Motion.

**Supports:** Staggered stance mechanics: foot spread, bent legs, hands forward, elbows in, head up, chest forward.; Forefoot pressure and maintaining position during motion.

**Limits:** A written study guide to a longer video; the linked video was not inspected. It does not prescribe this Pup game, exact stance width, or repetition count.

**S2: [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Full webpage text, specifically section I-A, Stance, Motion, Changing Level, and Making Contact.

**Supports:** Bent knees, hands and elbows in, shoulders and hips aligned.; Stance maintained during short, uncrossed steps; knee bend rather than waist-only folding.

**Limits:** A club coaching syllabus compiled from multiple coaching sources, not an experimental study. It gives concise checkpoints rather than a complete Pup progression.

**S3: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** PDF extracted text, page 1: How the Levels Should Be Approached; page 4: Level 1 Feet, Stance teaching note and two stance listings.

**Supports:** Stance and motion belong in repeated foundational teaching.; Advance through levels by demonstrated execution and understanding, with individual progression.

**Limits:** The stance section is a curriculum listing, not a mechanical demonstration. The title describes curriculum duration, not a four-to-six-year-old age group. No linked member videos were inspected.

<a id="p02"></a>

## P02 - Stance Steps

**Tier:** Pup | **Previous name:** Small Stance Steps

### Technical review

The original was a sound introduction to stance motion: short steps, the foot nearest the direction moving first, uncrossed feet, and a balanced pause all serve wrestling rather than merely general locomotion. Its main weakness was instructional ambiguity. A new coach had to infer which foot led backward, how far the following foot should travel, and whether the child could turn toward the marker or walk between destinations. The replacement makes a left-lead stance explicit, preserves that lead during forward and backward travel, and keeps the wrestler facing the coach during lateral travel. Markers are optional lane boundaries rather than foot targets that encourage looking down. The shorter name retains the actual skill.

### Selected variant

Solo step-and-follow motion from a slightly staggered, left-foot-forward stance. Directions are taught separately before the coach chooses the next direction. The left lead is a demonstration choice, not a claim that every wrestler must lead left; a coach can mirror the entire sequence for an established right lead.

### Mechanics and evidence

- USA Wrestling describes staggered and square stances with bent legs, a broad base, forward hands, tucked elbows and head up. Its motion section calls for lateral adjustment and travel into and away from an opponent while retaining strong position. These support maintaining the stance through the task rather than standing up between steps. [S1]
- Preston Mat Club explicitly teaches short, light, step-slide motion without crossing the feet and while maintaining stance. In this slow first lesson, the following foot restores the initial spacing; it does not slide all the way into the first foot. [S2]
- The UWW-hosted research description specifies leading toward the lateral direction, following with the other leg, maintaining bent knees, and avoiding crossed or touching ankles. It also explains that lateral motion keeps the opponent in front. Its quick hopping fitness-test variant is not used here. [S3]

### Teaching progression

- Demonstrate beside the child while facing the same direction, so left and right are not reversed by a face-to-face demonstration. Show the beginning and ending foot spacing before asking for continuous travel.
- Rehearse forward, lateral and then backward step pairs at a self-selected slow pace. The coach checks the empty retreat lane. There is no receiving partner or external resistance at this stage.
- After the child can stop balanced, introduce a single visible directional signal. The defined reaction is one step-and-follow in that direction, followed by a freeze. Progress to another direction only after both feet are settled. Later partner mirroring belongs after reliable stopping and spacing.

### Common mistakes and corrections

- Feet collide or cross: shorten the travel and use two temporary starting foot marks to show the stance width that should return after each pair of steps.
- The first step becomes a lunge: move a nearer distance so the hips travel with the feet instead of reaching the foot far away.
- The child turns toward the side destination or watches the feet continuously: keep the coach as the visual target and rehearse a single sideways pair while the chest remains forward.

### Readiness and rules

Pup indicates readiness for this introductory task, not automatic permission based on age. The relevant check is pain-free stepping and stopping with separated feet. No contact, grip, joint load or scoring action is introduced, so no event-specific legality claim is needed. A stumble calls for a smaller step or rest, not greater speed.

### What changed

- Renamed Small Stance Steps to Stance Steps.
- Specified the lead foot and the first foot in every direction.
- Made restoring stance spacing and facing the target explicit.
- Replaced a destination game with a defined directional reaction after isolated rehearsal.

### Evidence limits

Inspected source text and extracted PDF text; no linked instructional video was watched. The club syllabus contains actual movement cues, not only technique titles. The research article describes a fitness-test side-step and does not establish an optimal teaching method for children. The left-lead example, paused progression, lane arrangement and 20-30-second game are original coaching design, not validated doses. The cited sources do not dictate the exact forward/backward foot sequence; that sequence is the selected basic step-and-follow implementation that preserves a staggered lead.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Extracted PDF text on pages 1-2: Skill 1 Position and Skill 2 Motion, including stance features and multidirectional movement. Did not view the linked video.

**Supports:** Bent-leg staggered and square stances with hands forward, elbows in and head up; Moving laterally, toward and away while maintaining position

**Limits:** Study guide summarizes instruction; does not prescribe the exact step-and-follow foot order or a Pup drill duration.

**S2: [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Opened webpage text, section I-A, Stance and Motion entries.

**Supports:** Short steps and step-slide motion; Do not cross feet; retain stance and control

**Limits:** Brief club coaching syllabus; no individual author or age-specific progression is stated.

**S3: [Methodological Development of Wrestling Shuttle Test](https://academy.uww.org/app/uploads/2019/06/METHODOLOGICAL-DEVELOPMENT-OF-WRESTLING.pdf)** - International Journal of Wrestling Science; authors Kazunori Iwai, Ray Takahashi, Kenichi Yumoto and Koichi Nakazato; hosted by UWW Academy; accessed 2026-09-26.

**Inspected:** Extracted PDF text on PDF pages 2 and 4 (printed pages 22 and 24), especially Description of side-stepping movement and its key points.

**Supports:** Lateral lead foot travels toward the direction, followed by the other leg; Avoid crossed or touching ankles while retaining bent knees; Lateral motion helps keep an opponent in front

**Limits:** Describes a wrestling fitness test, including a fast hopping version; does not validate this slow introductory game or child-specific readiness. UWW hosting does not make it an official coaching rule.

<a id="p03"></a>

## P03 - Level Change

**Tier:** Pup | **Previous name:** Comfortable Level Change

### Technical review

The original correctly selected a small, unloaded lowering action and identified waist-only bending as an error. It also appropriately let the child use an achievable depth. Its main teaching weakness was the 'grow tall' cue and tree game: these could reward leaving wrestling stance after every repetition. The written return to the original height was better than that cue, but the two messages conflicted. The purpose also omitted why a wrestler changes level. This revision keeps the genuine foundational action, connects it to a future entry, and makes the finish a balanced stance. It does not turn a shallow level change into a full penetration step or claim that a solo repetition is a takedown.

### Selected variant

An in-place solo level change from a staggered stance, followed by recovery to that same stance height. Either lead foot works because the action has no side-specific grip or finish; the feet keep their positions during each repetition. This isolates lowering before P04 adds a step. The selected range is deliberately small and individualized rather than prescribed by an angle or target depth.

### Mechanics and evidence

- USA Wrestling identifies lowering the hips and bending the knees as the level-change action, with penetration treated as the next skill. Its stance description places the hands forward, elbows near the body and legs bent. These are the retained mechanical anchors. [S1]
- Preston Mat Club explicitly distinguishes knee bending from bending at the waist and teaches stance maintenance during motion. The correction therefore checks whether the hips actually descend, rather than merely whether the child's face stays pointed forward. [S2]
- A staggered stance already has some forward torso inclination. 'Back firm' means preserve useful posture during the small lowering; it does not demand a vertical torso or an exaggerated back arch. This is the audit's coaching interpretation of the source position cues, not a measured spinal-angle prescription. [S1]
- There is no receiver, grip, release or impact in this variant. Both feet remain the base of support. Returning to the initial bent-knee stance is the task-specific reset; full relaxation happens after the repetition.

### Teaching progression

- Demonstrate from the side so the learner can see the hips descend. Show the starting and finishing stance at the same height. Keep the demonstration shallow enough to copy without strain.
- Begin with two slow, unopposed copies and a rest. Observe whether the child can pause at the lower point and return without a recovery step. These repetitions and pauses are proposed coaching design, not a research-established dose.
- Add a defined visual reaction only after the action is recognizable: the coach lowers a hand to request lowering and raises it to request the original stance. The coach stays outside contact distance. A child should react with the legs and hips rather than reach for the hand.
- Readiness for a later entry is a repeatable, balanced lowering with the gaze forward and knees still bent on recovery. Add the P04 step only after this is consistent; short stance steps from P02 can be practiced separately.

### Common mistakes and corrections

- If the head dives while the hips remain high, reduce the range and demonstrate the hips moving downward. Looking at a picture alone cannot correct this error because a child can crane the neck while still folding at the waist.
- If the learner stands fully upright, remove the tall-tree cue and point out the initial stance height. Separate the active reset from the rest between repetitions.
- If the child drops into an uncontrolled deep squat or has to shuffle to recover, shorten the bend and slow the action before adding a signal. Do not use depth or speed as the success measure.

### Readiness and rules

Pup is a readiness tier, not permission based on age. This card is a noncontact standing foundation with no scoring claim or hold requiring a legality ruling. A coach must observe a pain-free range and stable support. Partner pressure, penetration to the knee and attack finishes require their own instruction; mastery of this card does not establish readiness for them.

### What changed

- Renamed Comfortable Level Change to Level Change.
- Replaced growing tall with recovery to the original wrestling stance.
- Specified planted feet, lowered hips, retained hand position and a small balanced range.
- Replaced the ornamental tree progression with an explicit noncontact visual reaction.

### Evidence limits

Inspected the USA Wrestling study guide's actual PDF text and the club's actual syllabus text. The former provides substantive level-change and stance mechanics; the latter independently supplies the key knee-versus-waist correction, though its treatment is brief. No linked videos were viewed. The hand-signal game, two-repetition introduction, individualized depth and readiness checks are this audit's coaching design. The sources do not establish a universal Pup age, exact knee angle or training dose.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling, Coaches Corner; accessed 2026-09-26.

**Inspected:** PDF text, page 1 stance/position section and page 4 Skill 3 of 7 Level Change (25:42-28:14) and level-change drills.

**Supports:** Lowering hips and bending knees are central to level change.; Staggered stance uses bent legs, hands forward and elbows in.; Level change is distinguished from the following penetration skill.

**Limits:** A written study guide accompanying a video, not the video itself. Partner attack drills in the guide are beyond the selected Pup variant. It supplies no Pup-specific depth or repetition prescription.

**S2: [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club via WV-Mat; accessed 2026-09-26.

**Inspected:** Full page text, especially I.A Basic Skills for Wrestling in Neutral Position: Stance, Motion, Changing Level and Penetration.

**Supports:** Changing level requires bending the knees rather than folding at the waist.; Maintain wrestling stance during motion.; Stance precedes level change and penetration in the club's foundation sequence.

**Limits:** Brief club coaching syllabus with no named individual author, measurements or age-specific progression. Its other techniques and historical rules were not relied on for this card.

<a id="p04"></a>

## P04 - Level Change and Step

**Tier:** Pup | **Previous name:** Step-In Entry Pattern

### Technical review

The draft contains a useful preparation sequence: level change before forward travel, a short lead-foot step, and recovery without partner contact. Its limitation is the implied connection between that sequence and a complete entry. A shallow step followed by a standing reset does not demonstrate penetration through an opponent, leg control, or a finish. It should therefore retain a preparatory purpose. The phrase 'gather the feet' in the original drill also conflicts with the stable base taught in the adjacent stance cards. The revision names the actual actions and makes the rear foot's destination explicit. Knee clearance is a restriction of this exercise, not a universal rule for wrestling entries.

### Selected variant

Solo level change followed by a short right-lead step and left-foot recovery into the same staggered stance. The left leg supplies gentle forward movement; the hips accompany the lead foot. There is no knee drop, pivot, contact, grip, receiver, or takedown. Left-lead practice is a separate mirrored repetition after resetting. This retains the original card's low-complexity objective without mislabeling the drill as a finished shot.

### Mechanics and evidence

- USA Wrestling describes lowering the hips with knee bending, then distinguishes penetration through the opponent from simply reaching the legs. These support the drill's order and its limited preparatory label. [S1]
- Bemidji's coaching outline specifies a spread stance, bent knees, a straight back, and a low entry powered by the legs without overextension. The short marker distance applies those principles while keeping the hips from being left behind. [S2]
- The PRTC description of Brandon Slay's penetration instruction includes level change, knee action, trail-leg recovery, pivoting, and driving across. It confirms that a full taught penetration sequence contains more than this standing exercise. It does not establish that every legitimate attack must touch a knee down. [S3]
- Recovering the left foot behind and beside the right preserves the starting stance. The exact marker placement and recovery endpoint are coaching choices for this preparation activity, not claimed as a source-prescribed takedown variant.

### Teaching progression

- Demonstrate from the side so the learner sees hips lower before forward travel, then from the front to show foot spacing. Review stance, stance steps, and level change first; none depends on this card.
- Use slow solo imitation with no external resistance. Check that the learner finishes without an extra balancing step, crossed feet, or hands touching down. Shorten the step when those checks fail.
- Add one defined visual reaction only after imitation is consistent: the coach lowers a hand, and the learner performs one complete sequence. The repetition count is proposed coaching design. A full penetration lesson remains a separate progression requiring its own knee transition, trail-leg action, contact position, and finish.

### Common mistakes and corrections

- If the learner bows the chest instead of lowering the hips, rehearse the small level change in place before adding travel.
- If the front foot reaches away while the hips remain behind, shorten the marker distance and ask for the body to travel with the step.
- If the rear foot closes next to the lead foot, demonstrate the original stagger again and recover only enough to recreate it.

### Readiness and rules

Pup describes readiness, not automatic age clearance. The activity needs enough balance to lower, travel, and stop on both feet. It has no receiver or competition scoring claim; no rule-specific legality assertion is needed. The no-knee-contact boundary belongs to this standing drill and must not be taught as a prohibition on knee-touch entries elsewhere.

### What changed

- Replaced 'Step-In Entry Pattern' with the plain action name 'Level Change and Step.'
- Explicitly identified a preparation drill rather than implying a complete penetration step.
- Specified right lead, left-leg push, hip travel, and left-foot recovery into a spread staggered base.
- Removed the instruction to gather the feet and added a simple visual-signal progression.

### Evidence limits

Inspected the extracted PDF text of USA Wrestling's study guide and Bemidji's coaching outline, plus PRTC's written video description. No linked instructional video, transcript, or frames were inspected. The sources substantiate general stance, lowering, forward drive, and the broader penetration sequence; they do not prescribe this exact solo marker exercise or its repetitions. The card's adaptation and readiness checks are original coaching design. Bemidji's historical scoring information was not used.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Extracted PDF text, pages 1-2 for stance and motion and pages 4-5 for level change and penetration (zero-based pages 0-1 and 3-4).

**Supports:** Stance uses separated feet, bent legs, and hands forward.; Level change lowers the hips through knee bending.; Penetration aims through the opponent's legs and has multiple entry variants.

**Limits:** Study-guide text, not direct inspection of its linked videos. Does not teach this exact standing preparation drill.

**S2: [Bemidji Elementary Wrestling: Basic Move Progression and Scoring](https://cdn1.sportngin.com/attachments/document/0139/5030/_Coaches_Page__elementary_move_progression.doc.pdf)** - Bemidji Elementary Wrestling; accessed 2026-09-26.

**Inspected:** Extracted PDF text, page 1, Stance and Penetration step sections.

**Supports:** Maintain a spread stance with bent knees and a straight back.; Lower by bending the knees; drive from a low position using the legs without overextending.

**Limits:** Concise club teaching outline without named individual author; no detailed knee-to-mat footwork. Historical scoring and other techniques were not used.

**S3: [Brandon Slay: 3 x 5 System Penetration](https://www.pennsylvaniartc.org/video-gallery/view/145)** - Pennsylvania Regional Training Center; accessed 2026-09-26.

**Inspected:** Public page's written explanatory paragraph describing coach Slay's penetration sequence.

**Supports:** The described complete penetration sequence includes level change, knee action, trail-leg recovery, pivot, and driving across.

**Limits:** Only the page description was inspected; the embedded video was not watched. Does not verify exact foot angles, timing, or a universal requirement for knee contact.

<a id="p05"></a>

## P05 - Bottom Base

**Tier:** Pup | **Previous name:** Hands and Knees Base

### Technical review

The original has a reasonable first support position: palms beneath shoulders, knees beneath hips, a clear head, and brief repetitions. Its main weakness is the purpose and feedback. A table-building game can reward a motionless silhouette even if the wrestler cannot keep the chest supported when a hand moves. However, a level-backed tabletop is a recognized bottom stance; it should not be dismissed as inherently non-wrestling. The repair retains that accessible position and makes support during a small action the success criterion. It does not demand whole-body stiffness, a deep elbow bend, or a prolonged hold. [S1]

### Selected variant

Solo tabletop bottom base, followed by one small hand release and replacement. This is an introductory foundation for bottom movement, not a complete escape, a partner pressure drill, or a lesson in the formal referee's starting position. A squat-back stance is another legitimate choice, but adding its hip position to this tabletop card would blur the demonstration.

### Mechanics and evidence

- Applegate's tabletop instruction places the thighs approximately upright, the back approximately horizontal, the head raised, and the heels of the hands pressed into the mat. His broader bottom instruction includes keeping elbows inside and restoring a lost base. This supports a purposeful tabletop base rather than passive stretching. [S1]
- Johnson describes several bottom bases, including kneeling, and emphasizes resisting collapse onto the stomach and avoiding backward reaches for the opponent. Thus the objective is a usable position, not a single permanently held body shape. [S2]
- USA Wrestling's Bottom Motion section connects restoring base with the next movement toward the feet. Its belly-to-base instruction includes freeing arms, bringing a knee underneath, and keeping the head up. P05 stops before those partner-dependent skills and provides the support they require. [S3]

### Teaching progression

- Demonstrate from the front and side so the athlete sees both support spacing and chest height. Explain that the wrestler needs to stay supported while moving, then show a small shift with all four main supports still touching.
- Begin with two brief solo builds, each followed by rest. Observe that the athlete can breathe and make a small adjustment without the head dropping. The number of repetitions is a proposed teaching choice, not an evidence-established dose.
- Once stable, shift toward the remaining palm before briefly releasing the other. The named-hand signal supplies a defined reaction without adding a rider. Coach or partner only gives the cue and observes; there is no receiving contact or grip to release.
- Readiness for the next floor lesson is repeatable replacement of either hand without chest collapse or rolling onto a hip. Then progress to P06's base travel. Holding still longer is not the progression target.

### Common mistakes and corrections

- If the athlete reaches far away, move the hand back near its starting support point and rehearse shifting before lifting. This separates balance from reaching distance.
- If the elbows buckle, keep both hands down and shorten the repetition. If the athlete instead locks everything and holds their breath, ask for one easy breath and a tiny shift; do not add a rigid brace cue.
- If the chin cranes upward, lower the visual target. Head clear means avoiding contact while maintaining support, not forcing neck extension.

### Readiness and rules

Pup is a readiness tier. This card requires pain-free support and ability to respond to a stop cue, not a particular age. No partner weight, breakdown, joint restraint, scoring claim, or formal starting-line requirement is taught. Event-specific referee-position rules must be taught separately when actual top-and-bottom starts are introduced.

### What changed

- Shortened the name to Bottom Base and identified the tabletop variant in research.
- Changed the aim from making a static table to preserving support during a small hand movement.
- Added the weight shift before a hand leaves the mat and an explicit replacement/reset.
- Kept the drill solo and replaced a timed hold with brief build, action, and rest repetitions.

### Evidence limits

Inspected accessible text of Applegate's coach-authored manual, Johnson's PDF, and USA Wrestling's written study guide. No linked video was watched. Applegate is hosted by a third-party document service; its historical rules, body-type prescriptions, and other techniques are not adopted. The sources establish base mechanics and its place in bottom wrestling, not a validated Pup protocol. Hand-width wording, the tiny hand-release exercise, signal progression, breathing check, and rest schedule are coaching adaptations. Exact limb angles and toe placement are not prescribed because they are unnecessary for this solo foundation.

### Sources inspected

**S1: [Basic Wrestling Fundamentals: Bottom Position Wrestling Skills and Table Top Stance](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate)** - Warren Applegate; accessible document text hosted by Scribd; accessed 2026-09-26.

**Inspected:** Accessible page text containing the manual's Bottom Position Wrestling Skills section around printed pages 40-41 and Table Top Stance before printed page 44; browser text lines 365-390. Also inspected the base/tabletop glossary definitions.

**Supports:** Tabletop is a legitimate bottom stance; Thighs upright, back roughly parallel to mat, head up, palm-heel pressure; Elbows inside and restoring base are bottom fundamentals

**Limits:** Third-party hosting of a coach-authored manual. No video inspected. Does not establish the proposed solo hand-release drill or current rules.

**S2: [Wrestling 101, Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf)** - Coach Lance Johnson; hosted by West Hills Wrestling; accessed 2026-09-26.

**Inspected:** PDF extracted text, PDF page 3 of 4, Chapter 5: Bottom Wrestling, lines 115-123; author information on PDF page 1.

**Supports:** Kneeling is one of several usable bottom bases; Bottom wrestler resists belly collapse and avoids reaching backward; Base serves further bottom offense

**Limits:** Short overview, not a detailed placement tutorial. Historical scoring text elsewhere in the booklet is not relied on.

**S3: [7 Basic Skills: Coach and Athlete Guide, Bottom Motion](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF extracted text on PDF pages 2-3 of 9, Bottom Motion section labeled 15:52-20:18, especially Belly to Base and Starting Position/Base to Feet.

**Supports:** Base building is part of active bottom movement; Clear arms, bring knee underneath, keep head up, and continue from base toward the feet

**Limits:** Written companion guide only; linked video not inspected. Does not specify this Pup adaptation or its practice dose.

<a id="p06"></a>

## P06 - Solo Belly to Base

**Tier:** Pup | **Previous name:** Base Travel and Recovery

### Technical review

The draft had reasonable spacing, short steps, pauses, and a head-clear boundary. Its central task, however, was crawling to a marker and turning. The athlete began in base and remained there, so no lost position was recovered. It was a coordination activity rather than a substantive lesson in bottom recovery. Replacing it with belly-to-base gives this card a clear job between P05's static base and later bottom techniques. The title includes Solo because resisting a rider, freeing trapped arms, and creating effective pressure against another wrestler are not taught here.

### Selected variant

An unresisted, one-knee-at-a-time belly-to-base recovery, first demonstrated with the athlete's right knee. This preserves a real wrestling objective while removing the top wrestler for the Pup rehearsal. The child finishes in base rather than adding a stand-up or hip heist. The coach-side progression represents which side an imaginary rider occupies; it is a recognition exercise, not proof that the child can escape that rider.

### Mechanics and evidence

- USA Wrestling's bottom-motion sequence distinguishes belly-to-base from base-to-feet. Its instructions establish free arms, a raised head, the outside knee advancing along the side, a knee slide, and back pressure. [S1]
- The solo adaptation begins with both arms available. Forearm support and the explicit right-then-left knee sequence make the written exercise reproducible; these teaching details are this audit's simplification, not a quoted USAW script. With a rider notionally at the athlete's left hip, the athlete's right knee is the outside knee. [S1]
- Preston describes the base as supported on hands and knees with some elbow bend, and identifies getting up from the mat as a bottom priority. Its endpoint supports the final posture, but it does not describe the intervening knee slide. [S2]
- Kolat treats rebuilding and holding base as continuing skills, emphasizes understanding pressure, and lists back-pressure base building. Those principles explain moving the hips back rather than substituting forward crawl travel. The curriculum listing does not verify exact limb sequencing. [S3]

### Teaching progression

- Show the whole recovery from the side, then repeat it in two parts: one knee alongside, then hips back and the second knee under. Check P05 first rather than making either card depend on P08.
- Begin without a partner. The child controls both lowering and rising; the coach does not flatten, lift, or pull the child. If the belly start is difficult, rehearse from forearms and knees before gradually extending one leg behind for a smaller recovery.
- Accept slow success on each side before using the coach-side cue. The observer stands clear of the limbs and changes position only after the athlete resets. This supplies a defined decision without adding body weight.
- The readiness check is a repeatable recovery with the face clear, no wrist or knee discomfort, and a balanced finish. The suggested repetitions and cue game are original coaching design. Actual hand clearing and pressure from a rider need their own supervised progression.

### Common mistakes and corrections

- A push-up with trailing legs misses the hip recovery. Stop at the first knee and help the child see the space for the hips to return over it; do not pull the child upward.
- Rolling onto the back changes the task and loses the belly-down position. Reduce the knee reach and keep the chest directed toward the mat.
- Reaching hands farther forward can reproduce the old crawl. Place the endpoint near the starting spot and cue the hips back rather than racing to a finish marker.

### Readiness and rules

Pup identifies readiness, not an automatic age clearance. This is a solo floor skill with no hold or competitive scoring claim. A hands-and-knees training endpoint should not be presented as a complete rulebook definition of the referee's starting position. Success here does not authorize partner breakdowns, neck loading, or live bottom wrestling.

### What changed

- Replaced a crawl route with recovery from an actual belly-down starting position.
- Named the activity Solo Belly to Base and made the limited solo purpose explicit.
- Specified knee order, hip direction, final supports, and a gentle reset.
- Replaced a wider crawl turn with an outside-knee recognition progression.

### Evidence limits

Inspected the USAW PDF's extracted page text, the Preston syllabus text, and Kolat's public curriculum text. No linked technique video was watched. USAW supplies the clearest actual recovery sequence; Preston independently verifies the base endpoint and bottom objective, while Kolat supports the curriculum role and pressure concept only. Neither the sources nor the selected card establish an age-specific dose or the effectiveness of this solo drill under resistance. The cited Kolat title refers to a multi-year teaching curriculum, not a curriculum for children aged four to six.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Extracted PDF text, printed pages 2-3 (zero-based pages 1-2), Bottom Motion, especially Belly to Base and Starting Position/Base to Feet.

**Supports:** Belly-to-base is a distinct bottom recovery.; Clear arms, keep head up, advance outside knee along the side, knee slide to base, and apply back pressure.

**Limits:** A written study guide; the linked Bill Zadick video was not inspected. It describes wrestling with an opponent, not the exact solo Pup adaptation.

**S2: [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Full public page text, particularly II - Mat Wrestling, Bottom Man, Basic Skills for Mat Wrestling, and Defensive Mat Wrestling.

**Supports:** Hands and knees with slightly bent elbows are features of a bottom base.; Getting to base and continuing up from the mat are fundamental bottom skills.

**Limits:** A club syllabus, not a current rules authority; no detailed belly-to-base sequence or age-specific progression is given.

**S3: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers by Cary Kolat](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** Public page text, Level 1 Bottom: introductory teaching note, Holding Base, Base Building, and Bottom Drills/Base Drills.

**Supports:** Base building is a foundational, repeatedly drilled skill.; Bottom recovery depends on learning pressure, including pressure back into the opponent.

**Limits:** Curriculum headings and coaching notes support purpose and progression, not exact knee or hand mechanics. Linked library videos were not inspected.

<a id="p07"></a>

## P07 - Solo Sprawl

**Tier:** Pup | **Previous name:** Solo Sprawl Shape

### Technical review

The current revision has repaired the original category error: a floor leg stretch was not a sprawl. It now starts standing, takes the legs back, lowers the hips, and returns to stance. Those are useful defensive components. The remaining weakness was ambiguity about how the hands accept support and how the child gets back up. The instruction to keep knees off the floor while lowering hips could also become a prolonged cobra-like stretch if the coach rewards maximum depth. The revised card makes the action brief, keeps the hips square, specifies palm placement and a feet-supported recovery, and explicitly avoids forcing a back arch. A deliberate one-foot-at-a-time entry is a teaching adaptation; it does not reproduce the timing of stopping an actual shot.

### Selected variant

Solo, square-hip sprawl rehearsal with a step-back entry and step-in recovery. This preserves the purposeful transition away from a standing leg attack while removing the airborne entry and all partner loading. It is suitable for a learner who has the prerequisite support and coordination, irrespective of chronological age. The title is the familiar Solo Sprawl; the purpose and first instruction clearly identify the slower teaching stage. It is not a partner sprawl, hip-pressure drill, go-behind, burpee, or flexibility hold.

### Mechanics and evidence

- Eric Akin's published coaching notes teach lowering the hips, then squaring them, and warn against an upward jump before sprawling. They also place the skill inside stance-and-motion practice. These facts support a hips-low defensive action rather than a static plank. [S1]
- Welker's publisher-hosted excerpt emphasizes keeping the knees from becoming the support in its sprawl-based counter and retaining pressure before circling. That is relevant to distinguishing extended legs from kneeling, but its partner snap-down is not the solo variant taught here. [S2]
- USA Wrestling's article places stance, head/hand position, and level change before introducing the sprawl; it describes getting the legs back as part of beginner defense. It also emphasizes experience and skill over rigid age categories. [S3]
- Palm spacing, the one-foot-at-a-time sequence, a brief low position, and the supported step-in reset are this card's teaching design. They organize a repeatable solo rehearsal without pretending to verify shot-blocking effectiveness. No exact hip-to-floor distance, elbow angle, or required arch is prescribed.

### Teaching progression

- Demonstrate once from the side so the learner can see the legs move behind the body and the hips lower. Explain that, in wrestling, this motion helps move the legs away from someone trying to catch them. There is no receiver on this card and no child should dive underneath the demonstration.
- First check a squat-to-hand-support transition and a single backward step with each foot. If support fails or the learner needs a knee to hold the position, return to the prerequisites instead of asking for a faster sprawl. Hands-and-knees comfort alone does not establish readiness for hands-and-feet support.
- Use the complete slow sequence for two self-paced repetitions, allowing a full rest and fresh stance between them. Watch the entry, low position, and recovery separately. This repetition count is an economical coaching choice, not a researched dose.
- After repeatable execution, add the defined visual signal while the learner is stationary in stance. The signal should request one repetition, with a pause for balance afterward. Later, an observing coach can teach a coordinated two-leg withdrawal; speed and partner contact are separate progressions, not automatic rewards for finishing this card. [S1, S3]

### Common mistakes and corrections

- High hips throughout: demonstrate the difference between the temporary hand-supported entry and the brief low-hip finish. Do not solve it by pushing on the child's back.
- Knees coming forward under the hips: shorten the sequence and show both legs extending behind before lowering. If that support cannot be maintained, regress instead of repeatedly rehearsing a kneeling finish.
- Chest lifted high with a pronounced low-back arch: reduce the depth and duration; permit the elbows to bend while retaining active arm support. Hips approaching the mat are enough; touching it is not a pass/fail requirement.
- Hands leave before the feet regain support: pause in the recovery crouch, then lift the hands and settle in stance. This makes the reset observable and avoids turning every repetition into a forward stumble.

### Readiness and rules

Pup is a readiness tier. No source establishes that every child of a particular age should perform the full action. Use clear wrestling-mat space, active support, voluntary participation, and symptom-free execution. This solo rehearsal has no opponent, grip, score, release, or competition ruling. It does not authorize landing on another child's neck or spine. A later partner lesson must teach the attacker's posture and defensive contact separately.

### What changed

- Renamed Solo Sprawl Shape to Solo Sprawl.
- Retained the corrected standing-to-legs-back action and identified the step-back as a teaching adaptation.
- Specified palm placement, separate feet, square hips, and a supported return to stance.
- Made the low position brief and removed maximum-depth or back-arching implications.
- Defined readiness and a simple reaction drill without adding partner pressure.

### Evidence limits

Inspected the complete relevant published text from Akin's lesson summary and Welker's book excerpt, and the full USA Wrestling article body retrieved directly as HTML after the web reader returned 403. No embedded video was watched. Akin teaches a more dynamic leg-curl entry; Welker's excerpt teaches a partner counter. Neither directly prescribes this exact step-back solo progression. Its hand placement, pacing, repetitions, visual signal, regression, and recovery are original coaching design based on the verified movement purpose, not a claimed verbatim curriculum. The USA Wrestling article supports sequencing and readiness, not exact limb geometry. The Kolat page exposed video headings but not inspectable instruction, so it is not used as mechanical evidence.

### Sources inspected

**S1: [Avoid a Takedown with a Good Sprawl! - Eric Akin, Sprawl Drill](https://www.championshipproductions.com/news/2014/09/01/avoid-a-takedown-with-a-good-sprawl/)** - Championship Productions; accessed 2026-09-26.

**Inspected:** Published lesson-summary text, particularly the Sprawl Drill paragraphs; embedded video not viewed.

**Supports:** Lowering and squaring the hips; Avoiding an upward jump before the sprawl; Practicing the sprawl from stance on a coach's signal

**Limits:** Publisher's account of Akin's instruction, not a video transcript; its dynamic leg-curl entry and partner circling finish differ from this card's slower solo entry.

**S2: [How to use takedown counter drills to your advantage - excerpt from The Wrestling Drill Book, 2nd Edition, Bill A. Welker](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage)** - Human Kinetics; accessed 2026-09-26.

**Inspected:** Takedown Counter Drills introduction and Snap-Down Redirect setup, action, coaching point, and common error sections.

**Supports:** Fundamental sprawling and hip positioning precede advanced counters; Kneeling is a technical error in the described sprawl-based counter; Partner pressure and circling require additional skills beyond a solo floor action

**Limits:** The actual example is a partner snap-down redirect, not a preschool or step-back solo lesson. Its toe-based pressure instruction is not presented as a universal rule for every sprawl variant.

**S3: [Techniques by Age - Matt Krumrie, with coaches Nate Engel and Kevin Roberts](https://www.themat.com/news/2019/october/10/techniques-by-age)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Full article body retrieved from the official URL as HTML using Invoke-WebRequest; inspected introduction, Ages 5-8, Ages 9-12, Ages 13 and older, and Focus on skill and experience level sections.

**Supports:** Stance, head/hand position, and level change precede beginner sprawl instruction; Getting the legs back is a beginner defensive skill; Fun, foundational repetition, skill, and experience guide youth teaching

**Limits:** Coaching guidance organized by broad age ranges, not clinical readiness criteria or a mechanical tutorial; it does not validate the proposed repetition count or exact solo step-back progression.

<a id="p08"></a>

## P08 - Solo Stand-Up

**Tier:** Pup | **Previous name:** Solo Stand-Up Movement

### Technical review

The original offered a useful general floor-to-standing task: a flat foot, deliberate rise, no backward head throw, and a pause before turning. However, beginning by leaving base for upright kneeling, allowing the hands to remain down, moving the hips over a forward foot, and finishing in ordinary standing did not teach enough of a wrestling stand-up. It omitted the coordinated arm/leg action, waist-hand awareness, compact posture, hip clearance, and facing finish. Those omissions matter because simply rising can leave a wrestler folded forward with a rider still attached. The replacement rehearses recognizable stand-up mechanics while explicitly describing itself as the solo preparation stage. Hand placement is a rehearsal target, not a claim to have secured an absent opponent's wrist.

### Selected variant

Outside-leg stand-up with an imaginary rider on the athlete's left: right foot rises with the left arm, right hand attends to the waist, both feet come under the body, and a forward hip-clearance step precedes a left backstep/turn. College Park's handbook supplies this variant [S1]. The mirror side reverses every direction. The card uses a slow stepping turn without a head post; that is a beginner rehearsal adaptation, not the handbook's complete head-led cutaway under resistance.

### Mechanics and evidence

- The College Park handbook pairs inside arm with outside leg, lifts the chest, brings the outside hand to the stomach hand, then reaches both feet and uses both hands to clear the opponent's hand [S1, p. 31]. With the imagined rider on the left, inside means left and outside means right. The card preserves that coordination rather than arbitrarily choosing a kneeling leg.
- Its bottom principles emphasize a compact base and hips underneath; its stand-up finish clears the hips forward, backsteps/pivots with the inside foot, and faces in a low stance [S1, pp. 14, 31]. Here the first step stays close enough to support the rising trunk, and the turn moves the feet rather than twisting over a stationary knee.
- Preston teaches a different, inside-leg stand-up, but independently includes an elbow block, control of the waist hand, creating space, and peeling away [S2]. It corroborates why hand awareness and separation belong to the stand-up family; it is not evidence for the replacement's outside-leg footwork.
- Kolat's curriculum distinguishes proper standing position/cutting away, breaking the lock, and elbow-hand versus stomach-hand capture. It also instructs the coach to choose the stepping leg [S3]. These are meaningful later skills rather than details that can be assumed accomplished by touching one's own belly.

### Teaching progression

- Demonstrate from the side, naming the imaginary rider's location. First rehearse the balanced standing finish and step-turn; then show the right-foot/left-arm action from base. College Park specifically teaches its stand-up backward, progressing from standing footwork to base and then partner work [S1, p. 14].
- Allow a half-kneeling rise as a prerequisite check or regression, but label it a rise exercise. Successful solo repetitions begin in base, bring the chest and foot up together, reach two-foot support, and finish facing without stumbling.
- The card's two repetitions, rest, and visual start signal are proposed coaching design, not research-established doses. The defined reaction is to the signal; this solo card has no receiver and no partner resistance.
- Later partner instruction must add a specific wrist/waist-hand grip, actual clearance, a following top wrestler, and a taught cutaway. Begin with cooperative following and stop before any mat return. Do not infer that completing P08 alone establishes readiness for resisting a rider.

### Common mistakes and corrections

- Long stepping or crawling forward: shorten the first step, pause with the chest lifted, and check that rising does not require hauling the trailing leg from far behind.
- Backward head throwing: keep the head aligned with the lifted chest. With no rider or wall providing support, the athlete must balance independently rather than lean backward into empty space.
- Spinning before standing or fixing one foot to the mat: separate rise and turn initially, then step each foot through the change of direction. Keeping the hands near the waist rehearses their job but must not be mistaken for breaking a real grip.

### Readiness and rules

Pup is a readiness tier, not an age authorization. Require comfortable hand/knee support, a stable independent rise, and the ability to pause in stance. This is a solo folkstyle bottom-skill rehearsal; it does not demonstrate a scored escape or establish readiness for live mat returns. No event-specific legality ruling is needed for the solo drill. The handbook's head-assisted wall cut is deliberately not assigned here.

### What changed

- Use the standard, friendly name Solo Stand-Up.
- Restore a base start and a named outside-leg variant with explicit athlete-relative directions.
- Add chest/arm/leg coordination, waist-hand awareness, hip clearance, and a facing stance finish.
- Identify the simplified solo stage honestly and defer actual hand fighting to partner instruction.

### Evidence limits

Inspected extracted PDF text and full source-page text, not video playback. S1 provides the selected mechanics; S2 provides an independent but different-leg variant; S3 provides curriculum distinctions and progression context, not detailed grip verification. No source establishes the exact shortened wording, rehearsal tempo, repetitions, visual reaction game, or suitability for every child. Those are coaching adaptations. The web search tool failed authentication, so accessible primary URLs from the source leads were fetched directly.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** Extracted text of PDF pages 8, 14, and 31: Wall Standup; Basic Bottom and backward teaching progression; Standup execution table.

**Supports:** Inside-arm/outside-leg coordination; Outside hand to stomach hand and later two-hand clearance; Hips compact underneath, hip clearance, inside-foot backstep, facing finish; Teach standing footwork before base-to-feet and partner work

**Limits:** Team handbook, not a rulebook or age-specific validation. Its complete cut includes head-led/head-assisted actions omitted from this solo adaptation. PDF text inspected; videos not watched.

**S2: [Preston Mat Club Syllabus: Defensive Mat Wrestling](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Full HTML text, particularly Defensive Mat Wrestling, Inside Leg Stand Up, and the syllabus teaching goals.

**Supports:** A stand-up includes blocking an elbow, attending to the waist hand, creating space, and peeling away; A planted-foot rise alone omits wrestling-specific actions

**Limits:** Inside-leg variant, not a source for the selected outside-leg footwork. Brief coaching outline; not sufficient for detailed partner grip teaching by itself.

**S3: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** Page text of Level 1 bottom section, including the Stand-Up teaching note and listed hand-capture, lock-breaking, and cutaway skills.

**Supports:** Choose a specific stepping leg; Separate standing position/cutaway, lock breaking, and hand-capture skills; Teach individual moves before linking them

**Limits:** Curriculum listing supports scope and sequence, not exact grips or mechanics. Four to six years refers to the curriculum's training span, not an age clearance. Linked demonstrations not watched.

<a id="p09"></a>

## P09 - Solo Sit-Out

**Tier:** Pup | **Previous name:** Solo Sit-Out Movement

### Technical review

The original retained useful features: a solo start, low speed, an upright finish, a separate reset, and attention to trapped knees. Its decisive action was too vague. Shifting onto a hip and letting the second leg follow could teach ordinary side-sitting without the supporting foot, leg clearance, and hip transfer of a wrestling sit-out. A seated forward scoot is a useful regression for posture but does not repair that missing transition. The revised card preserves a genuine sit-out entry while stopping before a partner-dependent escape. It also removes Movement from the title. An isolated seated endpoint is a rehearsal checkpoint, not a claim that the wrestler has escaped.

### Selected variant

A short solo sit-out with a right outside-foot step, left-hand post, and left leg passing forward under the raised right knee. For explaining outside versus near, imagine a rider beginning on the learner's left; no rider is used on this card. The sequence can then be mirrored. This is the base-to-seat portion of the sit-out family, not a front-headlock sit-through, switch, head-post roll, or complete turn-in.

### Mechanics and evidence

- College Park's detailed sit-out section specifies a short outside-foot step followed by bringing the near leg through. Its basic-bottom section likewise describes stepping out and pivoting into the rider. This establishes the essential leg-and-hip action missing from the original. [S1]
- Horaski and Garcia explicitly describe a left-hand cross-post, right hand at the right thigh, raised right knee with the foot supporting, and left leg passing beneath the right. This provides an actual instructional basis for the card's hand/foot coordination. [S2]
- Weber teaches a compact sit-out with abdominal tension and pressure back into the opponent, followed by a separate escape action. Thus 'chest up' means maintaining posture, not leaning far back or treating a forward scoot away from the rider as the universal live tactic. [S3]
- Level Up's seated-balance drill uses hip scoots and hand posts to recover position. This supports allowing the solo learner to reposition a hand, rather than demanding a fixed wrist while the body turns. [S4]

### Teaching progression

- Demonstrate from the front and side, naming the learner's limbs. Show the final seat, then the foot-and-hand supports, then the leg passing through. Rehearse one side before mirroring so the learner does not have to solve both versions at once.
- Begin without resistance or a receiver. A coach observes rather than pulls the child through the movement. If the learner cannot lift the knee clear, return to the support-and-step prerequisite; a seated scoot alone is preparation, not a completed repetition.
- The proposed two-repetition drill first tests the complete sequence, then adds a defined visual go/no-go response. Stop and reset after each attempt. Repetition count, signal choice, and rests are coaching design, not a validated training dose.
- Later partner teaching must add hand control, the rider's following response, and a finish. Kolat specifically separates individual skills before combining sit-outs, stand-ups, and hip heists. This card therefore does not require P10 or B18 first, avoiding a circular prerequisite. [S5]

### Common mistakes and corrections

- A knee left beneath the seat means the leg has not cleared. Reduce speed and rehearse the support transfer before lowering; do not rotate the torso against the trapped knee.
- A long backward hand reach often accompanies a collapsing chest or backward fall. Reset to a shorter sit, keep the torso supported, and permit hand repositioning rather than asking the child to catch the fall.
- Do not import the lesson plan's fixed knee-height target or its instruction to drop heavily onto the mat. The required clearance depends on the learner, and a gentle lowering preserves the same leg-through action. [S2]

### Readiness and rules

Pup is a readiness tier. The learner must tolerate hand support, clear the moving knee, and lower the hips without an uncontrolled fall. There is no receiving partner, scoring claim, or competitive hold on this card, so it does not require a sport-rule interpretation. Transfer to B18 must distinguish useful back pressure into a rider from throwing the head or torso backward. Partner pressure, chops, head posts, and rolling finishes require separate instruction.

### What changed

- Renamed the card Solo Sit-Out.
- Replaced unspecified side-sitting with a named supporting hand, outside-foot step, and opposite-leg clearance.
- Defined the seated checkpoint and separate reset without promising an escape.
- Changed the correction to rehearse the missing support-and-clearance action.
- Added a simple signal response after successful solo repetitions.

### Evidence limits

Inspected actual written instruction in the school handbook, authored lesson plan, and coaching articles. The Vimeo video linked by Weber could not be fetched and was not watched. The PE lesson plan supplies unusually explicit limb sequencing, but is not a governing-body certification or child-readiness standard; only its sit-out entry is used. College Park and Weber independently establish the short sit-out family and its live purpose, but neither validates this exact Pup drill dose. Kolat supplies progression guidance and technique listings, not detailed hand placement. Slow speed, soft lowering, visual signals, and the independent reset are deliberate teaching adaptations.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text extracted in memory; printed pages 14 and 32, Basic Bottom and SIT OUT/TURN OUT.

**Supports:** Short outside-foot step and near-leg passage.; Pivot and pressure back into the rider; later finishing actions.

**Limits:** A school technique handbook, not an age-specific standard; does not specify the entry's posting hand.

**S2: [Wrestling Unit Block Plan, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** PDF page text, pages 83-85 (zero-based 82-84), especially the solo sit-out instruction on page 84; authorship on page 2.

**Supports:** Left-hand cross-post, right hand by thigh, right knee raised, and left leg passing through.; Slow solo demonstration before partner rehearsal.

**Limits:** Authored PE instruction, not verified elite-coach credentials. Fixed knee height, heavy landing wording, old scoring, and later finishes are not adopted.

**S3: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://attackstylewrestling.com/sit-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Complete page text, particularly Basic sit out position and Seal off, hip heist away.

**Supports:** Compact seated posture and pressure back into the rider.; The sit-out position precedes an escape or reversal finish.

**Limits:** The linked video was inaccessible; article text does not give the entry's exact foot and hand sequence.

**S4: [Wrestling Drills: Sit out/Scoot Drill](https://coaches.levelupwrestling.com/wrestling-drills/)** - Level Up Wrestling Coaches Resource Center; accessed 2026-09-26.

**Inspected:** Actual page text in the Sit out/Scoot Drill section.

**Supports:** Hip scoots and hand posts as seated-balance recovery actions.; Hand clearing and a heist follow the seated position in partner work.

**Limits:** Starts already seated and uses partner pressure; does not independently establish the base-to-seat entry or authorize that pressure for this solo card.

**S5: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** PDF page text, pages 1 and 8-9: progression principles, First Move Techniques, and Sit-Out Drills.

**Supports:** Teach constituent bottom skills individually before combining them.; Progress by demonstrated competence, with sit-out posture and motion drills.

**Limits:** Curriculum guidance, not detailed sit-out mechanics. The title describes a multi-year curriculum, not permission based on ages four to six.

<a id="p10"></a>

## P10 - Hip-Heist Preparation

**Tier:** Pup | **Previous name:** Low Hip-Heist Preparation

### Technical review

The original properly identified a low, optional solo activity and warned against twisting over fixed supports. Its main problem was mechanical: moving the hands to one side, taking tiny steps, and eventually kneeling can produce an ordinary seated-to-base transition with no hip heist. It did not identify the diagonal support, unload a particular leg, or describe one leg passing under the other. A seated quarter-turn with the hips left on the mat is an easier floor transition, but should not be presented as successful performance of the heist. The replacement isolates the actual lift-and-thread action and retains Preparation because it omits the opponent, hand clearing, back pressure, separation, and escape finish.

### Selected variant

A slow solo seated hip-heist segment to hands-and-knees base, turning through the wrestler's own right side. The right hand and left foot support the initial lift; the right leg passes underneath, the chest turns toward the posted hand, and the left hand joins the mat before the knees settle. The card selects one side and gives a separate mirrored reset. It does not merge a sit-out, switch, head-post roll, and stand-up into one exercise.

### Mechanics and evidence

- Malinconico's seated demonstration shows bent knees and a hand behind the hip, hips lifted, and a leg traveling underneath before the body finishes facing the opposite direction. The inspected right-side sequence uses the right hand and opposite foot while the right leg passes through. The second hand comes down as the chest turns toward the mat. [S1]
- The Henry Ford College coaching page independently specifies a seated/crab start, one foot moving over while the other passes beneath, rotation, and a hip switch. This is the decisive distinction from walking around on hands and knees. [S2]
- The exercise's base finish is an isolated learning endpoint. Weber's actual sit-out escape adds sealing the sides, shoulder pressure into the opponent, lifting the hips, and heisting away. USA Wrestling likewise connects the competitive heist to hand control, hip separation, and recovery toward the feet. These partner requirements are deliberately outside this card. [S3, S4]

### Teaching progression

- Demonstrate beside the learner, facing the same way, so right and left are unambiguous. First show a seated position and a brief lift with the right hand and left foot. A coach should see the right foot become free without the support arm buckling before asking for the leg-through.
- Use one repetition at a time. Show the right leg's route separately, then connect lift, thread, second-hand placement, and knees down. Landing in base is the stop point; there is no requirement to reverse immediately or keep spinning.
- The two-repetition rehearsal and later coach signal are proposed teaching design, not a researched dosage. The signal adds a simple response while keeping resistance at zero. There is no receiver or riding partner. Later partner escape instruction belongs to a separate card with a specified grip and cooperative release.
- If the learner cannot lift and clear the leg, practice a hip lift only and identify it as preparation. Do not award completion for a seated swivel. The Pup tier is a readiness grouping; it does not establish an age at which all children can perform this task.

### Common mistakes and corrections

- Seat remains heavy and the foot drags: reduce the repetition to a brief lift; confirm the moving leg is unloaded before adding rotation.
- Foot catches under the body: return to sitting and rebuild the starting space. Do not force a knee around a planted foot or insist on finishing the repetition.
- Learner travels around a large circle: demonstrate a single leg-through within the same small lane. Malinconico's line drill specifically checks unnecessary sideways travel. [S1]

### Readiness and rules

This is a solo foundation, so it earns no escape and makes no competition-legality claim. Readiness means supporting and lowering one's own weight with the head clear and feet free to turn. A coach should observe the entire repetition. The higher wall, head-supported, and partner-release progressions in the source video are not included here; they would add requirements absent from this Pup exercise.

### What changed

- Removed Low from the name while keeping Preparation to communicate the limited teaching goal.
- Replaced unspecified tiny steps with a named support hand, opposite support foot, and a particular leg-through.
- Defined the second-hand placement, opposite-facing base finish, separate reset, and solo reaction drill.
- Reclassified the hip-lift-only regression as preparation rather than an alternate completed heist.

### Evidence limits

Actual coaching text and a full auto-generated video transcript were inspected; selected frames were also examined to resolve limb placement. Caption errors such as hip hops and hand piece were not treated as technical terms. The sources support the heist's essential action and its role in wrestling; none validates this exact slow Pup lesson, repetition count, readiness threshold, or safety boundary. Those are explicit coaching adaptations. Curriculum-only listings and unavailable or unviewed clips were not used as mechanical verification.

### Sources inspected

**S1: [Hip Heist by Mike Malinconico](https://www.youtube.com/watch?v=qi-crQ-Kwec)** - Fanatic Wrestling, coach demonstration on its official YouTube channel; accessed 2026-09-26.

**Inspected:** Read the complete available English auto-generated transcript, 0:00-4:42. Visually inspected seated-drill frames at approximately 1:03, 1:33-1:37, and 1:42, including intermediate frames through the leg switch. The detailed seated coaching is at 1:02-1:46.

**Supports:** Hips lift before the foot-under/foot-over action.; Seated right-side demonstration's support and leg path.; Turn to face the opposite direction without unnecessary sideways travel.; Higher wall and partner-supported drills are distinct progressions.

**Limits:** Auto-captions misrecognize several wrestling terms. Selected frames, rather than uninterrupted viewing of every demonstration, were inspected. The coach does not prescribe this card's slow Pup adaptation.

**S2: [Changeover Series - Hip Heist Drills](https://www.coachmackenzie.com/changeover-series.html)** - Henry Ford College Wrestling, Coach MacKenzie coaching site; accessed 2026-09-26.

**Inspected:** Read the live page text, especially Hip Heist Drills / On the mat and the separate wall/partner drill listings.

**Supports:** Seated/crab position as a solo starting position.; One foot up/one foot over, turn on an axis, and switch hips.; Mat, wall, and partner versions are separate progressions.

**Limits:** Abbreviated coaching checklist; it does not alone establish exact right/left hand placement or a child-specific progression. Embedded videos were not inspected.

**S3: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Read coach-authored article text, especially Step 1: Basic sit out position and Step 2: Seal off, hip heist away.

**Supports:** Competitive sit-out-to-heist includes sealing the sides, back pressure through the shoulders, a hip lift, and heisting away.; The solo base transition does not by itself teach a complete escape.

**Limits:** The embedded 7:11 video was not viewed. Article text does not specify the solo drill's full limb sequence.

**S4: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Read extracted PDF text on page 3 (zero-indexed page 2), including Starting Position/Base to Feet and 23:48-24:21 Hip-Heist Drill.

**Supports:** The applied hip-heist drill uses inside hand control and isolates a top wrestler's hand.; The competitive objective includes separating the hips and recovering toward the feet.

**Limits:** A study guide to linked instruction, not a detailed solo-leg-path tutorial. Linked videos were not viewed and this source does not verify the exact Pup adaptation.

<a id="p11"></a>

## P11 - Go-Behind Footwork

**Tier:** Pup | **Previous name:** Circle to the Hip Marker

### Technical review

The original correctly kept the activity noncontact and asked the child to take an outside route. Its line of shoulder, waist, and hip markers did not clearly represent the obstacle formed by an opponent's head, arms, and body. Starting beside the shoulder and stopping beside the hip could become a short trip along one side, rather than learning to arrive behind. Allowing travel on either knees or feet also combined different tasks without identifying what transferred to wrestling. A crawl toward a hip marker does not reproduce a spin-behind's pressure, arm clearance, or footwork. The revision preserves a modest, useful objective: recognize front versus rear and take balanced circular steps to the rear. Its name and purpose explicitly identify footwork preparation.

### Selected variant

Solo standing go-behind footwork around an empty marked oval. The child's right and left determine the direction; the foot nearest the chosen direction starts. The chest gradually turns toward the center while the feet follow the outside arc. The endpoint lies beyond the imagined hips, with the child facing back toward the head end. There is no hold to release and no receiving partner. Standing and walking outside the station provide a distinct reset.

### Mechanics and evidence

- USA Wrestling identifies circling in both directions, lateral adjustment, and movement toward or away from an opponent while preserving position as motion fundamentals. This supports practicing balanced circular footwork as a separate foundation. [S1]
- Welker's snap-down redirect combines a sprawl, chest pressure, an arm block, and a spin around the opponent; it specifically distinguishes toe support from dropping onto the knees. The solo card carries over only the route around and rear destination, not the contact mechanics. [S2]
- College Park's backhand go-behind describes chest/shoulder pressure, blocking the near triceps, circling behind, and finding a near-leg anchor. This confirms that getting around the upper-body barrier and establishing rear control require more than reaching a side marker. Those partner actions are deliberately absent from this preparation activity. [S3]
- The oval, uncrossed short steps, stationary finish spot, and shallow stance are teaching choices for this rehearsal. They should not be presented as an exact reproduction of a competitive spin-behind or as a source-prescribed drill.

### Teaching progression

- First identify the head end and hip end together. Demonstrate the whole outside arc and freeze beyond the hips so the destination is visible before the child starts.
- Rehearse one direction slowly with no resistance and no partner. Check that the child keeps space between the feet, turns progressively, and reaches the rear spot without entering the oval. Reset before changing direction.
- Add a defined visual reaction: the coach points right or left before the start. The child selects that route and stops at the same rear destination. This tests direction choice without turning the drill into a race.
- A later partner go-behind needs separate instruction in pressure, arm clearance, rear control, and the receiver's role. Completing this spatial drill alone does not establish readiness for that contact task.

### Common mistakes and corrections

- Stopping next to the hips: move the finish spot visibly beyond the hip end and ask the child to face the head end from there. This makes the rear destination unambiguous.
- Crossing feet or turning in one large pivot: slow to step-and-follow and turn a little with each pair of steps. Widen the route if the child repeatedly loses balance.
- Cutting inside or crawling through the oval: return to standing outside the start spot and demonstrate the curved route again. There is no person underneath or inside this activity.

### Readiness and rules

Pup is a readiness tier, not automatic permission based on age. The relevant prerequisite is balanced stance travel and stopping, not hands-and-knees crawling. Keep the oval empty and routes separate. No head, neck, arm, or waist control is taught, and reaching the finish spot is not represented as earning takedown points. Event-specific contact and scoring rules become relevant when teaching the later partner technique.

### What changed

- Renamed the activity Go-Behind Footwork and identified it as preparation.
- Replaced optional knee travel with a single standing footwork variant.
- Replaced a narrow marker line with a visible outside route and an endpoint behind the hips.
- Added exact direction cues, gradual facing adjustment, a separate reset, and a visual direction-choice progression.

### Evidence limits

Inspected accessible primary instructional text and extracted PDF sections, not linked video footage. The sources establish circling fundamentals and the additional contact mechanics of actual go-behinds. None verifies this exact marker layout, its effectiveness for a particular age, or a required repetition dose. The station layout and progression are original coaching design. PDF screenshot retrieval was incomplete; no visual claims rely on it.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Extracted PDF text, pages 1-2, especially Skill 2 of 7 Motion at video-reference time 12:42-15:52; no linked video watched.

**Supports:** Circle to both sides and adjust laterally while maintaining position.

**Limits:** A study guide, not detailed instruction for this solo marker drill or age-specific validation.

**S2: [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage)** - Human Kinetics; excerpt from The Wrestling Drill Book, 2nd Edition, by Bill A. Welker; accessed 2026-09-26.

**Inspected:** Full accessible page text under Takedown Counter Drills and Snap-Down Redirect: Setup, Action, Coaching Point, and Common Error.

**Supports:** An actual spin-around follows defensive positioning and upper-body control.; The presented snap-down redirect emphasizes toe support rather than dropping to the knees.

**Limits:** Contact drill with a snap-down; its head pressure and partner mechanics are not instructions for this Pup preparation.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Extracted PDF text, PDF page 25 (zero-based page 24), Short Offense table: Backhand and Short Drag; also Spin Drills on PDF page 9. Screenshot retrieval failed.

**Supports:** Actual go-behind instruction includes chest/shoulder pressure, near-arm clearance, circling behind, and a near-leg anchor.

**Limits:** Coach-authored team handbook, not a rulebook or validation of a noncontact Pup progression; precise contact execution is outside this card.

<a id="p12"></a>

## P12 - Side Breakfall Prep

**Tier:** Pup | **Previous name:** Low Side Receiving

### Technical review

The original's solo setting, seated height, pauses, and observation were sensible limits. Its decisive instruction, however, was to place a bent forearm on the floor and lower onto that support. That describes a supported transfer to side-lying, not a substantiated receiving action. Calling it receiving could encourage a coach to carry the elbow-support habit into actual falls. The revision replaces that uncertain link with a documented floor exercise and names it preparation. It is deliberately narrower than a complete side breakfall and does not promise injury prevention or proficiency in receiving a takedown.

### Selected variant

Use the lying-down entry to yoko-ukemi: a small back-to-side roll with the corresponding arm contacting the mat. Judo Canada supplies this exact starting progression [S1]. Obukan independently teaches a supine side-fall exercise, although its raised-leg start differs [S2]. Retain the Canadian bent-knee floor start throughout this card; do not combine it with Obukan's legs-up start or with British Judo's standing entry.

### Mechanics and evidence

- Judo Canada's floor exercise starts supine with separated feet and slightly bent legs, then turns over the shoulder blade and flank; the same-side arm moves from across the chest to the mat and the other hand stays near the belt [S1].
- Obukan's instructions independently establish palm-down arm contact, a relaxed extended arm, a side finish, and separation of the legs [S2]. Extension for contact is different from placing a rigid hand under the body to hold its weight.
- British Judo's children's syllabus explicitly teaches the chin-in action and palm contact in side breakfalls [S3]. Its partner-assisted and standing examples are outside this card's scope.
- The diagonal arm cue follows the Canadian guide's approximately 45-degree direction [S1]. Obukan specifies 30 degrees [S2]; the card does not pretend that one measured angle is a universal requirement. The coach demonstrates an arm beside, rather than underneath, the body.

### Teaching progression

- Demonstrate the finished floor position first. Have the child copy the hand placement and a gentle arm tap without turning; then show one small roll. The gentle contact is this card's adaptation for learning placement, not the forceful striking instruction used later in the manuals.
- Observe one child at a time until each can pause without head contact or an elbow prop. Use separate repetitions with rest instead of a continuous rocking race. No partner supplies resistance or initiates the roll.
- The defined reaction is a visual right-or-left cue after the child can copy both directions. This adds listening and side selection while retaining the same floor start. It is original coaching design, not a tested training dose.

### Common mistakes and corrections

- If the child props on the elbow, stop the roll and return to a static side-position arm rehearsal. Do not solve this by pushing the child farther over.
- If the child turns the head independently or cannot keep it clear, end the repetition and rest. Reduce the task to watching the demonstration; do not hold or pull the child's head.
- If feet cross or the child rolls onto the belly, reset the starting position and shorten the turn. Successful practice ends with an observable pause, not extra momentum.

### Readiness and rules

Pup is a readiness tier. Willing participation, repeatable head control, and a qualified coach's observation determine access to this exercise. It has no opponent, throw, scoring action, or competition-rule claim. A completed floor drill is not permission for standing partner takedowns; receiving those requires a separate progressive assessment.

### What changed

- Renamed the card Side Breakfall Prep to identify its actual purpose and limited scope.
- Replaced the unsupported forearm-first descent with a documented supine roll-and-arm-contact exercise.
- Specified the child's right side, both hand roles, reset, and a simple visual reaction.

### Evidence limits

Inspected the manuals' parsed PDF text, not video demonstrations. These are coaching instructions, not biomechanical experiments or evidence for a universal age threshold. The sources vary in starting leg position, arm angle, and emphasis on impact. The revision uses one low progression and omits force-transfer explanations, standing work, assisted falls, and claims that a mat slap guarantees protection. Gentle tapping, observation checks, and the direction game are explicit teaching adaptations.

### Sources inspected

**S1: [Breakfalls Instruction Guide (September 1, 2023)](https://judocanada.org/wp-content/uploads/2023/07/Guide-Chutes_2023_EN.pdf)** - Judo Canada; adapted from Francis Drouin's Les Chutes (2000); accessed 2026-09-26.

**Inspected:** Parsed PDF text, printed pages 3, 6-7 and 9-11; especially page 9, Yoko-ukemi, Progression and learning stages, Lying down.

**Supports:** Supine, bent-knee floor progression with alternating side turns and corresponding arm contact.; Hand starts near opposite shoulder; other hand stays near belt.; Head clearance, uncrossed legs, qualified supervision, and approximately 45-degree arm direction.

**Limits:** A judo coaching guide, not a pediatric trial or permission for standing wrestling falls. Its later vigorous strikes, assisted exercises, and standing progression are not prescribed here. Its impact explanations were not adopted.

**S2: [Obukan Judo Dojo Teacher's Manual: Beginner Course, May 31, 2011 draft](https://obukanjudo.org/wp-content/uploads/2011/09/BeginnerCourseTeacherManual.pdf)** - Obukan Judo Dojo; accessed 2026-09-26.

**Inspected:** Parsed PDF text, cover and PDF pages 11-13: back fall, lying-down side fall, and side fall from squat/standing.

**Supports:** Independent floor-start side-fall teaching progression.; Palm-down contact with relaxed extended arm, side finish, and separated legs.; Instruction uses a 30-degree arm angle, demonstrating a coaching variation.

**Limits:** Draft club manual with a different raised-leg start and some wording errors. Used to corroborate shared contact principles, not to replace the selected bent-knee starting variant or establish a child-specific dose.

**S3: [JudoKids 2nd Sho Syllabus](https://www.britishjudo.org.uk/wp-content/uploads/2024/10/JudoKids-2nd-Sho-Syllabus.pdf)** - British Judo Association; accessed 2026-09-26.

**Inspected:** Parsed PDF text, PDF pages 4-6, assisted yoko-ukemi and Stage 2 yoko-ukemi.

**Supports:** Children's coaching material includes side breakfalls with chin tucked and palm contact.

**Limits:** Its illustrated sequence uses a standing entry and its assisted variants use partners; neither is included in this card. It does not verify the original forearm-supported lowering.

<a id="b01"></a>

## B01 - Wrestling Stance

**Tier:** Beginner | **Previous name:** Balanced Wrestling Stance

### Technical review

The original already contains the core of a useful neutral stance: a modest stagger, flexion at both hips and knees, a long back, forward attention, compact arms, and movement as a balance test. Its weaknesses are ambiguity and progression. 'Half a step' can turn into a long lunge, and 'nose, knees, toes' can be interpreted as forcing three body landmarks onto a vertical line. Raising the chest alone does not reliably correct insufficient knee bend. The shoulder-touch progression has no defined pressure, receiving action, or success condition; a light tap scarcely tests balance, while an unexpected shove changes the task. The replacement keeps the original stance family and uses a clear stop response to test position before adding contact in later cards.

### Selected variant

A staggered neutral stance with the wrestler's own right foot slightly ahead, followed by a full reset to practice the left lead. This matches the P01 foundation while adding independent stepping and stopping. Shoulder-width is an initial coaching reference, adjusted so the athlete can move without a recovery step. No exact weight percentage, knee angle, or fixed stance depth is prescribed. A square stance is a valid alternative, but is not mixed into this initial lesson.

### Mechanics and evidence

- USA Wrestling lists staggered and square stances separately. Its staggered stance combines a wide foot base, bent legs, hands ahead, inward elbows, the chest forward over a knee, and a raised head. The guide also identifies toe pressure among its positional principles. These support the card's foot, leg, trunk, and arm checkpoints. [S1]
- Preston's neutral-position syllabus independently emphasizes flexed knees, inward hands and elbows, and aligned shoulders and hips. It then calls for short step-slide motion without crossing the feet while preserving stance. The card's one-step test applies those checkpoints before B02 adds sustained motion and level changes. [S2]
- USA Wrestling's motion section requires preserving position while circling, adjusting laterally, and moving toward or away from an opponent. Being able to stop after a short step is the chosen coaching check for that positional goal, not a source-prescribed test. [S1]

### Teaching progression

- Demonstrate from the front to show lateral foot spacing and compact elbows, then from the side to show simultaneous knee and hip bend. Show the stance with the right lead before asking the athlete to mirror it. Contrast a stable stance with a narrow tightrope and an overlong lunge.
- Start with three solo builds and standing resets. Add one step and stop in each direction at the coach's pace. The endpoint is bent knees, usable foot spacing, hands forward, and no extra recovery step; standing up is reserved for the reset.
- For the partner drill, the leader takes small deliberate steps and the follower preserves the facing relationship and gap. Both partners are demonstrators and movers; there is no receiver taking force, gripping, or falling. Begin with predictable motion before allowing the leader to stop without warning. Swap roles and rest before fatigue changes posture.
- The readiness check for B02 is repeated stepping and stopping without crossed feet, rising upright, or drifting into the partner. Twenty-second turns and three initial repetitions are practical coaching suggestions, adjustable to attention and execution, not research-established training doses.

### Common mistakes and corrections

- For waist-only folding, return to standing and rebuild with a smaller bend through knees and hips; lifting the chin does not fix the leg position. For heel sitting, shorten an excessive stagger and test a small step instead of insisting on a deeper squat.
- For a tightrope or crossed feet, use two floor targets with lateral separation and slow the step-follow sequence. For arms reaching ahead, restore bent elbows and have the feet carry the athlete closer only when a later contact drill permits it.

### Readiness and rules

Beginner describes demonstrated readiness rather than age. This is a foundation lesson with no scoring, grip, or event-specific legality issue. Its successful completion does not establish readiness for live takedowns. A partner must follow the stop signal and preserve the gap; the learner should reduce stance depth or rest when position deteriorates. Pain is a reason to stop, not to force a lower stance.

### What changed

- Shortened Balanced Wrestling Stance to Wrestling Stance.
- Specified lateral spacing, whose lead foot is used, facing alignment, and a standing reset before changing leads.
- Replaced the ambiguous nose-knees-toes cue with visible knee, eye, hand, and elbow checkpoints.
- Replaced the shoulder touch with a defined no-contact mirror-and-stop progression and reduced the rigid six-round prescription.

### Evidence limits

Inspected written PDF text and the club webpage, including its attribution note; no video was watched. S1 and S2 verify the basic positional and motion mechanics. Preston's syllabus draws on several coaching sources, so it is a club teaching document rather than an independently tested biomechanical standard. Shoulder-width as an adjustable starting point, heels near the mat as a safeguard against tiptoeing, the demonstration sequence, foot targets, and the drill format are coaching interpretations. P01 was read for continuity but was not used as technical authority.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF extracted text, page 1: Skill 1 Position and both stance descriptions; page 2: Skill 2 Motion, including maintaining position while moving in different directions.

**Supports:** Staggered stance foot spread, bent legs, forward hands, inward elbows, forward chest, and head position.; Forefoot pressure as a positional principle and maintaining position during motion.

**Limits:** Written study guide to a longer video. The video was not inspected. It does not prescribe an exact stance width, weight split, or this mirror-and-stop drill.

**S2: [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Webpage text, section I-A: Stance, Motion, Changing Level, and Making Contact; closing source-attribution note.

**Supports:** Bent knees, compact arms, and shoulders and hips facing together.; Short uncrossed steps that preserve stance and closing distance with the feet instead of reaching.

**Limits:** Club syllabus compiled from common coaching knowledge and named coaching videos, not a single-author mechanical study. No referenced video was inspected and the present timing and reaction drill are original teaching design.

<a id="b02"></a>

## B02 - Motion and Level Change

**Tier:** Beginner | **Previous name:** Motion And Level Change

### Technical review

The original card was largely sound: short uncrossed steps, continued orientation toward the partner, and lowering through the legs are appropriate foundations. It did not clearly connect footwork and level change, however; its four steps could be interpreted as separate activities. The correction also prescribed a pause without explaining that the pause is temporary teaching assistance. The revised card tests whether the athlete can move directly from the lower position. The original mirror progression made the follower choose direction after a clap, leaving leadership ambiguous. A fixed leader now chooses the stimulus and the follower has one clear response. The familiar original technique name needs only normal capitalization.

### Selected variant

Noncontact staggered-stance step-and-follow motion with a modest standing level change. Both knees remain off the mat and the athlete keeps the chosen lead leg during each repetition. This is preparation for B03, not a penetration step, defensive block, or completed attack. Right and left refer to the moving athlete's own feet. The fixed lead and directional foot order are beginner teaching constraints rather than claims that all competitive wrestling motion follows one immutable rule.

### Mechanics and evidence

- USA Wrestling teaches circling both ways and adjusting sideways, toward, and away from an opponent while retaining position. Its level-change section connects lowered hips and knee bending to subsequent penetration. This supports integrating the two skills while keeping penetration distinct. [S1]
- Preston Mat Club specifies short step-slide motion, uncrossed feet, and retention of stance. Its distinction between lowering at the knees and folding at the waist supports the revised error correction. [S2]
- The College Park handbook adds that level changes may accompany a small step in different directions. Its shadow drill assigns one partner motion and fakes while the other stays facing and matches level. The card uses only the noncontact portion of that idea. [S3]
- Hands remain available in front rather than reaching down to create a false impression of lowering. Level-change depth is limited by retained balance and the ability to take another step, not a prescribed knee angle. These are practical execution checks for this selected beginner exercise.

### Teaching progression

- Demonstrate one successful step-and-follow sequence and one obvious feet-together error. Have the learner stop on command before adding a partner; the stop should not require another balancing step.
- Rehearse the vertical lowering action separately, then link step, lower, step. A brief freeze lets the coach inspect position, but remove that pause once the learner can stay balanced. Avoid teaching a permanent stop before every eventual shot.
- The partner is a visual target and leader, not a receiver of force. First use predictable slow motion, then let the same leader choose an unannounced direction or height change. Swap roles only between rounds. The follower maintains the gap and faces the leader.
- Progress to B03 when the athlete can change height, continue stepping, and recover stance without diving or standing tall. Repetition counts and round lengths are proposed practice organization, not a research-established training dose.

### Common mistakes and corrections

- A following foot that catches the first foot removes the useful base. Reduce travel distance and check the gap after each pair of steps before restoring continuous motion.
- If only the head drops, rehearse a shallower knee-and-hip bend and check from the side. Do not fix this by forcing an exaggerated upright torso or a deep squat.
- If mirroring becomes a chase, slow the leader and return to one change per sequence. The exercise rewards matching position and distance, not catching the other athlete.

### Readiness and rules

B01 is the sole technical prerequisite, so no circular dependency is introduced. No grip, fall, head contact, or scoring action occurs in the selected drill. Its boundary is therefore spacing and balance rather than a special competition-rule restriction. More advanced stance changes, contact reactions, and penetration require their own instruction; the Beginner label alone does not establish readiness.

### What changed

- Kept the recognizable name Motion and Level Change.
- Defined directional foot order and preservation of the base.
- Added a direct footwork-to-level-change-to-footwork sequence.
- Made the partner's role and reaction progression unambiguous.
- Separated standing level change from B03 penetration and removed a permanent pause implication.

### Evidence limits

Inspected instructional PDF text and the club syllabus itself, not merely curriculum titles. The linked USA Wrestling video was not watched. College Park supplies an actual shadow-drill description, but its additional blocks and sprawls are outside this card. No source establishes the proposed four-round schedule, exact cue wording, readiness test, or a universal required depth; those are coaching design. The step-order language operationalizes the uncrossed step-slide instruction for beginners.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF text: page 1 stance; page 2, Skill 2 Motion (12:42-15:52); page 4, Skill 3 Level Change (25:42-28:14), including the following drill outline.

**Supports:** Moving in several directions while retaining position; Lowered hips and bent knees during level change; Progression from level change to penetration

**Limits:** Study-guide instructions were inspected; linked video and its demonstrations were not. The contact drills and attack finishes are not reproduced in this noncontact card.

**S2: [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Full page text, with emphasis on section I-A, items 1-5: Stance, Motion, Changing Level, Making Contact, and Penetration.

**Supports:** Short step-slide motion without crossing feet; Maintaining stance during motion; Lowering through the knees rather than folding at the waist; Closing distance with the feet and hips rather than reaching

**Limits:** Concise club coaching syllabus, not a biomechanics study. It does not prescribe the exact drill schedule or quantify stance width or level-change depth.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling, hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text, printed pages 7-8: The Foundation, Gable Warmup Level 1 items Stance, Motion, Level Change/Set Your Feet, and Level 2 Shadow Drill.

**Supports:** Short sliding or shuffling steps with the base retained; Integrating a small step and level change; One leader supplies motion and level changes while the follower faces and matches level

**Limits:** The handbook is a broader team system. Only relevant stance, motion, level-change, and shadow-drill passages support this card; its additional attacks and contact responses are omitted.

<a id="b03"></a>

## B03 - Penetration Step

**Tier:** Beginner | **Previous name:** Penetration Step And Recovery

### Technical review

The draft correctly placed the level change before the step, used the lead knee, brought the trail leg forward, and required a return to stance. Its sequence omitted the rear-foot push and could be read as stepping and then dropping vertically. 'Head above hips' is too weak a posture check: a bent-over athlete may still satisfy it. The trail-foot location and which knee remains up were also unclear. The revised card makes the right/left sequence explicit and treats recovery as the conclusion of a solo repetition. It does not claim that rising directly to stance is a universal response to a defended shot; B13 owns that situation.

### Selected variant

A solo inside penetration step, initially right leg leading, with a light lead-knee touch and immediate trail-foot recovery. This is a foundation for later leg attacks, not a complete double-leg takedown. The name is the familiar Penetration Step; recovery stays in the instruction. The partner is an observer and distance cue, not a receiver of an unfinished takedown.

### Mechanics and evidence

- Lower the hips by bending the legs while maintaining an upright head and a straight, supported back. USA Wrestling separates level change from penetration and identifies the raised trail leg as part of the low attacking position. Hips must advance with the entry instead of remaining far behind the shoulders. [S1, S2]
- For the selected right lead, the left foot supplies the initial push. The right foot enters first; the right knee then travels forward as the body rolls over the right toes. Preston's instruction explicitly progresses from toe to knee for its inside double-leg entry. 'Knee tracking over toes' means alignment, not a ban on the knee passing the toes during this transition. [S2, S3]
- The left foot comes forward as the right knee lowers, leaving a right-knee/left-foot support position with the left knee up. Eric Akin's published teaching summary links the front knee descending to the back knee stepping up. It starts from a lowered rear-knee teaching position; that is not a direction to crash the lead knee into the floor. [S3]
- Return to a low stance by supporting the body on the newly planted trail foot and bringing the kneeling leg back underneath. This exact solo reset is coaching design. It reinforces a usable stance; Shai separately teaches practicing the ability to abandon an entry and regain stance. No universal step length or opponent-relative knee coordinate is prescribed: Kolat says penetration placement depends on the attack and available opening. [S4, S5]

### Teaching progression

- Demonstrate slowly from the front and side. First rehearse the end position: right knee down, left foot planted to its left, chest lifted, hips underneath. Have the athlete rise without pulling on another person. Then add the forward entry and finally the preceding level change.
- Pauses are temporary teaching checks. Once the athlete understands the sequence, connect the lead-knee touch and trail-foot arrival without waiting on both knees. Use low-speed repetitions before asking for speed. Akin's alternating partner drill and Shai's staged teaching support building the pieces before adding reactions. [S3, S4]
- The proposed three-repetition drill and hold-or-retreat choice are original coaching design. Keep the observer beyond contact range and outside the travel lane. A retreat asks the athlete to restore distance with footwork, not stretch the shot farther. Add an actual partner entry only with the grip, head side, receiving action, and finish taught in the relevant attack card.

### Common mistakes and corrections

- Heavy lead-knee landing: reduce speed and step length, establish the lower position first, and check that the hips are moving forward. Repeated harder knee contact is not the correction.
- Hips left behind or chest folded down: rehearse the one-knee/one-foot end position and bring the trail foot in promptly. 'Head up' should not become a backward neck arch.
- Both knees settle on the mat: restore the trail-foot plant and combine it with the lead-knee touch. A staged rear-knee exercise is not the final rhythm of this card.

### Readiness and rules

This is an unloaded mat drill, not a scoring action. Readiness is the ability to lower, make light knee contact, and rise with balance; Beginner is not an age exemption. Knee pain or impact calls for a reset and coaching adjustment. No takedown-rule interpretation is needed for the selected noncontact drill.

### What changed

- Shortened the title to Penetration Step.
- Specified lead and trail sides, initial rear-foot drive, forward knee travel, and immediate trail-foot arrival.
- Replaced the vague head-above-hips condition with chest, eye, and hip checks.
- Separated staged kneeling instruction from forceful knee impact.
- Replaced an incomplete partner entry with a defined noncontact distance reaction.

### Evidence limits

Inspected accessible page text and USA Wrestling PDF text, not the embedded videos. Akin's publisher summary verifies the knee transition but not a measured foot placement; the left-of-right-knee position is a practical description for this solo variant. Shai's article concerns a different complete attack, so its grip placement and preliminary back-foot step are not imported. Kolat supports avoiding rigid placement rules, not the exact reset. Repetition count, noncontact reaction, and readiness checks are proposed coaching design.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF page text, pages 4-5: level change, low attacking position, and penetration sections.

**Supports:** Lowering the hips and bending the knees for level change; Head up, back straight, and trail leg up in low attacking position; Penetrating through rather than merely arriving at the legs

**Limits:** Study guide, not a frame-by-frame entry description; linked videos were not watched. The named knee-pound drill is not evidence that beginners should strike the mat with the knee.

**S2: [Preston Mat Club Syllabus: Neutral Position and Double Leg Takedown](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Page text, Basic Skills in Neutral Position and Double Leg Takedown sections.

**Supports:** Level change through the knees; Keeping hips underneath during penetration; Inside foot entry and toe-to-knee progression

**Limits:** Concise club coaching syllabus. Its complete double-leg grips and finish are outside this solo card, and it does not specify trail-foot recovery.

**S3: [Develop Your Inside Penetration Step with a 4x All American!](https://www.championshipproductions.com/news/2014/02/14/develop-your-inside-penetration-step-with-a-4x-all-american/)** - Championship Productions, Eric Akin instruction from Youth Wrestling: Takedown Fundamentals; accessed 2026-09-26.

**Inspected:** Publisher's full accessible instructional summary beneath Inside Step Penetration; embedded video not watched.

**Supports:** Rear-foot push from a lowered rear-knee teaching position; Front knee descending as the back knee steps up; Alternating entries with a retreating partner as a teaching drill

**Limits:** Publisher summary of Akin's instruction, not a transcript or personally inspected video. Shoulder rotation and alternating repetitions belong to its drill; this card selects a simpler solo repetition.

**S4: [How to Improve the Speed of Your Takedown](https://www.luchafit.com/articles/how-to-improve-the-speed-of-your-takedown)** - LuchaFit, Katherine Shai; accessed 2026-09-26.

**Inspected:** Coach-authored page text: Back foot first, Penetration step, and Putting it together sections.

**Supports:** Rear-foot loading for the forward entry; Practicing a return to stance when the attack must change; Learning the component positions slowly before adding speed or reactions

**Limits:** The article teaches a specific partner attack with its own setup and grips, which are not adopted here. Embedded clips were not inspected.

**S5: [Wrestling Moves Questions: Penetration Step Question](https://www.kolat.com/technique-questions.html)** - Cary Kolat, KOLAT.COM; accessed 2026-09-26.

**Inspected:** Coach's written answers in the Penetration Step Question section; embedded Vimeo material was not accessible through the web reader.

**Supports:** Prioritizing penetration through the opponent over a fixed knee landing coordinate; Entry placement depending on the selected attack and opponent's opening

**Limits:** Written answers only; does not verify this card's exact trail-foot position or solo recovery.

<a id="b04"></a>

## B04 - Wrist and Inside Tie

**Tier:** Beginner | **Previous name:** Wrist Tie To Inside Control

### Technical review

The draft correctly favored bent elbows, foot movement, whole-wrist contact, and immediate release for joint discomfort. Its central problem was ambiguity: 'their forearm' did not identify the second arm, and 'swim inside' did not define a path or a final grip. A beginner could put both hands on the wrist-controlled arm, inadvertently turn the exercise into a two-on-one, or push against a closed elbow. Resting a hand somewhere on the upper arm also fails to explain why the position is an inside tie. The revised card selects the familiar wrist/inside-tie combination and names the two different opponent arms. Its finish is a usable neutral tie followed by a reset, not a takedown or a claim of scoring control.

### Selected variant

Left hand on the partner's right wrist, right forearm inside the partner's left arm with the right hand cupping the upper arm. The two grips remain on opposite arms. This is a high inside tie, rather than Cox's lower elbow-crook variant, an underhook, or a Russian two-on-one. The title describes the resulting combination accurately. The slow wrist-first acquisition is a teaching sequence assembled from the inspected contacts, not a claim that a particular coach prescribed this exact five-step drill.

### Mechanics and evidence

- Esposito's public demonstration shows wrist contact above the hand and an inside position with the forearms beneath/inside the opponent's arms and hands around the upper arms. The card applies those observed contacts to opposite sides, avoiding individual fingers. Selected frames were inspected, not a complete audio transcript. [S1]
- Ironside's publisher explicitly lists an inside-tie/wrist combination and describes bent-elbow positioning and coordinated hand/foot movement. This establishes that the combination is conventional; the sales description does not establish its exact entry choreography. [S3]
- USAW identifies one- or two-handed wrist and biceps contacts and defines pummeling as bringing the arms inside. This supports calling the right-hand action an inside entry while keeping it distinct from a back-reaching underhook. [S4]
- The circle is short and supported by uncrossed feet; the receiver follows to face instead of holding the feet fixed while the arm turns. College Park's handbook specifically emphasizes moving an opponent from inside ties through pulling and circling. Direction to the attacker's right is the selected rehearsal, not an assertion that only that direction works. [S5]

### Teaching progression

- First demonstrate the finished position from front and side. Have the athlete name 'their right wrist' and 'their left upper arm' before making contact. The receiver keeps a bent elbow and relaxed hand so the grip can be checked without resistance.
- Rehearse acquiring the wrist, adding the other tie, taking one short circle, and fully releasing. The receiver steps with the contact and never tries to win by stiffening an arm. Mirror only after the first side is understood.
- The defined reaction is withdrawal of the free elbow before entry. The attacker must notice a closed lane and reset rather than pry it open. This deliberately narrow game tests distance, hand placement, and release before adding a previously taught attack. Weber's developmental guidance supports foot movement, entering/leaving ties, and keeping beginner setup work simple. [S2]
- The three repetitions and four timed rounds are proposed coaching organization. They are not validated training doses or a minimum readiness test. Progress when both partners can move their feet, maintain bent arms, and release promptly.

### Common mistakes and corrections

- Both hands seek the same arm: return to stance and name the two target limbs. Opposite-arm contact is the defining choice here; a two-on-one requires its own lesson.
- The inside elbow flares or the hand merely pushes the shoulder: bring the elbow down and check that the forearm is inside the biceps with fingers around the upper arm.
- The athlete hangs on while the partner retracts or retreats: open the grip, shorten the distance with the feet, and re-enter. Do not substitute a stronger squeeze or a wrist turn for lost position.

### Readiness and rules

This is a neutral hand-fighting lesson, so neither participant needs to receive a fall. Tier is a readiness description, not age permission. The no-finger and no-joint-forcing boundaries are explicit lesson restrictions. The inspected current USAW international-style rulebook prohibits finger twisting and force against joints and explains the 'NO FINGERS' command. It expressly excludes folkstyle from its scope, so it is not cited as an NFHS penalty ruling. No competition points, stalling time, or universal age authorization are claimed. [S6]

### What changed

- Renamed the card to the familiar combination 'Wrist and Inside Tie'.
- Specified left-to-right wrist control and right-to-left upper-arm control, retained together.
- Defined the inside forearm position, upper-arm contact, short circling step, receiving action, and release.
- Replaced an open-ended hand fight with one clear receiver reaction and a reset option.

### Evidence limits

S1 and S2 video evidence consists of sampled visible frames, without an inspected transcript or claimed continuous viewing. S3 is only publisher text, not the paid instructional. S4 gives contact taxonomy and inside-entry principles, not an exact wrist-to-inside recipe. S5 supports movement from the tie. These sources substantiate the component positions and established combination; the wrist-first teaching order, rightward circle, receiver task, cues, and dosage are original coaching synthesis. The card does not borrow the more forceful snaps, head pressure, or advanced finishes appearing elsewhere in the sources.

### Sources inspected

**S1: [Controlling Ties - Wrist, Inside, and Elbow](https://www.playsportstv.com/wrestling/wrestling-moves_controlling-ties-wrist-inside-and-elbow)** - PlaySportsTV; instruction by Dave Esposito; accessed 2026-09-26.

**Inspected:** Page description and public embedded Vimeo 116951855 video frames at player positions approximately 0:16, 0:21, 0:36, 0:51, 0:56, 1:01, 1:31, and 1:46. Wrist contacts and double inside arm positioning were visible.

**Supports:** Whole-wrist contact above the hand; Inside forearms and upper-arm grips; Distinction from a same-arm two-on-one

**Limits:** Sampled frames only, not the complete spoken lesson. The demonstrated wrist and inside contacts do not by themselves verify the full proposed combination entry.

**S2: [How To Teach Takedown Setups](https://www.attackstylewrestling.com/teach-setups/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full article text and sampled frames of its inside_tie_setups_854x480 public Vimeo 513328959 video at about 0:00, 0:10, 0:40, 1:10, 1:40, and 2:10; the 1:10 frame showed partners moving from inside ties.

**Supports:** Inside ties are loose control ties; Developing wrestlers should move their feet and learn to enter and leave ties; Keep early setup teaching simple

**Limits:** Article provides teaching principles; selected video frames are not a spoken technical transcript or proof of the specific wrist-first entry.

**S3: [The Art of Hand Fighting](https://www.championshipproductions.com/cgi-bin/champ/p/Wrestling/The-Art-of-Hand-Fighting_WRD-04532A.html)** - Championship Productions; instruction by Mark Ironside; accessed 2026-09-26.

**Inspected:** Public Features & Benefits description, especially the paragraphs naming the inside tie/wrist combination and hand-fighting positioning.

**Supports:** The inside tie/wrist combination is an established coaching option; Keep elbows close and coordinate hands and feet

**Limits:** Publisher description only. Paid video was not accessed; it cannot verify exact grips or the entry sequence.

**S4: [Coach's Guide to Excellence, Second Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling, Coaches Corner; accessed 2026-09-26.

**Inspected:** PDF text extracted directly from public PDF pages 151-158, particularly printed pages 151-152 (Contacts and Set-ups) and 155-157 (Clearing Ties).

**Supports:** One- and two-arm biceps and wrist contacts; Pummeling means bringing arms inside for control; Teaching contacts and their clearing reactions

**Limits:** These pages identify contacts and related actions, but do not detail this exact wrist/inside combination entry.

**S5: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text: printed page 8 motion guidance and printed page 16 Inside/Inside Collar introduction (PDF pages 8 and 16).

**Supports:** Short uncrossed steps; Moving an opponent from inside ties with pulling and circling

**Limits:** Does not specify this wrist-first sequence. Other advanced techniques in the handbook are outside this card's scope.

**S6: [Rule Book & Guide to Wrestling, 2027 Edition](https://www.usawmembership.com/usa_wrestling_rule_book)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Public rulebook text, last updated September 13, 2026: scope statement; section 7.5 NO FINGERS; sections 18.1 and 18.3 on illegal and potentially dangerous holds.

**Supports:** Finger twisting and force against joints are prohibited; Officials stop potentially dangerous situations

**Limits:** Freestyle, Greco-Roman and women's international-style rules; the book explicitly excludes folkstyle. Used for joint-control principles, not NFHS penalty details.

<a id="b05"></a>

## B05 - Arm Drag to Go Behind

**Tier:** Beginner | **Previous name:** Arm Drag To Rear Position

### Technical review

The original correctly combined wrist and upper-arm control, arm clearance, footwork, and release before pulling the arm backward. Its main problem was unresolved laterality. 'Opposite hand,' 'opposite hip,' and 'outside the controlled arm' did not tell a new coach which arm or foot to demonstrate. Releasing into an unspecified rear position also left a gap between passing the shoulder and controlling the hips. The replacement identifies one arm throughout and teaches the waist transition. Getting behind in this standing drill is not presented as a completed takedown.

### Selected variant

Standing wrist-control arm drag with an outside step and go-behind. Attacker left hand controls opponent right wrist; attacker right hand controls opponent right triceps. Coaches sometimes call this same-side wrist control because the arms face each other; the card avoids that confusing label. Stopping upright is a beginner drill restriction before Weber's full downward finish.

### Mechanics and evidence

- Kesting specifies right hand to opponent left wrist and left hand to that same triceps; the card mirrors this. The wrist feeds the upper-arm grip, which draws the arm across while the attacker advances toward the back. This differs from dragging an opponent who already holds the attacker's wrist. [S2]
- Weber teaches an outside step and pivot without overextension, keeping the head at roughly the same height and turning with the hip. His preview frames show solo footwork, then the wrist-and-triceps entry. Translated to the opponent's right arm, the left foot steps outside their right foot and the right foot follows around. [S1]
- The elbow travels across the attacker's front toward the pulling-hand side as the attacker moves toward the exposed shoulder. The arm clearance and footwork belong to one action; pulling to completion and only then beginning to walk gives the receiver time to square. [S1, S2]
- Weber connects the drag to the far hip. The card specifies the transition: the left wrist hand reaches around the waist after passing the right shoulder; the triceps hand releases upon reaching rear position. Weber finishes downward; stopping upright with separate hands at the waist is this card's adaptation. [S1]
- The Human Kinetics sheet starts with the opponent holding the wrestler's wrist and follows the elbow drag with a double leg. It confirms the arm-clearance purpose but supplies a different entry and finish, which were not mixed into the selected variant. [S3]

### Teaching progression

- Demonstrate once from the front so the two grips are visible and again from the side so learners see the step past the shoulder. Before contact, rehearse the left outside step followed by the right foot coming around; finish balanced rather than crossing the feet or lunging.
- In the first partner repetitions, the receiver keeps the elbow free to bend and takes small following steps as their shoulder turns. They remain on their feet and do not manufacture a fall, lock the elbow, or plant their feet against the arm pull. Attacker and receiver should both be able to stop during the transition.
- Start with an offered wrist and a light grip. Add the hip catch only when the pair can pass the shoulder smoothly. Then allow the receiver one squaring step. The attacker must either continue around with the feet or release and reset when the opening closes. Repetition counts and this restricted reaction are coaching design, not a research-established training dose.

### Common mistakes and corrections

- A wrist-only tug moves the forearm without clearing the shoulder. Pause to find the triceps with the second hand, then pair the pull with the outside step.
- A long sideways step leaves the attacker too far from the hip. Shorten the step and follow the cleared shoulder; do not try to bridge the gap by pulling harder on the arm.
- Hanging onto both grips after arriving beside or behind the receiver can draw the arm backward. Transfer the wrist hand to the hip during the go-behind and release the remaining upper-arm grip at the standing endpoint.

### Readiness and rules

Use this as a standing positional drill once both partners can maintain stance, follow footwork, and release promptly. Beginner is a readiness tier, not an age permission. No competitive scoring or mat-return rule claim is needed for this endpoint. A later takedown finish requires its own receiving lesson and the rules for the applicable event. Kesting's submission-grappling wrist manipulation and submission follow-ups are not part of this wrestling card.

### What changed

- Changed the name to the familiar Arm Drag to Go Behind.
- Specified both gripping hands, one opponent arm, elbow direction, and the outside stepping foot.
- Added the wrist-to-far-hip transition and a clear standing stop/reset.
- Explained cooperative receiving and limited the first defensive reaction to one squaring step.

### Evidence limits

Inspected Weber and Kesting's public article text, the Human Kinetics sheet, and sampled public preview frames from Weber's embedded video. The stills cover approximately 0-90 and 138-256 seconds; useful grip/pivot frames fall around 224-248 seconds. No continuous playback, audio, transcript, or claim of watching the entire 472-second video. The standing stop, separate-hand waist contact, receiving instructions, and restricted drill are coaching adaptations. The downward finish and submission details were excluded.

### Sources inspected

**S1: [Arm Drag Takedown; embedded Same Side Wrist Drag to Mat demonstration](https://www.attackstylewrestling.com/arm-drag/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Public article text, including steps 1-3; sampled public preview frames from embedded Vimeo video 506474386, particularly solo footwork near 16-28 seconds and partnered grips/pivot near 224-248 seconds. No audio inspected.

**Supports:** Outside step and pivot without an overlong entry; Head remaining at the same general level; Upper-arm drag coordinated with hip and footwork; Connection to the far hip after the drag

**Limits:** The full taught finish draws the receiver to the mat. Preview frames are sampled stills and do not verify every instant or spoken cue; the beginner standing endpoint is an adaptation.

**S2: [The Four Simplest Armdrags for BJJ and Submission Grappling](https://www.grapplearts.com/four-simple-armdrags-for-bjj-and-submission-grappling/)** - Stephan Kesting / Grapplearts; accessed 2026-09-26.

**Inspected:** Full public article text; especially section 1, Armdrag from Wrist Control, and its distinction from section 2, Armdrag vs Wrist Control.

**Supports:** Explicit opposite anatomical hand to wrist and other hand to the same arm's triceps; Wrist feed followed by upper-arm pull and advance toward the back; Distinction between owning the wrist and the opponent owning your wrist

**Limits:** Primary instruction by a grappling coach, not a wrestling rule authority. It includes submission-grappling details that the card excludes and does not specify a numbered standing foot sequence.

**S3: [Offensive Neutral Position Move: Arm Drag](https://s3.amazonaws.com/my.llfiles.com/00224751/armdrag.pdf)** - Human Kinetics / Coaching Youth Wrestling Course, 2003; publicly hosted course sheet; accessed 2026-09-26.

**Inspected:** Extracted text of the entire one-page PDF.

**Supports:** Arm drag as a takedown setup; Dragging the elbow across the wrestler's body creates an attacking angle; Its opponent-holds-wrist entry and double-leg follow-up are a separate variant

**Limits:** Used for comparison, not as proof of the selected wrist-control/outside-step/go-behind sequence. The PDF photographs were not available through the web screenshot tool.

<a id="b06"></a>

## B06 - Elbow Pop

**Tier:** Beginner | **Previous name:** Pop And Go

### Technical review

The original correctly linked an upward clearance with a level change and penetration. Its starting situation was missing: hands held loosely in front are not the same problem as an opponent posting through the upper arms. Forearms near the elbows also leaves the coach unsure which surface receives the lift. The title could describe several unrelated actions. This revision identifies the two-arm elbow pop and specifies its receiving position. The old final instruction depended on an already-taught double-leg finish despite naming only B03-B04 as prerequisites. Making the endpoint a paused leg capture removes that hidden dependency without claiming that an entry scores a takedown.

### Selected variant

Two-arm elbow pop against extended upper-body posts, followed immediately by a double-leg entry. USA Wrestling separates this upward clearance from a collar-tie pass and a downward arm snap [S1]. Heath Sims also labels elbow popping a basic double-leg setup [S3]. This retains the original card family and gives beginners one recognizable action.

### Mechanics and evidence

- The contact point is the underside of each upper arm immediately above the elbow. USA Wrestling places the upward pop in its straight-arm clearing section [S1]. The short card uses palms and slightly yielding elbows as a rehearsal specification; the target is the upper arm, not a bent wrist or the elbow joint itself.
- Mazzeo describes initiating forward motion and attacking as the opponent returns it: both arms rise at the elbows, then the attacker lowers and penetrates between the legs [S2]. A partner who simply floats both hands overhead would remove the timing problem the setup is meant to solve.
- For the right-lead example, the head goes to the attacker's left, outside the partner's right ribs; each hand catches behind a knee. This applies Mazzeo's head-opposite-lead-leg and separate leg-capture instructions [S2]. The named sides are an explanatory convention, not a claim that only right leads work.
- Release the upper-arm contact as the hands travel to the legs. The deliberate pause, release, and return to stance are this card's training endpoint. A coach can later connect the established entry to B07; no finish is silently imported here.

### Teaching progression

- Demonstrate the complete entry and reset, then show the hand placement from the side. Have the receiver identify the contact on the upper arm before either athlete adds speed. Start close enough that neither wrestler needs to lean or reach to establish the posts.
- For the first three repetitions, the receiver supplies a small forward response and lets the elbows rise. The attacker should finish balanced with the head beside the torso and hands at the knees. Both hold still, release, and reset together. The receiver remains standing; there is no fall to improvise.
- Add one defined choice: receiver presses back or withdraws the posts. Score the learning task by whether the attacker recognizes the opening and either enters promptly or resets. Do not reward lunging after retreating hands. Round lengths and the three-repetition introduction are proposed coaching design, not a studied dose.

### Common mistakes and corrections

- If the athlete reaches toward the wrists, stop and re-place the palms on the upper arms. Contact farther down the limb can move the hands while leaving the upper-arm obstacle in place.
- If the athlete rises tall with the pop, rehearse the hands rising as the hips lower at walking speed. If the legs are reached only by stretching forward, shorten the initial distance and repeat B03 before adding resistance.
- If the receiver locks the arms or braces against the lift, reduce the force and restore yielding elbows. This is not a contest to force the shoulder upward. If the lane closes, release and restart rather than combining an improvised head snap with the pop.

### Readiness and rules

Readiness means a balanced B03 entry, cooperative receiving, and reliable release. Beginner is a readiness tier rather than an age clearance. The card teaches no throw, lift, fall, or scoring claim, and does not need a rule-specific finish. Face contact and forced shoulder range are excluded from the exercise; a later competitive finish needs its own receiving and event-rule checks.

### What changed

- Renamed Pop And Go to Elbow Pop.
- Specified upper-arm contact above both elbows and mapped the hands.
- Defined returning forward pressure as the entry opportunity.
- Specified one right-lead double-leg entry and replaced the unspecified finish with a capture-and-reset endpoint.

### Evidence limits

The official USA Wrestling PDF was inspected as extracted page text, including PDF pages 156-158 (printed pages 155-157); its brief instruction does not supply a full double-leg lesson. Mazzeo's own instructional page and author context were read; the animated GIF was not inspected, and its lifting/dumping finish is excluded. Evolve's public lesson description confirms the technique name and double-leg relationship only; the subscription video was not watched. The selected training start, soft elbows, open palms, pause, withdrawal choice, and drill dose are explicit coaching design built around the documented mechanics.

### Sources inspected

**S1: [USA Wrestling Coach's Guide to Excellence, 2nd Edition - Clearing Ties](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Official PDF downloaded in memory and read with pypdf: PDF pages 156-158, especially page 157 / printed page 156, Clearing Ties item 4A. Official educational-resources page inspected to verify its PDF link.

**Supports:** Straight-arm clearance by popping both arms upward above the elbows and shooting.; Distinct descriptions for collar-tie elbow pass, downward arm snap, and one-arm pop variants.

**Limits:** Brief coach-manual prescription, not a full photographed sequence; no claim of inspecting embedded movies or a modern event-rule ruling.

**S2: [Wrestling Takedown Reference Library - Double Leg w/ dump](https://www.todayfitness.net/wrestling/takedowns/)** - TODAY! Fitness; Pete Mazzeo and fellow wrestling coaches; accessed 2026-09-26.

**Inspected:** Full HTML instructional text, specifically the takedown introduction and Double Leg w/ dump paragraph. The parent wrestling page identifies the coach-authored demonstration project; the main site identifies Pete Mazzeo. Animated GIF not viewed.

**Supports:** Forward motion followed by an opponent returning pressure.; Two-elbow upward clearance followed by level change and a penetration step between the legs.; Head outside opposite the lead leg and hands behind both knees or upper calves.

**Limits:** Independent coaching website, not an official curriculum or rule authority. Its lift-and-dump finish is not used in this card.

**S3: [Double Leg Basic Setup Elbow Pop - Heath Sims](https://evolve-university.com/library/wrestling/beginner/video-double-leg-basic-setup-elbow-pop/)** - Evolve University; accessed 2026-09-26.

**Inspected:** Public lesson title and descriptive paragraph. Page requires subscription for the demonstration; video not watched.

**Supports:** Recognized coach Heath Sims teaches elbow popping as a basic double-leg setup.

**Limits:** Corroborates naming and purpose only; not cited for hand placement, timing, footwork, or finish.

<a id="b07"></a>

## B07 - Double Leg Takedown

**Tier:** Beginner | **Previous name:** Double Leg Corner Finish

### Technical review

The original correctly included a level change, separate knee grips, a recovered trail foot, and side-hip receiving. Its decisive problem was circling toward the attacker's head side. That could send the attacker around the near hip without removing the far-leg base. The selected finish drives across the opponent while bringing the knees the other way. The draft also omitted the entry foot, head side, and hand actions. Its instruction to separate a clasp contradicted the separate grips taught at entry. The revision resolves these details within one variant.

### Selected variant

Right-foot penetration into a head-outside double with an angled head-drive finish: 'flair' in College Park's handbook and 'turning the corner' in Horaski and Garcia's lesson. The beginner rehearsal stays low, without the separate standing lift. Directions belong to the attacker unless the receiver is named. Teach the mirror version separately.

### Mechanics and evidence

- The head stays outside and each hand holds behind one knee; the trailing foot steps outside to generate the finish. John B. Will explicitly describes these connections and a far-hand action that prevents the receiver hopping away. His photographs also show a substantially higher lift than this card permits. [JOHN_WILL]
- For the chosen right-foot version, the head is on the attacker's left at the receiver's right ribs; the left trail foot comes outside that same right leg. The left hand controls the receiver's right knee and the right hand controls the far left knee. These right/left labels are an explicit teaching orientation of the outside-head, opposite lead/trail arrangement shown in the source sequence. [JOHN_WILL]
- Horaski and Garcia specifically direct the finish toward the original lead-leg side, with shuffling steps across the body. Thus this right-foot version travels diagonally right, not left around the head. They pair removal of the far-leg support with the near-leg action and describe the shooter arriving above the hips. [HORASKI_GARCIA]
- College Park describes an angled head drive with the legs drawn inward and sideways, ending on the receiver's hip. Its separate corner-lift row changes the grips and elevates the opponent; those mechanics are not imported into this basic finish. [COLLEGE_PARK]
- USA Wrestling identifies the double as a basic attack and emphasizes that completing a shot should also improve subsequent control. The inspected guide pages do not provide the detailed side or hand sequence. [USAW_GUIDE]

### Teaching progression

- Demonstrate entry, freeze, and finish with an assistant. Place a floor marker at the attacker's right-front corner and identify the receiver's right leg before partners begin. This is proposed coaching design.
- Rehearse receiving separately from a squat: lower to the left hip and side, keep the head off the mat, and avoid catching body weight on a locked elbow. During initial doubles the receiver cooperates with descent; the attacker retains connection and supports their own weight. This is the practice adaptation, not a claim that a resistant opponent willingly sits.
- Check the outside foot and far-knee grip before each of three alternating repetitions. Progress to a single retreat before entry, with an explicit reset if distance is lost. This drill dose and reaction are original coaching choices; a sprawl is a later lesson, not an unexplained escalation here.

### Common mistakes and corrections

- If the receiver steps away with the far foot, restore the right-hand grip behind the left knee and move the feet across before increasing speed.
- If the attacker's knee stays planted or the torso folds, return to B03 and shorten the entry until the trail foot can supply the drive.
- If the receiver posts rigidly, stop full finishes and repeat the low receiving rehearsal. Do not solve poor receiving with a faster takedown.

### Readiness and rules

Beginner is a readiness tier. Both partners need reliable stops, mat awareness, knee alignment, and demonstrated receiving before added resistance. The side of the head maintains contact; the crown is not a driving surface. A leg being unweighted during the finish is different from a standing body lift or dump. The card deliberately keeps separate grips and makes no scoring or locked-hands rule claim; no historical points statements from these sources were adopted.

### What changed

- Use the familiar name Double Leg Takedown and define the specific finish in the steps.
- Correct the ambiguous head-side circle to rightward cross-body drive for a right-foot shot.
- Specify both hands, head side, trail foot, opposite knee-gather direction, and left-side receiving.
- Replace the unexplained clasp release with a definite settle-and-reset endpoint; distinguish a low finish from a standing lift.

### Evidence limits

College Park supplies the basic finish; Will corroborates entry and drive connections but illustrates a higher elevation. Horaski and Garcia clarify direction; their older PE unit is not used wholesale or as a rule authority. USA Wrestling's guide pages were visually inspected, including the lone first image of Zadick's sequence on PDF page 242; that image cannot verify a complete finish. No inaccessible videos were treated as watched. Receiving restrictions, stops, counts, and reaction progression are coaching design.

### Sources inspected

**COLLEGE_PARK: [College Park Wrestling Technique Handbook: Double finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text for basic position on page 9 and finish descriptions on page 23; rendered page 23 inspected visually, especially DOUBLE / FLAIR and TURN CORNER LIFT rows.

**Supports:** Chest-up double position with trail leg available and hands behind both knees.; Angled head drive and inward-sideways leg pull ending on the receiver's hip.; Distinct grips and elevation for the separate corner-lift finish.

**Limits:** Team manual, not a rulebook. Does not prescribe this card's receiving drill or right/left labels. Historical scoring language is not used.

**JOHN_WILL: [How to set up wrestling's double leg from the classic Thai clinch](https://www.grapplearts.com/Clinch%26MMATakedowns.pdf)** - John B. Will; authored instructional PDF hosted by Grapplearts; accessed 2026-09-26.

**Inspected:** PDF pages 2-3 text under The Takedowns / The Basic entry; rendered PDF page 3 inspected for the upper six-photo basic-double sequence and distinction from the lower high-crotch sequence.

**Supports:** Lead foot between the legs, head outside, separate grips behind the knees.; Outside trail-foot step and far-hand control during the drive.

**Limits:** Submission-grappling context. Photographs include a high elevation, so they do not justify copying that landing into a beginner card. The card's right-foot version explicitly orients the same basic connections.

**HORASKI_GARCIA: [Wrestling Unit Block Plan: Lesson 3, Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Extracted PDF page text on pages 11-15, especially pages 12-14: angle toward the original lead-leg side, shuffle across the body, far/near knee actions, and finish above the hips.

**Supports:** Explicit lead-leg-side direction for turning the corner.; Separate entry rehearsal before a full finish and cross-body footwork.

**Limits:** Older authored PE teaching unit, not current wrestling rules. Some wording elsewhere is unsuitable for this card; its defense, impact, and trip instructions were not adopted.

**USAW_GUIDE: [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached official PDF text and rendered PDF pages 154-155 (printed pages 153-154), plus rendered PDF page 242 (printed page 241), Bill Zadick thumb-block-to-double page containing only photo 1 of 5 in this export.

**Supports:** Double leg as a core attack and the importance of finishing into useful control.

**Limits:** 2015 guide; inspected pages offer general principles, not complete double-leg mechanics. No current scoring or legality claim derives from this source, and the exported single Zadick photo is not a complete technical sequence.

<a id="b08"></a>

## B08 - Single Leg Run the Pipe

**Tier:** Beginner | **Previous name:** Head-Inside Single Circle Finish

### Technical review

The draft identified the correct family: head-inside single, one leg held between the attacker's legs, an outside backstep, and a low finish. Its main problem was an incomplete action description. 'Bow over the captured thigh while guiding it down' can become waist folding, arm pulling, or repeated circling without moving the receiver's hip. It also left the reader to guess whose outside foot moved. The replacement names the standard finish, starts in an established single-leg position, and uses an explicit right-leg example. This is a finishing card; B03 alone does not teach the single-leg pickup, so that pickup is now an explicit coach-taught prerequisite.

### Selected variant

A head-inside, hands-clasped-behind-knee run-the-pipe finish, with the receiver's right leg between the attacker's thighs. The attacker steps the outside left foot backward, pivots on the inside right foot, lowers the hips, and uses the left shoulder over the thigh to lower the receiver's right hip. Mirror the complete example for the other side. The card excludes a high-crotch head-outside finish, calf-grip version, trip, and lift-and-dump.

### Mechanics and evidence

- The USA Wrestling guide explicitly names running the pipe among shot finishes and stresses the resulting position for subsequent control. It does not specify this finish's grip or stepping foot. [S1]
- College Park starts its single finishes with the head high against the ribs and a locked single-leg grip. Its run-pipe instruction retains that grip and combines a backward step with a pivot and inward leg pull, taking the receiver toward the held-leg side. [S2]
- Horaski and Garcia explicitly teach a head-inside single with a clasp behind the knee, the leg between the attacker's legs, a backstep/pivot, lowered hips, and shoulder pressure on the thigh. That supplies the selected grip and torso action. [S3]
- The card's right/left labels translate those positional instructions into one demonstration: the attacker is facing the receiver, holds the receiver's right leg, and places the left shoulder nearest that thigh. The left foot is outside the held leg; the right foot is inside. These labels are an editorial clarification, not quoted laterality from the manuals.
- Avellan independently emphasizes directing the hip downward through shoulder contact above the thigh rather than relying on rapid circling. His separate ankle-securement and knee-pressure detail is not adopted in this wrestling card. [S4]

### Teaching progression

- Demonstrate the starting grip and both feet from front and side. Have the athlete point to the receiver's right leg and their own outside left foot before moving. Rehearse the step and pivot without a partner first.
- Teach receiving separately: turn the whole body with the held thigh and settle to the near side while keeping the head clear and avoiding a rigid hand behind the body. The attacker follows at matching speed; the receiver does not resist by fixing the captured foot to the mat.
- Begin with an already established single to isolate the finish. After three smooth repetitions, allow one small balancing step. This narrowly defined reaction checks adjustment without introducing an untaught whizzer counter. A stall or loss of alignment produces a reset, not harder twisting.
- Link the pickup and setup only after both partners can stop, release, and land predictably. The repetition counts and readiness checks are proposed coaching design. USA Wrestling supports separating a complex single leg into teachable parts and teaching the defensive side alongside offense. [S1]

### Common mistakes and corrections

- Upright circling leaves the receiver able to track with the free foot. Rehearse one backward step with simultaneous hip lowering; keep shoulder contact on the thigh rather than chasing speed.
- Pulling the ankle sideways while the thigh is fixed loads the knee. Retain the near-knee grip, move the feet and receiver's hip together, and release immediately if the leg cannot follow.
- Bending only at the waist can drop the head and leave the attacker stretched out. Reduce the descent, bend the knees, and recover a supported stance before adding the finish.
- Stopping at the landing leaves an unfinished takedown. Teach the follow to hip/arm control as part of each repetition; the clasp change is a coaching transition, not a claim that every clasp around one leg is illegal.

### Readiness and rules

Beginner is a readiness tier. The prerequisites are a sound pickup, release on command, and cooperative receiving on a wrestling mat. Lifting the captured foot is distinct from lifting the receiver's entire body. This card does not prescribe a submission, knee hyperextension, or force against a planted leg. It makes no scoring-value or current event-legality claim; the historical manuals are not current rulebooks.

### What changed

- Renamed the card Single Leg Run the Pipe.
- Specified the held leg, both arms, head side, stepping foot, pivot foot, and hip destination.
- Replaced vague bowing and guiding the leg down with coordinated hip lowering, shoulder contact, and an inward leg draw.
- Added the pickup prerequisite, explicit receiving, follow-through control, and one defined balancing reaction.

### Evidence limits

The official USA Wrestling text was inspected independently at PDF pages 119 and 154-156; it supplies teaching principles and finish context, not exact mechanics. The two instructional PDFs supply the mechanical text. They use different shooting/trail labels because their entry contexts differ; the card instead names the feet by position and laterality. Only accessible text was inspected; no linked video is claimed as watched. S4 is corroboration of shoulder/hip action, not the chosen grip variant. Receiving and the short drill are conservative coaching design rather than a verbatim source protocol.

### Sources inspected

**S1: [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Local official-source cached PDF extraction with page markers: PDF page 119 (printed 118) and PDF pages 154-156 (printed 153-155), plus origin metadata.

**Supports:** Breaking single-leg instruction into component skills; Running the pipe as a recognized shot finish; Following a finish into useful control and teaching corresponding defense

**Limits:** No exact run-the-pipe hand placement or footwork. Historical rule content was not used.

**S2: [College Park Wrestling Technique Handbook: Single finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF extracted page text: PDF page 24 (printed 24), Single header and Run Pipe row; surrounding finish rows to distinguish dump and circle-to-hole variants.

**Supports:** Head at ribs and retained single-leg lock; Backward step, pivot, inward leg pull, and near-side landing; Run-the-pipe can be the first-choice finish

**Limits:** Uses far/trail terminology rather than an explicit right/left example. Screenshot request failed; only PDF text was inspected.

**S3: [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** PDF extracted text, authorship on PDF page 2; Lesson 10 on PDF pages 38-40, especially instruction on PDF page 39; Lesson 11 review on PDF page 42.

**Supports:** Head stays inside, hands lock behind the knee, and held leg lies between the attacker's legs; Backstep and pivot combined with squatting and shoulder pressure on the thigh; Progression from cooperative partner to balance/foot-recovery defense

**Limits:** School instructional plan, not a rule authority. Its shooting/trail labels refer to its outside-step entry. Exact squat depth and higher-resistance drills were not imported.

**S4: [Running the Pipe](https://davidavellan.com/running-the-pipe/)** - David Avellan, coach's own instructional blog; accessed 2026-09-26.

**Inspected:** The accessible explanatory article text beneath the video embed; video not watched.

**Supports:** Shoulder over the thigh and downward hip action distinguish the finish from mere spinning

**Limits:** MMA/grappling context. Its ankle-securement and knee-bar pressure detail is excluded from the selected clasp-behind-knee wrestling variant.

<a id="b09"></a>

## B09 - Sweep Single

**Tier:** Beginner | **Previous name:** Sweep Single To Cover

### Technical review

The draft correctly recognized an outside attack, head-inside positioning, a circling trail leg, and a finish behind the hips. Its decisive finish was missing: drawing one knee close does not by itself explain why an opponent must fall. The receiver was effectively instructed to supply the takedown by lowering onto a knee and hip. The draft also left the wrapping hand, shooting leg, second hand, and direction of travel unspecified. This revision gives the attacker an actual second-leg control and makes the receiver's descent a response to that finish. B08's standing single is not a necessary prerequisite for this low route; the entry, inside tie, and receiving skills are the useful foundations.

### Selected variant

Right-side outside sweep against the opponent's left leg, followed by a low backside far-knee finish. The right arm initially captures the near knee; after reaching the backside, the left hand takes the captured lower leg and the right hand collects the far knee. This is the hand-switching finish described by Gable, rather than a standing trip, high-leg finish, or shelf finish. Side labels are an explicit mirrored teaching example, not a claim that the manuals mandate attacking only this side.

### Mechanics and evidence

- The College Park handbook teaches a level change, outside step, and swinging trail leg; its inside-tie sweep keeps the opposite arm until the attacked knee is captured. The card maps that relationship to left-arm control and a right-arm attack on the opponent's left leg. [S1]
- Pell's coaching notes require an upright head during entry and tight shoulder placement behind the thigh, beneath the buttock. This location matters more than a vague instruction to keep the chest lifted: it gets the attacker past the hips while retaining contact. [S3]
- Gable's sweep-single finish proceeds behind the opponent, changes hands with mat support, drives forward, and uses the formerly posting arm to grasp the far knee. The revision makes each hand's job visible and maintains the captured leg during the exchange. [S2]
- USAW separates learning attacks from learning finishes; listing sweep single does not establish this card's grips. The guide is used only for that curriculum distinction. [S4]

### Teaching progression

- Demonstrate the entire move from both sides of the pair, then begin teaching at the backside. Have the receiver start low enough that the coach can check the ankle grip, shoulder contact, far-knee reach, and side-hip landing before adding a standing entry. This backward rehearsal is a coaching choice for this card.
- Rehearse the outside swing step without a partner first. The shooting foot must remain free to turn with the knee; do not coach a forceful twist on a planted foot. Add an open entry, then the inside-arm pull and stepping response. After the tie is released, the receiver can use bent arms to reach the mat during a low descent rather than absorb a fall through a locked elbow.
- The first receiving task is to let the captured leg and pelvis travel together. The later task is one deliberate step to face the attacker before the backside is won. If that step closes the corner, reset; beginners are not being asked to invent a scramble finish. The repetition counts and reaction constraint are original practice design.

### Common mistakes and corrections

- Pulling the captured leg sideways while its foot remains planted: stop, restore alignment, and shorten the entry. The target is a new position behind the hips, not rotation through the receiver's knee.
- Reaching for the far knee from beside the opponent: recover shoulder contact and circle farther before transferring the grip. Merely extending the arm exposes the attacker to being flattened.
- Letting go of the near leg during the hand switch: rehearse the transfer from a stationary backside position. The left hand establishes the lower-leg hold before the right hand leaves it.

### Readiness and rules

Beginner is a readiness tier. Coach-check the outside entry and cooperative descent before adding even the single squaring reaction. Stop for a trapped knee, neck loading, or a rigid landing arm. The finish uses separate leg holds and transitions to the program's taught top position; this review makes no scoring-point claim and does not adopt historical freestyle rules from the USAW guide. Event-specific folkstyle interpretations remain for the supervising coach and referee.

### What changed

- Shortened the name to Sweep Single.
- Added the setup, explicit side labels, shooting leg, trail-leg path, and hand transfer.
- Replaced an assumed receiver collapse with a sourced far-knee finish.
- Removed the unnecessary B08 dependency and replaced fixed timed rounds with positional rehearsal and one defined reaction.

### Evidence limits

Inspected full accessible coaching text, including the College Park PDF text and the Gable book's page-labeled transcription. The Gable figure caption was readable; its illustrated frames were not inspected. Pell's written key points were inspected, but the linked premium videos were not watched. The USAW guide provides curriculum context only. Exact right/left mapping, gentle receiving, release/reset instructions, and rehearsal dose are this audit's coaching adaptation. High-leg, standing-trip, shelf, and backdoor alternatives were deliberately excluded from the short card.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text: page 8, Swing Step; page 17, Swing Single; pages 24-25, Circle to Hole and Rear Double (1-based PDF pages).

**Supports:** Outside swing-step entry; Keep the far arm until the knee is secured; Circle behind and collect the other leg

**Limits:** Telegraphic team instructions; no illustrated side-specific demonstration was available. Contains advanced alternatives not adopted here.

**S2: [Coaching Wrestling Successfully, Figure 7.11: Sweep-single finish](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730)** - Dan Gable / Human Kinetics; accessible book transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Full page-labeled text around printed page 95, Figure 7.11, within Teaching Folkstyle Skills and Drills; illustrated frames not inspected.

**Supports:** Reach the backside; Switch hands while posting; Drive forward and collect the far knee with the posting arm

**Limits:** Primary coach-authored book text on a third-party host. Caption does not specify right and left; the card's side assignment is an explicit teaching mapping.

**S3: [Matt Pell's Method to Developing a Top Level Head Inside Single](https://www.flowrestling.org/articles/5024045-matt-pells-method-to-developing-a-top-level-head-inside-single)** - FloWrestling; Matt Pell's coaching plan published by Martin Floreani; accessed 2026-09-26.

**Inspected:** Accessible article text: Day 1 inside-tie pull/lower-level sweep key points and Day 4 mat-finish key points; linked premium videos not inspected.

**Supports:** Circle-pull setup with an opponent stepping response; Head up on the shot; Shoulder tight behind the thigh and below the buttock

**Limits:** The written plan includes several finishes; the selected card does not import its shelf or backdoor instructions.

**S4: [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached official PDF text, PDF pages 154-155 (printed pages 153-154), attack priorities and shot finishes.

**Supports:** Sweep single is a recognized attack; Attack and finish require separate instruction

**Limits:** Freestyle curriculum context, not a mechanical demonstration or current folkstyle rule reference.

<a id="b10"></a>

## B10 - Snap-Down Go-Behind

**Tier:** Beginner | **Previous name:** Snap And Spin

### Technical review

The draft identified a real snap-down attack and correctly paired the pull with retreating feet and a level change. Its main weakness was the gap between bringing a partner to base and simply circling behind. It never identified the side being attacked, the blocking arm, or what replaces head contact. A receiver could therefore turn with the attacker or reach the legs, and the student might compensate by pulling the neck harder. The revised card gives the transition an observable checkpoint: the arm block is established before the released collar hand reaches the thigh. The original neck-loading restrictions remain, with the receiver's actual mat contact now taught explicitly.

### Selected variant

A collar-and-triceps snap followed by the backhand arm-block go-behind, circling to the attacker's left around the receiver's right side. This is the handbook's basic snap and backhand finish, expressed with a consistent right/left example. It does not insert a chin strap, locked front headlock, head-in-the-hole finish, or short drag into the sequence. Those are distinct options and would require additional teaching. The selected finish uses the near-hand backhand block on handbook page 25. Pages 9 and 19 also describe a far-hand transfer variant; that different hand exchange is not combined into this card.

### Mechanics and evidence

- The handbook identifies forward leaning as a snap opportunity and combines the head pull, triceps pull, backward step, and level change. Its basic snap brings the opponent beneath the chest with the attacker's feet back. [S1]
- The handbook gives two backhand descriptions: pages 9 and 19 exchange to the far hand, while page 25 names a near-hand block. This card selects the latter to preserve the existing left-arm control during a leftward circle. The left hand blocks the receiver's right triceps; the released right hand reaches the right thigh. Chest contact remains as the feet circle. [S1]
- Welker's separate snap-down redirect example uses a right collar tie and left wrist control, then blocks the receiver's right arm before circling. Its chest-on-back and feet-active emphasis corroborates the finish principle; its wrist entry and reactive sprawl are not substituted into this card. [S2]
- USAW distinguishes a snap, which draws a control point downward, from a block, which holds a control point while the attacker passes it. That distinction explains why releasing the head must not mean abandoning all upper-body control. [S3]

### Teaching progression

- First demonstrate the finish with the receiver already on hands and knees. The receiver stays mobile enough to reveal an ineffective block; they do not rigidly brace the elbow or neck. Have the attacker freeze at the hand transfer so the coach can check that the left hand contacts upper arm rather than face or throat.
- Add the kneeling snap only after the receiver can accept a gentle forward weight shift through bending arms without dropping the forehead. Vallimont's publisher describes a kneeling drill progressing from the snap into a go-behind, with slow repetitions before faster work. His actual front-headlock transition is different from the chosen backhand version. [S4]
- Then rehearse from stance with the receiver voluntarily following a small forward pull. The receiver lowers the knees rather than falling onto locked arms. These receiving instructions are conservative lesson design, not a claimed verbatim protocol from the sources.
- For the defined reaction, the receiver tries to turn square only after reaching the mat. Success means the attacker reaches behind the hips while preserving contact and balance. If the receiver stays upright or escapes the block, reset. The repetition counts and success test are proposed coaching choices; the cited material does not establish an optimal dose.

### Common mistakes and corrections

- A neck-only tug is corrected by rehearsing the backward step and coordinated arm pull with very light contact. The partner should move their torso, not have the head forced away from a stationary body.
- A loose transition is corrected at the hand-transfer checkpoint. A wide running circle is shortened so chest contact persists until the thigh is reached. Continuing to hold the collar after passing the shoulder is corrected by releasing it during the transfer; the head must not be twisted behind the turning torso.

### Readiness and rules

Beginner denotes readiness, not an age permission. The coach must verify receiving, balanced circling, and immediate release before resistance. This card finishes with separate hands and ordinary rear coverage; it assigns no points and makes no claim that briefly reaching the side constitutes a takedown. The older manuals are technique evidence, not current scoring authorities. Their forceful head-to-mat language is not adopted as an instruction for this beginner lesson. No new rules-dependent hold or competition ruling is introduced.

### What changed

- Use the familiar name Snap-Down Go-Behind.
- Specify the collar hand, controlled triceps, backhand transfer, circling side, and near-thigh reach.
- Replace the ambiguous release-and-circle instruction with an arm block that preserves the attacking angle.
- Teach hands-and-knees receiving and a single turn-to-face reaction before open resistance.
- Editorial cross-check corrected the leftward finish: left backhand blocks their right triceps; the released right hand reaches their right thigh. This mirrors B11 and follows the handbook near-hand block.

### Evidence limits

Inspected actual handbook and USAW PDF text plus the full accessible Human Kinetics excerpt and Fanatic publisher explanation. No embedded video was watched, and no inaccessible instructional is cited as inspected. The handbook supplies the chosen variant; Welker corroborates its blocking and pressure principles with a different entry. The right/left assignment is an explicit teaching mapping of the handbook's near/far terminology. USAW supplies definitions rather than the complete finish. The receiving progression, separate-hands endpoint, and drill prescription are editorial coaching adaptations. The handbook contains both near-hand and far-hand backhand variants. The final card deliberately uses its page 25 near-hand version, matching the mirrored finish in B11.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text: page 9 Spin Drill; page 10 Snap Down and counter-offense; page 16 Collar Tie / Snap Downs; page 19 short-offense backhand and arm-block instructions (one-based PDF pages). Root editorial cross-check additionally inspected PDF page 25 Short Offense / Backhand, which explicitly uses the near hand to block the near triceps; the final card selects that variant.

**Supports:** Coordinated collar-and-triceps snap with retreat and level change; Backhand transfer to triceps; Arm block, circling, and near-thigh finish

**Limits:** Undated team manual; author not individually identified in the inspected sections. Uses near/far terminology and sometimes aggressive language. Not used as a current rules source.

**S2: [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage)** - Human Kinetics; excerpt from The Wrestling Drill Book, 2nd Edition, edited by Bill A. Welker; accessed 2026-09-26.

**Inspected:** Complete accessible Snap-Down Redirect text: Setup, Action, Coaching Point, and Common Error. Linked illustration returned 404 and was not inspected.

**Supports:** Right collar-tie example blocking the receiver's right arm before the spin; Chest pressure and feet remaining active before circling

**Limits:** Uses a wrist tie and incoming-attack sprawl, not the selected triceps-tie entry. Its head-to-mat wording is intentionally not used in the beginner card.

**S3: [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached official PDF text, PDF pages 152-153 (printed pages 151-152): Contacts and Set-ups, including snap, post, and block definitions.

**Supports:** Head-and-arm contacts as attack preparation; Distinct purposes of snapping and blocking a control point

**Limits:** General coaching definitions; does not verify the complete go-behind or current folkstyle scoring.

**S4: [Master Snap and Go Behind Drills with Dan Vallimont](https://fanaticwrestling.com/blogs/news/master-snap-and-go-behind-drills-with-dan-vallimont)** - Fanatic Wrestling, publisher of Dan Vallimont's instruction; accessed 2026-09-26.

**Inspected:** Full publisher article, specifically the kneeling start, collar/inside tie, weight-on-hands target, armpit-block explanation, and gradual drill-speed discussion. Embedded video not inspected.

**Supports:** Kneeling rehearsal before increased drill speed; A blocking action prevents the receiver from turning with the go-behind

**Limits:** Publisher's written account rather than an inspected video transcript; uses a front-headlock transition different from the chosen variant.

<a id="b11"></a>

## B11 - Sprawl and Go-Behind

**Tier:** Beginner | **Previous name:** Sprawl And Go Behind

### Technical review

The original had the right overall sequence: move the legs back, use body pressure, clear the legs, then go behind. It also correctly rejected neck loading and turning against a trapped leg. Its decisive actions were too vague to reproduce: "control an upper arm" did not say which arm, with which hand, or how that prevents the shooter reaching again. "Bring one foot underneath" could invite an early rise that removes pressure. Finally, merely moving behind was treated as control without defining a supported finish. The revision gives one sided example and an observable clearance checkpoint.

### Selected variant

An early double-leg sprawl followed by a backhand arm-block go-behind to the defender's right. The backhand is a named short-offense option in the College Park handbook [S1]. This is a beginner response to a stopped, extended entry, with a separately taught rear-control finish. It is not presented as a universal escape from an established single-leg lock.

### Mechanics and evidence

- The handbook describes hips moving backward and downward, followed by chest/shoulder contact on the back. Its double-defense section explicitly adds scooting to finish freeing the grip [S1, pp. 8, 19]. The selected example begins early enough that this is a manageable clearance task; a persistent tight grip is a reset during introductory practice.
- Welker's publisher excerpt stresses toe support and back pressure before the spin, and identifies dropping onto the knees as a mistake [S2]. Therefore the defender keeps the knees clear during the mobile phase. This does not mean balancing with the hips high: the body remains connected to the shooter.
- The backhand instruction places a hand between the defender's chest and the opponent's head to block the near triceps, followed by circling and reaching a near thigh or ankle [S1, p. 25]. The card maps this to right hand/left triceps and a rightward circle. Left-hand contact transfers to the nearby thigh only as the angle makes it reachable.
- Kolat explicitly orders sprawl, clearance, and spin and says elbow-post spinning follows hip clearance [S3]. The leg-free checkpoint therefore precedes turning. Arm blocking prevents the next reach; it is not a lever for winding a straight arm behind the shoulder.
- The finish is a coaching specification: reach beyond the shoulder to the hips, then release the temporary arm block and establish the already-taught ride with separate hands. USA Wrestling places sprawl-and-spin in beginner counter offense [S4], but its curriculum list alone does not define when an official awards control.

### Teaching progression

- First demonstrate the endpoint over a partner on a stable hands-and-knees base. Let the defender feel chest contact and rehearse the backhand passage slowly. The receiver keeps elbows flexible and never props up the defender with the head.
- Next rehearse from a paused shallow penetration step. The defender moves back gradually before adding a dynamic sprawl. The shooter stays aligned, releases as the legs withdraw, and builds a base rather than deliberately hanging from a knee. This cooperation teaches receiving; it is not claimed to prove grip-breaking against resistance.
- Add the full entry only when both can stop immediately without collapsing. Then give the shooter one specific reaction: circle on the knees to face after releasing the legs. This tests pressure and arm blocking. Progress by improving position before speed; the listed repetitions and timed rounds are proposed coaching design.

### Common mistakes and corrections

- An airborne jump delays the hips and makes landing pressure unpredictable. Rehearse a low backward leg extension with hands supporting the transition, then reconnect to the partner.
- A defender who stands up to run around loses the contact needed to slow the shooter. Freeze before the first step and check that knees are clear while chest contact remains.
- If the shooter catches the circling leg, shorten the steps and restore the upper-arm barrier. If a grip never cleared, return to the square position instead of turning harder.
- If the defender stops beside the shoulder, mark the hip line as the destination. Require a stable rear position and release of the temporary block before counting the repetition.

### Readiness and rules

Beginner is a readiness tier. The partner must tolerate gradually added body contact, maintain an aligned neck, and release promptly. The card deliberately excludes impact to the head and forced joint rotation. Its separate-hand finish is a conservative folkstyle teaching choice, not a complete explanation of locked-hands exceptions. No point value, automatic takedown award, or universal event-legality claim is made; the coach must apply the event's control criteria.

### What changed

- Uses the familiar name Sprawl and Go-Behind with conventional punctuation.
- Defines the blocked triceps, hand orientation, circling direction, thigh contact, and release.
- Replaces a vague foot-underneath instruction with pressure maintained during short circling steps.
- Adds an honest cooperative receiving phase and a specific knee-circling reaction.

### Evidence limits

The College Park PDF was downloaded into memory and its text inspected, including pages 8-9, 19, and 25; no video was watched. Human Kinetics supplies direct published coaching text for related counter-drill pressure, not this complete entry-and-finish chain. Its forceful head-to-mat wording is not copied into the beginner card. Kolat provides sequencing and curriculum guidance; his linked technique page required login, so no locked instruction is claimed. USA Wrestling supplies classification only. The sided mapping, conservative receiving limits, finish checkpoint, and drill dose are the audit's coaching synthesis.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn2.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public Sport Ngin-hosted team handbook; accessed 2026-09-26.

**Inspected:** PDF text: title and mission pages 1-3; sprawl and spin descriptions pp. 8-9; Sprawl Butt Drag on p. 19; Backhand short-offense finish on p. 25. Retrieved directly and parsed in memory with pypdf.

**Supports:** Hip withdrawal and chest-to-back contact.; Scooting to clear remaining grip.; Backhand triceps barrier, circling, and near-thigh/ankle contact.

**Limits:** Team handbook does not identify an individual author in the inspected front matter. Some advanced content and forceful head-pressure cues are unsuitable for this beginner card; those are excluded. Text inspected, not video or photographic motion.

**S2: [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage)** - Human Kinetics; excerpt from The Wrestling Drill Book, 2nd Edition, edited by Bill A. Welker; accessed 2026-09-26.

**Inspected:** Full relevant publisher webpage text: Takedown Counter Drills and Snap-Down Redirect, including Setup, Action, Coaching Point, and Common Error.

**Supports:** Stop an initial attack before counterattacking.; Use chest pressure on the back, block an arm, and circle.; Stay supported on toes instead of dropping to knees during the spin.

**Limits:** The shown entry is a collar-tie snap-down redirect, not an identical double-leg sprawl. It corroborates shared pressure and mobility principles. The linked illustration returned 404; no image inspection claimed.

**S3: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** Accessible article text: How the Levels Should Be Approached and Level 1 Feet, especially Defense Key Points and Defend Double Leg.

**Supports:** Clear hips before the elbow-post spin.; Sprawl-clear-spin is a foundational defensive sequence.; Advance by skill evaluation rather than assuming a fixed year equals a level.

**Limits:** A curriculum and sequencing source, not verification of the precise backhand grip. Linked double-leg instruction required member login and was not inspected.

**S4: [USA Wrestling Core Curriculum: Folkstyle Level 1](https://www.usawmembership.com/usa_wrestling_core_curriculum)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Public curriculum page and its one-page Folkstyle Level 1 PDF; Counter Offense lists Sprawl & spin.

**Supports:** Standard naming and placement as foundational counter offense.

**Limits:** Listing only. Embedded video could not be fetched; it does not substantiate the card's detailed grips, direction, or finish.

<a id="b12"></a>

## B12 - Down Block and Circle

**Tier:** Beginner | **Previous name:** Down Block And Circle

### Technical review

The original correctly aims to defend early, move the threatened leg, and keep facing the opponent. Its hand instruction is a general shoulder/upper-arm block, however, and its sequence can read as hands first and feet afterward. The defining down-block action is an arm dropped between attacker and legs while the attacked leg withdraws. The original also gives two endings, stance recovery or an unspecified go-behind. This revision teaches one early single-leg defense ending in stance.

### Selected variant

Same-side down block against an early entry at the defender's right lead leg, followed by a short circle to the defender's left and a facing stance. Right hand and right leg act together. The chosen leftward recovery is a fixed rehearsal direction, using ordinary stance footwork after the leg has cleared; it is not claimed as the only direction used in wrestling. There is no cross block, head push, sprawl, arm drag, or go-behind in this card.

### Mechanics and evidence

- USAW's Motion section specifies dropping a hand into the route to the leg, sending the leg back, balancing on the opposite foot, and looking to circle. Its stance section supports bent legs, head up, forward hands, and elbows in. [S1]
- College Park distinguishes a down/cross block from generic hand blocking: lower the head and body level when reaching, put the arm between the opponent and the legs, and withdraw the attacked leg simultaneously with the downward hand action. Its motion instruction calls for short sliding or shuffling steps without crossing the feet. [S2]
- For this right-lead example, the right forearm fills the entry lane as the right leg moves away; the left leg supports balance. The publisher's explanation of Zach Tanelli's warm-up explicitly links the lead hand and lead leg for a single-leg threat, including the reversed stance. This corroborates the same-side selection. [S4]
- USAW describes down and cross blocks as ways to defend while remaining on the feet and places hip defense after the earlier defensive barriers. A block is therefore not permission to circle against an already secured leg grip; deeper defense needs its own instruction. [S3]

### Teaching progression

- Demonstrate solo, then with a partner, from front and side. Pause after withdrawing the right leg to check the bent left knee and balance. Remove this teaching pause as coordination improves.
- The receiving partner supplies an honest but slow entry toward the named leg and stops forward drive when blocked. They do not fall into the defender, cling to a caught leg while the defender circles, or turn the exercise into a struggle. Both return to stance before roles change. USAW specifically permits simulated reaching entries for down/cross-block rehearsal. [S1]
- After three cooperative repetitions each, allow the attacker to choose a fake or one slow entry to the same leg. The defender must stay in stance on the fake and coordinate the block only on the entry. Later mirror the whole sequence. These repetition counts and the fake-or-entry progression are proposed coaching design, not a researched training dose.

### Common mistakes and corrections

- A planted threatened foot defeats the purpose of the arm barrier. Return to solo hand-and-leg coordination, then have the partner reach slowly enough to verify simultaneous action.
- Bending only at the waist creates a long reach and poor balance. Start closer, bend the supporting knee, and reduce the distance traveled by the hand. [S1, S2]
- Crossing feet or standing upright during recovery invites another attack. Shorten the circle and finish with bent knees and hands forward before increasing entry speed. [S1, S2]

### Readiness and rules

Readiness is demonstrated balance and a partner's ability to stop an entry, rather than an age label. Use mat space clear of other pairs and a downward barrier, not a blow to the head or an elbow braced against a collision. This is a neutral-position defensive drill with no scoring claim. It does not introduce a neck hold or mat finish. Historical manuals are used for mechanics, not as current folkstyle rule authorities; no event-specific legality or point value is asserted.

### What changed

- Replaced a generic shoulder block with the characteristic same-side downward arm barrier and simultaneous leg withdrawal.
- Named the defender's right hand, right leg, supporting left leg, and a fixed recovery direction.
- Removed the optional undefined go-behind and specified a facing-stance finish and receiver reset.
- Replaced immediate either-leg entries with a same-leg fake-or-entry reaction before mirroring.

### Evidence limits

The two primary manuals independently establish the core mechanics and stance recovery principles. Neither prescribes this complete five-step right-side drill or its leftward reset; those are explicit teaching choices assembled from the verified down block and basic circling. The USAW guide supplies conceptual defensive sequencing. The Tanelli source is the instructional publisher's written explanation, not a transcript or personally inspected video. No video viewing is claimed. The blocked-leg stop and receiver behavior are conservative drill boundaries, not claims that a caught single must stop in competition.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF text, pages 1-2: stance and Skill 2 Motion, including the down/cross-block instructions; page 4: Neutral Defense - Performance Motions. Inspected the cached page-marked extraction and opened the official PDF.

**Supports:** Downward hand obstruction, withdrawal of the attacked leg, balance on the opposite foot, and circling.; Balanced stance and simulated reaching attacks for partner rehearsal.

**Limits:** A study guide with technical bullet points; no claim to have watched its linked video. Does not prescribe the card's complete right-side sequence or drill dosage.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text, page 7 stance and page 8 Motion and Down Block/Cross Block in the Gable Warmup. Inspected the cached page-marked extraction and opened the original PDF.

**Supports:** Lowering level while bringing an arm between opponent and legs.; Simultaneous downward hand action and straight-back withdrawal of the attacked leg.; Short circling footwork without crossing the feet.

**Limits:** Combines down-block and cross-block discussion; not sufficient alone to assign the blocking hand. Its separate head-block and sprawl finishes are not imported into this card.

**S3: [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached official PDF text, PDF page 156 (printed page 155), Counter Offense, including down/cross blocks and the sequence of shot-defense barriers. Original URL confirmed from cache metadata; direct web reopening returned an error.

**Supports:** Down and cross blocks as foot-based early defense.; Distinction between hand defense and later hip/sprawl defense.

**Limits:** General coaching discussion, not the exact hand-and-foot demonstration. Freestyle-oriented context and historical rule statements are not used as current folkstyle rules.

**S4: [Defensive Based Warm Up With Zach Tanelli](https://fanaticwrestling.com/blogs/news/defensive-based-warm-up-with-zach-tanelli)** - Fanatic Wrestling, publisher of Zach Tanelli's instruction; accessed 2026-09-26.

**Inspected:** Full written instructional explanation, particularly paragraphs describing linked hands and feet and lead-hand/lead-leg withdrawal against a single (web lines 532-536).

**Supports:** Same-side lead-hand and lead-leg coordination for the selected single-leg defense.; Mirroring that action in the opposite stance.

**Limits:** Publisher's written account of the coach's demonstration, not a personally inspected video or transcript. Does not establish the card's chosen circling direction.

<a id="b13"></a>

## B13 - Peek-Out Recovery

**Tier:** Beginner | **Previous name:** Recover A Stopped Shot

### Technical review

The original card had a useful intention: stop reaching from a failed attack, release an endangered leg, and recover before the defender circles behind. Its instruction to post a forearm and stand did not explain how to remove the defender's chest pressure or free the head. Those omissions matter because merely bringing a foot forward does not defeat a sprawl or a secured front headlock. The revised card teaches one recognized recovery, the peek-out, against an early front cover. It changes the endpoint from an unspecified retreat to a recovered attack and the previously learned low double finish. It does not promise that every stopped shot can be rescued this way.

### Selected variant

A right-side peek-out from a released shot and a light, unlocked front cover. The shooter posts the left hand, steps up with the right foot, withdraws the right elbow, and brings the left knee and hips in while clearing the head beneath the partner's left arm. The partner's hands begin separately behind the upper arms, following College Park's drill. The finish uses B07 mirrored: the head is on the shooter's right at the receiver's left ribs, right trail foot up, drive left and gather knees right. This preserves the side reached by the peek-out instead of requiring an unexplained head-side change.

### Mechanics and evidence

- USA Wrestling's Peekout photo lesson explicitly identifies a left-hand post, shortening the extended position, a right-elbow withdrawal, a rightward head exit, continued posting during re-penetration, and renewed foot motion to a double. Its captions and selected stills were inspected directly. [S1]
- College Park describes the initial hands-and-knees/front-cover drill with the partner's chest over the back and hands hooked behind the arms. Its double-leg recovery section permits either foot to step up, followed by the other knee sliding in. The card chooses right foot/left knee rather than presenting two directions. [S2]
- These sources share the important order: recover space underneath, clear the arm/head obstruction, then regain useful attacking posture. The card's release of the initial leg grip establishes the specified drill start; it is not a claim that all peek-outs require abandoning every leg grip. [S1, S2]
- The receiver faces the shooter, so a head exit to the shooter's right is under the receiver's left arm. Left-palm support remains until that clearance. Looking up in the handbook is expressed as raising the chest after clearance, avoiding an instruction to force neck extension while pinned underneath. [S2]

### Teaching progression

- Demonstrate the exact front cover before adding a shot. The receiver supports much of their weight through their own legs, keeps separate arm contacts, and permits the shooter's right arm and head to pass. Stop each first repetition after head clearance to check the right foot and following left knee.
- Begin with the three cooperative repetitions and then join recovery to the already learned low double. The receiver follows the turn onto the hip and keeps the catching arm bent. Coaching the receiving role is necessary before adding resistance; it is not incidental to the move.
- Progress to a slow shot, one light sprawl, release, and the same recovery. The defender initially follows rather than adding a headlock, crossface, or spin. Kolat places peek-out drills and immediate recovery after missed shots in the same training session; the short rounds and restricted defense here are original beginner coaching choices. [S3]

### Common mistakes and corrections

- A long base leaves the head and hips separated: move the right foot closer and slide the other knee in before trying to raise the chest.
- Reaching for legs before the head clears recreates the stuck position: freeze at head clearance, then add the second attack.
- Swinging the right elbow into the receiver turns a clearance into a strike: teach a close withdrawal toward the hip, with the receiver releasing the arm contact as it passes.

### Readiness and rules

Use this readiness tier only after the wrestler can support the light starting position, move a knee under the hips, and receive B07. This is a wrestling recovery, not permission to torque out of a locked front headlock. Stop for neck loading or an immobilized shoulder. No lift, throw, scoring value, or event-specific legality claim is added; the inspected historical manuals are not current rulebooks.

### What changed

- Named the actual technique, Peek-Out Recovery.
- Replaced a vague stand-up under pressure with a defined post, foot step, elbow clearance, knee slide and head exit.
- Specified the receiver's unlocked front cover and a familiar, prerequisite finish.
- Limited the first resistance to one light sprawl instead of open-ended defense.
- Editorial chain check identifies the mirrored B07 finish after the rightward head exit, including the matching right-hip receiving side.

### Evidence limits

College Park supplies actual written mechanics, not just a curriculum listing. The official USA Wrestling photo page was fetched as HTML after the browser fetch timed out; stills 003, 004, 006, 007 and 009 were viewed. The motion GIF was not watched. Kolat's public practice-plan text supports the recovery emphasis and drill family only; linked members-only instruction was not used as mechanical evidence. The receiver limits, repetition count, round duration and freeze checks are coaching design. The mirror mapping into B07 is an editorial consistency check, not a claim that the photo captions prescribe this exact wording.

### Sources inspected

**S1: [Peekout](https://content.themat.com/CoachesCorner/technique/Peekout/default.php)** - USA Wrestling, Coaches Corner; accessed 2026-09-26.

**Inspected:** Full HTML captions for the 12-image lesson; still photographs 003.jpg, 004.jpg, 006.jpg, 007.jpg and 009.jpg. Retrieved directly after web fetch failure.

**Supports:** Left-hand mat post and right-elbow clearance.; Rightward head exit, re-penetration and a subsequent double-leg finish.

**Limits:** Historical photo lesson with no publication date displayed. Stills are low-resolution; no motion clip inspected. The card uses College Park's explicit step-up/knee-slide variant rather than requiring the photo caption's cross-step.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extraction: PDF page 9, drill 6 PEEK OUT/CUT BACK; PDF page 23, double-leg finish PEEK OUT/CUT BACK DOUBLE. Also read page 22 front-head counter section to distinguish alternate variants.

**Supports:** Hands-and-knees start, chest-to-back front cover, and separate contacts behind the arms.; Step up with one foot, knee slide with the other, peek under the arm, and turn back in to finish.

**Limits:** Compressed coaching prose with typographical errors. Historical scoring statements and unrelated holds are not adopted. Does not prescribe the card's limited resistance or receiving progression.

**S3: [Shot Recovery and Low Single Leg Training Session](https://www.kolat.com/blog/shot-recovery-and-low-single-leg-training-session)** - Cary Kolat / KOLAT.COM; accessed 2026-09-26.

**Inspected:** Public practice-plan text dated December 5, 2014, especially warm-up recovery and peek-out drills and conditioning-drill description.

**Supports:** Continued recovery immediately after a missed shot.; Peek-out drill connected to a double leg or other established attack.

**Limits:** Practice plan and drill list, not detailed grip/footwork verification. Linked library videos were not inspected; its practice volumes were not transferred to beginners.

<a id="b14"></a>

## B14 - Referee's Bottom Start

**Tier:** Beginner | **Previous name:** Referee's Bottom Start

### Technical review

The original appropriately required stillness and a whistle response. Its rule description was incomplete: 'hands in front' could mean fingertips alone, and it omitted parallel knee alignment, elbows off the mat, and access for top on either side. Conversely, shoulders over hands, hips over knees, not sitting on heels, and a particular division of weight are coaching choices rather than the definition of a legal start. The revision makes the required contacts explicit without claiming one coached base is the only legal base.

### Selected variant

The ordinary NFHS-style folkstyle defensive start, with bottom established first and a loose partner taking the standard top position under coach supervision. This is a starting-position lesson, not a stand-up lesson or an international par-terre lesson. A setup-only reset lets beginners learn it before B17 or another escape, preventing circular prerequisites.

### Mechanics and evidence

- NFHS Rule 5-19-2 specifies stationary hands-and-knees contact, knees behind and parallel to the rear line, heels of both hands beyond the forward line, elbows clear, and access for top on either side. The complete paragraph was read visually in the 2024-25 primary rulebook, including its lower-page image. [S1]
- Horaski and Garcia's starting-position lesson teaches the two lines, partner checks and a wide knee base. It also advocates sitting toward the heels and unloading the hands. That latter coaching preference differs from the original card's equal-support suggestion; neither is presented here as a formal rule. [S2]
- USA Wrestling's study guide uses referee-position 'Get Set' drills to practice reacting to a whistle and repeats the drill from both sides. This supports the transition from solo alignment to a partner start and an actual whistle response. Its arm-chop action is not imported into this beginner setup rehearsal. [S3]
- The post-whistle reset rehearses signal recognition without requiring a new escape. Later, top follows a known escape before resistance is introduced. This is proposed coaching design, not a rulebook procedure.

### Teaching progression

- Demonstrate both lines and point to the heel of the hand so the child does not confuse it with the fingertips. Show one correct setup, then an incorrect hand placement, and have the learner identify the difference.
- Rehearse alone before adding top. Check that bottom can maintain the position without painful wrist or knee loading, that elbows stay clear, and that top has space on either side.
- Add a cooperative partner who takes the coach-checked top start and remains loose. Vary the wait before the whistle. Bottom stays still through the partner's setup; at the whistle top releases for the practice reset.
- After repeated correct setups, teach an escape separately. Return for one escape action with top following lightly after the whistle. Counts and progression thresholds are practical lesson design.

### Common mistakes and corrections

- Fingers across the mark with palms behind it: inspect the base of each palm and move the hands forward until the actual required contact clears the line.
- An exaggerated or crooked base prevents top starting on one side: reposition bottom's supports before top makes contact. Do not force top to squeeze into an obstructed start.
- Rocking when top touches, or anticipating a rhythmic count: shorten the first holds, vary the delay, and count only motionless starts followed by a whistle response.

### Readiness and rules

This lesson uses NFHS-style folkstyle requirements. The 2025-26 official changes summary and the NFHS 2026-27 release were inspected; neither identifies a change to the defensive starting-position rule. Continuing the inspected 2024-25 wording is therefore a continuity inference, not a claim that the complete 2026-27 rulebook was read. The event's governing rules and referee remain controlling, especially for youth adaptations. No international rulebook is offered as folkstyle authority. The card uses the whistle as the action cue without promising a universal spoken 'set' command. Readiness requires a sustainable base and cooperation, not a particular age.

### What changed

- Retained the familiar name.
- Added hand-heel contact, parallel knees, elbows off the mat and room for either-side top placement.
- Separated required positioning from optional coached posture and weight distribution.
- Replaced generic timed rounds with observable setup, stillness, whistle and reset repetitions.
- Made an escape an optional later progression so the foundation does not depend on its own dependent card.

### Evidence limits

S1 was inspected as scanned primary rule text; the complete latest book was not accessible. S4-S5 provide subsequent official change checks. S2 is a historical PE lesson with coaching conventions and oversimplified rule language. S3's guide text was read, not its video. Repetition counts, neutral head cue, reset and low-resistance progression are coaching design, without experimentally established doses.

### Sources inspected

**S1: [2024-25 NFHS Wrestling Rules, Rule 5-19-2](https://nhwoa.org/wp-content/uploads/2024/11/24-25-NFHS-Wrestling-Rule-Book.pdf)** - National Federation of State High School Associations; copy hosted by New Hampshire Wrestling Officials Association; accessed 2026-09-26.

**Inspected:** Printed page 27, Rule 5-19-2, on PDF page 12 of the 45-page scanned file. Both the upper and lower embedded page images were displayed and read, covering the entire defensive starting-position paragraph.

**Supports:** Exact NFHS defensive starting contacts and alignment; Stationary setup; Elbows must not touch mat; Top must be able to start legally on either side

**Limits:** 2024-25 edition, not the complete current-season rulebook. Subsequent change documents were checked separately.

**S2: [Wrestling Unit Plan, Lesson 17: Top and Bottom Starting Position](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF text, PDF pages 65-67: objectives, setup demonstration, bottom-position refinements and partner assessment.

**Supports:** Teaching knees behind and palms forward of the starting lines; Wide knee base as a coaching cue; Solo setup followed by partner checks

**Limits:** Historical school lesson, not current rules authority. Sitting back toward heels and unloading hands are presented there as coaching choices; its seven-inch practice-line spacing and simplified top/rule directions are not adopted.

**S3: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF text, page 2, Get Set Drills - Arm Chop, listed video interval 12:14-12:36; page 3, Starting Position/Base to Feet. Only guide text was inspected, not the linked video.

**Supports:** Whistle reaction practice from referee's position; Repeating starts from both sides; Later progression from base to feet

**Limits:** Does not specify the complete legal starting position. Its arm chop is not the action used in this setup-only card.

**S4: [Wrestling Rules Changes - 2025-26](https://nsaa-static.s3.amazonaws.com/textfile/ref/wrrules.pdf)** - NFHS; hosted by Nebraska School Activities Association; accessed 2026-09-26.

**Inspected:** Entire one-page official change summary, dated September 26, 2025, opened and read as PDF text.

**Supports:** Subsequent-season check: no defensive starting-position change appears in the listed changes

**Limits:** Summary of changes, not full rulebook or assurance against event-specific adaptations.

**S5: [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf)** - NFHS, April 17, 2026; hosted by Massachusetts Interscholastic Athletic Association; accessed 2026-09-26.

**Inspected:** Entire three-page NFHS 2026-27 rules-change press release, opened and read as PDF text; rule-change discussion on pages 1-2.

**Supports:** Current-season change check: the announced changes concern other rule areas and do not announce a new bottom starting position

**Limits:** Press release summarizing changes. The full 2026-27 rulebook was not inspected; retention of the older starting-position language is explicitly identified as an inference.

<a id="b15"></a>

## B15 - Referee's Top Start

**Tier:** Beginner | **Previous name:** Referee's Top Start

### Technical review

The original had the correct elbow/navel pairing, loose contact, stillness and a sensible intention to prevent lunging. However, 'at least one knee' without specifying its side omitted a defining condition. It also omitted prohibited leg contact and placement between the opponent's legs, and did not explain that bottom becomes stationary before the referee directs top to cover. 'Head centered above the back' was close but needed to distinguish legal position from pressing the chin into the back. The revision teaches one fully specified setup before adding a ride. Its release-and-reset finish avoids making B22, which depends on B15, an undeclared prerequisite.

### Selected variant

Ordinary NFHS-style top start from bottom's left: top's left knee down and left palm at bottom's left elbow; top's right foot behind and still on bottom's left side; right palm at the navel. This is one teachable legal arrangement, not the only legal leg arrangement. The opposite-side version mirrors every named limb. It is not the optional two-hands-on-back start.

### Mechanics and evidence

- Rule 5-19-5 requires a knee down on the elbow-hand side. The waist arm crosses the trunk at a right angle to its length; its palm rests loosely at the navel. A rear knee or foot is permitted behind bottom's feet, but not between the legs or in a straddle. Top's legs/feet cannot touch bottom. [S1]
- Head location is on or above the back's midline. Chin contact is not mandatory. Horaski-Garcia's lesson uses chin-on-back and grabbing-the-elbow language; the card instead selects a hovering head and light palm. Their outside-knee-down teaching arrangement is useful, but the legal endpoint controls its execution. [S1, S2]
- Bottom settles first; the referee then invites top into position. After top is legal and stationary, the NFHS procedure uses a spoken set, a brief pause and the whistle. The MHSAA officiating manual independently confirms the inspected hand/head checks and no-leg-contact requirement. [S3]
- The numbered hand placement is a teaching routine, not a claimed mandatory navel-first or elbow-first rule. The inspected NFHS article describes the completed contacts without assigning those hands a placement order. [S1]

### Teaching progression

- Show the left-side setup with a cooperative partner. Have the learner name whose left elbow, left knee and right hand are being used, then locate each contact before assuming the whole position.
- Bottom holds the B14 base without widening the feet to block top. Top supports their own weight while the coach checks hand location and the gap around both legs. Begin with setup and release so neither athlete has to invent a breakdown or escape.
- Rehearse an unpredictable pause and whistle. USA Wrestling's Get Set drill supports whistle-response practice and repeating starts on both sides; its arm chop and knee drive are not imported into this foundation card. [S4]
- After consistent legal starts, introduce one slow bottom knee-slide and a light following action, stopping after that single reaction. Teach a real breakdown separately before joining it to the start. Counts and resistance progression are proposed coaching design.

### Common mistakes and corrections

- A foot slips between bottom's feet: move it behind and to the selected side before checking the hands. Use a visible gap rather than permitting a knee to lean on bottom.
- Fingers clamp the elbow or the waist is already tight: flatten and relax the palm, lighten the waist arm, and restart the check.
- Top reacts to set or to a predictable cadence: vary the pause and count only whistle responses. Never correct anticipation by adding a required delay after the whistle.

### Readiness and rules

This is a folkstyle foundation with an NFHS procedure. Current USA Wrestling's published 2027 Kids Folkstyle Nationals rules use modified NFHS rules for boys and girls and list no starting-position modification. That is event-specific, not proof that every youth league uses this procedure. The inspected 2024-25, 2025-26 and 2026-27 change documents list no replacement of this start; carrying the older inspected text forward is explicitly a continuity inference. [S5-S8] No NCAA or international rulebook is used as NFHS authority. Beginners should sustain the setup and release on command before resistance.

### What changed

- Retained the familiar name and specified one left-side variant.
- Added knee-side placement, rear-foot location and no leg contact.
- Added bottom-first, referee-directed setup and whistle sequencing.
- Separated a legal head position from optional chin contact and light palms from gripping.
- Replaced generic timed riding rounds with observable start, release and one-reaction practice.

### Evidence limits

S1 is actual accessible 2023-24 NFHS rule text hosted by Scribd; no locked portion or video was claimed inspected. S3 is a 2024-25 state officiating supplement, not a replacement rulebook. The complete 2026-27 NFHS book was not accessible. S5-S7 check subsequent changes, not every current case interpretation. S2 is historical school instruction with simplified rules. S4 was read as study-guide text, not watched as video. Release/reset, following drill, repetition counts and head hovering are selected coaching design.

### Sources inspected

**S1: [2023-24 NFHS Wrestling Rules, Rule 5-19](https://www.scribd.com/document/758557564/NFHS-WR-RB-2023-24)** - National Federation of State High School Associations; accessible copy hosted by Scribd; accessed 2026-09-26.

**Inspected:** Opened full accessible document text; printed pages 27-28, especially Rule 5-19-5 and 5-19-9, and page 66-67 illustration captions. Read complete paragraphs, not only search snippets.

**Supports:** Knee on elbow-hand side; Palm at near elbow and loose navel contact; Head on or above back midline; No legs/feet touching, splitting legs or straddling; Bottom-first and referee-directed top setup; set then pause

**Limits:** Older edition; hosted copy. Subsequent rules changes were checked separately. No claim of full latest-book access.

**S2: [Wrestling Unit Plan, Lesson 17: Top and Bottom Starting Position](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF text, PDF pages 65-67: lesson objectives, top-position demonstration and partner checks.

**Supports:** One knee down with other foot behind; Matching elbow-side hand and knee teaching variant; Elbow and belly-button contacts; Cooperative partner setup and checking

**Limits:** Historical PE curriculum. Its grab-elbow and chin-on-back cues are refined against rule requirements; they are not treated as compulsory contacts.

**S3: [2024-25 Wrestling Officiating Mechanics and Procedures Blue Book](https://www.mhsaa.com/sites/default/files/Wrestling/2024-25/2024-25-MHSAA-WRESTLING-OFFICIAL-BLUEBOOK-111824.pdf)** - Michigan High School Athletic Association; accessed 2026-09-26.

**Inspected:** Opened PDF text; page 9, Referee's Position, and page 5 identifying the document as a supplement.

**Supports:** Elbow/navel/head and rear-foot checks; No leg or foot contact; Stationary bottom before directing top to cover; Set and brief pause before whistle

**Limits:** State mechanics supplement from 2024-25, not full current NFHS rulebook.

**S4: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached text, PDF page 2: Get Set Drills - Arm Chop, guide's listed video interval 12:14-12:36.

**Supports:** Whistle reaction from referee's position; Practice starts on each side

**Limits:** Only guide text inspected. Its chop and knee drive belong to later technique instruction, not this setup card.

**S5: [Wrestling Rules Changes - 2024-25](https://nfhs.org/resources/sports/wrestling-rules-changes-2024-25)** - NFHS; accessed 2026-09-26.

**Inspected:** Search service returned the full six-item change article with rationales; all listed rule references read. Direct page open returned an error.

**Supports:** No offensive-start change appears in this subsequent-season change list

**Limits:** Used only for change checking, not as mechanical verification or a full-rulebook substitute.

**S6: [Wrestling Rules Changes - 2025-26](https://nsaa-static.s3.amazonaws.com/textfile/ref/wrrules.pdf)** - NFHS; hosted by Nebraska School Activities Association; accessed 2026-09-26.

**Inspected:** Entire one-page change summary, dated September 26, 2025, opened and read as PDF text.

**Supports:** No offensive-start change appears in the listed changes

**Limits:** Change summary only.

**S7: [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf)** - NFHS, April 17, 2026; hosted by Massachusetts Interscholastic Athletic Association; accessed 2026-09-26.

**Inspected:** Entire three-page release opened as PDF text; rule-change discussion on pages 1-2.

**Supports:** Current-season release announces changes in other rule areas, not a new top start

**Limits:** Press release rather than complete 2026-27 rules or casebook. Continuity is identified as inference.

**S8: [2027 USA Wrestling Kids Folkstyle National Championship - Rules](https://usawrestlingevents.com/event/2700004502/rules)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Opened Rules page, 2026-2027 girls rules and general rules/modifications list.

**Supports:** This event follows modified NFHS rules; Boys and girls use the same modified rules; Listed modifications do not change the standard top start

**Limits:** One published youth national event's rules, not a universal statement about all youth organizations.

<a id="b16"></a>

## B16 - Belly to Base

**Tier:** Beginner | **Previous name:** Build Base From Belly

### Technical review

The original had the right purpose and correctly opposed a straight-arm push-up with the hips still flat. It left the working knee unspecified, omitted how the hips travel over the new support, and treated clearing any controlled wrist as one generic forearm movement. Those omissions become significant under a rider. The revised card specifies an outside-knee recovery beneath light pressure and starts with free arms. It does not claim that pulling a forearm is a universal wrist escape. The revised P06, Solo Belly to Base, rehearses this motor action without an opponent. B16 adds a rider's location, pressure, following reaction and a functional bottom position.

### Selected variant

Outside-knee belly-to-base recovery with the rider on the bottom wrestler's left; therefore the bottom wrestler's right knee advances first. Mirror the whole arrangement for the other side. A free-arm waist ride isolates base recovery before adding grip or leg-ride defenses.

### Mechanics and evidence

- USA Wrestling's written sequence is arms clear, head up, outside knee alongside the body, knee slide into base, then back pressure. This supports choosing the knee away from the rider rather than an arbitrary knee. [S1]
- The card expands the knee-slide cue into a demonstration checkpoint: forearms support the upper body while hips move back and the second knee comes underneath; rising onto the palms completes the base. This is a teaching explanation of the sequence, not a separate named technique. [S1]
- College Park emphasizes a compact bottom position with hips underneath, plus continued attempts after an initial escape is stopped. That supports checking the recovered posture and connecting it to subsequent offense. [S2]
- Preston explicitly describes the bottom base as hands and knees with slightly bent elbows and emphasizes continued upward movement. Its instruction supports the endpoint rather than the exact recovery path. [S3]

### Teaching progression

- Demonstrate the right-knee version without contact first; ask the athlete to identify the outside knee after the rider changes sides. This checks the decision, not memorization of right versus left.
- Top initially supports most body weight on the mat and follows without gripping either arm. Bottom should make space for the knee without rolling onto the back or bracing on the head.
- Add only the stated reaction: top follows the hips with mild forward pressure. If bottom cannot move a knee or keeps collapsing, decrease pressure instead of demanding more repetitions.
- First stop at a balanced base. Link to a stand-up or sit-out only after that separate escape has been taught. Neither escape is a prerequisite for B16, avoiding a circular progression. Repetition counts and timed turns are proposed coaching design.

### Common mistakes and corrections

- Chest rises but hips stay down: rehearse only outside-knee placement and backward hip travel, then restore the complete recovery.
- Hands stretch far forward: shorten the supports so the athlete can move hips underneath instead of crawling away from pressure.
- Athlete reaches backward or attempts to rise through a trapped arm: stop and restore the free-arm start; teach the relevant hand-control defense separately.

### Readiness and rules

This is a folkstyle bottom skill with an active rider, not an escape award or a rule-defined starting position. Readiness means pain-free support, a successful solo recovery and a partner who can regulate pressure. The unclasped hands, no-turn and no-leg-ride conditions are drill constraints; no claim about every event's legal ride is made. A trapped arm, inserted leg or secured half nelson changes the problem and requires its own defense.

### What changed

- Use the familiar name Belly to Base, paired with P06's Solo Belly to Base.
- Identify the outside knee and explain the hips-back transition before rising onto the hands.
- Remove the unsupported generic wrist-clear instruction and narrow the starting ride.
- Replace vague resistance with a defined hip-following reaction and a recovery reset.

### Evidence limits

Inspected actual PDF text for USAW pages 2-4 and College Park pages 31-32, plus Preston's public page text. USAW provides the principal recovery sequence; the independent club sources corroborate posture and bottom priorities, not every joint action. The linked USAW YouTube clip could not be fetched, and Kolat's linked Vimeo video returned forbidden; neither was watched or used to claim unseen mechanics. The forearm-to-palm checkpoint and restricted rider setup are explicit coaching elaborations, not quoted prescriptions. Historical rule statements and advanced leg-defense actions in the manuals were not adopted.

### Sources inspected

**S1: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF pages 2-3: Bottom Motion, Belly to Base; page 4: Pressure Down Drill for Stand Ups.

**Supports:** Clear arms before rebuilding; keep head up; advance outside knee; knee slide to base and apply back pressure.; Practice belly-to-base beneath partner pressure.

**Limits:** Written study guide. Linked Bill Zadick and Seven Basic Skills videos were not inspected. Does not specify the card's exact light waist ride or practice dose.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF/printed pages 31-32: Bottom, Escapes and Reversals, and Counters.

**Supports:** Maintain a compact bottom base with hips underneath.; Continue to another bottom action when the first attempt stops.; Leg rides require distinct clearing actions before rebuilding.

**Limits:** Supports posture and distinctions, not the exact outside-knee recovery order. Advanced counters and historical rules were not adopted.

**S3: [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm)** - Preston Mat Club, hosted by WV-Mat; accessed 2026-09-26.

**Inspected:** Public page text, II - Mat Wrestling: Bottom Man, Basic Skills for Mat Wrestling and Defensive Mat Wrestling (retrieved lines 133-170).

**Supports:** Hands-and-knees base with slightly bent elbows.; Bottom wrestler keeps moving and comes up from the mat.

**Limits:** Club syllabus rather than a current rule authority. Does not explain the belly-to-base path; its buttocks-on-heels starting cue was not adopted.

<a id="b17"></a>

## B17 - Inside-Leg Stand-Up

**Tier:** Beginner | **Previous name:** Stand Up With Hand Control

### Technical review

The original correctly prioritized waist-hand control, a supported rise, a cooperative rider, and stopping before mat returns. However, it left the stepping leg and rider's side unspecified, told the athlete to move an unnamed hand across the waist, and delegated the decisive finish to a 'taught cutaway' without teaching one. This creates an incomplete escape and risks combining incompatible instructions. The revised card uses a documented inside-leg stand-up and includes its facing finish. Standing alone is an intermediate checkpoint. The existing P08 review teaches an outside-leg solo version; its balance and chest-lift practice transfer, but its right-foot start and left turn are not the exact rehearsal for this card. B17 therefore names its variant and does not list P08 as an exact footwork prerequisite.

### Selected variant

Bill Welker's left-side-rider, inside-leg stand-up: left foot rises, left elbow clears toward the rider, right hand captures the rider's right hand, and hip clearance precedes a right turn while retaining that hand [S1]. This source explicitly supplies the sided finish. No back-pocket hand switch or opposite turn is added.

### Mechanics and evidence

- The primary instruction identifies the rider's side and the two right hands, removing the ambiguity in 'control the wrist.' It also explains the clearing elbow's job: obstructing the rider's free arm from reconnecting around the rising wrestler [S1]. In this beginner drill that is positioning, not an elbow strike.
- The independent instructional unit places the inside foot near the opposite knee, brings the elbows close, and teaches rising before separating the hips and facing [S2, PDF pp. 68-70]. This supports a compact first step rather than a long lunge that leaves the chest over the thigh.
- The Human Kinetics youth-coaching handout teaches clearing the near arm, raising the chest, retaining bent knees and a broad base, then finishing low while protecting the legs [S3, p. 1]. Its rear leg moves little during the rise; the card does not prescribe a large second step or straight-legged finish.
- USA Wrestling separates inside hand control, isolating a hand away from the hips, and making space between the wrestlers' hips [S4, p. 3]. Here the selected whole-hand grip stays near the wrist with neutral alignment; hip movement creates clearance instead of levering fingers. The top wrestler's hands remain separate during this introductory drill, so breaking a locked rear grip is not assumed taught.

### Teaching progression

- Demonstrate the standing hand-control and facing finish first, then add the rise. College Park explicitly uses backward teaching from standing footwork to hand control and finally base-to-feet work [S5, p. 14]; that teaching order transfers even though its stand-up uses the outside leg.
- Teach both roles. Top begins on the assigned side, follows upward on their own feet, and allows the captured arm to move without stiffening the wrist or shoulder. Bottom should retain independent balance rather than hang backward on the receiver. Initially freeze at two-foot support, then complete the facing finish.
- After slow successful repetitions, top takes one following step to reduce hip space while maintaining light separate-hand contact. Bottom must restore the space before turning; stop and reset if the hand cannot be cleared. The three repetitions and defined reaction are coaching design, not validated training doses. Full riding, grip changes, locked-hand battles, and returns require separate instruction.

### Common mistakes and corrections

- Standing without a captured hand leaves the partner free to reconnect: rehearse the simultaneous foot rise, elbow clearance, and hand capture at low speed.
- Bending forward or taking an oversized first step: shorten the step beside the opposite knee and lift the chest before completing the rise. Check balance without the receiver supporting body weight.
- Twisting before making space: return to the standing checkpoint and move the hips away while retaining the whole-hand grip. If the receiver's wrist bends or their shoulder is pulled behind them, release and reset rather than forcing the turn.
- Facing in tall, narrow posture invites an immediate reattack: finish with knees bent, usable foot spacing, and the free hand protecting the legs [S3].

### Readiness and rules

Beginner is a readiness tier, not an age permission. Require a stable base, a painless independent rise, and prompt release on command. Use B14-B15 for the coach's event-specific starting-position checks. This card teaches a folkstyle escape action without making a scoring promise: the rider must actually lose control. The no-return and separate-hand limits define this drill; they are not claims that all mat returns or every standing lock are illegal. Historical source scoring and starting-rule details are not adopted.

### What changed

- Name a specific familiar variant: Inside-Leg Stand-Up.
- Specify left-side rider, left stepping foot, right-to-right hand capture, and right facing turn.
- Replace the unspecified cutaway with hand retention, hip separation, and a low facing finish.
- Separate this partner variant from P08's outside-leg solo preparation and define the receiver's limited reaction.
- Editorial prerequisite check keeps base and partner-start readiness without requiring the separate belly-to-base skill first.

### Evidence limits

Inspected full article text and the cited PDF text, including cached page-marked extracts. No video playback was inspected, and attempted screenshot retrieval did not provide a usable image, so no visual claim is made. S1 is the authority for the exact sided sequence; S2-S4 corroborate placement and position principles, not an identical complete variant. S5 is used only for comparison and teaching order. Whole-hand safety language, restrained contact, pauses, reset criteria, and drill dosage are coaching adaptations.

### Sources inspected

**S1: [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/)** - Bill Welker, The Wrestling Drill Book; Human Kinetics excerpt published by Coaches Insider; accessed 2026-09-26.

**Inspected:** Full article text, especially Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration was not visually inspected.

**Supports:** Left-side rider and inside left-foot rise; Left elbow clears toward rider's chest; Bottom right hand holds rider's right hand; Hips clear before a right turn; captured hand remains held

**Limits:** Short instructional excerpt. Does not teach breaking a locked rear grip. Its broad safety superlative is not adopted.

**S2: [Wrestling Unit Plan, Lesson 18: Stand-up Escape](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Horaski and Garcia; instructional unit hosted by PE Links 4U; accessed 2026-09-26.

**Inspected:** Cached PDF text, pages 68-71, with emphasis on the actual teaching instructions on pages 69-70.

**Supports:** Inside foot placed near the outside knee; Close elbows and waist-hand capture; Rise to both feet, separate hips, then face; Slow cooperative partner rehearsal

**Limits:** Physical-education instructional unit, not current rules or evidence for an age-specific training dose. Does not identify an exact direction for the final turn.

**S3: [Bottom Move: Standup to an Escape](https://s3.amazonaws.com/my.llfiles.com/00224751/turkstep.pdf)** - Human Kinetics, Coaching Youth Wrestling Course, 2003; accessed 2026-09-26.

**Inspected:** Full one-page PDF text, from inside-leg entry through low facing finish; illustrations not visually inspected.

**Supports:** Inside arm clears as the inside leg steps; Bent knees and wide foot spacing; Small rear-leg adjustment rather than a large second step; Turn to face and protect legs from a low stance

**Limits:** Historical coaching handout hosted by a third party. Text inspected only. Its locked-hand passage is not taught by this introductory card.

**S4: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF text pages 2-3, particularly Push Back Drill and Hip-Heist Drill at the printed video timestamp 23:48-24:21. The referenced video was not watched.

**Supports:** Inside hand control during the rise; Isolate a hand away from the hips; Separate the wrestlers' hips before escape motion

**Limits:** Study-guide instructions support shared escape principles, not the exact leg choice or final turn direction.

**S5: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF text pages 8, 14, and 31: Wall Standup, Basic Bottom, and Standup execution table.

**Supports:** P08's distinct inside-arm/outside-leg coordination; Teach standing footwork and hand control before adding the rise; Stand-up requires actual hand and hip clearance

**Limits:** Different variant. Its backstep text does not expressly name a left or right final turn, so it is not used to establish B17's direction.

<a id="b18"></a>

## B18 - Sit-Out

**Tier:** Beginner | **Previous name:** Sit Out And Turn In

### Technical review

The original sought hip separation and hand control but omitted the supporting hand, outside-foot step, passing leg, rider side, and particular wrist. Its turn toward the controlled hand substantially overlapped B19 without verifying a distinct turn-in. The prohibition on leaning into the rider also removed useful back pressure. Morrison actually teaches a head-supported turn-in; Horaski and Garcia describe a continuing shoulder-roll reversal. Neither verifies the original's implied simple no-head turn-in. Following root's scope decision, this becomes a partner sit-out ending at a seated checkpoint, explicitly not an escape.

### Selected variant

A right outside-foot, left leg-through sit-out with the rider on the learner's left. Entry matches the already audited P09 solo preparation. After sitting, the learner covers the rider's right waist wrist with the right hand and seals the left elbow. The partner adds contact and a following response. The separate escape remains B19; B20 adds the thigh attack and reversal. No head support or rolling finish is included.

### Mechanics and evidence

- College Park specifies a short outside-foot step and passage of the near leg, followed by pressure back into the rider through the heels. Its separate sit-out, switch, and Granby sections distinguish these families. With top on the learner's left, outside means right foot and near means left leg. [S1]
- Horaski and Garcia give the entry's cross-post, raised right knee, left leg-through action, and elbows-in seated position. Their partnered instruction also explains that crossing the left hand clears the rider's elbow contact. The card retains this coordination but replaces the prescribed heavy landing with a slow lowering. [S2]
- The same manual's turn-in setup identifies right-hand control of the partner's right wrist after the sit-out. This card uses only that seated hand relationship, not the subsequent roll. Contact stays around the wrist as a unit, without bending it. The left hand is no longer a fixed post once seated. [S2]
- Weber distinguishes getting into a compact sit-out from the subsequent escape. He teaches abdominal tension, pressure into the rider, and sealing the sides before hip-heisting. Thus chest-up posture can coexist with shoulder back pressure; it does not mean arching or throwing the head backward. [S3]
- Morrison's actual instruction confirms that his turn-in uses a sealed arm, side-of-body transition, head-and-toes support, a high leg, and continued motion. This is evidence for removing an unverified finish, not permission to add head loading to this beginner card. [S4]

### Teaching progression

- Repeat P09 solo, then add light left-side contact. Demonstrate from both sides before mirroring. Clear the passing knee before lowering the hips.
- The first partner repetitions end in a brief seated check: feet can push, torso is supported, the waist wrist remains in front, and the other elbow closes the side. The receiver follows with knees and feet rather than pulling backward or holding a planted arm.
- Top's defined response is a light reach toward the left ribs while following. Bottom seals that side without abandoning waist-hand contact. Repetition count, pause, and reset are coaching design, not researched doses.
- Release before the separate return to base. Once B19 is learned, connect entry to escape without the training pause. In live wrestling the seated checkpoint is a transition, not a resting place. No prerequisite requires B19, so the sequence remains non-circular.

### Common mistakes and corrections

- An ordinary side-sit with the left knee still underneath is incomplete. Rehearse the right-foot support and leg clearance before adding partner contact.
- A long backward post exposes the arm and invites a fall. Keep the entry short, support the descent, and release the mat post once the seated balance is established.
- Scooting far away with straight legs can leave the learner unable to push or follow. Recover bent knees and a compact torso; use light back pressure while maintaining separation between the hips.

### Readiness and rules

Beginner is a readiness tier. Require the solo entry, painless hand support, and reliable partner following/release. Head-supported balance, shoulder rolls, and forced arm rotation are excluded. No score is claimed. B14-B15 supply the event-appropriate start; historical scoring passages are not adopted.

### What changed

- Renamed Sit Out And Turn In to Sit-Out and honestly limited its purpose to creating a position for later offense.
- Specified rider side, cross-post, supporting foot, passing leg, seated wrist contact, and release/reset.
- Restored useful back pressure without a backward fall or head throw.
- Kept the entry consistent with P09 and assigned the complete hip-heist escape to B19.
- Removed the unsupported no-head turn-in instead of substituting a head-supported version.
- Editorial prerequisite check requires base, partner-start and solo sit-out readiness without requiring belly-to-base recovery first.

### Evidence limits

Read the cited manuals and Weber's authored instruction. Morrison's complete automatic transcript and selected video frames were inspected; caption errors preclude relying on ambiguous transcribed limb names. His commercial course and Kolat's member video were not inspected. The card combines a verified entry, seated wrist relationship, and compact-pressure principles. No source publishes this exact drill. The freeze/reset, restricted response, and omission of head support are teaching choices.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 14 and 31-32: Basic Bottom, Tripod, Sit Out/Turn Out, and Switch.

**Supports:** Outside-foot step and near-leg passage.; Heel-driven back pressure and separation of sit-out, switch, and rolling finishes.

**Limits:** Does not give the exact posting hand; historical rule and scoring passages are not adopted.

**S2: [Wrestling Unit Block Plan, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 83-88, especially partnered entry on page 85 and seated wrist relationship on page 86.

**Supports:** Specific cross-post and leg-through coordination.; Elbows-in seat and right-hand control of the rider's right wrist.

**Limits:** Authored PE lesson plan, not an elite-coach certification or age-readiness standard. Its heavy landing, fixed knee height, and rolling turn-in are not used.

**S3: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full authored page text, especially Steps 1, 2, and 5; embedded Vimeo video not inspected.

**Supports:** Compact sit-out and back pressure.; Sealing the sides before a separate hip-heist escape.; Hand control and later stand-up options.

**Limits:** Does not specify the cross-post entry or this exact partner drill.

**S4: [Sit Out, Turn In by Jon Morrison](https://www.youtube.com/watch?v=vkY16JCnNnQ)** - FANATIC WRESTLING, official instructional YouTube channel; accessed 2026-09-26.

**Inspected:** Automatic English transcript 0:00-4:12 and paused demonstration frames at 1:55, 2:00, 2:15, 2:20, 2:25, 2:30, 2:40, 4:00, 4:05-4:07, and 4:09 through the browser.

**Supports:** Actual turn-in employs sealed elbows, head/toes support, high-leg motion, and continued circling.; Distinguishes that finish from the short seated checkpoint retained here.

**Limits:** Used to assess and exclude the head-supported finish, not as an age-readiness endorsement. Automatic transcript has errors; no full course access claimed.

<a id="b19"></a>

## B19 - Hip-Heist Escape

**Tier:** Beginner | **Previous name:** Hip Heist To Face

### Technical review

The draft correctly paired an opposite hand and foot and described passing the free leg under the body. It also warned about twisting a fixed support. However, it did not identify a ride or a hand to clear, delayed hand clearing until after turning, and treated a facing base as interchangeable with an escape. This could teach a useful solo transition while leaving the athlete attached to the rider. The replacement retains a low seated hip switch but puts it inside a short-sit escape sequence. Human Kinetics explicitly teaches hand clearing before the inside spin [HK]. Weber likewise makes sealing the sides and creating back pressure part of the heist [WEBER]. Neither supports treating an uncontrolled seated turn as a finished escape.

### Selected variant

A left-turning hip-heist escape from an already established short sit, with left palm and right foot as the initial diagonal supports, left leg sweeping underneath and right leg passing over as the hips rotate. Left/right are a consistent coaching illustration of the movement, not a claim that the sources mandate one side. B18 supplies the short-sit entry. This card owns the leg switch, hip separation, and facing finish; P10 remains solo preparation, and a shoulder-roll turn-in/reversal is a different technique.

### Mechanics and evidence

- The short sit keeps the knees bent and the feet available; posted hands initially help maintain the seat, then the bottom wrestler attacks the rider's hands. The inspected handout's final photos show an inside turn and separation in front of the former rider [HK].
- Weber describes sealing both sides and pressing the shoulders back before heisting away. The revised card uses this to create room while the waist hand is cleared, rather than telling the beginner to collapse backward [WEBER].
- Malinconico's publisher describes a seated heist as one leg passing under and the other over, with a low hip switch rather than a shoulder roll. That under/over action is the important addition to the draft's vague knee recovery [MAL].
- The left-hand/right-foot example makes the free left leg identifiable. The support is temporary: shift or replace the hand as the body turns. This is the card's coaching explanation of the diagonal support and leg switch, not a quoted source prescription.
- The finish faces the partner, then creates enough distance to end contact and returns to stance. Horaski and Garcia explicitly teach facing on hands and knees, moving backward clear, and getting to the feet [HG]. A retained waist ride means the action has not completed its intended escape.

### Teaching progression

- Demonstrate the diagonal supports and leg switch alone, in both directions. Require a low turn without loading the head or rolling onto a shoulder before adding waist contact.
- Begin partner practice in B18's established short sit. The receiver kneels behind, offers one loose waist hand, and allows the bottom wrestler to clear it. This starting position and restricted receiver role are proposed coaching design.
- After cooperative success, top follows on the knees and attempts only to retain waist contact. Bottom must clear, turn, separate, and face. Rebuild base when the rider successfully follows. Repetitions, round lengths, rest, and these restrictions are coaching choices, not research-established doses.

### Common mistakes and corrections

- If the rider follows easily, check whether hand control was actually removed before increasing speed. Isolating a hand away from the hips is also explicit in USA Wrestling's heist drill [USAW].
- If the athlete tips sideways onto a shoulder, return to the seated under/over rehearsal. Malinconico's distinction is switching the hips while remaining low, rather than substituting a roll [MAL].
- If the supporting palm or knee becomes a fixed pivot, reduce the turn and permit support changes. A strained joint is a stop signal, not a cue to rotate harder.

### Readiness and rules

Beginner is a readiness tier. The athlete must manage the solo support transition and release immediately on a stop cue. This card uses no head bridge, neck-supported drop, mat return, or shoulder-roll reversal. The receiver's hands stay unlinked for this drill. The sources teach an escape family, but the card makes no current scoring-value or event-rule claim; the coach must judge actual loss of control under the competition's rules.

### What changed

- Renamed the card Hip-Heist Escape to state its wrestling purpose.
- Moved hand clearing ahead of the heist and specified the starting waist contact.
- Named the diagonal supports and both legs' jobs instead of only bringing a free knee underneath.
- Added separation and stance as the finish, with base recovery as a reset when top retains control.
- Removed any dependency on B18 containing an unverified turn-in finish.
- Editorial hand-control clarification specifies whole-hand contact near the wrist and release before posting, so the heist does not twist a retained hand grip.

### Evidence limits

Inspected the complete Human Kinetics one-page handout, including all nine demonstration photos; Weber's actual article text; the Fanatic Wrestling publisher's written explanation of Malinconico's demonstration; and the relevant cached manual text with PDF page markers. The YouTube video did not load, so no claim is made to have watched it. The Fanatic article is publisher interpretation, not a verbatim coach transcript. USA Wrestling's cited hand-control drill starts from standing, so it corroborates the hand-and-hip separation principle rather than proving this card's seated footwork. Horaski and Garcia give the facing finish but not the exact diagonal supports. The card's selected left-side wording, receiver limits, reset criteria, and dosage are coaching synthesis. No historical scoring language or advanced head-supported drill was imported.

### Sources inspected

**HK: [Bottom Move: Hip Heist to an Escape](https://s3.amazonaws.com/my.llfiles.com/00224751/hipheist.pdf)** - Human Kinetics, Coaching Youth Wrestling Course (2003); public course sheet; accessed 2026-09-26.

**Inspected:** Complete PDF page 1 text and all nine photos, rendered in memory; enlarged final three photos inspected for the turn and facing finish.

**Supports:** Short sit, back pressure, compact legs, posting before attacking hands, clearing hands before the inside spin, and recovering stance after escape

**Limits:** Historical course sheet. Captions do not label the final heist's left/right supports; its sequence supports the technique, not every side-specific coaching phrase.

**WEBER: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Article text, especially Step 1: Basic sit out position and Step 2: Seal off, hip heist away; surrounding alternatives read to distinguish variants.

**Supports:** Short sit with tight position; seal the sides; shoulder back pressure before the hip heist away

**Limits:** Embedded Vimeo clip did not load. Article does not specify the seated heist's diagonal supports; its knee-under stand-up and gizoni alternatives are not combined into this card.

**MAL: [Hip Heist Drills by Mike Malinconinco](https://fanaticwrestling.com/blogs/news/hip-heist-drills-by-mike-malinconinco)** - Fanatic Wrestling, publisher of Mike Malinconico's coaching instruction; accessed 2026-09-26.

**Inspected:** Full article text, especially Seated Hip Heist and Seated Wall Hip Heist; advanced drill sections read only to establish exclusions.

**Supports:** One leg under and one over; low hip switching rather than rolling; create distance from the opponent

**Limits:** Publisher's narrative description, not a verbatim transcript. Did not watch the inaccessible YouTube demonstration. Head-supported wall and partner-drop variants are excluded.

**HG: [Wrestling Unit, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extraction, pages 85-87, with the heist sequence on PDF page 86 and the separate turn-in continuation on page 87.

**Supports:** Heist from a sit, face partner on hands and knees, move backward clear of contact, and rise; separate heist and shoulder-roll turn-in finishes

**Limits:** Physical-education teaching unit. Wording 'flip over' does not independently specify the leg switch or support hand and should not be reproduced as a sufficient technical cue.

**USAW: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extraction, PDF page 3, Hip-Heist Drill section keyed to 23:48-24:21; relevant bottom-motion context on pages 2-3.

**Supports:** Inside hand control, isolate a hand away from hips, create hip separation with back pressure, and recover the feet after heisting

**Limits:** Written study guide rather than the video. This particular drill comes from standing; it corroborates hand control and separation but not the seated hand/foot assignment.

<a id="b20"></a>

## B20 - Switch

**Tier:** Beginner | **Previous name:** Switch Reversal

### Technical review

The draft identified the correct family and the standard left-side rider/right-side switch, correctly prohibited reaching over the back, and retained a useful hip-heist prerequisite. Its purpose, however, described turning an escape into control: the intended action is a direct reversal from bottom. The unnamed thigh, unexplained shoulder contact, and instruction to turn toward a reaching hand left the decisive relationship unclear. Merely passing a leg underneath can produce an escape heist without establishing control. The revision retains one short-sit switch and spells out its route to the rider's right thigh and rear position.

### Selected variant

A right-side short-sit switch against a left-side tight-waist rider, with the bottom wrestler's left hand controlling the rider's right wrist. This uses the hand-control version described in Horaski-Garcia and the short-sit discussion in Winning Wrestling Moves. It excludes the inside switch, power switch, standing switch, running switch, and rolls.

### Mechanics and evidence

- Welker explicitly starts the rider on the left, places the switching wrestler on the right buttock, sends the right hand between the rider's legs, and finishes behind. His stated common error is reaching over the back. [S1]
- Horaski-Garcia describes clearing the left elbow by taking the left hand across, stepping up the right foot and passing the left leg through for the sit. Its switch instruction then uses the left hand on the rider's right wrist at the belly, the right arm reaching for the rider's right leg, and a rightward turn into the hips. [S2]
- College Park identifies the tight waist as a useful opportunity and links the pocket-level reach to the inside thigh, raised hips, and a hip heist behind. This is more specific than an unrestricted backward reach. [S3]
- Winning Wrestling Moves explains the over-arm/under-leg connection, moving the hips away instead of sitting parallel beside the opponent, lowering the rider's right shoulder, clearing the waist arm, and scissoring the left leg over the right to finish. Its short-sit variation adds opposite-hand arm control. The shoulder contact must move with the rider's torso; the card does not prescribe wrenching a fixed arm. [S4]

### Teaching progression

- Demonstrate slowly from both viewing sides, naming each wrestler's limbs. Pause at the short sit, thigh connection, and rear-control finish. The bottom wrestler must be able to stop at each stage without falling onto a locked posting arm.
- For receiving, the rider begins with light waist contact, moves the knees with the turning torso, and allows the waist arm to clear. Bottom releases that wrist during the transition. Neither wrestler freezes an arm while the other continues turning. These receiving constraints are coaching design informed by the joint-pressure boundary. [S6]
- Use cooperative repetitions before the rider adds only a following circle. Bottom may reset if the leg is unavailable or the turn stops. Facing without the opponent controlling them is an escape outcome; controlling behind the opponent is the reversal objective. A thigh touch alone does not complete this card. The repetition count is a proposed teaching dose.

### Common mistakes and corrections

- A long sit or reclining chest leaves the athlete extended. Shorten the sit and restore shoulders over hips before reaching; these are the two errors specifically highlighted in Eric Akin's publisher summary. [S5]
- A hand over the rider's back lacks the intended thigh connection. Return to the pocket-level route between the legs. [S1, S3]
- Turning while still flat on the buttocks encourages an arm pull. Rehearse lifting and scissoring first. If the shoulder cannot travel with the torso, release and reset instead of increasing force. [S3, S6]

### Readiness and rules

Beginner is a readiness tier, not permission to apply joint pressure at speed. This is a folkstyle reversal lesson; it does not assign points from historical manuals or borrow international scoring. USA Wrestling's current folkstyle modifications use NFHS scoring with modifications and emphasize stopping undue pressure to the head, neck, or joints, particularly for 14U and younger. [S6] The hand on the thigh is a connection for changing position, not a submission. Keep the rider's arm free to leave the waist and release before twisting an immobilized shoulder.

### What changed

- Shortened the familiar name to Switch and made direct bottom-to-top control the purpose.
- Named the rider's right wrist, right upper arm, right shoulder, and right thigh.
- Added the elbow clearance and compact sit before the reach.
- Replaced the ambiguous free-leg instruction with the documented scissor to rear control.
- Specified wrist release, receiving behavior, and the distinction between escape and reversal.

### Evidence limits

S1 is a publisher-provided book excerpt inspected as page text; its illustration link did not load. S2-S3 were inspected in cached PDF-page-marked extractions and their original PDFs were opened online. S4 is coach-authored instruction in a third-party OCR transcription with interleaved columns; only the coherent switch passage and its adjacent short-sit/counter explanations are used. S5 verifies only the publicly visible coaching summary, not the embedded video. No video viewing is claimed. The exact release timing, receiver limits, and constrained drill are conservative teaching design, not quotations or experimentally established practice doses.

### Sources inspected

**S1: [Escapes and Reversals - Switches, from The Wrestling Drill Book](https://coachesinsider.com/wrestling/escapes-and-reversals-switches-article/)** - Bill Welker / Human Kinetics, publisher-provided excerpt on Coaches Insider; accessed 2026-09-26.

**Inspected:** Public article text, standard SWITCH setup, action, coaching point, and common error; also distinguished its separately named variants.

**Supports:** Left-side rider and right-buttock/right-hand switch; Between-the-legs reach and hip heist behind; Hip-heist prerequisite and no over-back reach

**Limits:** Text only; linked illustration unavailable. Does not detail the wrist grip or shoulder contact.

**S2: [Wrestling Unit Block Plan, sit-out switch lesson](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** PDF pages 90-92, cached page-marked text of sit-out review, switch instruction, and closing cues; original PDF opened online.

**Supports:** Left-hand clearance and right-foot/left-leg sit sequence; Left hand controls rider's right wrist; Right hand reaches rider's right leg and turn goes right into the hips

**Limits:** School teaching unit, not a rulebook. Its language about using the wrist to lift the buttocks is not retained as an instruction to load or twist the joint.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** PDF page 32, SWITCH row in Escapes and Reversals; cached page-marked text and original PDF opened online.

**Supports:** Switch against a tight waist; Clear near arm, reach at pocket level to inside thigh; Raise hips and hip heist behind

**Limits:** Brief team-coaching notes omit exact sidedness and receiving detail; unrelated advanced holds and historical scoring are not adopted.

**S4: [Winning Wrestling Moves, Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics; OCR text hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Coach-authored book transcription, printed pages 130-132: Switch From Referee's Position, Short Sit to a Switch, and adjacent reswitch/limp-arm explanations; Using This Book confirms left-side rider convention.

**Supports:** Over-arm/under-right-leg switch connection; Hips away, right-shoulder pressure, and left-over-right scissor behind; Opposite-hand arm control for short-sit variant and clearing the waist arm

**Limits:** Third-party OCR interleaves columns and contains errors; photographs were not inspected. No historical rule claim is used.

**S5: [Learn a Technique that will Help Your Wrestlers Get a Quick Reversal!](https://www.championshipproductions.com/news/2014/11/01/learn-a-technique-that-will-help-your-wrestlers-get-a-quick-reversal/)** - Championship Productions; Eric Akin's Youth Wrestling: Escape Fundamentals; accessed 2026-09-26.

**Inspected:** Public Switch coaching summary identifying excessive sit-out distance and leaning backward as errors.

**Supports:** Compact sit; Keep hips beneath shoulders instead of reclining

**Limits:** Embedded video not inspected; summary does not verify exact grip or foot sequence.

**S6: [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Current online edition, section 25.5-25.8; page identifies last update as September 13, 2026.

**Supports:** NFHS scoring with USAW folkstyle modifications; Stop undue pressure to head, neck, or joints, especially for younger athletes; State modifications may differ

**Limits:** Folkstyle appendix supplies safety and event framework, not detailed switch mechanics or the complete NFHS scoring definitions.

<a id="b21"></a>

## B21 - Stand-Up Finish

**Tier:** Beginner | **Previous name:** Standing Cutaway Escape

### Technical review

The draft correctly made hand clearance precede a facing escape and prohibited returns during introductory practice. However, 'one controlling wrist,' 'the cleared side,' and 'step outward' never established which arm encircled which hip. It also introduced a two-hand grip without explaining its relationship to B17. That could lead a coach to combine a wrist-break or back-pocket finish from one stand-up with the opposite turning direction from another. The replacement isolates the final standing phase of the already verified B17. It is a focused finish rehearsal, not a second unrelated escape or a claim that standing alone ends control. 'Stand-Up Finish' is a familiar description of this teaching purpose.

### Selected variant

Use the finish of Welker's inside-leg stand-up: right hand retains the rider's right hand, hips separate, then the bottom wrestler turns right [S1]. B17 supplies the rise from a left-side rider. This card begins on both feet and preserves that hand assignment. It does not teach breaking a locked rear body grip.

### Mechanics and evidence

- Welker explicitly retains the captured hand through the facing turn. Accordingly, releasing at the start of rotation would remove an important part of the chosen finish [S1]. The card's near-wrist whole-hand grip avoids individual-finger manipulation; that wording is a beginner safety adaptation.
- USA Wrestling's Hip-Heist Drill separates three tasks: gain inside hand control, isolate a hand away from the hips, and create distance between the wrestlers' hips [S2, PDF p. 3]. The card uses those shared clearance principles but does not adopt a different footwork sequence from that drill.
- The right hip is the clearance checkpoint because this variant exits to the right. That is a teaching clarification of S1's direction, not a separate sourced back-pocket grip. Both hips first move away from the rider; simply twisting the shoulders inside an encircling arm is not the finish. No exact hand-transfer route, pivot foot, or outward step is claimed by the inspected source, so none is prescribed.
- The low facing stance is corroborated by College Park's stand-up execution table [S3, PDF p. 31]. Its two-hand push toward the back hip and outside-leg entry belong to another version and are not imported into this card. Both feet may adjust during the selected turn rather than leaving the knees fixed beneath rotating hips.

### Teaching progression

- Demonstrate the end position first: independent balance, the rider's rear contact gone, and both wrestlers facing. College Park specifically teaches standing footwork, then partner hand control, before adding the rise from base [S3, PDF p. 14]. That teaching order supports isolating this finish.
- Initially the rider places the right arm lightly around the waist, keeps the other hand separate, and allows the captured arm to travel with the turn. The receiver moves their feet and does not anchor the hand, stiffen the shoulder, or drag the escaping wrestler backward. Start with a pause after hand isolation and another after hip clearance.
- After three smooth repetitions each, the rider takes one following step to reduce the gap. Bottom restores hand-and-hip clearance before facing. Reset for a persistent grip or loss of balance. This receiver restriction and repetition count are coaching design; they are not published training doses. Finally reconnect the finish to B17's rise without an artificial pause.

### Common mistakes and corrections

- An early hand release permits renewed waist contact: slow the turn and keep the assigned hand until facing and clear.
- A shoulder-only spin leaves the hip trapped: return to the standing checkpoint, identify the right hip, and make space before rotating.
- Bending the receiver's wrist to manufacture clearance: stop and reposition the whole hand and body; use hip movement rather than a joint lever.
- Standing tall or crossing the feet at the finish: shorten the turn, retain bent knees, and check a usable stance before resetting.

### Readiness and rules

This drill requires independent standing balance, prompt release, and a cooperative receiver; Beginner is a readiness tier, not an age permission. Separate hands and no returns are drill limits, not declarations that every standing lock or mat return is illegal. No point value or current event-rule interpretation is asserted. A coach must verify actual loss of rear control rather than counting the rise or turn alone as success.

### What changed

- Rename the card Stand-Up Finish and make its relationship to B17 explicit.
- Specify bottom right hand to rider right hand, right-hip clearance, and a right facing turn.
- Remove the unsupported generic two-on-one and mandatory outward-foot step.
- Retain hand control through the turn and define release after the rear contact is cleared.
- Give the receiver one following step and a clear reset instead of unrestricted grip fighting.

### Evidence limits

Inspected the full coaching excerpt and relevant PDF text. No video was watched, and the linked illustration was not visually inspected. S1 supplies the exact sided finish; S2 independently supports hand isolation and hip separation; S3 supports teaching order and finishing stance but uses different stand-up mechanics. The free-hand protection, receiver limits, balance checks, and drill dosage are explicit coaching adaptations. The article does not specify an exact first turning foot, so the review does not invent one.

### Sources inspected

**S1: [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/)** - Bill Welker, The Wrestling Drill Book; Human Kinetics excerpt published by Coaches Insider; accessed 2026-09-26.

**Inspected:** Full article text, including Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration not visually inspected.

**Supports:** B17's left-side-rider inside-leg stand-up; Bottom right hand captures rider right hand; Hip clearance precedes a right turn while retaining that hand

**Limits:** Does not detail a locked-grip break, two-on-one transfer, first turning foot, or beginner receiver restrictions. The article's broad safety superlative is not adopted.

**S2: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** PDF text pages 2-3, especially the Hip-Heist Drill on page 3 at the printed video timestamp 23:48-24:21. Referenced video not watched.

**Supports:** Inside hand control during the rise; Isolate one hand away from the hips; Create space between the wrestlers' hips before escaping

**Limits:** Supports general clearance principles, not this card's exact handedness or right-turn direction.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF text page 14, Basic Bottom stand-up teaching progression, and page 31, Standup execution table.

**Supports:** Teach the standing finish and hand control before the rise; Clear hips and finish facing in a low stance

**Limits:** Uses an outside-leg entry and a different hand-clearing description. It is not used to establish this card's grip or turn direction.

<a id="b22"></a>

## B22 - Tight Waist Chop

**Tier:** Beginner | **Previous name:** Tight Waist And Chop

### Technical review

The draft correctly paired waist control with removal of the near-arm post, kept hands separate, and required cooperative receiving. Its decisive action was too vague: a hand above the elbow and an unspecified step 'forward and around' could produce an arm-only pull or be confused with a spiral breakdown. It never identified which side or limbs to use, omitted the rear-knee contribution, and ended by releasing the arm without establishing a useful ride. The revision retains the standard family but names one left-side execution, synchronizes the arm action with forward drive, and connects the breakdown to a specified wrist hold. 'Chop' is retained as familiar wrestling vocabulary and immediately explained as close forearm contact, not a strike.

### Selected variant

Left-side tight waist chop to cross-wrist and outside two-on-one control. Top's right arm supplies the waist connection, left forearm folds bottom's left elbow, and rear right knee advances the hips. The finish uses the right hand on bottom's left wrist and left hand on that arm's triceps. This is a forward breakdown, not the separate spiral, arm-bar turn, knee-block variant, or roll-through tilt found in some sources.

### Mechanics and evidence

- Kolat's inspected demonstration frames show top on bottom's left, a right arm around the waist, and a left forearm meeting the near arm near its elbow. Between approximately 0:43 and 0:44, the receiver's elbow folds and the near forearm lowers to the mat. These frames support the contact and folded-arm direction; they do not establish an exact pressure magnitude or a mandatory palm rotation. [S1]
- The club's actual lesson text explains the diagonal collapse toward the belly while driving over the chopped arm. It also connects the tightened waist, toes and rear-knee drive rather than treating them as separate attacks. The card translates those cues into a cooperative-speed repetition. [S2]
- USAW's Get Set drill specifies the near-arm chop and rear knee moving the buttocks forward; its top-motion section identifies chest pressure and leg drive as essential. Flynn's published explanation independently emphasizes moving forward instead of sitting on the legs and advancing the back knee as the rider becomes extended. [S3, S4]
- College Park explicitly connects the tight waist elbow chop to forward leg drive and cross-wrist control. Its control-position description identifies right hand to left wrist and the free hand on the same arm's triceps for an outside two-on-one. The card stops at that control rather than importing its subsequent crab ride, tilt or turk. [S5]

### Teaching progression

- First check the B14-B15 starting positions and rehearse the receiving action without top pressure: bottom bends the near elbow, allows that forearm to lower, and then lowers the trunk. The free arm remains available to support the descent. This receiving rehearsal is coaching design.
- Demonstrate the waist, forearm and rear-knee contacts individually at negligible resistance. Then join them after the whistle. Slow practice should preserve simultaneous forward drive and arm folding rather than teaching a hard isolated chop followed by a delayed push.
- Once the pair can stop throughout the descent, introduce the cross-wrist catch and upper-arm control. Check that the wrist is held as a unit without bending it and that the rider remains behind the shoulders with support through the legs.
- The first defined reaction is one attempt by bottom to bring a knee underneath and rebuild. Top follows the hips without adding an untaught turn. Three repetitions and the one-reaction limit are a proposed coaching progression, not an evidence-based dosage. Mirror the technique only after the named-side version is reliable.

### Common mistakes and corrections

- Elbow moves but the base stays strong: check whether top has sat back. Restore forward toe pressure and the rear-knee hip advance before adding force with the arm.
- A wind-up or impact replaces the chop: begin with the forearm already touching the elbow area and rehearse a short folding action. Bottom must not lock the posting elbow against the demonstration.
- Top runs around the head or pulls the arm across immobile hips: return to a forward path with the trunk and hips advancing together. The selected move does not need a large circle.
- Bottom immediately recovers because top releases everything: practice the wrist catch at low speed, then maintain upper-arm contact while following. Release only for reset or lost safe alignment.

### Readiness and rules

This is a folkstyle riding lesson, not a submission. B15 supplies the separately audited legal start; the tight waist and knee contact begin after the whistle. The separate-hands instruction avoids teaching a clasp around the grounded torso. The wrist catch holds the opponent's wrist, not the rider's own hands around the body. No claim about scoring, pin criteria or every event's exceptions is needed here. Stop a locked-arm, painful shoulder, twisted wrist or neck-loaded position rather than using additional force to complete the demonstration. Readiness depends on receiving and release behavior, not merely the Beginner label.

### What changed

- Shortened the familiar name to Tight Waist Chop.
- Specified both wrestlers' limbs and a single left-side version.
- Replaced the ambiguous hand push and circling cue with close forearm contact plus forward toe and rear-knee drive.
- Specified the receiver's bent-arm lowering and a cross-wrist follow-up.
- Replaced open-ended timed resistance with cooperative repetitions and one defined base-building reaction.

### Evidence limits

S1 was inspected through paused video frames, including 0:16, 0:36, 0:41, 0:43, 0:44, 0:46, 0:56, 1:04, 1:06, 1:09 and 1:14. No audio transcription was available, and this review does not claim to have heard Kolat's explanation. S2 and S4 were read as accessible instructional page text, not their linked or embedded videos. S3 and S5 were read in cached, page-marked PDF text. The Horaski-Garcia lesson was also inspected but its added knee block was excluded to avoid mixing variants. Receiving language, reduced practice intensity, stop conditions and drill structure are coaching adaptations. The curriculum listings alone were not used to verify mechanics.

### Sources inspected

**S1: [Wrestling Moves KOLAT.COM Wrestling Chop & Tight Waist](https://www.youtube.com/watch?v=fnI_WjItbdI)** - Cary Kolat, verified KOLATCOM YouTube channel; accessed 2026-09-26.

**Inspected:** Paused video frames at 0:16, 0:36, 0:41, 0:43, 0:44, 0:46, 0:56, 1:04, 1:06, 1:09 and 1:14; particularly near-elbow contact and the folded forearm in 0:43-0:46. Channel identity and description inspected in browser.

**Supports:** Left-side orientation and right waist arm; Left forearm contact near the receiver's near elbow; Near elbow bending and forearm lowering

**Limits:** Frame inspection only; no available transcript or claimed audio inspection. No exact force or palm-angle prescription inferred.

**S2: [Pre-season Clinic: Top Wrestling Part 6 - The Tight Waist Near Arm Chop and Roll Through Tilt, November 2, 2025](https://madisonyouthwrestling.club/)** - Madison Youth Wrestling; accessed 2026-09-26.

**Inspected:** Opened club page and read the November 2 instructional entry, specifically the paragraph explaining rear knee, waist elbow, diagonal arm collapse and toe drive.

**Supports:** Arm folds diagonally toward belly; Rear knee advances hips; Waist, toes and arm action occur together

**Limits:** Club lesson notes with no individual author identified. Linked Kolat video inspected separately; later tilt instructions not used.

**S3: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached page-marked text, PDF page 2 Get Set Drills - Arm Chop and PDF page 3 Top Motion.

**Supports:** Near-arm chop after whistle; Rear knee moves buttocks forward; Chest pressure and leg drive in top wrestling

**Limits:** Study-guide text inspected, not its referenced full video. Does not specify the exact forearm surface.

**S4: [Breakdown Your Opponent with the Tight Waist Chop](https://www.championshipproductions.com/news/2014/10/01/breakdown-your-opponent-with-the-tight-waist-chop/)** - Championship Productions; Tim Flynn instruction; accessed 2026-09-26.

**Inspected:** Opened and read the complete accessible instructional paragraph below Tight Waist Chop, dated October 1, 2014.

**Supports:** Forward drive rather than sitting back; Chop and drive after whistle; Back knee advances when rider becomes extended

**Limits:** Publisher's summary of Flynn's demonstration, not a watched embedded clip. Its between-the-legs continuation is not prescribed as the drill's endpoint.

**S5: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached page-marked PDF text: page 12 Basic Top and Breakdowns; page 27 Tight Waist Elbow Chop and Basic Control Positions/Cross Wrist.

**Supports:** Forward drive into chop; Cross-wrist capture with former waist hand; Outside two-on-one free-hand triceps control; Follow-up control after breakdown

**Limits:** Coach handbook with terse instructions and historical rule context. Its near-knee language differs from USAW's back-knee wording; the card uses the explicit USAW rear-knee version. Crab ride and later turns are omitted.

<a id="b23"></a>

## B23 - Near Ankle Breakdown

**Tier:** Beginner | **Previous name:** Near Ankle Breakdown

### Technical review

The original has useful ankle rather than toe control, an immediate release, and awareness of knee alignment. Its decisive action is wrong for the substantiated tight-waist/near-ankle variant: dragging the ankle straight backward along the mat is not the ankle drive described in the inspected manuals. The original also leaves the top side and controlling hands unspecified and gives bottom no receiving route. Its blanket prohibition on movement of the heel toward the buttocks conflicts with ordinary knee flexion in the selected breakdown; the important limit is forced flexion or levering the leg after the pelvis is pinned. The revised card preserves the familiar name and replaces the central action rather than merely adding a safety warning.

### Selected variant

Left-side tight-waist/near-ankle drive: top retains the right-arm waist connection and moves the left elbow hand to bottom's left ankle. The lifted ankle travels forward toward the seat as top drives the body forward. This is the lifting version described by College Park, with the explicit hand assignment corroborated by the Baltimore teaching guide. It ends at belly control, without adding a turn.

### Mechanics and evidence

- The Baltimore guide retains the right arm around the waist, sends the left hand from elbow to near ankle, and moves top behind bottom. It describes the ankle drive as forward and down. This independently contradicts the draft's backward drag, but does not describe the initial lift in detail. [S2]
- College Park explicitly pairs waist control with an ankle lift toward the seat and leg drive; once bottom is flat it directs an immediate transition to further control. Its general top instruction keeps the head behind the shoulders. These support the chosen variant, rather than the separate far-knee breakdown. [S1]
- USA Wrestling identifies chest pressure and leg drive as essential top-motion components. The drive therefore comes from moving the feet and body; the ankle arm does not perform the breakdown alone. [S3]
- Fanatic Wrestling's explanation of Hudson Taylor's defense describes the attacker's intention as transferring bottom's weight from hips and legs to the hands. This supports the forward-pressure purpose, but the article does not establish the exact near-ankle grip. [S4]

### Teaching progression

- Demonstrate from the left side, then freeze with each hand in place. Have both athletes identify bottom's left ankle. The above-heel cup is a teaching choice that makes ankle control explicit and avoids using the toes as a handle.
- Rehearse the receiving route without a grip first: let the hands travel forward, bend the elbows, lower through the forearms, and settle the hips and chest while keeping the face clear. This is a cooperative receiving task, not a prescribed competitive defense.
- Use slow complete repetitions before resistance. The receiver allows the whole body to travel; top stops the lift as the pelvis lowers, releases the ankle, and establishes a simple wrist connection. A coach checks that a flattened pelvis is never used as a fulcrum for further leg lifting.
- The later reaction is a slow attempt to rebuild the base. If the ankle escapes, reset instead of catching toes or chasing a rotated leg. The repetition count and short rounds are original coaching design; readiness is demonstrated control, not completion of a timer.

### Common mistakes and corrections

- Backward tug with stationary feet: return to the forward-drive entry and ask top to move the torso with the feet before increasing resistance.
- Ankle pulled outside its knee: release and reset the partner alignment. Do not solve a blocked breakdown by rotating the foot against a planted knee.
- Continuing to lift after bottom is flat: lower the leg immediately and switch to upper-body control. The finish is loss of base, not a knee stretch or low-back arch.

### Readiness and rules

Use matched partners who can receive pressure without locking the elbows or falling onto the face. The card is a coached folkstyle practice progression and does not assign competition permission by age. Keep the hands separate in this drill. Neither the 1970 guide nor College Park is used as current rules authority; the card makes no scoring or age-specific legality claim. Event rules and the supervising official still govern competitive use.

### What changed

- Replaced the unsupported backward ankle drag with a forward ankle drive powered by the legs and torso.
- Specified left-side top position, right-arm waist, and left-hand control of bottom's left ankle.
- Added the receiving route and a release at the flattened-hips endpoint.
- Distinguished normal knee bending from forced heel-to-seat compression, knee twisting, and low-back levering.

### Evidence limits

Inspected actual manual text and a publisher's explanatory article; no video was watched. S1 supplies the selected lifting variant; S2 is an independent but old teaching manual whose forward/down wording is not treated as a precise account of that lift. S3 corroborates general pressure and propulsion only. S4 explains the weight-transfer objective, not exact hand placement. The cup location, receiver rehearsal, immediate lowering rule, pain stop, and drill dose are conservative coaching specifications, not claims that every source states them. No locked instructional material or search snippet is counted as mechanical verification.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extraction, PDF pages 26-27: general TOP instruction, TIGHT WAIST ANKLE NEAR OR FAR, and subsequent control entries; web extraction also inspected.

**Supports:** Ankle lifting version with waist control and leg drive.; Head behind shoulders and transition after flattening.

**Limits:** Compact team notes cover near and far variants together and are not a current rule book. Receiver behavior and exact lift limits are not specified.

**S2: [Elementary School Physical Education: A Guide for Physical Education Teachers](https://files.eric.ed.gov/fulltext/ED093805.pdf)** - Baltimore County Board of Education, 1970; archived by ERIC; accessed 2026-09-26.

**Inspected:** PDF text, physical PDF pages 317-318 (printed pages 338-339), especially Tight Waist Near Ankle and Teaching Techniques.

**Supports:** Right arm at waist, left elbow hand to near ankle, movement behind the opponent, forward ankle drive.; Cooperative learning before partial resistance.

**Limits:** Historical physical-education teaching source. Not used for contemporary rules, age permissions, or exact lift height; its forward-and-down instruction does not detail the entire ankle path.

**S3: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF text, page 3, Top Motion section marked 20:18-21:14.

**Supports:** Chest pressure and leg drive as key top-wrestling mechanics.

**Limits:** A study guide; its breakdown list does not independently verify this card's exact grips or ankle direction. Linked video not inspected.

**S4: [Granby Roll Defense With Hudson Taylor](https://fanaticwrestling.com/blogs/news/granby-roll-defense-with-hudson-taylor)** - Fanatic Wrestling, publisher of Hudson Taylor's instruction; accessed 2026-09-26.

**Inspected:** Accessible article text, especially the explanation of tight-waist ankle pressure moving weight toward the hands; embedded video not inspected.

**Supports:** Forward pressure transfers bottom's weight from hips and legs toward the hands.

**Limits:** Publisher explanation of a defense, not direct verification of the near-side grip. Its Granby counter is not included in this beginner drill.

<a id="b24"></a>

## B24 - Spiral Breakdown

**Tier:** Beginner | **Previous name:** Spiral Breakdown

### Technical review

The original identifies the correct family: an arm-and-thigh spiral using circular footwork. It is too ambiguous to teach reliably. For the selected left-side version, the thigh contact must be on bottom's RIGHT inner thigh, the far thigh, rather than the stated near thigh. 'Near arm' also leaves unclear whose arm is meant. The original omits getting off the knees and establishing chest pressure, and its unspecified final ride does not teach how to retain the advantage. The revision gives a concrete left-side example and a near-wrist finish. The familiar name needs no change.

### Selected variant

A basic spiral from bottom's left: top's left arm supports bottom's left upper arm from underneath; top's right hand pries bottom's right inner thigh. Circle left toward the head and finish with left-hand-to-left-wrist control. This uses the chest/upper-arm branch of the spiral and does not add a claw, half nelson, leg insertion, or tilt.

### Mechanics and evidence

- Spealler explicitly describes starting at bottom's left, putting the right hand inside bottom's right thigh, reaching the left arm underneath bottom's left arm, advancing chest contact, rising onto both feet, and circling left while the left arm presses forward and the right presses back. The purpose is to lengthen the base and remove supporting posts. [S1]
- Amine's publisher explains an under-biceps contact with the base of the left hand and a forward bump that shifts bottom's weight onto the hands. This supports the selected shallow upper-arm contact. The article continues into leg riding; that continuation is excluded here. [S3]
- College Park specifies the FAR inner thigh, foot-driven pressure with knees off the mat, and obtaining the near wrist as bottom reaches an elbow. Its near-wrist definition uses the same-side hand. Returning the free arm to waist control is a beginner endpoint chosen from its general top-control instruction. [S2]
- The handbook's claw reaches to the far shoulder; its chop uses a tight waist and elbow action leading to cross-wrist control. Those contacts are different from this card's under-arm support and far-thigh pry. Its combined SPIRAL/CLAW entry is therefore not copied as one blended move. [S2]
- USA Wrestling identifies chest pressure, leg drive, and continuing motion as general top fundamentals. It lists the spiral but does not supply its exact grips. Hips follow the moving chest and feet here; an isolated hip twist is not the breakdown mechanism. [S4]

### Teaching progression

- Demonstrate on bottom's left and name every hand and target before mirroring sides. Freeze at the two contacts so the coach can check the far thigh and upper arm.
- The receiving partner first keeps an ordinary base, lets the left elbow bend as pressure develops, lowers onto the forearm, and follows to the belly with the face clear. This is cooperative receiving practice, not a prescribed competitive defense.
- Add the foot circle and wrist collection only after both partners can stop immediately. Check that top stays connected without falling over the shoulder line or increasing pressure against a rigid arm.
- Progress to the stated base-rebuilding reaction. Reset if bottom stands or rotates into an unpracticed position. The repetition count, ten-second task, and receiving sequence are proposed coaching design, not research-tested doses.

### Common mistakes and corrections

- If the right hand stays on the near thigh, stop and identify bottom's right leg before restarting; this is the selected far-thigh version.
- If top's feet move but the chest separates, shorten the steps and reconnect before circling. If bottom braces a straight arm, reduce pressure and rehearse yielding to the forearm.
- If top releases both spiral contacts together, pause at the elbow-down position and secure the near wrist before reorganizing the free hand.

### Readiness and rules

Beginner denotes readiness, not an age exemption. Require supervised partner pressure, immediate release, and successful low-resistance receiving. The card starts from the separately taught legal referee's position and changes contacts after the signal. It makes no scoring claim or assertion that every claw, neck contact, or historical variation is legal under current event rules.

### What changed

- Corrected near thigh to far inner thigh for this variant and named all right/left contacts.
- Added feet, chest, and hip-following requirements; specified circling on the left toward the head.
- Replaced a vague final ride with near-wrist and waist control.
- Defined cooperative receiving and a limited base-rebuilding reaction.

### Evidence limits

Inspected coaching text, not video playback. Spealler permits a chest-or-neck arm path; only the chest/upper-arm path is adopted. College Park groups several spiral/claw continuations, so it cannot alone establish a single beginner variant. Amine's accessible publisher text corroborates the entry but targets leg insertion. USA Wrestling supplies general pressure principles only. No present-day rule conclusion is inferred from these older coaching materials.

### Sources inspected

**S1: [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf)** - Chris Spealler, CrossFit Journal, Issue 69, May 2008; accessed 2026-09-26.

**Inspected:** PDF text, page 3, Breakdowns and spiral-ride paragraphs; page 4 author biography. Spealler identifies his Division I wrestling background at Lock Haven.

**Supports:** Left-side example with right hand on bottom's right inner thigh and left arm underneath bottom's left arm; Chest advances, both feet support top, circle left, arm forward and thigh backward; Lengthening the base and disrupting posts

**Limits:** Historical instruction, not current rules. Allows chest or neck contact and does not define the final wrist ride. Only the chest/upper-arm route is used. No video was watched.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 26-28: Top, Breakdowns, Spiral/Claw, Tight Waist Elbow Chop, Near Wrist, Cross Wrist, and opening control entries. Original PDF URL also opened.

**Supports:** Far inner-thigh pry and collecting near wrist when bottom drops to an elbow; Feet-driven pressure and knees off mat; Same-side definition of near-wrist control; Distinguishing claw and chop contacts and continuations

**Limits:** Spiral and claw variants share an entry; not every listed variation is adopted. Historical rules and forceful advanced continuations are not treated as beginner requirements.

**S3: [How To Spiral Ride With Malik Amine](https://fanaticwrestling.com/blogs/news/how-to-spiral-ride-with-malik-amine)** - Fanatic Wrestling, publisher of Malik Amine's instruction; accessed 2026-09-26.

**Inspected:** Accessible article text under How To Spiral Ride, especially the hand-placement and forward-bump paragraphs, web lines 53-60.

**Supports:** Base of left hand underneath the upper arm/biceps; Forward pressure transfers weight to bottom's hands; Entry after the whistle

**Limits:** Publisher's written explanation was inspected; embedded YouTube retrieval was throttled and the video was not watched. Its later leg-riding sequence is outside this card.

**S4: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 1-3, especially page 3 Top Motion, corresponding to the guide's 20:18-21:14 section; original PDF opened.

**Supports:** Chest pressure, leg drive, and motion as general top-wrestling fundamentals; Spiral ride is included among top breakdowns

**Limits:** Study guide supplies general principles and a technique listing, not exact spiral grips or footwork. Linked video was not inspected.

<a id="b25"></a>

## B25 - Near Wrist Ride

**Tier:** Beginner | **Previous name:** Near Wrist Ride

### Technical review

The original had the right family name and useful emphasis on moving the feet and avoiding wrist bending. Its central instruction, however, was only to cup the wrist with the nearby hand. That leaves the arm route and same-side relationship unclear. It also proposed starting on either base or belly, pulling beneath the shoulder, and moving to an unspecified breakdown or half. These are several teaching problems, not one complete ride. The revision isolates the belly-down entry and ends with demonstrated control and release. A turn needs its own grip, angle, receiver instruction, and endpoint.

### Selected variant

Belly-down left-hand-to-left-wrist one-on-one, using forward body pressure to trap the wrist beneath the belly. Winning Wrestling Moves describes this entry explicitly; College Park identifies the same-side relationship and shoulder pressure. The chosen left-side example makes every hand assignment visible. The prerequisite permits an already-taught breakdown without making the chop-to-cross-wrist sequence the assumed entry.

### Mechanics and evidence

- Near wrist here means anatomical same-side control: top's left hand holds bottom's left wrist. College Park explicitly gives the mirrored right-to-right example. Its cross-wrist entry from a chop transfers the near wrist to the hand around the belly, producing right-to-left control. An outside 2-on-1 then adds the free hand at the triceps; an inside 2-on-1 adds it under the armpit at the forearm. None of those transfers is part of this card. [S1]
- The controlling arm travels under the receiver's near arm and over the wrist. The book's belly-down entry starts with the arms forward; it emphasizes advancing the receiver's body over the held wrist when pulling the wrist underneath is difficult. The rewrite therefore uses leg and body pressure rather than an isolated backward tug. [S2]
- College Park's general top instruction places the head behind the shoulders and uses the feet for downward pressure; it also identifies tight-waist control as a useful companion. The card assigns the otherwise free right arm to that waist contact and keeps the hands separate. [S1]
- Gable's near-wrist drill describes capture during rebuilding or after a jam, then forward drive and circling to retain the wrist. This supports the small following steps during the receiver's slow rebuild. Weber independently emphasizes forward pressure and control of shoulder position, though his page does not specify this card's exact grip. [S3, S4]

### Teaching progression

- Demonstrate from the receiver's left and identify both left wrists aloud. Show the route under the upper arm before adding pressure, so learners cannot confuse the grip with reaching over the shoulder or taking a cross-wrist.
- The receiver begins belly-down, arms forward and elbows unlocked. Initially they permit the forearm to fold beneath the torso as top advances. Keep enough space to demonstrate the grip before settling body weight; do not force a wrist that cannot be comfortably collected.
- After cooperative repetitions, bottom makes one defined response: draw the knees underneath to rebuild. Top follows while remaining balanced. A cleared wrist ends the repetition rather than triggering harder gripping or an untrained turn. Durations, repetitions, and this stop condition are proposed coaching design.
- The endpoint is retained top control with bottom belly-down. Practice unloading and opening the grip before the receiver repositions the arm. Connect to a separately taught turn only after both athletes can enter, follow, and release this ride consistently.

### Common mistakes and corrections

- Wrong hand: pause and compare left-to-left with right-to-left. Hand identity, not whichever hand seems nearby, distinguishes this ride from the cross-wrist.
- Wrist-only pulling: shorten the reach and move the body forward. The trapped arm should travel with the torso; the hand must not become a lever for wrist flexion.
- Sitting back or freezing during a rebuild: reconnect the chest, widen the base, and use short following steps. If alignment is lost, restart rather than retaining the grip through a twist.

### Readiness and rules

Beginner is a readiness tier: require successful receiving and immediate release, then introduce resistance gradually. The no-finger-pulling and no-arm-on-back boundaries define this introductory exercise; they are not a claim that every other wrist-control variant is prohibited. Current event rules govern later turns and competition use. No scoring or stalling rule is inferred from the older books, and a timed practice hold is not a competition strategy.

### What changed

- Preserved the familiar name Near Wrist Ride.
- Specified left-to-left control and the under-arm, over-wrist route.
- Replaced the vague inward arm pull with forward movement of the body over the wrist.
- Separated this ride from the B22 cross-wrist/2-on-1 continuation and removed the unspecified half-nelson finish.
- Added an observable ride endpoint, deliberate release, and one defined receiver reaction.

### Evidence limits

Inspected College Park's cached PDF-page-marked text and actual book transcriptions, not merely search snippets. The book transcriptions contain OCR noise; the near-wrist prose was readable, but the photographs were not inspected. Weber's public written explanation supplies principles only. His embedded Vimeo player did not provide accessible instruction during this audit; no video viewing is claimed. The exact drill schedule, release rehearsal, and restricted beginner endpoint are editorial coaching choices. A particular thumb orientation beyond an over-wrist grip is not prescribed because the inspected near-wrist text does not establish one.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; Sport Ngin-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached extracted PDF text, PDF pages 26-28: TOP principles; NEAR WRIST; CROSS WRIST, outside/inside 2-on-1; BAR ARM and TURK context.

**Supports:** Same-side right-hand-to-right-wrist relationship; Shoulder pressure and capture following spiral or ankle breakdown; Cross-wrist and 2-on-1 distinctions; Feet-driven top pressure, head behind shoulders, and tight-waist support

**Limits:** Text handbook rather than a filmed demonstration; historical teaching and scoring language are not current rule authority. Its arm-bar and turk continuations are not taught on this card.

**S2: [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics, 1994; accessible transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Title/authorship text and printed page 156, NEAR-WRIST CONTROL and The Near Wrist; neighboring half-nelson continuation text on pages 156-157.

**Supports:** One-on-one definition: controlling arm under the opponent's arm and over the wrist; Belly-down entry with arms forward; Use the legs to move the opponent's body over the wrist; A far-side half is a separate continuation requiring an angle change

**Limits:** Coach-authored primary instruction accessed through a third-party OCR transcription. Photos were not inspected. Historical scoring is excluded.

**S3: [Coaching Wrestling Successfully, Figure 7.20: Near wrist ride drill](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730)** - Dan Gable / Human Kinetics; accessible transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Printed page 103, Figure 7.20 caption and near-wrist ride drill text; preceding jam-drill caption for context.

**Supports:** Capture while the bottom wrestler rebuilds or following a jam; Forward drive traps the wrist; circling maintains it

**Limits:** Caption and text inspected, not the underlying photographs. Does not independently define finger or thumb placement; no historical competition-rule claims adopted.

**S4: [Near Wrist Ride](https://www.attackstylewrestling.com/near-wrist-ride/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Public coach-authored article text, especially the paragraph naming forward pressure, wrist control, shoulder control, and reaction-based continuation.

**Supports:** Purpose of the near-wrist ride as control that creates scoring opportunities; Forward pressure and responding to the receiver's reactions

**Limits:** Public prose is brief. Embedded Vimeo instruction was unavailable in the attempted access, so neither its exact grip nor demonstration frames are claimed as verified.

<a id="b26"></a>

## B26 - Half Nelson

**Tier:** Beginner | **Previous name:** Half Nelson Turn

### Technical review

The original correctly used a prone start, underarm entry, and perpendicular chest-to-chest finish. It did not name a side or roll direction, and its far-wrist control lacked an acquisition or purpose. A wrist-and-half is real, but College Park's near-side half with far-elbow post provides a clear alternative. The revision specifies that variant and replaces a generic neck warning with the recognizable shoulder danger of a trapped elbow being driven behind the defender's head.

### Selected variant

Left-side near half on a belly-down opponent, using the free hand to post the far elbow, then a basic chest-to-chest half finish. Left and right belong to each wrestler's own body. This is College Park's near-half/far-elbow branch, mirrored into an explicit left-side example. It excludes that handbook's far-side half from near-wrist control, knee-assisted high half, and reverse-half follow-up. [S1]

### Mechanics and evidence

- With both initially facing the same way, top's left arm travels beneath bottom's left upper arm to the back of the head. Top's right hand passes beneath the chest to the far right elbow; its job is to remove the far arm's supporting post, not to drag that arm behind the back. College Park specifies the near half and far-elbow post; the anatomical hand labels make that instruction explicit. [S1]
- The attacking elbow rises underneath the near upper arm, while the palm keeps the head from rising. Cejudo's publisher describes the same-side hand, elbow elevation, and feet moving toward the head. Horaski-Garcia specifies moving the legs out on the half side until perpendicular. Together these describe an arc out on the left toward the head, not a lap around to the opposite side. [S2, S3]
- Pressure comes from the feet through the chest into the near shoulder and upper torso. The receiver rolls away from the attacking side, onto their right side and then back. Weber's basic half explicitly drives the opponent to the opposite side. This is shoulder-girdle and torso rotation: the arm supplies leverage, but continuing to rotate the humerus while the torso stays stuck is not a successful turn. [S4, S5]
- Once the receiver is turning, the attacking arm can slide deeper to support the back of the head. Weber describes an elbow-deep half after reaching the side. Cejudo and College Park support chest-to-chest contact, low hips, and a wide base. Do not confuse the attacker's elbow scooping behind the head during the finish with forcing the defender's trapped elbow behind their own head. [S1, S3, S4, S5]

### Teaching progression

- Demonstrate the finish first, then insertion and side-on pressure. Keep the far hand and defender's shoulder visible to the coach.
- The receiver leaves room for insertion and lets their torso follow the cooperative turn. They use a spoken stop for pressure they cannot follow, without fighting a trapped shoulder or rolling through suddenly.
- After three slow repetitions each, add early near-elbow closure. Top resets a blocked entry. This follows S2's cooperative-to-defensive progression; the repetition count and narrow reaction are coaching design. B27 can later expand the defense. [S2]

### Common mistakes and corrections

- Parallel hips and planted feet make the head do too much work. Reset to an open arm, then step out on the half side before driving across the shoulder line. [S2, S3]
- Reaching too far across at the finish leaves the attacker's belly over the receiver's chest and invites a roll-through. Move the chest across, lower the hips, and spread the feet. [S1, S3]
- An arm rising while the receiver's torso remains pinned is a stop signal. Release and restore room for the torso to roll; increasing leverage can take the shoulder to its limit. [S5]

### Readiness and rules

Beginner is readiness, not age permission. Require matched partners, immediate release, and observation of shoulder motion. NFHS identifies the elbow-behind-head danger and normal joint-range limit. [S5] The current 2027 USAW Kids Folkstyle event uses NFHS with USAW modifications; international freestyle/Greco restrictions cannot simply be imported. [S6] The 2026-27 NFHS change announcement is not the complete rulebook. Event-specific youth restrictions and the referee's dangerous-position judgment govern. No age cutoff, scoring count, or blanket legality claim is supplied. [S7]

### What changed

- Shortened the familiar name to Half Nelson.
- Specified left-side insertion, a far-elbow post, the same-side foot arc, and a roll onto the receiver's right side.
- Added the deeper head scoop and low-hip finish without introducing a reverse half.
- Replaced vague safety language with receiver behavior and a visible shoulder-range stop condition.
- Replaced long timed rounds with cooperative turns and one clearly defined early defensive reaction.

### Evidence limits

Inspected page-marked manual text and accessible publisher/coach text; no video claim. S1 supplies the specific far-elbow branch. Other sources corroborate compatible basic-half components, not an identical setup. S4 supplies only roll direction and the deeper finish, excluding its power/spike/sweep variants. S5 is an official sheet hosted in 2024; S6-S7 establish current context without reproducing every hold rule. The receiver instructions and short drill are editorial coaching design.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook, Basic Top: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF text, pages 12-13; especially page 13, Turns, Half Nelson, near-side half after flattening with far-elbow post.

**Supports:** Near-side half with far-elbow post; Chest-to-chest perpendicular finish with feet wide and hips down

**Limits:** Compressed coaching notes; several alternative half setups appear together. Only the near-side/far-elbow branch is selected.

**S2: [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia, PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF text, pages 101-104, instructional tasks for the half and its early defense.

**Supports:** Underarm entry and hand on back of head; Move legs out on the half side until perpendicular; Cooperative instruction before defensive situations

**Limits:** Historical PE curriculum. Does not specify the far-hand job. Its straight-arm lever cue and historical scoring are not adopted.

**S3: [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo)** - Fanatic Wrestling, publisher of Angel Cejudo instruction; accessed 2026-09-26.

**Inspected:** Full accessible article text, especially Half Nelson section, lines 535-539 in browser extraction.

**Supports:** Same-side arm beneath the near arm; Elevate elbow and walk feet toward head; Chest-to-chest finish with head up and hips lowered

**Limits:** Publisher's written explanation was inspected; embedded video was not viewed. Does not establish the far-elbow post.

**S4: [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Coach-authored article text; steps 1-3 and remaining variant headings to distinguish the basic half from later combinations.

**Supports:** Drive opponent to side opposite attacker; Deepen half after opponent reaches side; Chest-to-chest pin position and wide feet

**Limits:** No video claim. Ear grip, forehead-post finish, and later power/sweep/spike variations are not prescribed in this introductory card.

**S5: [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf)** - National Federation of State High School Associations, hosted by Iowa High School Athletic Association; accessed 2026-09-26.

**Inspected:** PDF page 1 text, example 2 for half nelson and Rule 5-20 normal-range definition; page 2 text for general dangerous-position context.

**Supports:** A legal half can become potentially dangerous; Shoulder injury concern when the trapped elbow is forced behind the head; Stop at the limit of normal joint movement

**Limits:** Official instructional sheet hosted in 2024; not a complete 2026-27 rulebook.

**S6: [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Rules section specifying NFHS scoring rules with USAW modifications and the 2026-2027 girls provision.

**Supports:** Current folkstyle event framework uses NFHS with event modifications; International rules must not be presumed to govern a folkstyle event

**Limits:** One event's rules; not universal youth authorization and not a half-nelson mechanics source.

**S7: [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf)** - NFHS, April 17, 2026; hosted by Massachusetts Interscholastic Athletic Association; accessed 2026-09-26.

**Inspected:** PDF pages 1-2, 2026-27 approved change announcement and current rulebook publication information.

**Supports:** Identifies the 2026-27 NFHS rules cycle and official changes announced for it

**Limits:** Change summary does not reproduce all hold rules or independently establish unchanged half-nelson wording.

<a id="b27"></a>

## B27 - Early Half Nelson Defense

**Tier:** Beginner | **Previous name:** Early Half Nelson Defense

### Technical review

The original correctly treated this as prevention, closed the threatened elbow, used an away-facing head position, cleared the grip, and ended with base recovery. Its main teaching problems were the ambiguous 'free hand,' an unspecified start, and moving the hips 'away from the turning angle.' Those words do not tell a novice which limb moves and can contradict keeping the attacked hip down. The selected lesson makes a left-side example explicit. It also removes the circular reliance on completing B26: an introductory demonstration and B16 are sufficient before paired offense and defense practice.

### Selected variant

Early belly-down defense to a loose basic half: close the attacked armpit, preserve a low shoulder and hip, look away while the head is free, use the attacked-side hand for the peel, then recover base. This is the same-side peel taught in the Horaski/Garcia lesson, not a universal instruction for every half-nelson position. It excludes a power half, a trapped far wrist, and escape from an established turn. [S1]

### Mechanics and evidence

- The University of Victoria instructional page distinguishes prone defense from defense on a base. Its prone sequence begins by clamping the attacking arm and widening support, followed by looking upward and away and removing the hand. The card translates that clamp into elbow-to-ribs and a low attacked shoulder; it does not add a forceful shoulder shrug. [S3]
- Johnson's compact folkstyle instruction confirms the head-up, away-facing, hand-peeling combination. 'Head up' here means keeping the face clear and preserving posture, not maximal backward bending. The free-neck condition and stopping threshold are deliberate beginner teaching limits. [S2]
- Horaski/Garcia explicitly identify the half-side hip and the same-side peeling arm. Therefore a half under the defender's left armpit is answered with the defender's left hand, while looking right. Their page does not specify a knuckle grip or a wrist-lock action; the card's whole-hand language simply excludes pulling separate fingers. [S1]
- The half must be cleared before the defender abandons the defensive arm position. Base recovery uses a knee beneath the hip followed by the second knee, with elbows/forearms supporting the body. This links the defense to the earlier belly-to-base skill rather than promising an immediate escape or reversal. [S1, S2]

### Teaching progression

- Demonstrate from both sides with top stationary. Have bottom name the attacked armpit, the peeling hand, and the direction to look before contact. Top supplies a loose insertion and lets the hand be removed, rather than driving through a successful clamp.
- First rehearse the clamp and head position, then a short peel, then the complete recovery. The defender should keep the shoulder from being lifted and reach a balanced base without a head post. Use the opposite side only after the first side is understood.
- The defined reaction is top choosing one side and making one light insertion. Success means clearing and rebuilding; top is not trying to complete a pin in this drill. Three repetitions and this limited reaction are original coaching design, not a researched dose.

### Common mistakes and corrections

- A large reaching motion gives away the arm position. Shorten the reach and rehearse the clamp separately before adding hand clearance.
- Looking toward the attacking side defeats the chosen head-position cue. Pause before insertion and have the defender indicate the opposite direction.
- Continuing to peel after the head is fixed changes an early defense into a struggle against an established hold. End that repetition and restart earlier.

### Readiness and rules

Beginner is a readiness tier. Both partners must respond immediately to stop/release and distinguish loose contact from an established turn. The lesson does not teach fighting through neck or shoulder pain, bridging on the head, rolling through, or a power-half counter. These are practice boundaries, not claims that every established half is illegal. No scoring values or current competition-rule interpretation are derived from the older manuals.

### What changed

- Preserved the familiar name and meaningful early-defense distinction.
- Specified the attacked side and same-side peeling hand.
- Replaced vague hip movement with a low attacked hip and explicit base recovery.
- Set an earlier drill reset and removed circular prerequisites.

### Evidence limits

Inspected actual instructional text, not merely technique titles. S1 and S2 are independent authored lessons; S3 supplies additional clamp-and-support instruction. No video was watched, and inaccessible photographs were not used to infer grips. The KOLAT.COM defense page required login; a user-created plan on that site was not treated as Cary Kolat's personal instruction. Whole-hand contact, low-shoulder wording, the exact staged drill, and stop criteria are conservative teaching clarifications rather than verbatim source prescriptions.

### Sources inspected

**S1: [Wrestling Unit: Lesson 25, Base Recovery; Lesson 26, Half-Nelson Pinning Combination and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; hosted by PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text and public PDF text: PDF page 99 for belly-to-base recovery, pages 103-104 for half defense and the early situational start. Public extraction uses zero-based P98 and P102-P103 for these pages.

**Supports:** Half-side hip down, look away, same-side hand peel; Begin defense before top reaches a perpendicular turning position; Knee-by-knee base recovery after belly-down position

**Limits:** Older physical-education lesson plan. Does not prescribe an exact palm or wrist grip. Historical rules and broader live-drill prescriptions are not adopted.

**S2: [Wrestling 101, Chapter 6: Pinning; Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf)** - Coach Lance Johnson; hosted by West Hills Wrestling; accessed 2026-09-26.

**Inspected:** Cached full text and public four-page PDF text; PDF page 2 half-nelson defense row and page 3 bottom-position discussion.

**Supports:** Head up, look away, peel as basic half defense; Hand fighting and rebuilding a useful bottom position

**Limits:** Brief 2019 coaching summary, not a complete grip demonstration. Roll-through option is mentioned but not taught or adopted. Historical scoring is not used.

**S3: [Half Nelson Technique: Defense to the Half Nelson](https://web.uvic.ca/~thopper/wrestling/WrestUnit/Gametasks2/tactical_awareness.htm)** - University of Victoria-hosted wrestling teaching unit on Tim Hopper's teaching site; accessed 2026-09-26.

**Inspected:** Full page text, especially 'From the Prone Position,' steps 1-3. Linked photographs were inaccessible and were not visually inspected.

**Supports:** Clamp the attacking arm from prone position; Maintain a broad base of support; Look up and away and remove the attacking hand

**Limits:** University-hosted instructional resource with no individual author established on the inspected page. Text does not identify the peeling hand; that detail is supported by S1.

<a id="b28"></a>

## B28 - Half Nelson Pin Finish

**Tier:** Beginner | **Previous name:** Chest-To-Chest Pin Finish

### Technical review

The draft had useful finishing principles: perpendicular chest contact, a broad base, low hips and following small shoulder movements. Its central weakness was that 'control a far arm' and 'maintain the taught head-and-arm connection' did not specify an actual hold. A beginner could press on the chest without retaining either shoulder, or invent a clasp around the neck. B26 supplies a half nelson entry, so this revision identifies the finish as a half nelson with opposite-wrist control. It preserves the original learning objective while making the arm connection and release inspectable.

### Selected variant

Half nelson pin finish with the opposite wrist retained, beginning after the B26 turn. The card uses the top wrestler's left half arm under the receiver's left upper arm, plus right-hand control of the receiver's right wrist; the whole arrangement mirrors. It does not introduce a throw, reverse-half transition, power half or headlock clasp.

### Mechanics and evidence

- A half enters beneath the receiver's upper arm and reaches behind the head. Horaski and Garcia explicitly teach the under-arm path, perpendicular position and chest-to-chest finish. The anatomical labels in the card resolve which limb remains included after the receiver rolls, when 'near' and 'far' can otherwise become confusing. [S2]
- College Park's half-nelson instruction retains the opposite wrist, draws it in, and finishes with the chest across the receiver, feet spread and hips down. Retaining that wrist removes a posting arm; the half retains the other upper arm and shoulder. The card uses this single combination, with hands separate throughout. [S1]
- The Human Kinetics photographs and captions show the top wrestler lowering the hips as the receiver reaches the back. Their stated purpose is to prevent a roll-through; the later illustrations also show a broad foot base and a perpendicular chest position. These general finishing principles corroborate the chosen half finish, although the sheet subsequently changes to a reverse half. [S3]
- The finish aims to manage the shoulders through the torso and retained arms. It is not an instruction to press the receiver's throat or force the head farther forward. Small foot adjustments preserve the angle during this introductory drill; a lost arm connection ends the repetition rather than triggering a stronger squeeze. This response limit is coaching design.
- A separate hold on an arm does not make a head-only clasp legal. The NFHS illustrated interpretation distinguishes an arm actually enclosed at the elbow or shoulder from an arm merely entwined elsewhere. Because this selected finish uses a half and separate wrist grip, the card explicitly rules out adding any head clasp. [S4]

### Teaching progression

- First demonstrate the finish from a cooperative side/back position. Identify both receiver arms, show the half's under-arm route, and have the receiver confirm that they can breathe and signal stop before adding weight.
- Use B26 to supply the turn, but pause at arrival on the back. The coach checks the retained upper arm, opposite wrist and chest position before the top wrestler settles. The finish is a distinct balance lesson, not another turning contest.
- Begin with cooperative placements and a complete release after each one. Then allow one gentle attempt to turn toward the belly. Do not prescribe a forceful neck bridge or a live roll-through as the beginner receiving task.
- Advance only when the wrestler can follow a small shoulder shift without climbing onto the head or losing the arm, and can release immediately. The three placements and five-second holds are proposed practice doses, not doses established by the cited sources.

### Common mistakes and corrections

- High hips and closely placed feet make the top wrestler easier to roll. Widen the feet and lower the hips while maintaining chest contact; Human Kinetics specifically connects hip lowering with avoiding the roll-through. [S3]
- An arm slipping out of the half removes the intended shoulder control. Reset the under-arm connection cooperatively; never repair it by locking the hands around the remaining head. [S2, S4]
- Sliding toward the face or yanking the wrist changes shoulder control into neck or joint pressure. Unload the hold and replace the chest over the upper torso; keep the wrist close without twisting it. This is a conservative instructional correction.

### Readiness and rules

Beginner identifies readiness, not permission based on age. The receiver must understand the stop signal and tolerate light, gradual chest pressure. NFHS's 2024-25 illustrated interpretation identifies a head-only clasp as illegal and all headlocks as potentially dangerous. The currently published 2027 USA Wrestling Kids Folkstyle event specifies modified NFHS rules, but is not a complete current NFHS rulebook. This card makes no claim about a universal pin count or universal youth permissions. The coach must apply the event's current rules. [S4, S5]

### What changed

- Replaced a generic chest-contact name with Half Nelson Pin Finish.
- Specified both arm controls and excluded a head-only clasp.
- Selected a foot-based finish instead of leaving knees or feet as interchangeable options.
- Defined gentle receiver action, loss-of-position reset and a complete release sequence.
- Editorial chain check mirrors the teaching example to a left-arm half, matching B26 directly; the same opposite-wrist finish is retained.

### Evidence limits

S1 and S2 are accessible coaching documents, not current rule authorities. S3 was inspected as one full illustrated page; its reverse-half transition was deliberately not added to this card, and its head-lifting language was not converted into a neck-cranking cue. S4's page text was inspected, but its screenshot fetch failed; no claim is made to have inspected its photographs. A full 2026-27 NFHS rulebook was not accessed. The restrained receiving task, stop conditions, release order and drill dose are original coaching design rather than verbatim source prescriptions.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook, Turns: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF page 13, section 2(a), Half Nelson; independently read the wrist-retention and final pin-position instructions.

**Supports:** Half nelson with opposite wrist retained and drawn in.; Perpendicular chest-to-chest finish, spread feet and lowered hips.

**Limits:** Team handbook with compact shorthand; no specific beginner drill dose or release sequence. Its reverse-half alternative is not included in the card.

**S2: [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF pages 101-104, half-nelson objectives, demonstration instructions and partner progressions.

**Supports:** Under-arm route to the back of the head.; Move to a perpendicular angle and finish chest-to-chest.; Demonstration and cooperative rehearsal precede greater resistance.

**Limits:** Physical-education unit, not current rules. Strong straight-arm and head-lifting wording is not reproduced as a force cue.

**S3: [Top Move: Half-Nelson and Reverse Half-Nelson](https://s3.amazonaws.com/my.llfiles.com/00224751/halfnelson.pdf)** - Human Kinetics, Coaching Youth Wrestling Course, 2003; accessed 2026-09-26.

**Inspected:** Full single-page PDF text and all nine photograph panels, rendered in memory and visually inspected; especially the transition onto the back and final position.

**Supports:** Lowering the hips as the opponent reaches the back reduces roll-through risk.; Chest across chest, perpendicular torso, head up and spread-foot finishing base.; The sheet distinguishes the turning half from its subsequent reverse-half finish.

**Limits:** The exact reverse-half transition is not the selected variant. Illustrations corroborate body placement; they do not independently verify the chosen opposite-wrist grip.

**S4: [Illegal Headlock / Legal Headlock: Look Close, Rule 7-1-5d](https://iwcoa.net/wp-content/uploads/2024/12/NFHS-Head-Lock-2024-2025.pdf)** - NFHS rule interpretation reproduced by Illinois Wrestling Coaches and Officials Association; accessed 2026-09-26.

**Inspected:** Full extracted text of PDF pages 1-3, including the rule citation and legal/illegal frame captions; screenshot fetch failed.

**Supports:** A headlock clasp must actually include an arm at the elbow or above.; An entwined arm elsewhere is not equivalent to an arm within the headlock.; Headlocks remain potentially dangerous.

**Limits:** 2024-25 interpretation, not a fully inspected 2026-27 rulebook; used to explain the excluded head-only clasp rather than certify every application.

**S5: [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Current event-page rules text, specifically the 2026-2027 girls provision and NFHS rules with USA Wrestling modifications.

**Supports:** Current USA Wrestling Kids Folkstyle national event uses modified NFHS rules, with boys and girls under the same stated framework.

**Limits:** Event-specific authority; it does not reproduce all NFHS hold restrictions or establish a universal local-club rule set.

<a id="b29"></a>

## B29 - Near-Side Cradle

**Tier:** Beginner | **Previous name:** Near-Side Cradle

### Technical review

The original correctly chose the near leg, paired it with the head, and warned against forcing head and knee together. Its arm wording was imprecise: an arm around the upper back is not enough to describe the cradle. It did not name a hand lock or specify which side top occupied. Most importantly, 'step around hips' did not establish a documented near-side turning direction, and 'supporting head and shoulders' suggested spare hands despite both arms holding the cradle. The repaired card teaches one straight-over finish. It retains the familiar name and replaces vague reassurance with a receiving role, body contacts, a specific direction, and an actual finishing base.

### Selected variant

Near-side cradle from the opponent's left side, using their left knee and a palm-to-palm Gable grip, followed by the straight-over chest-to-chest finish. College Park's inside-cradle first finish supplies the directional sequence [S2]; Human Kinetics' near-side cradle corroborates the leg drive, chest action, and forehead-post finish [S1]. Right/left labels are an explicit mirrored teaching example of these front-arm/back-arm mechanics, not quoted labels from either manual. No crossface, far-knee capture, backward pull, roll-through, or leg-hook finish is added.

### Mechanics and evidence

- With top on bottom's left and facing the ribs, top's left arm is the head-side arm and the right arm is the leg-side arm. The former goes over the head; the latter surrounds the near left knee. Weber specifies the front elbow behind the neck and rear elbow behind the knee, and recommends the Gable lock [S3]. This is not a half-nelson arm threaded under the armpit.
- The clasp belongs near the head rather than down at the hip [S1]. Hall defines the Gable connection as palms pressed together, with thumbs against the index fingers [S4]. The card therefore explains the grip rather than merely naming it. It does not use interlaced fingers or a separate head-only lock.
- College Park places head/chest at the opponent's side and directs the opponent onto the far hip, then straight onto the back with chest-to-chest contact and a wide stance [S2]. For the chosen left-side example that means driving toward bottom's right hip. Human Kinetics describes using the legs and chest to lift the near shoulder during the turn [S1].
- The final hold retains the head-and-leg connection. Top lowers the hips, spreads the feet, and posts the forehead; these details distinguish this finish from a far-side cradle held from behind [S1, S2]. The card deliberately starts with an available compact position. It does not teach forcing additional neck flexion to manufacture a lock.

### Teaching progression

- First show left-side orientation, the two separate arm loops, and the palm connection without turning. Coach checks that the neck sits in the elbow bend without throat pressure and that the captured knee can travel with the hip.
- Rehearse the finishing base separately under direct coaching, with a neutral, stable neck and no sudden weight transfer onto the forehead. The Beginner label does not waive this readiness requirement. If that base is unavailable, postpone this finish rather than inventing a different one mid-card.
- Bottom cooperates by turning the torso and pelvis onto the far hip and back, keeping the captured leg aligned and avoiding a rigid arm post. Top pauses before increasing pressure. Open the clasp before the receiver extends the leg or sits up.
- Only after cooperative repetitions does bottom lengthen the near leg before the hands connect. That makes the decision explicit: take an available cradle or reset. Post-lock escape wrestling, bridging contests, and alternative finishes are outside this introductory drill. Repetition counts and this limited defensive progression are coaching design, not research-tested dosing.

### Common mistakes and corrections

- A reach from too far away produces arm pulling and a loose lock. Move the torso close first; if the available range still does not permit the clasp, abandon the attempt.
- Driving down on the head leaves the shoulder unturned. Change the action to leg drive and chest contact under the near shoulder; stop if the receiver's neck becomes the load-bearing point.
- Sitting backward or circling behind mixes in another cradle finish. Keep this rehearsal directed across the far hip, then follow the chest.
- Letting the knee slip while preserving only a head grip changes the hold. Release immediately and rebuild a normal top position.

### Readiness and rules

This is a supervised folkstyle pinning lesson, not a stretching exercise. The receiver must breathe normally and move without neck or knee pain; release immediately on a stop signal. Keep the near leg included and avoid a head-only clasp, throat compression, neck cranking, or an arm forced into a Nelson configuration. The historical technique sources do not certify current competition legality. Current NFHS pages were sought, but direct page access was blocked, and no complete current rulebook was inspected. Therefore this review makes no scoring claim or universal age/event permission claim; the supervising coach must apply the event's current rules and potentially-dangerous-hold judgment.

### What changed

- Kept the familiar name Near-Side Cradle.
- Specified left-side top position, left head-side arm, right leg-side arm, and bottom's left knee.
- Defined the Gable grip and located the clasp near the head.
- Replaced an unspecified circle with the documented drive to the far hip and chest-to-chest forehead-post finish.
- Added receiver behavior, staged release, and a decision to reset when the knee extends.
- Editorial photo check confirmed the documented forehead-post finish and made aligned, pain-free head support an explicit prerequisite.

### Evidence limits

Actual instruction inspected: Human Kinetics PDF page text, College Park cached PDF-page-marked text, Weber's public instructional article, and Hall's authored grip explanation. The initial agent could not render the photos; root editorial review subsequently rendered and inspected all nine Human Kinetics photographs, including the final forehead post. Other source images were not inspected. No embedded videos were watched. The USA Wrestling cached guide did not supply an exact near-side cradle sequence, so its generic citation was removed. Source descriptions of pulling head to knee or pounding with an elbow were not carried into this beginner lesson. The available-position entry, explicit receiver instructions, release rule, and drill are conservative teaching design. The finish itself remains the documented straight-over variant.

### Sources inspected

**S1: [Top Move: Cradle (Near-Side), from Coaching Youth Wrestling Course](https://s3.amazonaws.com/my.llfiles.com/00224751/cradlens.pdf)** - Human Kinetics Publishers / American Sport Education Program, 2003; publicly hosted course handout; accessed 2026-09-26.

**Inspected:** Complete one-page PDF text. Editorial review additionally rendered and inspected all nine demonstration photographs, including the last two forehead-post/hip-adjustment frames.

**Supports:** Arm over the head plus opposite arm behind the near knee; Lock nearer the head; Leg drive and chest action lifting the near shoulder; Center-of-forehead post, hip adjustment, and shoulder pressure at the finish

**Limits:** Historical teaching handout, not current rules. Its head-driven entry wording is not a recommendation to load or force the neck. No exact right/left labels or named hand lock.

**S2: [College Park Wrestling Technique Handbook - Inside Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached extracted PDF pages 28-29: cradle introduction, distinction from crossface cradle, and Inside Cradle / Bow and Arrow first finish. Page 13's inside-cradle grip note was also inspected.

**Supports:** Near-side head-and-near-leg capture; Head/chest at opponent's side and drive to the far hip; First finish goes straight over, chest to chest, forehead posted, feet wide; Separate far-side crossface and alternative inside-cradle finishes

**Limits:** School coaching notes are terse and include forceful language and advanced alternatives. Only the first straight-over finish is selected; no historical rule or scoring statement is adopted.

**S3: [6 Step Near Side Cradle Series](https://www.attackstylewrestling.com/near-side-cradle-series/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Public article text, particularly Step 1's elbow locations and Gable lock, and the distinction between Steps 2-6's finishes. Embedded video was not watched.

**Supports:** Front elbow behind neck and rear elbow behind knee; Gable lock as a near-side cradle grip; Far-hip direction and existence of distinct finishes

**Limits:** Its barbell, crunch, high-leg, backbridge, and elevated-leg finishes are not substituted for the selected straight-over finish. Elbow-pounding language is not included in the card.

**S4: [Dubuque RTC 'Wrestling's Basic Truths' Part IV: Lifting](https://fivepointmove.com/greco-wrestling-training/hall-dubuque-rtc-volume-iv-lifting/)** - Dennis Hall's authored instruction, published by Five Point Move; accessed 2026-09-26.

**Inspected:** Article attribution explaining Hall's authorship and the opening hand-lock paragraphs under Lifting from the Stand Up Position.

**Supports:** Gable grip uses palms together and thumbs alongside the index fingers

**Limits:** Used only to define the shared hand grip. The article's lifts, body locks, and mat returns do not verify or enter this cradle card.

<a id="b30"></a>

## B30 - Early Cradle Defense

**Tier:** Beginner | **Previous name:** Early Cradle Defense

### Technical review

The original correctly prioritized early recognition, hand fighting, head-knee separation and a stop when tightly trapped. Its main mechanical omission was the attacked hip: lengthening the leg while leaving the hips high can expose the other leg. It also left 'threatened leg,' 'approaching wrist' and 'hips away' insufficiently defined. The revision uses an attacker on the defender's left, identifies the defender's left leg and hip, and controls the hand belonging to the head-wrapping arm. This is a prevention card with a successful return to base, not an escape from a completed pinning hold. Keeping the existing familiar name is appropriate because 'early' marks a meaningful technical boundary.

### Selected variant

Before-lock defense to a left-side near-side cradle: near leg back with near hip lowered, head-arm hand control, head up, then base recovery. Applegate supplies the actual early-counter sequence; the other inspected coaching sources corroborate separation and hand fighting. [S1, S2, S3, S4]

### Mechanics and evidence

- Applegate pairs the mule kick with lowering the inside hip and requires hand control and head-up posture before returning to base. His attack section explains that a kick with the hip still high allows the attacker to reach the far leg. [S1]
- Winning Wrestling Moves identifies the left leg as the near leg when the attacker is on that side, and shows the head and knee being enclosed by different arms. The side labels on the card are a concrete teaching example of that relationship. [S3]
- Johnson's near-cradle prevention emphasizes hand fighting and keeping head and knee apart. The card applies those principles by protecting the space until both are free rather than immediately folding the knee underneath. [S2]
- Weber explicitly lists catching the hand and raising the head for near-side cradle defense. It is a curriculum outline, so it corroborates those actions but does not demonstrate an exact grip. The card's two-handed whole-hand/wrist catch is a coaching implementation of hand control, not a claim that Weber prescribes those precise fingers or hand assignments. [S4]

### Teaching progression

- Demonstrate on one side and name the defender's left leg and hip aloud. Have the receiver point to the approaching head-arm hand before any motion. Explain that the attacker must be close enough to present a real cradle threat, while the hands remain unlinked.
- Rehearse with the top wrestler offering the two reaches and allowing the defender to complete the sequence. Watch that the defender keeps a supporting knee, lowers the attacked hip without falling onto the back, and lifts the head with the chest rather than wrenching the neck backward.
- Add the single defined reaction: the attacker lightly tries to bring the hands together. The defensive win is separated hands followed by a usable bottom base. A connected grip ends the repetition immediately. After consistent success, mirror sides. The repetitions, timing and stop-at-connection game are proposed coaching design.

### Common mistakes and corrections

- A high kick can become an uncontrolled strike and a loss of balance. Teach a backward leg extension close to the mat, with a deliberate hip lowering and space behind the foot.
- Grabbing individual fingers changes hand fighting into finger stress. Demonstrate a whole-hand/wrist hold and keep both athletes responsive to release.
- Returning to base while the head is still wrapped recreates the original vulnerability. Require clear head-and-knee separation first, then restore the missing support.

### Readiness and rules

Beginner is a readiness tier, not blanket age permission. Partners must identify the before-lock position, accept a stopped repetition and release immediately. The drill's stop at hand connection is a teaching boundary, not a claim that every cradle clasp is illegal or that a wrestler may unilaterally stop a match. This card supplies no scoring or event-specific legality claim. Forced neck flexion, throat pressure or a trapped knee ends practice immediately for coach assessment.

### What changed

- Added the attacked-hip lowering that the original omitted.
- Specified the near leg using a left-side example and identified the head-arm hand as the hand-control target.
- Made head clearance precede knee recovery.
- Replaced an open-ended cradle attempt with a single reach and a stop at hand connection.

### Evidence limits

Applegate's actual authored instruction was read in a third-party text reproduction, including the printed page markers; the site's AI questions were excluded. No video was watched. Johnson is a short coaching booklet, and Weber is only an outline. Winning Wrestling Moves was inspected as book text, not as reliable visual reproduction of its photos. None of their historical scoring or forceful locked-cradle responses is adopted. The support-knee detail, exact two-hand catch, conservative clearance wording and drill structure are explicit teaching choices, not quotations or experimentally established prescriptions.

### Sources inspected

**S1: [Basic Wrestling Fundamentals: Near Side Cradle Series; Countering a Nearside Cradle](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate)** - Warren Applegate; authored instructional text reproduced on Scribd; accessed 2026-09-26.

**Inspected:** Full page text, Near Side Cradle Series at printed pp. 58-59 and Countering a Nearside Cradle at printed p. 62; web text lines 494-499 and 522-527. Also read the glossary definition of two-on-one hand/wrist/arm control. Did not use the AI-generated question section.

**Supports:** Lower inside hip during the early mule-kick defense; Secure hand control and lift head before returning to base; A high-hip kick exposes the far leg; Distinction between early prevention and an already locked cradle

**Limits:** Third-party reproduction of primary coaching instruction; no footage or diagrams inspected. Later locked-cradle counters and other neck-loading material are outside this card.

**S2: [Wrestling 101, Chapter 6: Pinning; Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf)** - Coach Lance Johnson; hosted by West Hills Wrestling; accessed 2026-09-26.

**Inspected:** Cached page-marked extraction, PDF pp. 2-3, including Near Cradle row under Stop This PIN and bottom-position principles; official host PDF also opened through web tool.

**Supports:** Hand fighting and head-knee separation as cradle prevention; Stable bottom position and avoiding unnecessary exposure

**Limits:** Concise 2019 booklet, not detailed grip instruction. Its arch-back advice and obsolete scoring are not used.

**S3: [Winning Wrestling Moves, Near-Side Cradle and cradle counters, printed pp. 160-163](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics; book text hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Accessible book text at web lines 3331-3336 and 3367-3380, carrying printed page headings 160 and 163.

**Supports:** Which leg is captured in a near-side cradle; Head-down inside-leg recovery creates cradle exposure; Preventing cradle positions is the first defense; Hand attack and inside-hip position matter in countering cradles

**Limits:** Text reproduction contains OCR errors; photographs were not inspected. Its explosive responses from a completed lock or the back are not included.

**S4: [Escapes & Reversals Series, Cradle Defense](https://www.attackstylewrestling.com/wp-content/uploads/2014/04/escapes_and_reversals.pdf)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Actual four-page PDF text, PDF p. 4: near-side cradle catch-hand/head-up entry and separately listed break-lock and later defenses.

**Supports:** Catch the hand and lift the head as named early near-side defense actions; Treat later lock-breaking defenses as separate material

**Limits:** Curriculum outline only; it does not independently establish the exact catch, leg direction, support knee or clearance sequence.

<a id="a01"></a>

## A01 - Russian Tie to Single Leg

**Tier:** Advanced | **Previous name:** Russian Two On One To Single

### Technical review

The draft recognized useful wrist-and-upper-arm control and the need to create an angle before attacking. It did not identify an entry, grip orientation, attacking side, specific stepping response, or complete transition to a finish. Pulling an unspecified arm diagonally, releasing an unspecified wrist, and collecting the near leg could describe several different Russians. The instruction to use a taught low finish also failed to connect the setup to a particular finishing position. The replacement uses one documented foot-block single, with the opponent's right arm and right leg throughout. This changes the original setup action rather than pretending its unspecified circle-and-draw sequence was verified.

### Selected variant

Ciasulli's palms-up Russian obtained from a right-hand shoulder post, followed by the near-ankle block and weight shift in his own public high-single description. The right hand leaves the wrist to collect the right leg while the left forearm moves the ribs away. After collecting a stable head-inside single, use B08's run-the-pipe finish. B08 was read: its right-leg example matches this card directly, so no mirror is needed. B09's low backside far-knee finish is a different continuation and is not used.

### Mechanics and evidence

- Ciasulli specifies the partner's right hand on the attacker's left shoulder, the attacker's right hand initially palm down on the wrist, a roll to palm up, and the left hand supporting beneath the partner's right armpit. His text places the attacker slightly to their own left. The card keeps this exact side relationship. [S1]
- The linked high-single video's public description explicitly assigns the left foot to block behind the near leg, left forearm to move the rib cage away, and right hand to pick up the lightened leg. It instructs shifting weight to the far leg. The public lesson classifies this as offense despite the video's confusing 'Defend' title. [S2]
- Vallimont's publisher explains a Russian with close chest contact and inside head position, then a small block behind the near foot; if that foot stays, a single is available. This corroborates the block's purpose. Its subsequent far-ankle-pick footwork is excluded. [S3]
- The foot blocks retreat briefly; it does not kick or reap the ankle. Once the right arm has the leg, the left foot disengages and the left hand transfers from upper-arm control to the outside of the thigh. That explicit bridge establishes B08's two-arm single rather than trying to turn while still holding the arm and trapping the ankle. The bridge is this card's coaching adaptation.
- Horaski and Garcia teach the finish with head inside, clasp behind the knee, the leg between the attacker's legs, backstep/pivot, hip lowering and shoulder action over the thigh. College Park likewise retains the lock while stepping back and turning toward the captured-leg side. The explicit left-back/right-pivot mapping matches the audited B08. [S4, S5]

### Teaching progression

- Demonstrate the shoulder-post entry separately. Partners inspect both palms and identify the controlled right arm before adding movement. Rotate the forearm as a unit; do not bend the wrist joint to force clearance.
- Rehearse the block and weight shift without a takedown. The receiver allows weight to move to the left leg. The attacker must remain balanced on the right foot and be able to release the left-foot block immediately.
- Add the pickup and pause in B08's starting position before finishing. The receiver turns the whole captured leg with the pelvis and settles onto the right side without bracing through a locked elbow. Practice doses and these pause checks are proposed teaching design.
- The reaction phase allows early near-foot withdrawal only. If it removes the target, reset. The card does not ask athletes to chase the far ankle, force the blocked knee, or improvise a scramble.

### Common mistakes and corrections

- Trying to curl up the leg while its foot bears weight: rehearse the rib-cage pressure and weight transfer, then collect with hips lowered.
- Keeping the foot hooked during the pipe turn: pause after capture, unhook and recover a two-foot stance before the finish.
- Losing the arm away from the chest or allowing the defender's head to come inside: rebuild the tie and angle before using the foot.

### Readiness and rules

Advanced denotes readiness, not age permission. Partners need a secure head-inside pickup, reliable release, and B08 receiving. This is a brief ankle block and low leg collection, without a body lift, forced joint rotation or submission. Historical manuals are used for mechanics, not contemporary scoring or event-rule claims. The supervising coach must apply the actual event rules.

### What changed

- Shortened the familiar name to Russian Tie to Single Leg.
- Replaced the vague diagonal pull with a sourced foot-block and weight-shift entry.
- Specified both grips, each foot's role, pressure direction, target leg, release order and matching B08 finish.
- Added a defined early-withdrawal reaction and a reset instead of chasing an unavailable leg.

### Evidence limits

S1 is the coach's full accessible instructional page. S2 is his public description retrieved from the YouTube watch page, not captions or watched footage; the video itself requires membership and was not accessed. S3 is the instructional publisher's written explanation, not an inspected demonstration. S4-S5 are independently read cached PDF text with page markers. College Park page 18 uses a different overhook-style Russian; that entry was examined but not combined with Ciasulli's palms-up grip. Exact hand transfer into B08, foot disengagement, receiving and drill dose are explicit teaching adaptations. No source is represented as demonstrating this entire combined lesson.

### Sources inspected

**S1: [Two-On-One (Russian Tie), Lesson 6](https://www.sethciasulli.com/lessons/two-on-one-russian-tie)** - Seth Ciasulli / Spark Wrestling; accessed 2026-09-26.

**Inspected:** Full accessible page text, particularly Offense paragraphs describing entry from a right-hand post and both palms-up grips.

**Supports:** Exact shoulder-post entry, wrist hand and upper-arm hand; Slight outside angle and immediate use of the tie

**Limits:** Linked attacks are separate lessons; this page alone does not verify the single-leg transition.

**S2: [Defend a Two-On-One / Russian Tie - Hook Ankle, Single (linked as Offense, High Single)](https://www.youtube.com/watch?v=lvG5CY-l81s)** - Seth Ciasulli, coach's official YouTube channel; accessed 2026-09-26.

**Inspected:** The entire public video description in the watch-page response; linked from https://www.sethciasulli.com/lessons/two-on-one-russian-tie/offense/high-single. Video playback reports members-only and was not watched.

**Supports:** Right-arm Russian, left-foot block behind the near leg; Left forearm moves the ribs away while right hand collects the leg; Weight transfer onto the far leg

**Limits:** No transcript or frames inspected. Despite the title, the description and lesson placement concern offense from one's own Russian. Author permits a choice of high-single finish and recommends a trip; B08's pipe finish is this curriculum's substitution.

**S3: [Fake Single To Ankle Pick With Dan Vallimont](https://fanaticwrestling.com/blogs/news/fake-single-to-ankle-pick-with-dan-vallimont)** - Fanatic Wrestling, publisher of Dan Vallimont's instruction; accessed 2026-09-26.

**Inspected:** Full accessible instructional article, especially initial Russian position, near-foot block, and the statement that the single remains available if the foot does not retreat.

**Supports:** Arm close to chest and inside head position; Small near-foot block as a single-leg threat

**Limits:** Publisher explanation of coaching footage; video not watched. Far-ankle-pick continuation and its scoring statements are not adopted.

**S4: [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF extracted text, PDF page 39, finish demonstration and refinement columns; original URL metadata checked.

**Supports:** Head-inside knee clasp and leg between the attacker's legs; Run-the-pipe backstep/pivot, hip lowering, shoulder pressure

**Limits:** Does not teach the selected Russian entry. Shooting/trail labels are converted to positional right/left labels consistent with B08; exact prescribed squat depth is not adopted.

**S5: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF extracted text, PDF page 18 Russian section and PDF page 24 Single/Run Pipe rows; original URL metadata checked.

**Supports:** Retain the single-leg lock while stepping back and pivoting toward the captured-leg side; Distinguishes the overhook-Russian near-single variant from the chosen palms-up entry

**Limits:** Its overhook entry was not imported. Finish text has no explicit right/left illustration; current rules are not established by this handbook.

<a id="a02"></a>

## A02 - Underhook Knee Pick

**Tier:** Advanced | **Previous name:** Underhook Cross Knee Pick

### Technical review

The original correctly paired a left underhook with an attack on the opponent's opposite knee and recognized the need to bring that leg into range. However, 'collect' and 'pick' could suggest lifting a leg; neither explains the decisive block. The shoulder's vague diagonal action and an unexplained circle also left the entry and direction open to interpretation. 'Follow behind' skipped the landing and the transition from a side finish. The rewrite uses the familiar Underhook Knee Pick name, specifies one complete right-sided example, and separates the takedown from the subsequent top-control exercise.

### Selected variant

Dan Henderson's demonstrated underhook knee block: a deep right underhook, left hand on the far right knee, and travel across the opponent's front. His published photo sequence supplies the concrete example. Its additional inside-leg brace is omitted from this introductory rehearsal; the hand block and moving torso remain the mechanism. [S1]

### Mechanics and evidence

- The College Park handbook independently describes a cross knee pick as lowering, blocking the far knee, and using the underhook shoulder against the ribs with the head across the chest. It prescribes a shallower mid-back grip; that grip is not substituted into Henderson's example. [S2]
- Winning Wrestling Moves calls for contact on the outside of the knee and continued driving; a single step may not finish. Its circle-to-step setup is another documented entry. The book's optional step on the opponent's foot is deliberately excluded. [S3]
- The Henderson photos establish inside head position, the change from elbow control to knee contact, and a finish beside the opponent. The written explanation identifies the right leg as the inside leg used while traveling across the front. The card retains this crossing step without trapping the foot. [S1]
- The left and right labels always belong to the named athlete. In the card, 'their right' is the side opposite their underhooked left arm; it is not the attacker's right. The hand stops the base from escaping while the body changes position. This is neither an ankle pick nor a demand to rotate the knee against a fixed foot. [S2, S3]

### Teaching progression

- Demonstrate the start and finish from both viewing sides before drilling. Have each athlete identify the underhooked arm and opposite target knee. Begin already close and angled, removing the need to improvise a hand-fighting setup.
- Rehearse lowering and placing the blocking hand without completing the takedown. The coach checks that the attacker can reach without hanging on the partner's shoulder or bending the neck down.
- Add a cooperative descent with room to land. The receiver lets the right hip lower and keeps the right arm from becoming a rigid landing post. The attacker supports their own weight and follows rather than jumping onto the partner.
- The belly-down response and separate waist/near-arm cover are an original folkstyle teaching completion. They make the landing useful without teaching a forced pin or requiring the receiver to remain on the back. Release the knee before following that turn.
- Progress to a defined choice: the receiver either leaves the knee available or withdraws it before contact. An escaped knee means reset, not a longer reach. The proposed three repetitions are coaching organization, not an evidence-based training dose.

### Common mistakes and corrections

- If the attacker stretches across a gap, move the starting position closer and rehearse the level change separately. Reach should follow body position, not replace it.
- If only the hand moves, freeze the action and point out that a knee touch has not displaced the torso. Resume with a small crossing step and cooperative body travel.
- If the receiver's foot remains stuck as the upper body turns, stop, release, and reset. Do not coach harder pressure as the solution to a blocked joint.

### Readiness and rules

Advanced describes readiness, not automatic age permission. Both partners need reliable yielding, side receiving, and an immediate stop response. This is a wrestling takedown adapted from an MMA coaching demonstration: the cage finish and guard discussion are not included. The card makes no current point-value or universal legality claim. Local coaches must apply their event's rules; no historical rules are inferred from the 1994 or 2007 sources.

### What changed

- Shortened the name to Underhook Knee Pick.
- Replaced the vague collection/lift implication with an outside far-knee block.
- Specified a sourced right-sided grip, head position, crossing step, and direction.
- Added receiver behavior, release of the knee, and a separate folkstyle top completion.
- Removed arbitrary timed rounds in favor of cooperative repetitions followed by one defined defensive reaction.

### Evidence limits

S1 was inspected as both page text and rendered photos. S2 was inspected in the cached page-marked extraction and the original PDF's text. S3 was inspected as a coach-authored book's online OCR, not its photographs; ambiguous image-only details are not used. These sources establish the takedown family and selected example. The receiving script, reaction drill, joint limits, and belly-down top completion are conservative coaching design. No inaccessible video was treated as watched.

### Sources inspected

**S1: [Wrestling with Dan Henderson: Simple Takedown](https://library.crossfit.com/free/pdf/60_07_Simple_Takedown.pdf)** - CrossFit Journal, Issue 60, August 2007; Becca Borawski reporting Dan Henderson's instruction at Team Quest; accessed 2026-09-26.

**Inspected:** Both PDF pages: complete text and both rendered pages, including the starting clinch and four action/finish photographs.

**Supports:** Selected right-underhook example, far-knee contact, crossing action, and side finish.

**Limits:** MMA application. Extra leg bracing and cage advice are excluded; the folkstyle cover is a teaching addition.

**S2: [College Park Wrestling Technique Handbook: Underhook - Cross Pick](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team coaching handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF page 17, Underhook introduction and Cross Pick execution; relevant cached extraction and original PDF text.

**Supports:** Far-knee block, lowered level, underhook shoulder at ribs, and head across chest.

**Limits:** Shallow underhook variant; no precise lead-foot instruction or receiving script.

**S3: [Winning Wrestling Moves: Underhook Offense and Knee Pick](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis, and Brooks Simpson; Human Kinetics, 1994; OCR hosted on StudyLib; accessed 2026-09-26.

**Inspected:** Book text pp. 57-60: Underhook Offense, Finishes to the Underhook, and Knee Pick; online OCR lines 3448-3594.

**Supports:** Outside knee contact, circle-to-step timing, and continued drive after the first step.

**Limits:** OCR only; photos not inspected. Optional foot trapping is not adopted. Historical publication is not a current rule authority.

<a id="a03"></a>

## A03 - Underhook Duck Under

**Tier:** Advanced | **Previous name:** Underhook Duck Under

### Technical review

The draft correctly identified passing beneath an arm, lowering through the legs, circling behind, and stopping before a lift. Its setup was incomplete: wrist or upper-arm control left the second contact undecided, no lead side was named, and the partner supplied no identifiable opening. The instruction to reduce the lift also risked hiding the role of the underhook elbow: the arm must clear while the attacker changes level. The replacement retains the familiar name but uses a documented over-under pummeling entry, with a deliberately limited standing endpoint. It is an entry to rear position, not a complete scoring takedown.

### Selected variant

Bill Archer's pummeling-to-duck-under drill is the main sequence [S1]. The example uses a left underhook and attacks beneath the partner's right arm as that arm attempts to swim inside. This is a coherent alternative to a push-back setup. A pushing reaction is supported for the inside/collar-tie duck in the Nestor Taffur publisher article [S4], but that does not establish the same trigger for Archer's underhook drill. No push-back requirement is imported into this card.

### Mechanics and evidence

- The over-under start fixes both contacts: the attacker's left arm is under the partner's right arm; the right arm is over the partner's left arm. Archer's preceding pummeling drill places the lead foot on the underhook side and the head on the overhook side [S1].
- For the selected drill, the existing underhook elevates the partner's arm while the partner begins pummeling. Hip lowering, the step behind, and close body contact create the passage; the finish is standing behind with the hands joined around the body [S1].
- College Park describes a shallow underhook with the hand near the middle of the back and matching forward foot in pummeling. That supports the card's explicit upper-back hand contact [S2]. Its separate offensive underhook section uses head position on the underhook side; this card keeps Archer's pummeling head position instead.
- Martell explains that the head needs space between the upper arm and torso, then rises beneath the shoulder after clearing. He explicitly allows the duck-side foot to move behind the opponent [S3]. The card spells out that route relative to the partner's right foot and follows with the other foot.
- Releasing the opposite overhook and moving both arms to waist height makes the rear endpoint explicit. Light palm-to-palm contact, no lift, and the release-and-face reset are coaching constraints added for this rehearsal, not claims of a separately documented finish.

### Teaching progression

- Demonstrate the terminal position first: two balanced wrestlers, attacker behind, waist contact, and a prompt release. The receiver remains standing and can take small balance steps; receiving a throw is not part of this lesson.
- Rehearse a slow pummel with an actual opening. The receiver swims the right forearm inward without clamping the attacker's neck or wrenching the underhook. Pause after the head clears so the coach can check body proximity and feet.
- Progress to the stated choice between pummeling and a closed elbow. A closed route means reset, not harder elevation. Successful repetitions require recognizing the opening and reaching the defined stop without pulling the receiver off balance. Timings and repetition counts are proposed lesson design.

### Common mistakes and corrections

- Bending only at the waist leaves the head low and the hips distant. Rehearse the knee-and-hip level change close to the partner before adding arm elevation.
- Passing the head but leaving the feet in front lets the partner turn back toward the attacker. Pause, locate the duck-side foot behind the partner, then follow with the trailing foot.
- Hanging on the opposite overhook stalls the move around the body. Practice releasing it after clearance and transferring to the waist without dragging the shoulder.

### Readiness and rules

Advanced identifies readiness, not age permission. The coach must first see painless pummeling, balance, and immediate release. Archer cues head extension to prevent arm recovery; this card teaches the functional head-up recovery without asking children to force the neck backward. Standing rear contact alone is not presented as an awarded takedown. No historical scoring values, Greco throw permissions, or current event legality rulings are asserted; a competitive finish needs its own instruction and the applicable event rules.

### What changed

- Replaced unspecified wrist-or-arm control with an explicit over-under start.
- Defined the partner's pummel as the opening and distinguished it from a push-back variant.
- Named the attacking side, head path, hip lowering, lead-foot route, and trailing-foot follow.
- Kept a standing rear-control stop and defined receiver behavior, grip release, and reset.

### Evidence limits

Inspected the relevant cached College Park text and accessible transcriptions of coach-authored books; no book photographs or demonstration videos were inspected. The books are primary coaching content hosted on third-party transcription pages, so image-dependent details were not treated as verified. Martell supplies general duck-under mechanics, not Archer's exact setup. The Fanatic article supports the alternative pushing reaction only. The card's handed example, light waist grip, bounded resistance, and stop criteria are explicit coaching design.

### Sources inspected

**S1: [The Wrestling Drill Book, Chapter 1: Pummeling; Pummeling to a Duck-Under](https://pdfcoffee.com/88f82thewrestlingdrillbook-pdf-free.html)** - Bill Archer, in Bill Welker (editor), Human Kinetics; transcription hosted by PDFCoffee; accessed 2026-09-26.

**Inspected:** Accessible book transcription: Chapter 1 attribution; printed pp. 9-11, drills 4 and 5, including Setup, Action, and Coaching Point. Photographs not inspected.

**Supports:** Over-under starting position, lead foot and head placement in pummeling.; Underhook elevation during pummeling, lowered hips, step behind, close contact, and standing rear body lock.

**Limits:** Third-party transcription of a coach-authored book. It does not verify a push-back setup; exact photos and a throw finish were not inspected.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; Sport Ngin-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text: PDF p. 9 Inside Pummel and PDF p. 17 Underhook; also reviewed p. 5 duck-under notes and pp. 16-17 drop-duck setup.

**Supports:** Underhook hand near center of back.; Pummeling with the lead foot matching the underhook.; Separates offensive underhook head position and other duck setups from the selected pummeling drill.

**Limits:** Team manual gives multiple variants. Its underhook-side head position is not substituted for Archer's over-under pummeling start; its hard head pulls and lift finishes are not adopted.

**S3: [Greco-Roman Wrestling, Chapter 4: Duck Under](https://pdfcoffee.com/uilliah-h-hortell-pdf-free.html)** - William A. Martell / Human Kinetics, 1993; transcription hosted by PDFCoffee; accessed 2026-09-26.

**Inspected:** Accessible book transcription of printed pp. 44-47, including text referring to Figures 4.26-4.29; title, author, and publisher front matter. Figure images not inspected.

**Supports:** Space between upper arm and trunk permits the head passage.; Level change and head recovery beneath the shoulder.; Duck-side foot may step behind the opponent.

**Limits:** Greco-Roman coaching text with historical scoring references; no historical points or throw permissions transferred to this folkstyle teaching card.

**S4: [Duck Unders and High Crotches Via Nestor](https://fanaticwrestling.com/blogs/news/duck-unders-and-high-crotches-via-nestor)** - Fanatic Wrestling, publisher of Nestor Taffur instruction; accessed 2026-09-26.

**Inspected:** Article text explaining inside/collar-tie contacts, pushing to elicit pressure back, level change, elbow clearance, and the standing back-access position. Embedded video not viewed.

**Supports:** Push-back is a described trigger for a different basic duck-under tie.; Supports distinguishing that reaction from the selected pummeling entry.

**Limits:** Publisher commentary around the instructor's demonstration; not evidence for exact underhook pummeling mechanics or a finish to the mat.

<a id="a04"></a>

## A04 - High Crotch to Double

**Tier:** Advanced | **Previous name:** High Crotch To Double

### Technical review

The draft identified a useful attack chain and correctly emphasized following the entry with the hips rather than remaining stretched forward. However, it did not identify a lead foot, shooting arm, captured leg, or head side. 'Head upright' alone could describe a head-inside single, which is a different position. Its most consequential error was moving the outside hand to the second leg. In this high-crotch change-off, the outside hand retains the original leg and the inside shooting hand transfers to the far knee. The draft also made the change depend only on whether that knee was reachable. USA Wrestling adds an essential condition: drive to the feet and take weight off the captured leg before opening the two-hand control.

### Selected variant

Inside-step high crotch, followed by the low angled double-leg drive. The card fixes a left-foot, left-shooting-arm example attacking the receiver's left leg. The head is outside that leg, on the attacker's right; the right trail foot recovers outside it. B07 was read in full. This card explicitly mirrors B07's finishing relationships: drive left, gather knees right, and receive on the receiver's right hip. Left/right labels are an editorial orientation of the sourced mechanics, not a claim that the automatic captions name those sides. The separate outside-step entry, standing lift, dump, and crackdown are not combined with this example.

### Mechanics and evidence

- USA Wrestling's inside-step instruction links penetration, shoulder contact at the hip, outside recovery of the trail leg, and a deep outside arm. The inside hand catches behind the knee, its elbow returns toward the ribs, and the legs drive the attacker into the opponent. The trail foot comes to the side to supply the angled drive, rather than simply stepping forward in line. [USAW_INSIDE]
- For the chosen left-sided mapping, the left hand passes between the thighs and wraps the receiver's left leg from its inside. The right arm joins from outside that same leg; the head is outside the receiver's left hip, on the attacker's right. This preserves the head-outside relationship instead of placing the head between the captured leg and the receiver's midline. Horaski and Garcia independently teach the shooting arm on the same side as the penetration foot. [USAW_INSIDE, HORASKI_GARCIA]
- The change-off lesson warns against releasing the original leg while both of the opponent's feet remain weighted. Recover the trail foot, drive up with the hips in, and maintain the two-hand grip until the near leg becomes light. A slight unweighting of that leg is part of this action; it is not the separate standing body lift excluded from the rehearsal. [USAW_CHANGE]
- The inside shooting hand then changes to the far knee while the other hand retains the near knee. Horaski and Garcia explicitly identify the inside hand as the hand that releases. USA Wrestling shows the far-knee action, close elbows, and continued drive through the hips. [HORASKI_GARCIA, USAW_CHANGE]
- College Park connects high-crotch position directly to its double-leg head-drive finish: feet drive at an angle while the legs are gathered inward and sideways, ending on a hip. For this card's mirror of B07, pressure travels left across the stance while the knees are drawn right. [COLLEGE_PARK]

### Teaching progression

- First demonstrate B07 in this mirror orientation. Have partners identify the receiver's left leg, the inside left shooting hand, and the right hand that must retain the near knee. Rehearse right-hip receiving separately.
- Start in a low captured-leg position with an accommodating receiver. Pause after trail-foot recovery and again before changing hands. Progress to the full entry only when hips stay underneath and neither partner falls unexpectedly.
- The three alternating repetitions and single early retreat are proposed coaching design, not source-established doses. The defender gives that retreat before contact, then cooperates with the finish. A blocked far knee or lost posture calls for a reset; sprawling and scrambling require a separate progression.

### Common mistakes and corrections

- If the attacker releases the outside right hand, restore its near-knee control and practice changing only the inside left hand. This prevents abandoning the original leg.
- If the far knee requires a long reach, do not stretch farther. Recover feet and hips, shift the receiver's weight, and bring the finish within reach.
- If the pair falls toward the attacker's head side, re-mark the leftward drive corner and distinguish it from circling around the near hip.

### Readiness and rules

Advanced is a readiness tier. Require reliable low side landings, no locked-elbow posting, and the ability to stop when the neck or captured knee is loaded. Use side-of-head contact with the head up; do not drive through the crown. The final double uses separate knee grips and settles above the hips. This card makes no scoring, locked-hands exception, or age-specific legality claim. Historical point values in the manuals were not adopted.

### What changed

- Retain a familiar name and explicitly identify the high crotch as head outside.
- Replace the incorrect outside-hand switch with inside-left-hand transfer while the right hand retains the original leg.
- Add the feet-and-hips recovery and near-leg-unweighting checkpoint before the hand change.
- Specify a left-foot example and explicitly mirror B07's drive, knee-gather, and receiving directions.
- Distinguish unweighting the captured leg from a standing body lift.

### Evidence limits

Both official USA Wrestling videos were inspected through their complete exported automatic captions and selected still frames, not claimed as continuously watched with audio. The inside-step captions contain transcription errors, so the text was checked against the visible positions and the manuals. The independent manuals substantiate the same-side penetration arm, inside-hand change, and angled finish. Receiving restrictions, pauses, repetition count, and retreat reaction are coaching design. Ciasulli's linked cut-double video was members-only and was not used as viewed evidence; neither its unavailable instruction nor a curriculum title substitutes for the inspected demonstrations.

### Sources inspected

**USAW_INSIDE: [Level 2 - Folkstyle Core Curriculum - High Crotch Inside Step Penetration](https://www.youtube.com/watch?v=witUsu1OzX8)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Complete exported English automatic captions, 0:04-2:25, and browser still frames at approximately 0:35, 0:40, 1:27, and 2:02. Located through USA Wrestling's official Folkstyle Level 2 curriculum.

**Supports:** Inside-step penetration and head-outside high-crotch body position.; Inside hand behind the knee, elbow near ribs, hip/shoulder connection.; Trail-foot recovery to the side and coordinated outside-arm depth before driving to the feet.

**Limits:** Automatic captions are imperfect; inspected frames clarify position. This is not a claim of continuous audiovisual viewing. The card's explicit left/right mapping is editorial.

**USAW_CHANGE: [Level 2 - Folkstyle Core Curriculum - High Crotch Change Off to Double](https://www.youtube.com/watch?v=ehtf3Y5g6BI)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Complete exported English automatic captions, 0:05-4:20; browser still frames around 0:40, 2:20, and 2:25. Key instruction at 0:27-1:41 and 2:04-2:54.

**Supports:** Changing before recovering the feet and shifting weight is a common error.; Keep both hands on the near leg until its weight is removed, then change to the far knee.; Drive through with hips in and elbows close, finishing over the opponent's hips.

**Limits:** Demonstration rises to the feet and can elevate the near leg. The card adapts intensity and receiving for rehearsal; it does not claim the video teaches its exact low landing restrictions. Automatic captions and sampled frames were inspected.

**HORASKI_GARCIA: [Wrestling Unit Block Plan: High Crotch Shot and Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 45-48, especially page 45 same-side penetration arm and page 47 inside-hand release to double; pages 12-14 for the angled double-leg finish.

**Supports:** Use the shooting arm on the same side as the penetration foot.; Wrap the leg with the other arm and bring the feet underneath.; The inside hand changes to the second leg; angled footwork completes a double.

**Limits:** Older PE teaching unit with some awkward terminology. Its trip, rapid rotation, defense details, and historical rules were not imported. It does not explicitly assign the card's left/right labels.

**COLLEGE_PARK: [College Park Wrestling Technique Handbook: Basic Offense and Finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text on pages 9 and 23: HIGH-C POSITION, DOUBLE / FLAIR, and HIGH CROTCH / DOUBLE rows.

**Supports:** Teach a high-crotch finishing position with chest up, trail leg available, and both hands on one leg.; Change from the high crotch to the double head-drive finish.; Angled foot drive with inward and sideways leg gathering, finishing on a hip.

**Limits:** Team coaching handbook, not rule authority. Distinct dump, corner-lift, and other finishes on the same page were excluded; it does not supply the card's side labels or drill dosage.

<a id="a05"></a>

## A05 - Single Leg to Double

**Tier:** Advanced | **Previous name:** Run The Pipe To Double

### Technical review

The draft's useful idea was to change finishes in response to defense. Its exact chain was not established by the inspected instruction. It began with B08's head-inside single on the defender's right leg, then retained the left arm, reached the far knee with the right hand, moved the head to the defender's left hip, and turned 'toward that side.' These actions do not identify whether the finish is a cutback double, a head-outside double, or a Barzegar. A planted captured foot also demands a different response from a leg that remains elevated outside the attacker's stance. B07 cannot simply supply the missing mechanics: its head is outside at the defender's right ribs and its drive is across the body toward the defender's left side. A head-inside single has not already achieved that outside relationship. The replacement removes the attempted pipe and planted-foot trigger and teaches one verified conversion from the same single-leg family.

### Selected variant

Reactive Barzegar, presented under the straightforward name Single Leg to Double. The defender moves the captured right leg outside the attacker's left thigh. The attacker retains and elevates that leg with the left arm, blocks the free left knee with the right hand, and brings the right trail foot through. This matches Trasso's reactive demonstration without mirroring; the proactive stance-switch variation is excluded. College Park independently documents the same outside-leg reaction, leg elevation, head across the chest, and far-knee block. [TRASSO] [COLLEGE_PARK]

### Mechanics and evidence

- The starting right-leg single and the outside-foot reaction match Trasso's demonstration. His reactive version retains a left-foot lead, so the right foot must advance substantially to bring the attacker's hips through. The left arm supports the captured thigh and the right arm changes to the remaining leg. [TRASSO]
- The head begins inside, stays raised in contact, and travels across the defender's chest as the torso drives. It is not swung to the outside of the defender's left hip. College Park expressly identifies the across-chest relationship; inspected video frames show that connection during the knee block and step through. [COLLEGE_PARK] [TRASSO]
- The destination is across the defender's stance through the free-left-leg side, with that knee blocked and the captured right thigh elevated. The right step carries the hips beyond the defender's legs; the finish is not a backward pipe pivot. Frames around 1:38-1:40 show the direction and side landing. [TRASSO]
- College Park's separate Cut Back Double row describes whizzer pressure, hand fighting, a planted foot, level change and a jab step. That is evidence of another conversion, not proof of the draft's exact hand/head chain. Its Barzegar row provides the matching replacement. [COLLEGE_PARK]

### Teaching progression

- Demonstrate the held-right-leg position and receiver's outside-leg change before teaching a finish. The receiver moves at the hip and knee together while the attacker follows; do not force a foot around a fixed knee. Show the inside head position from the front and side.
- Rehearse support, unclasp, knee block, and right-foot step as separate freezes. Then join them slowly into a low side landing. This applies USA Wrestling's recommendation to divide complex skills into components. [USAW_GUIDE]
- Only after partners can stop and receive reliably should the receiver choose between leaving the leg inside and taking it outside. The counts and two-choice drill are proposed coaching design; the sources do not establish a training dose. B08 supplies the other finish, while B07 supplies receiving experience rather than this conversion's head position.

### Common mistakes and corrections

- If the far-knee reach stretches the attacker out, shorten the reach and advance the right foot with the torso. A long arm without advancing hips does not reproduce the demonstrated finish.
- If the captured leg slips when the clasp opens, restore firm left-arm support before freeing the right hand. If the receiver's outside foot becomes hooked and fixed, stop and free it before resuming.
- If the attacker tries to circle the head around the far hip, return to the across-chest demonstration. Do not teach the right-foot B07 double and this head-inside finish as though their head relationships were identical.

### Readiness and rules

Advanced is a readiness tier, not an age clearance. Partners need demonstrated leg support, a stable head-up stance, and side receiving. The demonstration is published for Jiu Jitsu; this card ends with wrestling hip control and imports no guard, submission, or scoring claims. Brief unweighting during a takedown is distinct from a separate standing body lift. The low-speed receiving adaptation limits impact but does not make knee twisting acceptable. No current legality conclusion is inferred from the historical handbook or the USA Wrestling guide.

### What changed

- Replaced the unverified run-the-pipe-to-planted-foot chain with a documented reactive Barzegar conversion.
- Defined the captured leg, outside-leg reaction, retained arm, releasing hand, knee block, head relationship, stepping foot, and finish destination.
- Kept B08 and B07 as distinct prerequisites instead of combining their head positions.
- Added a specific receiver reaction, controlled landing, release, and finish-or-reset progression.

### Evidence limits

Trasso's auto-generated transcript was inspected at 0:23-1:38, together with actual paused frames at approximately 0:37, 0:50-0:55, 1:15, 1:25, and 1:38-1:40. This is transcript and frame inspection, not a claim to have heard or watched the entire lesson continuously. College Park's cached page text was read, including adjacent finish variants; its web screenshot request failed. The USA Wrestling pages supply teaching principles, not Barzegar mechanics. The card's slower landing, modest supported elevation, repetition counts and choice drill are editorial coaching adaptations. The original exact pipe-to-double chain remains unverified and is not retained.

### Sources inspected

**TRASSO: [The Merge Ep. 39 - Single Leg Barzegar Finish To Side Control](https://www.youtube.com/watch?v=ohdmZoUmIsc)** - Michael Trasso / Merge Grappling, official instructional YouTube channel; accessed 2026-09-26.

**Inspected:** Exported auto-generated English transcript, especially 0:23-1:38; actual paused browser video frames around 0:37, 0:50-0:55, 1:15, 1:25, and 1:38-1:40. The reactive explanation is 1:07-1:38.

**Supports:** Reactive conversion when the defender moves the captured leg outside; Left-arm support of defender's right leg and right-arm attack on the free left knee; Left-foot lead retained in the reactive version, followed by a substantial right-foot step through; Head contact, cross-body drive, and finish beyond the defender's legs

**Limits:** Jiu Jitsu instructional context. Proactive and reactive variations are separate; only the reactive one is selected. The video does not prescribe this card's folkstyle follow-up or drill counts. Captions are auto-generated, so spatial interpretation also used the visible demonstration.

**COLLEGE_PARK: [College Park Wrestling Technique Handbook: Single finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF extracted text for PDF page 24, especially SINGLE / BARZGAR, RUN PIPE, DUMP, and CUT BACK DOUBLE; page 23 DOUBLE / FLAIR and HIGH CROTCH rows also read to distinguish variants.

**Supports:** Outside-hooked captured leg as the Barzegar trigger; Elevation to the hip, lowered level, head across the chest, and free-hand block of the far knee; Cutback double as a distinct planted-foot conversion rather than automatic verification of the draft

**Limits:** Brief team instruction does not name right/left sides; the card uses Trasso's demonstrated orientation. PDF text was inspected; attempted web screenshot failed. Historical rule/scoring content was not adopted.

**FUJI: [The Merge: Single Leg Barzegar Finish To Side Control](https://www.fujisports.co.uk/blogs/blog/the-merge-single-leg-barzegar-finish-to-side-control)** - FUJI Sports UK, publisher and sponsor of Michael Trasso's instruction; accessed 2026-09-26.

**Inspected:** Accessible article text and named Michael Trasso biography, including the description of the captured leg being outside rather than between the attacker's legs.

**Supports:** Attribution of the coaching lesson to Michael Trasso; Outside-leg starting condition and intended finish past the legs

**Limits:** Same lesson as TRASSO, not an independent mechanical corroboration. The short article alone does not verify the detailed grips or feet.

**USAW_GUIDE: [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Official-source cached text with page markers: PDF pages 119 and 154-156, printed pages 118 and 153-155.

**Supports:** Dividing complex skills into teachable components; Teaching offensive skills with their defensive reactions; Finishing attacks into useful subsequent control

**Limits:** General coaching principles and freestyle-context discussion; no detailed Barzegar instruction or current folkstyle rules.

<a id="a06"></a>

## A06 - Backside Single Finish

**Tier:** Advanced | **Previous name:** Backside Shelf To Cover

### Technical review

The original card identified a useful position and correctly required the captured knee, foot and hip to travel together. Its low supported start is also suitable for teaching the shelf separately from the entry. The incomplete part was the finishing control: reaching to the far hip and simply guiding the partner belly down did not explain how to remove the remaining leg support. A06 now uses the first Circle to Hole finish from the College Park handbook: shelf the foot, secure both thighs and apply forward shoulder pressure. Chris Ayres independently emphasizes continuing to a far leg rather than abandoning leg control for the waist. The old hip route is not declared universally wrong; it is replaced because the inspected evidence supports a clearer, specific finish.

### Selected variant

A grounded backside single with the defender's right leg captured, the attacker's left knee behind that leg, and the attacker's right foot planted to form a thigh shelf. This is the finishing segment of the handbook's circle-to-hole recovery. The start deliberately omits the initial sprawl and circling action, so athletes can learn it before A07. A07 was read for interface consistency, but its generated text was not used as evidence.

### Mechanics and evidence

- College Park directs the near knee behind the captured leg, far hand to the captured foot, foot onto the far thigh, shoulder into the buttocks, both thighs collected and forward drive. In this right-leg example, near is the attacker's left and far is the attacker's right. [S1]
- The USA Wrestling photo sequence shows a change of attack, backside pursuit, hip pressure and a proposed shelf on the back knee. Its demonstration is mirrored relative to this card and begins from a different attack. It corroborates the shelf position, not every hand transfer. [S2]
- Ayres advises keeping the head connected to the body while reaching for a far ankle or knee. He also distinguishes purposeful pressure into the body from circling away and losing contact. These points support staying close through the transition. [S3]
- The receiving stance, ankle cup, gradual lowering and final release are explicit teaching details for rehearsing the documented finish. They keep the lower leg supported while the hand changes tasks; they do not add a standing lift or a second turning technique.

### Teaching progression

- Demonstrate the right-leg example with both partners facing the same general direction. First check the left-knee/right-foot base without a partner. Then add the receiver on both hands and the left knee, with the captured right leg free of the mat. The attacker should be close enough that the far thigh is reachable without stretching across the back.
- Pause after shelving. Confirm that the thigh carries the foot, the left arm retains the near thigh and the right hand can leave the ankle without dropping the leg. Next rehearse the far-thigh collection and forward finish. The receiver follows the hip pressure and softens the elbows rather than bracing rigidly against it.
- Add one announced squaring step before the shelf only after these parts are dependable. If the receiver has turned in enough to remove the backside angle, reset instead of rotating a trapped leg. The repetitions, interval length and rest are proposed coaching design, not a research-established training dose.

### Common mistakes and corrections

- If the athlete grabs the waist and the receiver keeps a wide base, return to the shelved position and identify the far thigh before completing the finish. The point of the second leg control is to complete the takedown, not merely occupy rear position.
- If the shelf collapses during the hand change, shorten the distance between partners and rebuild the planted-foot base. Do not compensate by yanking the ankle upward. If the captured knee or toes remain planted while the hips move, release and reposition the entire leg.

### Readiness and rules

Require a coach to verify the shelf, receiving posture and immediate release before resistance. Advanced describes readiness, not an age permission. The no-body-lift restriction is a lesson boundary. No current event-specific scoring or legality certification is claimed. The freestyle leg-lace continuation mentioned by USA Wrestling is excluded; separate rules instruction is needed for any later turn or ride.

### What changed

- Shortened the title to Backside Single Finish.
- Replaced the unsupported far-hip transition with far-thigh collection and forward shoulder pressure.
- Specified whose leg is captured, both support legs and the hand change after shelving.
- Made the receiver's descent, leg lowering and reset explicit.
- Preserved the A07 shelf interface without making A07 a prerequisite.
- Editorial chain check links the exact earlier move IDs and requires the sweep-single entry on both sides before this right-leg example.

### Evidence limits

S1 was independently downloaded and inspected as extracted text on pages 23-25 and as a rendered page 24; it supplies the chosen finishing mechanics but has no identified individual author or date. S2 was independently inspected as extracted text and the complete rendered six-photo page. It does not picture the finished shelf or the entire far-thigh transfer. S3's public article text was inspected; its embedded videos were not viewed. The short card's staged start, exact practice dose and release routine are original coaching design. No locked video, technique index or generated review is presented as mechanical proof.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook - Single finishes: Circle to Hole](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** Downloaded the source in memory; extracted pages 23-25 and independently inspected the rendered page 24, including the Circle to Hole row.

**Supports:** Near-knee position, far-hand/far-thigh foot shelf, both-thigh control, shoulder pressure into the buttocks and forward finish.

**Limits:** No individual author or publication date established. The source uses near/far terminology, translated into the card's right-leg example. Surrounding techniques are not endorsed or used as rules guidance.

**S2: [Team USA Technique Tips: Improving Position in Neutral Attacks](https://www.auburntakedown.com/forms-and-documents/forms-2019-2020/201907---usa-wrestler.pdf)** - USA Wrestler, July 2019; Terry Steiner and Lenny Grodoski; photos by Mike Clayton; originally published in WIN Magazine; accessed 2026-09-26.

**Inspected:** Downloaded the source in memory; extracted page 36 and independently inspected its complete six-photo rendered technique page and captions.

**Supports:** Backside pursuit with hip pressure and shelving the captured leg on the back knee/thigh after improving attack position.

**Limits:** The pictured sequence changes from a far-leg attack to a near-side attack. The final caption describes a shelf that is not yet complete in the photograph. Far-thigh collection is supplied by S1, not claimed from this picture.

**S3: [The Technique Blog: Finishing a Single Leg on the Mat (Baseline)](https://coachayres.com/2020/12/11/the-technique-blog-finishing-a-single-leg-on-the-mat/)** - Chris Ayres, Coach Ayres; accessed 2026-09-26.

**Inspected:** Read public article text, particularly the introduction and Key Points to Finishing a Single Leg Backside. Embedded videos were not inspected.

**Supports:** Maintain body/head connection and attack the far knee or ankle instead of reaching to the waist; use pressure through the opponent while retaining the captured leg.

**Limits:** The article supports finishing principles and target selection, not the exact foot-shelf configuration or sided hand transfer. Its separate shin-whizzer and backdoor variants are not incorporated.

<a id="a07"></a>

## A07 - Sweep Single Recovery

**Tier:** Advanced | **Previous name:** Sweep Single Rebuild Against Sprawl

### Technical review

The draft correctly recognized that an extended attacker needs to improve position before finishing. Its main weakness was making a square sprawl lead almost automatically to standing: draw the knees underneath, plant the left foot beside the left knee, then stand and run the pipe. It did not explain how the wrestler removes the defender's weight, which hand can post, or which angle makes that rise available. The phrase 'foot beside knee' also fails to specify a useful support position. Neither a clinic index nor a list of single-leg finishes substantiates that exact left-foot-first chain. It is therefore replaced, not pronounced universally invalid. The selected recovery has a specific opportunity: the attacker retains the leg and can still move around its side. A defender who squares successfully closes this lesson's route.

### Selected variant

The College Park handbook's circle-to-hole single-leg finish against a sprawl, expressed as a right-leg example. It recovers behind the attacked hip and shelves the foot instead of requiring a standing single. This preserves the card's purpose while giving it a documented route. The shelf is taught beforehand; the existing A06 draft was not treated as authority.

### Mechanics and evidence

- The handbook specifies retaining the near-arm leg hook, circling toward that leg with knees off the mat, placing the near knee behind it, and using the far hand and thigh for the shelf. The right-leg example translates near to the attacker's left and far to the attacker's right. [S1]
- USA Wrestling's pictured example independently shows a hand post used to improve an extended attack, followed by a change of angle, backside pursuit and a shelf. Its original entry changes from a far-leg attack to the near leg, so it corroborates recovery principles rather than the entire sweep sequence. [S2]
- The receiver's hand-and-opposite-knee support makes the captured leg available. After the shelf carries the foot, the freed hand can collect the second thigh; the attacker finishes through the hips and then lowers the supported leg. This is a rehearsal description of the selected finish, not a separate standing takedown. [S1]

### Teaching progression

- Demonstrate from the stopped shot first. Have the partner retain some weight through their hands and feet so the attacker can identify the leg hook, free-hand post and available corner. Do not begin with a full bodyweight drop onto an inexperienced athlete.
- Rehearse the circle without the finish, then start separately behind the hip and teach the shelf-to-cover. Link the two only after the attacker can move without dragging the partner's knee sideways. These pauses are teaching checks, not instructions to stop during a successful live attack.
- Add one announced sprawl, then one squaring step. A reset is a correct response when the angle disappears. Judge success by position retained and the receiver's stable descent, not by forcing every attempt to score. The stated repetitions and rest intervals are proposed coaching design.

### Common mistakes and corrections

- If the attacker remains on both knees and stretches the arms, reduce resistance and ask them to move their feet around the leg before reaching again. If the grip disappears entirely, restart; the card does not teach recovering a lost leg.
- If the attacker grabs the ankle from directly in front, pause at the hip first. If the partner's knee or toes remain pinned while the foot is shelved, release and reposition the whole leg. The shelf is support, not a lever for twisting a fixed knee.
- If the receiver stiff-arms the landing, return to the supported finishing start and have them follow the forward pressure with bent elbows. Do not increase speed until both partners can stop and release promptly.

### Readiness and rules

Advanced denotes readiness for connected reactions, not an age permission. Require retained leg control, independent hand support, and cooperative receiving before resistance. The no-lift and early-reset limits are lesson constraints. No event-specific legality or scoring certification is claimed; the coach must apply the competition's rules. USA Wrestling's pictured freestyle leg-lace continuation is deliberately excluded.

### What changed

- Shortened the name to Sweep Single Recovery.
- Replaced the unverified stand-up-to-pipe sequence with the documented circle-to-hole variant.
- Specified attacker and receiver sides, the posting hand, shelf support and hand transition.
- Defined the defensive reaction and the condition for resetting.
- Separated source-backed mechanics from the proposed practice dose.
- Editorial chain check links the exact earlier move IDs and requires the sweep-single entry on both sides before this right-leg example.

### Evidence limits

S1 supplies written finishing mechanics and was inspected as text and as its rendered page. S2 was inspected as the actual six-photo page with captions. S3 supports including defensive reactions and a partner who follows during rebuilding drills; it does not verify grips or footwork. S4's public frames show a build-up-to-double alternative, but captions were unavailable and exact knee sequencing was partly obscured. That alternative was not combined with the selected shelf finish. No locked Kolat library video was accessed or claimed as viewed.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook - Single finishes, Circle to Hole](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; school coaching handbook hosted on SportsEngine; accessed 2026-09-26.

**Inspected:** PDF page 24: extracted full single-leg finishing text and inspected rendered page, especially the Circle to Hole row. Also read relevant surrounding pages 23 and 25.

**Supports:** Circling recovery against a sprawl and the knee-behind-leg, opposite-hand/thigh shelf finish.

**Limits:** No individual author or publication date established. Near/far terminology is translated into the card's right-leg example. Other techniques in the handbook are not endorsements or rules guidance.

**S2: [Team USA Technique Tips: Improving Position in Neutral Attacks](https://www.auburntakedown.com/forms-and-documents/forms-2019-2020/201907---usa-wrestler.pdf)** - USA Wrestler, July 2019; Terry Steiner and Lenny Grodoski; photos by Mike Clayton; originally published in WIN Magazine; accessed 2026-09-26.

**Inspected:** PDF page 36, extracted captions and rendered full six-photo technique page.

**Supports:** Improve an extended attack with a hand post, angle change, backside pursuit and a supported leg shelf.

**Limits:** The demonstration changes from attacking the far leg to a near-side single. It does not independently establish the card's exact sweep-single entry or every shelf detail.

**S3: [2010 Washington State Coaches Clinic with Cary Kolat](https://www.kolat.com/blog/2010-washington-state-coaches-clinic-with-cary-kolat)** - Cary Kolat, KOLAT.COM; accessed 2026-09-26.

**Inspected:** Public page text: single-leg sequence, discussion of drilling opponent defense, and rebuild-drill paragraph. Linked technique pages led to login.

**Supports:** Include realistic defensive reactions in shot practice; the drilling partner follows the rebuilding attacker.

**Limits:** Clinic outline and coaching comments, not exact mechanical verification. Linked membership videos were not inspected.

**S4: [Building Up on a Single Leg to Double Leg Finish](https://www.youtube.com/watch?v=2qod8qCChKw)** - Cary Kolat, official KOLATCOM YouTube channel; accessed 2026-09-26.

**Inspected:** Public page description and paused video frames near 0:00, 0:02, 0:05, 0:06, 0:08, 0:09, 0:19, 0:20 and 0:21, using the browser player. No transcript or audio analysis.

**Supports:** A distinct documented option builds from a defended single into a double-leg finish.

**Limits:** Low-resolution, partially obscured footwork; no captions available. Used to distinguish variants, not as authority for the selected backside shelf sequence.

<a id="a08"></a>

## A08 - Down Block to Ankle Reattack

**Tier:** Advanced | **Previous name:** Down Block To Re Shot

### Technical review

The original has a useful purpose and correctly asks the defender to recover their feet. It does not identify the initial shot, the actual down-block arm barrier, the opening for the double, or the double's side and finish. Its correction also asks both athletes to pause until fully balanced, which can erase the recovery window it claims to exploit. I could verify several curriculum references to down-block reattacks, but titles do not establish those mechanics. The replacement uses an inspected demonstration by Isaiah Martinez and deliberately teaches the ankle-entry portion. It is a same-family substitution, not a claim that the original double-leg variant is invalid. B03 and B07 were read for consistency; their double-leg entry and finish are not attached to this different attack.

### Selected variant

A left-lead down block against a sweep single, redirecting to the partner's left ankle. The action stops at the catch beside the partner's hip. The opponent remains low rather than standing fully before the reattack. Left/right in the card belongs to the defender unless the partner is named. B12 is mirrored as a prerequisite. The title names the actual target and the purpose explicitly says this is an entry lesson.

### Mechanics and evidence

- USAW describes a down block as placing a hand in the route to the leg while withdrawing the attacked leg and balancing on the other foot. This supports the initial left-hand/left-leg action and distinguishes the temporary one-foot defensive position from a shooting base. [USAW_SKILLS]
- College Park likewise connects the downward arm action with simultaneous leg withdrawal and lowering level. Its footwork instruction uses short steps without crossing, and its attack preparation requires setting the feet and loading the hips. The explicit foot plant before the ankle chase is a teaching checkpoint derived from these principles. [COLLEGE_PARK]
- Martinez demonstrates a sweep-single block, maintains separation, then redirects the pressure and follows the near ankle. Sampled frames show the right hand at the left ankle and the left hand on the partner's back. This is the documented connection between defense and entry. [MARTINEZ]
- The rightward step and shoulder labels orient the demonstrated route for the written card. They do not prescribe a measured angle or a long sideways lunge. The initial barrier must clear as the torso turns; retaining a stiff arm while reaching down would obstruct the entry. [MARTINEZ, COLLEGE_PARK]

### Teaching progression

- First demonstrate the left-side version of B12 and freeze after the threatened leg clears. Check that the athlete can replace the foot with knees bent and feet separated. The pause is a learning check, not the intended final rhythm.
- Use an assistant for the sweep-single setup. Rehearse the shoulder redirect without catching a leg, then add the ankle catch at walking speed. The partner maintains light forward pressure and permits the turn, staying low and supported. Stop at the named entry so neither athlete improvises a takedown or kick-out.
- After reliable cooperative entries, introduce one decision: continued pressure permits the redirect; withdrawal requires stance recovery. This count and reaction drill are original coaching design. Increase speed only when the defender can replace the foot without crossing, stay close to the hip, and release immediately. Teach the opposite orientation separately.

### Common mistakes and corrections

- A long one-legged reach for the ankle leaves the defender unable to follow. Remove the ankle target temporarily and rehearse foot replacement followed by the short outside step.
- If the partner has already secured the leg, the early-defense setup has failed. Stop this drill rather than torque a caught knee while attempting to circle.
- If the athlete waits for the partner to stand fully and separate, return to light forward pressure against the block. Teach the change from resisting that pressure to redirecting it; do not reward lunging after a retreating partner.
- If the head folds down or the athlete grabs the foot and twists it, move closer before lowering and rehearse an open whole-hand ankle cup. The partner must not add an untrained kick-out.

### Readiness and rules

Advanced is a readiness tier. Both wrestlers must demonstrate the mirrored down block, a slow stoppable sweep single, and reliable release. This card ends in an ankle-entry position and makes no scoring claim. It does not authorize a completed low-single finish, lift, neck lever, or ankle rotation. Ankle control is taught as a positional catch, not a joint lock. Historical manuals supply movement principles, not current event-rule interpretations.

### What changed

- Replaced the unspecific double-leg re-shot with a documented sweep-single block to ankle reattack.
- Specified the left lead, same-side block, foot replacement, shoulder route, target ankle, and both hands.
- Changed the trigger from waiting for full standing recovery to redirecting continued pressure.
- Removed the unsupported finish and made the entry-only stopping point explicit.
- Removed the double-leg prerequisite and replaced timed rounds with a defined pressure-or-withdrawal decision.

### Evidence limits

The Martinez clip's complete auto-generated English transcript was inspected, together with browser video frames at approximately 20, 25, 30, 35, 40, 45, and 55 seconds. This was transcript and sampled-frame inspection, not continuous audiovisual viewing. Captions contain recognition errors, so anatomical labels were checked against the displayed positions. The manuals independently verify the block and footwork principles, not Martinez's complete reattack. The exact staged foot reset, restricted receiving role, three-repetition dose, and pressure-or-withdrawal drill are teaching adaptations. The video shows further follow-through, but this card makes no detailed finish claim because the short clip does not explain one sufficiently for this library.

### Sources inspected

**MARTINEZ: [Downblock to a Reattack: Wrestling Technique with Isaiah Martinez](https://www.youtube.com/watch?v=q6FJeyfnxt4)** - RUDIS, instruction by Isaiah Martinez; accessed 2026-09-26.

**Inspected:** Complete auto-generated English transcript, 0:00-1:03 of the 1:10 clip, exported through the browser transcript tool; video frames sampled at about 0:20, 0:25, 0:30, 0:35, 0:40, 0:45, and 0:55.

**Supports:** Sweep-single down block connected to a shoulder redirect and near-ankle reattack; Maintaining separation before following the ankle

**Limits:** Short demonstration with imperfect automatic captions. No continuous audiovisual viewing claimed. Does not explain a complete standardized mat finish or prescribe the card's drill.

**USAW_SKILLS: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached official PDF page-marked text, pages 1-2 for stance and down/cross blocks, and pages 4-5 for simulated entries, level change, and attack-position principles.

**Supports:** Hand barrier and leg withdrawal while balancing on the other foot; Balanced stance and simulated reaching attacks for rehearsal

**Limits:** Study-guide text, not a full demonstration of the selected ankle reattack. Linked videos were not inspected.

**COLLEGE_PARK: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling, team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF page-marked text, page 8: Motion, Down Block/Cross Block, and Level Change/Set Your Feet; pages 9 and 23 also read to check the distinct double-leg position and finish.

**Supports:** Simultaneous downward arm action and attacked-leg withdrawal; Lowering level, setting the feet, and using short noncrossing steps

**Limits:** Does not verify the complete ankle reattack. Its head-block-to-double and double finishes are separate techniques and were not imported. Historical scoring statements were not used.

<a id="a09"></a>

## A09 - Standing Whizzer Defense

**Tier:** Advanced | **Previous name:** Whizzer And Hip Defense

### Technical review

The original correctly identifies the overhook, hip position, balance, and a prompt release as important. Its instructions do not establish which single is being defended, which arm is overhooked, or where either wrestler's head and captured foot belong. 'Hips back and toward the attacker' combines different defensive actions without identifying when to use them. A free hand at either shoulder or wrist also leaves the learner without a specific job. Finally, it jumps from those positions to a freed foot without giving a clearance mechanism. The replacement teaches a documented standing defensive position and honestly limits its finish: defend the turn, then reset when the grip opens or the drill ends.

### Selected variant

Cejudo's short standing whizzer with outside-shin contact, limited to its defensive holding phase. The card uses the familiar name Standing Whizzer Defense. His subsequent chin lift, double-overhook grip break, and leg kick are a separate continuation and are omitted. This is neither a kneeling shin-whizzer lock nor a whizzer throw.

### Mechanics and evidence

- The example fixes the defender's right leg as the attacked leg and their right arm as the overhook on the attacker's left shooting arm. Witulski explicitly gives this arm-to-leg relationship. The overhook is contact around an upper arm; it is not a command to twist an isolated shoulder. [S3]
- Cejudo's published instruction places the captured shin outside the attacker's near leg above its knee, uses the other hand on the far wrist, and keeps the heads at comparable height. The card spells out the right/left mapping for that situation. Moving the captured limb as a unit and refusing a trapped-foot turn are rehearsal constraints. [S1]
- The independent College Park manual likewise begins standing single counters with a near whizzer and far-wrist control. Its inside-trip entry includes bringing the captured leg back to the mat. That passage corroborates these basic controls, but its knee-drop trip is not included here. [S2]
- Pressure comes from the supporting foot and body connection. Cejudo expressly allows continuing the defensive position when the next clearance is unavailable, including the possibility that the attacker releases. A retained single is therefore a defended position, not an escape or a guaranteed finish. [S1]

### Teaching progression

- Demonstrate the fixed right-leg example with the attacker already holding the single low. Before moving, the coach checks the correct overhook arm, free-wrist hand, shin contact above the knee, and both athletes' balance. Mirror the entire arrangement together only after the first side is understood.
- The receiver maintains a light thigh grip and a neutral neck, follows the defender's small forward steps, and opens the grip before either shoulder or captured knee is loaded awkwardly. The receiver does not stay rigid to manufacture resistance. Initial repetitions end with an intentional release and the defender's stance recovery.
- Progress to one slow circling step, then a brief positional round. Success means denying that step's angle while remaining balanced; it does not require ripping the leg free. If the leg rises, the defender must post a hand, or alignment deteriorates, end this drill and reset. Repetitions, durations, restricted reaction, and these stop conditions are coaching design, not research-tested doses.

### Common mistakes and corrections

- If the arm is doing all the work, reduce resistance and reconnect the hip and outside shin before moving the supporting foot. The partner's whole body should move instead of their shoulder being held in place.
- If the captured foot catches, the attacker releases so the whole leg can be repositioned. Do not turn the hip over a planted foot or force the shin sideways into a knee.
- If the defender falls backward or bends their head below the attacker, restart with lighter contact and shorter supporting-foot steps; do not add an explosive whizzer kick.

### Readiness and rules

This Advanced label assumes demonstrated balance and partner care, not a particular age. The card is a folkstyle practice defense with no throw, leg-reaping finish, score claim, or promised referee stalemate. The old USA Wrestling article includes freestyle scoring and edge tactics; those are outside this card and are not presented as current rules. Local event rules and an official's safety judgment still govern live wrestling.

### What changed

- Specified the single, sides, overhook contact, free-hand job, shin location, and head relationship.
- Removed contradictory hip directions and the unsupported automatic clearance.
- Replaced pipe-finishing resistance with one defined circling reaction and a clear reset.

### Evidence limits

S1 is the instructional publisher's written explanation of Cejudo's demonstration; the embedded video itself was not inspected. S2 was read as actual PDF-page-marked coaching-manual text. S3's substantial indexed article body was inspected, including its explicit right-leg/left-arm example; direct page opening returned 403, and its linked historical images and clips were not inspected. S3 is used only for that mapping and the distinction between basic and throwing whizzers. No source establishes the drill dosage or guarantees a grip release. The simplified endpoint is intentional and disclosed.

### Sources inspected

**S1: [Single Leg Defense with Henry Cejudo](https://fanaticwrestling.com/blogs/news/single-leg-defense-with-henry-cejudo)** - Fanatic Wrestling; accessed 2026-09-26.

**Inspected:** Full accessible page text, especially paragraphs explaining the short whizzer, outside shin, far wrist, supporting-foot drive, head height, and maintaining position when the continuation is unavailable (retrieved lines 37-50).

**Supports:** Standing defensive position and conditional holding endpoint.

**Limits:** Publisher's written demonstration explanation; embedded video was not viewed. Its chin lift and double-overhook kick-out are deliberately excluded.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text: PDF page 20, SINGLE introduction and WHIZZER/INSIDE TRIP; page 19 sprawl/short-offense instructions read for comparison.

**Supports:** Near-arm whizzer, far-wrist control, balance while standing, and returning the captured leg to the mat.

**Limits:** Provides a different continuation through an inside trip. That trip, its knee drop, and the kneeling short-offense alternatives are not merged into this card. No current scoring claim is taken from this manual.

**S3: [Working on the Whizzer](https://www.themat.com/news/2001/april/30/working-on-the-whizzer)** - USA Wrestling; Ted Witulski; accessed 2026-09-26.

**Inspected:** Substantial indexed article body returned by targeted web search, including the right-leg/left-arm example and discussion separating basic counters from whizzers for distance. Direct open returned 403.

**Supports:** Explicit side mapping for an overhook against an attack on the right leg; distinction between basic defense and advanced throwing variants.

**Limits:** Historical 2001 coaching text. No linked video or image inspection. Not used as current rules authority or as the detailed source for the selected standing variant.

<a id="a10"></a>

## A10 - Limp Arm

**Tier:** Advanced | **Previous name:** Limp Arm From The Whizzer

### Technical review

The draft correctly discourages pulling a trapped arm against a fixed overhook and connects body movement with clearance. However, it does not identify a standing or grounded single, the overhooked arm, the opening, or the finish. Supporting the leg with the other arm occupies the hand needed by the selected wrist-control variation. 'Turn the hand toward the opening' is not an executable direction. The rewrite starts at a documented low seatbelt after releasing the leg, then teaches one complete continuation instead of promising to recover a single.

### Selected variant

Grounded seatbelt limp arm with control of the whizzer wrist, followed by a go-behind. Bekzod Abdurakhminov supplies the demonstration and publisher explanation; Applegate independently describes the palm-up, elbow-forward release. The fixed example uses the attacker's left arm beneath the defender's right arm. Standing, step-over, and belly-whizzer peek-out variations are excluded.

### Mechanics and evidence

- The publisher identifies a nearly parallel position, a planted outside foot, a relatively extended seatbelt arm, and wrist control maintained while circling. It warns against going over an uncleared whizzer. These are functional conditions, not simply relaxation cues. [S1]
- In the inspected front-angle frames, the attacker is at the defender's right: left knee down, right foot wide, left arm across the back, right hand initially available to post. The defender supports on the right knee and left hand. The reverse angle around 1:35 shows the attacker's right hand holding the defender's right wrist beneath the trapped arm. The arm is free by approximately 1:36-1:37 while that wrist remains controlled. [S2]
- Applegate distinguishes a low leg-grip 'Loose Arm' from the back-wrapping 'Limp Arm.' Both turn the working palm upward and lead with the elbow along the attacker's side. This supports a precise withdrawal direction without prescribing a violent shoulder rotation. His posting-hand version is independent corroboration of the release, not the source of this card's wrist control. [S3]
- The selected endpoint is a grounded rear position with separate wrist and waist contact. The coach checks that the cleared elbow and shoulder follow the body before the athlete circles. Merely removing the overhook is not the same as securing rear control.

### Teaching progression

- Demonstrate from the receiver's right, then turn the pair so both grips can be seen. Identify each athlete's right and left. Rehearse the palm-up elbow motion alone before adding an overhook. Pause with the arm free and both athletes balanced.
- Start directly in the low seatbelt instead of requiring a defended shot on every attempt. The receiver offers a loose overhook, a stable knee and hand, and modest inward pressure; they do not pull the shoulder down to test toughness. The attacker must demonstrate the outside-foot base and reachable wrist before trying the clear.
- Initially stop as soon as the elbow exits. Add the go-behind after several painless clearances. The receiver follows the pressure on bent, mobile limbs and restores both hands to the mat when permitted. Neither wrestler uses the head as a support or maintains a rigid arm to resist the rehearsal.
- The reaction drill offers light inward pressure or an early square-up. Pressure permits the practiced release; a closed angle means reset. Repetition counts and limited choices are coaching design, not a validated training dose. Mirror the entire arrangement after the first side is reliable.

### Common mistakes and corrections

- If the attacker pulls the hand first with the elbow flared, return to solo rehearsal: palm up, elbow leads, hand follows. A smaller clearance beats wrenching the shoulder against the overhook.
- If the defender squares before the wrist is controlled, rebuild the start. Do not turn a missed limp arm into an improvised twisting pull.
- If the attacker collapses onto both knees, restore the outside foot and upright neck before adding pressure. If the foot cannot post without trapping a leg, separate and reset.

### Readiness and rules

Advanced denotes demonstrated readiness. A09's audited Standing Whizzer Defense uses a different standing shin arrangement and is not this card's start; B09 supplies relevant low single-leg familiarity, not an automatic transition into this grip. The receiving task requires shoulder comfort, balance on a knee and foot, and immediate release. No throw, forced mat return, scoring value, or historical freestyle rule is prescribed. The card uses separate hands after the go-behind and stops when grounded rear control is established.

### What changed

- Shortened the name to Limp Arm.
- Replaced the unspecified single with a defined low seatbelt start and explicit sides.
- Added the supporting foot, correct wrist, palm direction, and elbow-first release.
- Replaced an unspecified corner finish with a go-behind and clear reset conditions.

### Evidence limits

Inspected the publisher's full written explanation, selected actual demonstration frames, and Applegate's accessible page-labeled text. The YouTube transcript panel remained loading, so no full transcript or uninterrupted audiovisual viewing is claimed. The cached USAW guide's counter-offense section and College Park's single finishes were read but did not independently establish this exact limp arm; their different counters are not imported. Side labels, conservative receiving, separate-hand endpoint, and drill design are teaching adaptations. The selected sequence is adequately supported; no compulsory transition from the standing A09 position is implied.

### Sources inspected

**S1: [Limp Arm From Underhook by Bekzod Abdurakhminov](https://fanaticwrestling.com/blogs/news/limp-arm-from-underhook-by-bekzod-abdurakhminov)** - Fanatic Wrestling, publisher of Abdurakhminov's instruction; accessed 2026-09-26.

**Inspected:** Full accessible instructional article, especially paragraphs on parallel position, outside foot, wrist control, pressure response, and avoiding a step over an intact whizzer.

**Supports:** Grounded seatbelt position with outside-foot base.; Maintain wrist control while clearing and circling behind.

**Limits:** Written publisher explanation accompanies the primary demonstration. It does not name every right/left relationship; those were checked against the clip.

**S2: [Limp Arm From Underhook by Bekzod Abdurakhminov](https://www.youtube.com/watch?v=KzRlNiNDalI)** - FANATIC WRESTLING, official instructional YouTube channel; accessed 2026-09-26.

**Inspected:** Actual browser video frames at approximately 0:30, 0:50, 1:10, 1:30, 1:35, 1:36, 1:37, and 1:57 of the 3:03 clip, including front and reverse views of the low start, wrist grip, and arm clearance.

**Supports:** Attacker's left arm under defender's right arm, with left knee down and right foot posted in the first demonstration.; Free right hand controls the defender's right wrist during release.; Clearance retains wrist contact and opens rear access.

**Limits:** Selected visual frames were inspected, not every frame or a complete transcript. The same instructor supplies S1 and S2, so these are complementary evidence rather than independent coaches.

**S3: [Basic Wrestling Fundamentals: Loose Arm and Limp Arm](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate)** - Warren Applegate; authored instructional manual reproduced on Scribd; accessed 2026-09-26.

**Inspected:** Accessible page-labeled manual text around printed page 34: Loose Arm steps 1-7 and the note distinguishing the Limp Arm with the arm across the opponent's back; glossary definition also read.

**Supports:** Palm-up release with the elbow moving forward and the hand trailing along the side.; Limp arm begins with the working arm across the back beneath a whizzer.

**Limits:** Historical manual text, not a current rule source. Its free hand posts and its footwork differs from the selected wrist-control variant; only the shared release mechanics are adopted.

<a id="a11"></a>

## A11 - Single Leg Kickout

**Tier:** Advanced | **Previous name:** Single Leg Hand And Hip Clear

### Technical review

The original correctly prioritized balance, whole-hand contact, knee alignment, and stance recovery. It never explained why the grip would open. Unspecified wrist and upper-arm contacts do not establish a clearance mechanism, and moving the hips away can stretch the defender out. Keeping the knee bent throughout also obscures the downward leg action. The replacement supplies a documented elbow-lift defense under the familiar family name Single Leg Kickout. Kickout means freeing one's leg into space, not striking the opponent.

### Selected variant

The two-hand elbow-lift variation in Horaski and Garcia's standing-single defense, starting with a low captured leg. Each hand controls one upper arm above the elbow. This is a clearance exercise with a stance-recovery finish. It is distinct from A09's outside-shin whizzer holding defense and from a high single with the ankle elevated in an armpit. The latter needs different instruction. It also does not require the chin lift, linked S-grip, or double overhook from Cejudo's related continuation.

### Mechanics and evidence

- The manual's preceding offense establishes a head-inside single, near-knee clasp, and captured leg between the holder's legs. Its defense then directs the defender to use the elbows or triceps, raise them, shift weight to return the foot, and push away to neutral. Those are the selected mechanical actions. [S1]
- The explicit right-leg demonstration translates that instruction: defender's right hand reaches the holder's left upper arm and left hand reaches the right upper arm. Contact is behind each elbow, on the lower triceps. This right/left map is editorial clarification rather than quoted laterality. [S1]
- The opposing actions matter: the arms move upward while the captured leg travels downward and backward. Cejudo's publisher describes this same clearance principle after squaring to the attacker, but uses joined hands over the upper arms. That corroborates the mechanism, not the exact independent-hand grip selected here. [S2]
- The foot must actually clear before stepping away. A foot on the mat with an intact leg clasp is not yet a completed defense. The stop-and-reset instruction prevents an unsuccessful attempt from becoming repeated sideways pulling. The card promises no automatic grip break.
- B08's audited review was checked to keep the holder's head-inside, low-leg setup consistent. A09's audited review was checked to avoid silently treating a retained whizzer position as a finished clearance. Neither draft nor review substitutes for the primary instruction.

### Teaching progression

- Demonstrate the captured right leg, both hand contacts, supporting left foot, and final stance from front and side. First rehearse returning the foot with a loose clasp and a stationary holder. The coach watches that the defender stays upright enough to balance rather than folding over the hands.
- The receiving partner holds the thigh lightly, keeps the neck neutral, and lets the elbows rise with the action. They release immediately if a foot catches or balance fails. They do not add a pipe finish during the initial clearance drill.
- After smooth stationary repetitions, add one slow circling step so the defender must adjust the supporting foot before clearing. Success is a free leg and a balanced facing stance. A retained grip earns a reset, not stronger pulling. The counts and restricted reaction are coaching design. Breaking a complex skill into parts is consistent with USA Wrestling's teaching guidance. [S3]

### Common mistakes and corrections

- If the defender leans away and stretches both arms, restart closer and regain balance before lifting. Hand contact should assist balance rather than substitute for the supporting foot.
- If the foot swings sideways, reduce resistance and rehearse a down-and-back path with the hip, knee, and toes moving together. Do not rotate the trunk around a trapped lower leg.
- If the defender releases both arms before the leg is free, pause at clearance and show the transition to upper-arm separation. Finish by facing the partner with hands available, rather than turning away.

### Readiness and rules

Advanced is a readiness tier: the pair must already manage a low single, small one-leg balance adjustments, and immediate release. This is a folkstyle practice clearance without a throw, trip, body lift, or score claim. No foot contact with the partner is prescribed. Historical source rules and stalemate comments are not treated as current authority; the card makes no event-specific legality assertion.

### What changed

- Replaced a vague hand-and-hip title with Single Leg Kickout.
- Replaced unspecified wrist contact with a sourced, bilateral elbow-lift mechanism.
- Specified the captured leg, head side, two hand contacts, supporting foot, clearance direction, and final stance.
- Separated the low-leg clearance from A09's whizzer defense and high-single defenses.
- Added a defined receiving role, one circling reaction, and an honest failed-attempt reset.

### Evidence limits

S1 was read as cached PDF text. S2's written explanation supports the clearance principle, not an identical grip; its embedded video could not be fetched. S3 supplies teaching structure, not exact mechanics. College Park's page 20 wrist-peel/inside-trip sequence was read for comparison and excluded. Drill restrictions, laterality, stance reset, and failure conditions are coaching design. No source validates a repetition dose.

### Sources inspected

**S1: [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text: PDF page 2 for authorship, page 39 for the standing head-inside single setup, and page 40 for the elbow/triceps lift, balance, foot recovery, and push-away defense. Original public PDF also opened successfully.

**Supports:** Low standing single setup and near-knee grip.; Lift behind elbows or triceps, adjust weight, put the foot down, and separate to neutral.; Balance while the holder moves and progression from a held-leg start.

**Limits:** School coaching lesson plan, not a rulebook. It does not give explicit right/left labels or call this variation a kickout; those are editorial clarifications. No illustrations or video were claimed as inspected.

**S2: [Single Leg Defense with Henry Cejudo](https://fanaticwrestling.com/blogs/news/single-leg-defense-with-henry-cejudo)** - Fanatic Wrestling, publisher of Henry Cejudo's instruction; accessed 2026-09-26.

**Inspected:** Full accessible page text, especially retrieved lines 41-50 describing the whizzer setup, squaring action, upper-arm grip, and simultaneous arm lift/leg withdrawal. Embedded YouTube fetch failed.

**Supports:** Lifting the upper arms while bringing the captured leg down and back can complete a standing single-leg clearance.; A defended position with the leg still held is distinct from the subsequent clearance.

**Limits:** Written publisher explanation, not an independently inspected video. Cejudo uses an S-grip and a preceding chin lift; neither is imported into the selected two-hand elbow-lift card. Stalemate comments are not current rules authority.

**S3: [USA Wrestling Coach's Guide to Excellence, Second Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Official-source cache metadata and PDF-page-marked text: PDF page 119 (printed 118), plus pages 154-156 for attack, finish, and defensive teaching context.

**Supports:** Separate complex skills into component actions and reinforce specific successful behaviors.; Teach defensive understanding alongside offensive technique.

**Limits:** Does not verify this clearance's grip or footwork. Freestyle/Greco discussion and historical rules were not imported into the folkstyle card.

<a id="a12"></a>

## A12 - Front Headlock Drag-Out

**Tier:** Advanced | **Previous name:** Front Headlock Elbow Drag

### Technical review

The draft correctly identified an escape using elbow control, an outside step, and head clearance. However, its left-hand grip on the holder's right elbow and shallow starting arm belong to College Park's near-side version, which pushes the arm downward and across. The draft instead prescribed a pull toward the opposite hip, blending versions. This revision selects the cross-body drag and adds a near-leg finish. A12 remains a counter by the wrestler underneath, distinct from B10/B11's offensive backhand go-behinds.

### Selected variant

Kneeling cross-body drag-out against a chin-and-opposite-triceps front headlock with the holder's right elbow accessible. The defender's right hand crosses to that triceps; the defender steps left around the holder's right side. This follows the handbook's cross drag and USA Wrestling's cross-hand sucker-drag family [S1, S2].

### Mechanics and evidence

- College Park distinguishes the cross drag from the near-side version on the same page. For the cross drag, the held arm reaches underneath and across to the triceps, the outside leg steps up, and the free hand connects to the near leg [S1]. The card maps those relative directions to an explicit right-arm headlock example. The practice holder keeps the elbow reachable; the defender does not first need to pull the held arm completely free.
- USA Wrestling separates a same-side elbow pass from a cross-hand drag. Its drag links moving the elbow across with taking the hips around the corner and clearing the head [S2]. Accordingly, the card couples the arm action to the outside step and body turn. It does not prescribe turning the neck inside a stationary headlock.
- Crowell stresses that dragging without a substantial step accomplishes little. His instruction also favors securing the leg during the go-behind; reaching only around the waist can let the opponent step over or circle away [S3, 0:31-1:25]. The revised finish therefore first gathers the near thigh after the head clears, then progresses to ordinary top control.
- Crowell's later explanation identifies flared elbows as an opening for a counter [S3, 3:31-3:54]. Keeping the pulling elbow close is useful here. The hand cups the upper arm; it does not torque the elbow joint. The last transition to separate waist-and-arm control is a conservative teaching endpoint, not a claim that head clearance alone earns a takedown.

### Teaching progression

- Demonstrate the roles: holder's right hand at the chin, left hand at the defender's right upper arm. Check that the defender reaches the correct triceps without twisting. The holder supports their own weight and offers a reachable elbow.
- Rehearse foot placement and hip turn with an open chin cup. Pause at head clearance before adding the thigh connection and rear control. The receiver follows the turn and lets the head leave naturally rather than closing the grip during the exit.
- Add only the defined reaction of following to face. If the defender cannot gain the angle or the arm stays trapped, reset instead of adding force. Match partners by control and balance. The repetition counts, timed turns, staged finish, and receiving limits are proposed coaching design rather than research-tested doses.

### Common mistakes and corrections

- Using the left hand for this selected cross drag recreates the original variant confusion. Freeze the setup and have the defender identify their held right arm before reaching across with that hand.
- Pulling from two fixed knees turns the exercise into an arm-strength contest. Establish the left-foot outside step, then let the hips travel with the elbow action.
- Reaching for the waist before the head clears can strand the defender underneath or permit a counter. Separate the clearance checkpoint from the near-thigh connection until both are reliable.

### Readiness and rules

Advanced means demonstrated readiness, not age permission. Require immediate release and supported kneeling balance. The starting position uses loose chin-and-arm contact, not neck squeezing. No throw, head impact, joint lock, or locked-hands finish is taught. These sources establish mechanics rather than current event legality; the coach checks event rules before live use.

### What changed

- Renamed the card Front Headlock Drag-Out and identified escape from the opponent's hold as its purpose.
- Selected the cross-body version and corrected the gripping hand to the defender's right hand on the holder's right triceps.
- Linked the outside step to hip travel, then made head clearance precede the near-thigh and cover finish.
- Added a specific receiving role and a limited facing reaction instead of unspecified following pressure.

### Evidence limits

Inspected the manuals' relevant text, the public Coaches Insider description, and the embedded Vimeo video's English auto-generated captions; no video frames were inspected. Unclear caption phrases were not used as evidence. The right/left example translates the manuals' relative directions. USA Wrestling's historical international-style scoring context was not adopted. Kolat and Ciasulli pages were leads only; their uninspected demonstrations are not cited as verification.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team handbook hosted by Sport Ngin; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF page 22: FRONT HEAD/COW CATCHER introduction, FH-CROSS DRAG, and FH-NEAR SIDE DRAG. Also read page 25's offensive BACKHAND and SHORT DRAG entries to distinguish roles.

**Supports:** Cross-body grip uses the held arm to reach underneath and across to the triceps.; Outside step, body turn, head clearance, and free-hand near-leg connection.; Separate shallow-arm near-side version uses a pushing action.

**Limits:** No individual author identified in the inspected handbook. Relative directions require mapping to a sided example. Text inspected; no demonstration video or movement frames inspected. Other forceful techniques in this handbook are outside this card.

**S2: [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF text: PDF pages 156-157, printed pages 155-156; Clearing Ties, item 6 Front head Locks, especially the two distinct elbow-pass and cross-hand drag options.

**Supports:** Distinguishes same-side elbow passing from the cross-hand drag.; Cross-hand drag combines elbow movement, hip angle, and head clearance.

**Limits:** Brief technical outline in an international-style development chapter, not a complete folkstyle practice script. Does not specify this card's hand-by-hand right/left example, drill timing, or current rules.

**S3: [Countering a Front Headlock with Dave Crowell - Nazareth Area High School (PA)](https://coachesinsider.com/wrestling/countering-a-front-headlock-with-dave-crowell-nazareth-area-high-school-pa/)** - Dave Crowell instruction published by Wrestling Coaches Insider; accessed 2026-09-26.

**Inspected:** Public article description and English auto-generated caption track for its embedded Vimeo video 772201057, duration 4:08; read full captions, using 0:20-1:25 for the drag-out and near-leg finish and 3:31-3:54 for elbow position.

**Supports:** A drag-out needs a meaningful step rather than arm pulling alone.; Connect around the leg during the go-behind to reduce step-over or circling counters.; Keep elbows close during the drag to reduce counter opportunities.

**Limits:** Caption transcript and article text inspected, not video frames. Auto captions have errors and do not establish exact right/left hand placement. Shoot-through and counterattack sections are not incorporated into this card.

<a id="a13"></a>

## A13 - Russian Tie Clear to Underhook

**Tier:** Advanced | **Previous name:** Two On One To Underhook Chain

### Technical review

The original intended to teach changing ties after a first attack closes. Its follow-to-single and pull-free-to-underhook branches were not established by the cited general curriculum. Following a Russian alone does not specify A01's foot-block single, and withdrawing a wrist while squaring up does not necessarily open an underhook. The draft also omitted which hand would enter and which arm would be underhooked. The replacement deliberately changes tie ownership: the partner has the Russian, and the learner clears it into an underhook. This is a documented related transition, not a claim that the draft's offensive chain was verified.

### Selected variant

College Park's Lift His Far Elbow to Near Underhook is the selected counter [S1]. The partner holds the learner's right arm; the learner's free left hand lifts the partner's right elbow, belonging to the wrist-gripping arm. The freed right hand travels down and across into an underhook beneath the partner's left arm. The learner's elbow lift and arm withdrawal create the opening in response to the existing Russian. There is no invented partner pull-free reaction. The lesson stops at the standing tie.

### Mechanics and evidence

- College Park directs the free hand to lift the opponent's far elbow up and away, then bring the trapped hand down and across into the near underhook, with head position beside the opponent's ear. That is the selected clearing action. [S1]
- USAW independently identifies the elbow of the arm holding the wrist as a route to freeing that wrist and obtaining an underhook. Its pull-elbow option corroborates the hand-identification principle, not College Park's exact upward direction. The card retains one method rather than combining elbow lift, hand chop, and elbow pull. [S2]
- Ciasulli explicitly teaches the right-hand wrist grip and left-hand support beneath the partner's right armpit, with both palms up. Reversing learner/partner roles supplies this starting Russian. A01 was read and uses the same configuration; its ankle block and single finish are excluded. [S3]
- College Park's underhook introduction specifies a shallow hand near the middle of the back, head on the underhook side, and a wrestling stance. Facing the partner with uncrossed feet and releasing the helper's elbow contact after clearance are teaching additions. [S1]
- A02 was read: its right underhook targets the opponent's left arm, but uses a deeper shoulder grip and a separate knee block. A03 was read: its left-underhook pummeling drill has different head placement and a specific pummel reaction. Neither attack is appended here.

### Teaching progression

- Identify ownership first: the partner has the Russian, and the learner has one free hand. Trace the wrist-gripping hand back to its elbow before moving.
- Begin with light grips and rehearse only elbow lift and hand clearance. The receiver lets the wrist grip slip as the action succeeds rather than maintaining a maximal squeeze. Do not peel fingers or abruptly rotate the arm.
- Add the right-arm swim and foot adjustment. Freeze at the underhook to check middle-back contact, inside head position, and balance. The receiver follows small steps and stays upright.
- Progress to the accessible-or-tucked elbow choice. Tucking occurs before the lift; an inaccessible elbow means reset. Repetitions, bounded resistance, pause, and release are proposed coaching organization, not research-established training doses.

### Common mistakes and corrections

- Lifting the upper-arm-control elbow does not address the wrist grip: point to the actual wrist-holding hand, then trace that arm to its elbow.
- Swimming under while the hand remains trapped twists the learner's shoulder: separate the rehearsal into loosen, clear, and enter until smooth.
- Leaning sideways with crossed feet sacrifices balance: pause after clearance, face the partner with short steps, and recover the stance before completing the tie.

### Readiness and rules

Advanced denotes readiness, not age permission. Athletes need painless pummeling and reliable release. The receiver cooperates with clearance and remains standing. This exercise does not establish a takedown, award points, teach a submission, or require a throw. Historical scoring and rule discussions in the manuals are not adopted; a competitive continuation needs separate instruction and the applicable event rules.

### What changed

- Changed the unsupported offensive chain to a sourced defensive Russian clear.
- Named the tie owner, trapped right arm, free left hand, wrist-gripping elbow, and resulting right underhook.
- Explained that the learner creates the opening by clearing the grip.
- Removed automatic single-leg and knee-pick branches.
- Added receiver behavior, a standing endpoint, and an early tucked-elbow reset.

### Evidence limits

S1-S2 were independently read as cached page-marked PDF text; S3 as full accessible coach-authored page text. S4's full publisher article describes an offensive double-overhand-to-underhook transition but does not specify every handed detail. Selected public-video frames around 0:19-0:20 and 0:49-0:50 were inspected, with some small-hand contacts obscured and no audio or transcript reviewed. These do not verify the draft's follow/square single-or-knee-pick chain, so the fully described defensive clear was chosen. S5 supplies general original coach explanations, not the missing offensive hand sequence. The handed example, foot-facing completion, pause, bounded reaction, and drill dose are explicit teaching adaptations.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text: PDF p.22 Russian 2 on 1, Lift His Far Elbow to Near Underhook; PDF p.17 Underhook introduction.

**Supports:** Free hand lifts far elbow up and away; trapped hand moves down and across into near underhook; Head on underhook side, hand near middle of back, and wrestling stance

**Limits:** No handed illustration inspected. The card translates near/far labels into S3's explicit right-arm Russian. The shallow underhook is selected; unrelated throws and rule statements are excluded.

**S2: [USA Wrestling Coach Guide to Excellence, 2nd Edition: Clearing Ties](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF p.157 / printed p.156, Two-on-one clearing options B-C and surrounding Clearing Ties introduction; official URL metadata checked.

**Supports:** Clearing the elbow of the wrist-gripping arm can free the wrist and lead to an underhook; Defense against an opponent's two-on-one

**Limits:** Brief technical outline. Elbow-pull and hand-chop alternatives are not blended with S1's upward lift. Historical rule commentary is not used.

**S3: [Two-On-One (Russian Tie), Lesson 6](https://www.sethciasulli.com/lessons/two-on-one-russian-tie)** - Seth Ciasulli / Spark Wrestling; accessed 2026-09-26.

**Inspected:** Full accessible lesson, especially Offense describing right wrist hand, left palm beneath the partner's right armpit, palms-up orientation, and outside angle.

**Supports:** Exact Russian starting contacts used by the receiving partner; Distinguishes the palms-up Russian from a double-overhand two-on-one

**Limits:** Provides the initial tie, not the selected clear. Linked member-only attacks were not accessed.

**S4: [Greco Roman Throw by with Pat Smith](https://fanaticwrestling.com/blogs/news/greco-roman-throw-by-with-pat-smith)** - Fanatic Wrestling, publisher of Pat Smith's instruction; accessed 2026-09-26.

**Inspected:** Full article. Selected paused frames around 0:19-0:20 and 0:49-0:50 of its public demonstration, https://www.youtube.com/watch?v=v_qe91aF3U8, including frame stepping near initial contact; no audio or transcript.

**Supports:** A separate offensive double-overhand two-on-one to underhook exists; Described whizzer response occurs after acquiring the underhook

**Limits:** Alternative assessed but not selected. Hand contacts are partly obscured; the text does not verify the draft's lost-wrist-to-knee-pick chain. Throw and scoring claims excluded.

**S5: [Lindland & Bisek Technique Series: Using a 2-on-1 Effectively](https://fivepointmove.com/greco-roman-technique-videos/lindland-bisek-technique-series-using-2-1-effectively/)** - Five Point Move; original technique series with Matt Lindland and Andy Bisek; accessed 2026-09-26.

**Inspected:** Full article, especially Establishing Position at 1:27 and Lindland's 5:07 distance-before-reaching explanation; original Bisek comments read. Embedded video not viewed.

**Supports:** Offensive wrist-control, two-on-one, and underhook transitions coordinate feet and spacing

**Limits:** General offensive context only. Does not verify the original chain or supply the selected defensive elbow-lift mechanics.

<a id="a14"></a>

## A14 - Stand-Up Hand Fighting

**Tier:** Advanced | **Previous name:** Stand Up Clear And Reclear

### Technical review

The draft correctly placed hand control before the turn. However, its instruction to control a new waist wrist never specified which hand remained held, where the new arm entered, or why the turning direction remained valid. B17 and B21 establish bottom right hand to rider right hand, left-foot rise, forward hip separation, and a right facing turn. A14 preserves that relationship. The replacement clears the rider's still-unsecured left-hand entry while maintaining the original right-hand control. It does not claim to solve an established rear lock or an arbitrary hand change.

### Selected variant

A standing inside-control drill linked to B17's existing finish. The rider's right hand remains captured; their left hand reaches under bottom's left arm. Bottom uses a short left-arm sweep to guide that entry outside the left hip and reseals the elbow. This is the standing windshield-wiper principle described in the Human Kinetics excerpt [S1], with the outward clearing direction independently explained by Cary Kolat [S2]. It is a defined coaching application of those principles rather than a claim that either source publishes this entire sided combination verbatim.

### Mechanics and evidence

- The standing drill emphasizes bent knees, upright trunk and close elbows. The elbow-to-armpit region blocks the rider's route inside; chasing with extended hands opens that route. Its arm-wiping action restores the barrier against an entering arm [S1]. Thus the left elbow stays near the ribs while the palm and forearm redirect the reach, rather than swinging the entire upper arm behind the back.
- Kolat describes moving the rider's hands from beneath the arms to outside the hips, retaining useful hand control and keeping one's own wrists free [S2]. Here that becomes a left-side outward sweep against the free left hand. Neither a finger peel nor an unsupported swap onto the other wrist is introduced.
- The established exit remains right-to-right hand retention, hip clearance, then a right turn [S3]. USA Wrestling independently separates inside hand control, keeping an isolated hand away from the hips, and increasing hip separation [S4]. A successful left-arm clear does not remove the need to clear the right hip before rotating.
- The receiver supplies an incoming hand rather than a completed lock. The standing source resets after the rider wins inside control [S1]; this card uses that limit once a wrist or body lock is established. The reaching arm must remain free to follow the sweep.

### Teaching progression

- Start on the feet so the coach can inspect the hand assignments and the incoming arm's route. Demonstrate the left elbow opening as the error, then show the short sweep with the upper arm close. Freeze when the rider's left hand is outside the left hip, and check that bottom still owns the original right hand.
- Use three cooperative repetitions per partner before allowing one unannounced reach and one following step. The receiver stays behind and moves their feet without pulling the captured arm backward. Success requires a clear left side, restored hip separation and the familiar facing finish. These reaction constraints and counts are coaching design.
- Reconnect to the full inside-leg stand-up only after the standing action is repeatable. The extra demand is recognizing and clearing the new reach during a familiar escape, not learning another rise, hand exchange, or mat-return response. No A15 or A18 prerequisite is assumed.

### Common mistakes and corrections

- Letting go of the right hand to chase the new contact loses the established exit. Pause the repetition and verify right-to-right control before restarting the left-side reach.
- A large elbow swing admits the rider's arm. Reduce the motion to a forearm-and-palm sweep beside the torso and immediately restore elbow contact with the ribs.
- Turning as soon as the new hand is displaced leaves the original waist arm attached. Re-establish the B21 hand-and-hip clearance checkpoint before facing.
- Continuing after the rider wins a secure grip exceeds this variation. Reset instead of improvising a joint lever or dragging an anchored partner through the turn.

### Readiness and rules

Require painless independent balance and release on command. Success means rear control is gone, without a point-value promise. Separate hands and no returns are drill restrictions, not assertions that standing locks or returns are illegal. Event rules remain the coach's responsibility; historical scoring was not adopted.

### What changed

- Use the familiar name Stand-Up Hand Fighting.
- Replace an unspecified hand change with a visible left-hand re-entry and a short outward clear.
- Keep B17/B21's original right-to-right grip and right facing direction throughout.
- Define the endpoint and reset when the opponent has already secured a grip.

### Evidence limits

Inspected article and PDF text plus the standing inside-control illustrations; no video was watched. The wiping action is described in text, while the stills establish positions. Kolat discusses base work rather than this exact standing combination. The sided reaction, B17/B21 integration, safety limits and dosage are coaching design. The draft's unsubstantiated general hand-switch sequence was removed.

### Sources inspected

**S1: [Inside Control, from The Wrestling Drill Book, Second Edition](https://coachesinsider.com/wrestling/inside-control-article/)** - Human Kinetics; publisher-provided excerpt on Coaches Insider; accessed 2026-09-26.

**Inspected:** Full article text, especially Inside Control in the Standing Position; linked image panels a-b (sitemgr_wr-insidecontrol1.jpg) and c (sitemgr_wr-insidecontrol3.jpg) visually inspected.

**Supports:** Close elbows and standing posture deny inside access; Windshield-wiper arm action to recover inside position; Reaching for hands opens the elbows; Hand control precedes escape and secured inside control triggers a drill reset

**Limits:** Does not specify the A14 left-arm sweep and retained right-hand combination word for word. Still panels establish positions rather than a frame-by-frame arm path. Its separate locked-hand heavy drills are not adopted.

**S2: [Getting Off The Bottom by Cary Kolat](https://www.kolat.com/blog/getting-off-the-bottom-by-cary-kolat)** - Cary Kolat, KOLAT.COM; accessed 2026-09-26.

**Inspected:** Authored article text dated December 9, 2014, particularly sealing off and capturing hand control; linked videos were not inspected.

**Supports:** Push incoming hands from under the arms to outside the hips; Keep elbows tight while retaining hand control and freeing one's own wrists; Learn positional hand control before adding the escape

**Limits:** Article focuses on base work. It independently verifies the clearing direction and positional principle, not the entire standing sided sequence.

**S3: [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/)** - Bill Welker, The Wrestling Drill Book; Human Kinetics excerpt on Coaches Insider; accessed 2026-09-26.

**Inspected:** Full Setup, Action, Coaching Points and Common Error text; this article's illustration was not inspected.

**Supports:** Left-side rider and left-foot inside stand-up; Bottom right hand controls rider right hand; Left elbow denies the rider's free arm; Hip clearance precedes right turn while retaining the captured hand

**Limits:** Supports the established B17/B21 exit, not a general solution to changing hands or a locked rear grip. Its broad safety superlative is not adopted.

**S4: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached page-marked PDF text, pages 2-3, especially the Hip-Heist Drill at the printed video timestamp 23:48-24:21; video not watched.

**Supports:** Gain inside hand control during the rise; Keep an isolated hand away from the hips; Create hip separation before the escape action

**Limits:** Corroborates clearance principles. It does not prescribe this hand-fighting variation or the right-turn footwork.

<a id="a15"></a>

## A15 - Sit-Out to Stand-Up

**Tier:** Advanced | **Previous name:** Short Sit To Stand Up

### Technical review

The draft recognized a compact seat, hand control, and a rise, but left the supporting hand, captured wrist, feet, triggering reaction, and finish undefined. It could be read as a squat rise or a posted-hand knee-under stand-up. Those are distinct solutions. Its warning against leaning backward also needed to distinguish an uncontrolled backward fall from useful shoulder pressure. USA Wrestling's actual Short Sit to a Stand Up demonstration supplies the missing reaction: the rider drives forward, and bottom uses planted feet and back pressure to stand [S1]. The revised card teaches that direct rise. B18 remains an entry and seated checkpoint; this card adds a separate escape sequence.

### Selected variant

Direct short-sit stand-up, retaining right-to-right waist-hand control and a sealed left elbow [S2], followed by Welker's right-facing finish [S3]. This is a deliberately assembled teaching chain with compatible standing hand positions, not a claim that one source publishes the entire card. B17's inside-leg first step is not imported into the seated rise.

### Mechanics and evidence

- USA Wrestling explicitly changes from a square seated/rising base to staggered feet after standing, keeps the hips low, and clears hands before facing. The inspected frames show the seated, standing, and facing checkpoints; the narration explains the forward-pressure response [S1].
- Winning Wrestling Moves, printed page 116, gives a direct rise with bent legs, feet near the seat, waist-hand control, and the opposite elbow closed. Its short-sit section identifies right-hand control and a left elbow seal. This resolves the otherwise unspecified grip [S2].
- Weber's different knee-under option requires hand control on one side, a mat post on the other, and the posting-side knee sliding under the seat [S4]. That alternate support sequence is omitted rather than blended with a direct squat rise.
- Welker retains the rider's right hand while clearing the hips and turning right [S3]. The hand assignment matches this selected seated control. B21 already rehearses that finish. No compulsory crossing step, grip transfer behind the back, or left-turn exit is added. Foot adjustments must let the hips turn without fixing the knees beneath them.

### Teaching progression

- Show the entire chain, then rehearse the finish standing before adding the rise and finally B18's entry. A coach checks that the learner can lower to and rise from a squat without knee pain. The first partnered attempts begin seated so the new task is easy to see.
- Explain the rider's role: maintain light separate-hand contact, apply a gradual forward pressure through the torso, and follow upward using their own legs. They do not lift the learner or abruptly withdraw the supporting contact. Bottom contributes leg drive rather than hanging on the captured arm.
- First pause at two-foot support to check balance and the same captured hand. Then remove the pause. After three successful repetitions each, the rider delays the gentle forward pressure until bottom has established the seated position and grip. This creates a recognizable reaction without unrestricted riding. Repetition count, pressure limit, and pauses are coaching design.
- A persistent backward pull is outside this drill. Reset instead of insisting on the rise or improvising a roll. The source family includes other responses, but a single card should not bury them in an untrained rescue instruction.

### Common mistakes and corrections

- Feet too far ahead leave the learner trying to pull upward through the rider's arm. Reposition before starting; the rider should feel torso pressure rather than an arm yank.
- A high, narrow finish gives away balance. Check that the learner can stop on their own feet before adding speed.
- An early turn can trap the waist arm. Return to the B21 checkpoint, restore hand and hip clearance, and move the feet with the turn. If the partner's wrist bends or shoulder is dragged, release and reset.

### Readiness and rules

Advanced denotes readiness, not age permission. Require B18, B21, independent balance, and prompt release. This is folkstyle escape practice; standing alone does not demonstrate loss of control. No score value or current rule interpretation is asserted. Separate hands and no returns are drill restrictions, not universal legality claims.

### What changed

- Use the familiar name Sit-Out to Stand-Up.
- Make the rider's forward pressure the defined reaction.
- Select a direct rise and remove the incompatible support-hand/knee-under ambiguity.
- Specify right-to-right hand control, closed left elbow, planted feet, and a staggered standing base.
- Teach the compatible B21 facing finish and release endpoint instead of saying only clear contact.

### Evidence limits

Inspected S1's full automatic transcript and paused frames at 0:15, 0:20, 0:25, 0:30, 0:35, 0:40, 0:45, and 0:50. Caption errors are not used to infer unnamed limbs. S2 was inspected as coach-authored book text in a third-party OCR reproduction; its photographs were not inspected. S3 and S4 were read as full authored page text. Exact sided control comes from S2-S3, not an uncertain video hand detail. Finger manipulation and head-driving from historical instruction are not adopted. The restrained receiver behavior and assembled progression are coaching adaptations.

### Sources inspected

**S1: [Level 2 - Folkstyle Core Curriculum - Short Sit to a Stand Up](https://www.youtube.com/watch?v=hDrypwAVVaE)** - USA Wrestling, verified official YouTube channel; linked by its Folkstyle Level 2 curriculum; accessed 2026-09-26.

**Inspected:** Complete automatic English transcript, spoken material approximately 0:04-0:57 of the 1:06 clip; paused browser frames at 0:15, 0:20, 0:25, 0:30, 0:35, 0:40, 0:45, and 0:50. Official curriculum page also inspected to verify the link.

**Supports:** Rider's forward drive as the stand-up opportunity.; Foot pressure and shoulder back pressure during the rise.; Low hips, staggered feet after rising, and a facing endpoint.

**Limits:** Automatic captions contain errors. Paused frames are not a continuous viewing claim; exact hand assignment is established separately.

**S2: [Winning Wrestling Moves: Short Sit Directly to a Stand-Up and Short Sit-Out](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis, and Brooks Simpson; Human Kinetics, 1994; OCR reproduction hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Authored OCR text under printed page 116, Short Sit Directly to a Stand-Up and From a Short Sit-Out, Post Your Hand; printed pages 123-124, Short Sit-Out; compared printed page 117 stand-up finishes.

**Supports:** Direct rise and posted-knee-under variants are distinct.; Compact planted feet and right waist-hand control with the left elbow closed.

**Limits:** Third-party OCR can misorder text; photographs not inspected. Its alternative finish begins with a different captured hand and is not imported. Historical finger and head-driving instructions are omitted.

**S3: [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/)** - Bill Welker, The Wrestling Drill Book; Human Kinetics excerpt published by Coaches Insider; accessed 2026-09-26.

**Inspected:** Full article text, Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration not visually inspected.

**Supports:** Right-hand capture of rider's right hand.; Hips clear before turning right while retaining the captured hand.

**Limits:** Its entry is an inside-leg stand-up from base. Used only for the compatible standing finish here, not the short-sit rise.

**S4: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full authored article text, especially Step 5, Knee under stand up. Embedded Vimeo video not inspected.

**Supports:** The separate knee-under variant uses the knee on the mat-post side.; Distinguishes that variant from the direct rise selected for this card.

**Limits:** Comparison source only for the alternate rise; does not provide the selected card's full sequence or drill.

<a id="a16"></a>

## A16 - Short Sit to Switch

**Tier:** Advanced | **Previous name:** Short Sit To Switch

### Technical review

The draft correctly sought a compact seat and rear control, but its trigger was only that top stayed close. It named neither waist arm nor thigh, and clearing the waist hand before reaching removed this version's useful connection. An unspecified mat post also conflicts with wrist control. The revision starts at B18's seated checkpoint and adds a rider response, hand transfer, and B20 finish. Selecting an already learned switch from changing contact distinguishes this advanced task from repeating B20.

### Selected variant

Right-side short-sit switch against a retained right tight-waist arm, rider initially behind-left. Bottom transfers the rider's right wrist from the right hand used in B18 to the left hand used in B20. Bottom's left elbow stays at the ribs; the right elbow crosses the rider's right upper arm to reach inside the rider's right thigh. This reconciles both prerequisite cards without mixing switch variants.

### Mechanics and evidence

- Horaski-Garcia explicitly connects a sit-out to left-hand control of the partner's right wrist at the belly, a right-arm reach to the partner's right leg, lifting the seat, and turning right into the hips. Its sit-out review clears bottom's left elbow and brings both elbows inward. [S1]
- College Park identifies a tight waist as the switch opportunity and directs a pocket-level reach to the inside thigh, then raised hips and a heist behind. Together these sources support an available waist-and-thigh connection rather than proximity alone. [S1, S2]
- Winning Wrestling Moves specifically addresses the short-sit problem: the rider keeps the waist arm, but reaching the thigh is harder from directly in front; opposite-hand arm control reduces the rider's limp-arm opportunity. Its standard finish moves the hips away, lowers the rider's right shoulder, and scissors the left leg over the right. [S3]
- Welker confirms the standard left-side rider, right-side sit, between-the-legs reach, and finish behind. His stated error is reaching over the back. [S4] Weber supports a compact seated posture and active response to the rider, rather than remaining parked on the buttocks. [S5]

### Teaching progression

- First demonstrate the seated checkpoint from both viewing angles. Ask the learner to name the rider's waist wrist and thigh before touching either. Rehearse the right-to-left wrist transfer with feet supporting the torso; the former entry post is no longer fixed to the mat.
- Use three slow repetitions per partner, briefly checking the thigh connection and rear finish. The receiver follows with the knees and lets the torso turn; the waist arm must be able to slide free. Do not make a frozen shoulder the resistance target. These receiving instructions and the repetition count are coaching design.
- Next the rider retains light waist pressure or withdraws that arm before the reach. Bottom identifies the usable connection. Reset on withdrawal instead of stretching after a disappearing leg. This proposed assessment does not claim that withdrawal requires a reset in a match.
- Only after that choice is reliable should a coach connect other previously learned escapes. Require a stable finish behind the hips and the ability to release immediately; touching a thigh or merely facing the opponent does not meet this reversal lesson's endpoint.

### Common mistakes and corrections

- If bottom reclines or folds toward the knees, return to the short seat with the feet available to push. Weber's compact-position instruction is useful here. [S5]
- If the right hand lands on the back, pause and retrace the between-the-legs route. Do not compensate by reaching higher or farther. [S4]
- If bottom pulls while still seated, separate the connection rehearsal from the hip-lift rehearsal, then reconnect them slowly. The manuals require raised hips, not a stationary arm tug. [S1, S2]
- If the partner's shoulder stops moving, release rather than adding force. A blocked repetition is information about position and timing, not a reason to wrench the joint.

### Readiness and rules

Advanced means readiness for a response-based chain. It does not permit greater joint force. USA Wrestling's current folkstyle appendix uses NFHS scoring with modifications and directs officials to stop undue joint pressure, especially for 14U and younger. [S6] This card assigns no historical point value. End in ordinary separate-hand rear control; local event requirements still apply.

### What changed

- Kept the familiar name Short Sit to Switch.
- Replaced close-following alone with an identifiable retained tight waist and available thigh.
- Made the B18-to-B20 wrist transfer and both wrestlers' elbow relationships explicit.
- Removed the unexplained support-hand instruction and premature waist-hand clearance.
- Added hip separation, a named scissor, wrist release, and a concrete rear finish.
- Replaced fixed timed rounds and an unqualified stand-up choice with a focused rider-response drill.
- Named B18 and B20 individually as prerequisites; B19 is not required for this chain.

### Evidence limits

Manuals and authored page text were inspected; no photographs or videos are claimed. S3 has interleaved OCR columns, so only coherent passages were used. S1's wrist-loading wording is not adopted. The USAW coaching guide, PDF page 150, mentions the switch without verifying grips and is not mechanical evidence here. Release timing, receiving limits, and drill structure are teaching decisions.

### Sources inspected

**S1: [Wrestling Unit Block Plan, Lesson 23: Sit Out Switch and Counters](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 90-92: sit-out review, switch sequence, and closing cues; original 184-page PDF opened online.

**Supports:** Left elbow clearance and elbows-in seated position; Left hand on rider's right waist wrist; Right-hand leg reach, raised hips, and rightward finish

**Limits:** School teaching unit rather than a rule authority; its heavy landing and wrist-loading wording are not retained.

**S2: [College Park Wrestling Technique Handbook, Escapes and Reversals](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 31-32, especially the Switch and Sit Out/Turn Out rows; original 55-page PDF opened online.

**Supports:** Tight waist as a switch opportunity; Pocket-level reach to inside thigh; Raise hips and heist behind

**Limits:** Concise coaching notes omit exact wrist choice and receiver behavior. Unrelated holds and historical scoring are not adopted.

**S3: [Winning Wrestling Moves, Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics; OCR transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Using This Book left-side rider convention and printed pages 130-132: Switch From Referee's Position, Short Sit to a Switch, and adjacent limp-arm/reswitch text.

**Supports:** Retained waist arm and opposite-hand control in the short-sit variation; Hip separation, shoulder pressure, and left-over-right scissor

**Limits:** Third-party OCR has interleaved columns and errors; no photographs inspected. Used as coaching instruction, not current rule authority.

**S4: [Escapes and Reversals - Switches](https://coachesinsider.com/wrestling/escapes-and-reversals-switches-article/)** - Bill Welker / Human Kinetics; publisher-provided Wrestling Drill Book excerpt on Coaches Insider; accessed 2026-09-26.

**Inspected:** Public article text, standard Switch setup, action, coaching point, and common error; other named variants distinguished.

**Supports:** Left-side rider and right-side switch; Between-the-legs reach and rear finish; Hip-heist preparation and correction of an over-back reach

**Limits:** Text only; does not specify the seated wrist transfer.

**S5: [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full authored page text, especially Steps 1-2 and 5.

**Supports:** Compact sit-out posture and back pressure; Sealing the sides and actively responding from the seat

**Limits:** This page teaches other sit-out finishes; it does not independently specify this switch's arm or leg sequence. No video inspected.

**S6: [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Current online edition, last updated September 13, 2026; sections 25.5-25.8.

**Supports:** NFHS framework with USAW folkstyle modifications; Stopping undue joint pressure, especially for 14U and younger; State event modifications may differ

**Limits:** Folkstyle appendix supplies the safety framework, not detailed switch mechanics or all NFHS scoring definitions.

<a id="a17"></a>

## A17 - Reswitch

**Tier:** Advanced | **Previous name:** Switch And Re Switch

### Technical review

The draft correctly treated this as the original rider's answer to a switch and limited the drill to one counter. It did not identify which arm remains connected, which thigh becomes available, or when the response must begin. 'Sit to the open hip' and 'circle through your own switch' require the learner to supply almost the entire technique. The revision uses B20 as the incoming action and teaches the counter window explicitly. It also recognizes that B20's successful hip separation and arm clearance can remove that window: a reswitch is an available response, not an automatic answer to every switch.

### Selected variant

One right-side reswitch by a rider who started on the bottom wrestler's left. The rider's right waist arm remains available as the first switch comes around. The counter changes that connection to the opponent's right inner thigh, uses a left-hand post and right-hip sit-through, and finishes behind. It excludes the limp-arm defense, high-leg/stepover counter, standing switch, and continuous switching contest.

### Mechanics and evidence

- Winning Wrestling Moves locates the reswitch when the opponent is just beginning to come around on top; the original rider's right arm is already positioned for the response. Its finish deliberately separates the hips until the other wrestler's waist arm comes free, preventing another immediate reswitch. [S1]
- Bill Archer's Switch-Reswitch drill expressly preserves an inside-leg connection for the rider while the first wrestler comes behind. The original draft's 'accessible thigh' is therefore replaced by the right inner thigh in the selected sided example, rather than an over-back reach. [S2]
- The right-side switch mechanics in the book use a left-leg sit-through followed by a left-over-right scissor. College Park corroborates the inside-thigh reach, lifting the hips, and heisting behind. These mechanics provide the finish to the counter, rather than an arm pull from a seated position. [S1, S3]
- Paused frames in Weber's public demonstration show the left-side rider, the first switch's left-arm clearance, the rider's left-hand support and seated response, then a further stepover counter. This visually checks the transition; the card ends before the stepover sequence. [S4]

### Teaching progression

- First rehearse B20 with an ordinary cooperative receiver. Then show the difference between a waist arm that remains mobile and one already cleared or pinned. Ask the rider to identify the counter opportunity before adding speed. A completed first switch should not be undone by twisting a trapped shoulder.
- For the first counter repetitions, bottom deliberately leaves enough space and light wrist contact for the right hand to move to the thigh. Pause at the thigh connection and seated position. The rider should have a support hand, an unforced shoulder, and room for both knees to follow the torso. Bottom releases contact that would immobilize the turning arm.
- Connect one switch to one reswitch and stop behind. Then bottom varies when the switch starts and attempts the B20 hip clearance. If the arm clears first or the leg is unavailable, reset and identify the missed window. This defined reaction tests recognition as well as memorized movement. Three repetitions and the restricted exchange are proposed teaching design, not research-established training doses.

### Common mistakes and corrections

- A late counter becomes a reach or shoulder struggle. Reset to the moment the first wrestler begins circling, and verify that the waist hand can move freely before repeating.
- Sitting flat and hauling on the thigh leaves the hips behind. Rehearse the lift and leg scissor without a resisting partner, then reconnect the thigh grip. [S3]
- Finishing hip-to-hip leaves the partner connected for another counter. Mark the finish only when the waist arm has cleared and rear control is established. [S1]

### Readiness and rules

Advanced indicates readiness for a moving exchange, not an age exemption. Both wrestlers must release on request, move the knees with the torso, and avoid rigid posts. This card teaches folkstyle position and does not promise scoring for each temporary change in orientation. USA Wrestling's current folkstyle appendix adopts NFHS scoring with modifications and directs officials to stop undue pressure on the head, neck, or joints, especially for 14U and younger; local modifications may differ. [S5] The teaching boundary is deliberately earlier than pain or an official stoppage.

### What changed

- Renamed the card Reswitch, the familiar name for the rider's counter.
- Specified the left-side ride, right waist arm, right thigh, left post, right-hip sit and leg scissor.
- Defined the counter window and the conditions that close it.
- Added hip separation and arm clearance to finish the exchange.
- Specified receiving behavior and a timing/clearance reaction instead of unrestricted circling.
- Kept the switch and its supporting movement skills as prerequisites rather than requiring the different B19 escape sequence.

### Evidence limits

S1 and S2 are coach-authored books inspected through public third-party transcriptions; their photographs were not available in those text views. S3 was inspected in the cached page-marked PDF extraction. S4 was actually viewed as paused browser frames, approximately 00:12-00:19 and 00:22, with additional setup frames at 00:37; no audio or transcript inspection is claimed. That clip teaches a subsequent stepover and does not supply the card's completed rear-control finish. Hand placement and sided wording apply the documented right-side switch to the documented reswitch entry. Receiving limits, pauses, and restricted drill progression are original coaching design.

### Sources inspected

**S1: [Winning Wrestling Moves, Switches and Counters to Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics; public transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Printed pages 130-132 in the public text: right-side switch entry and leg scissor, Reswitch, Countering His Reswitch, and adjacent Limp-Arm-Out distinction.

**Supports:** Counter as opponent starts coming around while right arm remains connected; Right-side switch's left-leg sit-through and scissor; Separate hips to clear waist arm and prevent a second reswitch

**Limits:** Third-party OCR interleaves some columns; only coherent technical passages used. Book photographs not inspected. Historical rule statements not adopted.

**S2: [The Wrestling Drill Book, Chapter 1, Drill 11: Switch-Reswitch](https://pdfcoffee.com/88f82thewrestlingdrillbook-pdf-free.html)** - Bill Archer, in Bill Welker (editor), Human Kinetics; public transcription hosted by PDFCoffee; accessed 2026-09-26.

**Inspected:** Printed pages 20-21: complete Setup, Action, and Coaching Point text; chapter attribution to Bill Archer also inspected.

**Supports:** Inside-leg connection during the switch/reswitch exchange; Counter while the first wrestler comes around behind; Leg control rather than reaching over the back

**Limits:** Transcription lacks usable photographs and does not name each limb. The card's limited repetition drill is original design.

**S3: [College Park Wrestling Technique Handbook, Switch](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extraction, PDF page 32, SWITCH row.

**Supports:** Inside-thigh connection against tight waist; Raise hips and hip heist behind

**Limits:** Corroborates switch mechanics, not a separate reswitch explanation. Brief coaching notes omit detailed receiving instructions.

**S4: [Switch / Re-Switch to a Step Over Chain Wrestling](https://attackstylewrestling.com/stepover/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Public page and embedded Vimeo video 526241877, paused visual frames approximately 00:12-00:19, 00:22 and 00:37; slowed playback used for the initial exchange.

**Supports:** Left-side start and first switch arm clearance; Rider's support hand and seated reswitch transition; Distinction between reswitch and the subsequent stepover counter

**Limits:** Visual inspection only; no audio transcription claimed. Low-resolution clip continues immediately into a stepover and is not used as proof of a completed reswitch finish.

**S5: [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Current online edition, sections 25.5-25.8; page identifies update as September 13, 2026.

**Supports:** NFHS scoring with USAW folkstyle modifications; Stop undue head, neck, or joint pressure, especially for 14U and younger; State rules can differ

**Limits:** Safety and event framework, not technical instruction or the full NFHS definition of control.

<a id="a18"></a>

## A18 - Quad-Pod Stand-Up

**Tier:** Advanced | **Previous name:** Tripod To Hand Controlled Stand Up

### Technical review

The draft correctly sought a head-free rise with one supporting hand and one controlling the waist contact. However, it left the entry foot, rider's side, captured hand, and facing direction unspecified. Iron Faith Wrestling demonstrates a real hand-supported version [S1], using a side shift and sequential foot placement rather than the draft's generic walk-in. Quad-Pod Stand-Up follows the video's title and identifies the initial four-point support; the one-hand stage has three contacts. This is a sourced variant, not a head-post technique renamed after deleting head support.

### Selected variant

Use S1's left-side-rider demonstration: hands shift left, weight moves over the right hip, left foot plants, then right foot. Bottom circles while rising, keeps the left palm down, and takes the right waist hand toward the right back pocket before turning LEFT. B17, B21 and A14 were read: their forward hip clearance and RIGHT turn belong to Welker's inside-leg version [S4]. That turning instruction must not be appended to this entry.

### Mechanics and evidence

- At 1:29-3:32 both hands move toward the rider's side, then weight shifts over the opposite hip to free the inside foot. The left foot plants before the right knee leaves the mat. Circling occurs during the rise [S1]. No measured stride or mandatory pivot foot is invented.
- The left palm remains available to resist pressure from the rider's side while the right hand attacks the waist contact, 3:34-3:58. The right hand guides the captured hand behind the right hip; the short facing turn is left, explicitly explained at 5:08-5:47 [S1]. Frames around 3:51-3:58 show hand isolation, the posted hand leaving the mat, and separation through that turn. Release accompanies clearance; the card does not import B21's requirement to retain the grip until fully facing.
- At 6:47-8:08 the instructor distinguishes a low, bent-knee position from an extended, hand-heavy posture. Feet must support enough weight to free a hand; the approximately 7:25 frame confirms the intended posture [S1]. USA Wrestling separately distinguishes a hand-and-foot bear-crawl/tripod from a head-post shrug [S2]. Its switch finish is not used here.
- USA Wrestling independently teaches isolating a hand away from the hips and making hip space before escape motion [S3, PDF p. 3]. That corroborates the purpose of the clearance, not this exact sided sequence. The card uses light separate-hand contact and a whole-hand grip near the wrist as an explicit practice restriction; it does not reproduce S1's finger-peeling language or teach a locked-grip break.

### Teaching progression

- First demonstrate the hand-and-foot support without a rider. Check left-foot placement, then the right-foot rise, while keeping the head clear. Next rehearse the finish with a cooperative partner: right waist hand behind the right hip, short left turn, release at separation. Explain why this exit differs from the earlier right-turn stand-up.
- The rider follows on their own feet with separate hands, letting the captured hand travel without anchoring the wrist or shoulder. After three smooth repetitions, add one gentle forward push; bottom retains the left post and restores a bent-knee base. These limits and dose are coaching design. Reset for lost posture or hand freedom.

### Common mistakes and corrections

- Removing the left post before dealing with side pressure causes collapse: restore the palm and shift weight onto the feet before completing the turn [S1].
- Standing with straight legs and a low head leaves the hands overloaded: lower the hips through the knees and raise the chest. Stop if the head approaches support [S1].
- Spinning right from this back-pocket configuration takes the long route and lets the rider reconnect: pause after clearance and rehearse the shorter left turn [S1].
- Continuing to pull after the rider captures a wrist can trap the arm: release and reset. The source specifically emphasizes avoiding that capture [S1].

### Readiness and rules

Advanced denotes readiness, not age permission. Require painless wrists and shoulders, independent balance, and immediate release. The no-lock/no-return limits define this drill. No current scoring or locked-hands interpretation is asserted; a facing turn counts as drill success only after rear control is gone. The source's one-hand-on-mat rule shorthand, stalling commentary, advice about early starts, and match-percentage claims are not adopted.

### What changed

- Rename the move Quad-Pod Stand-Up and verify a genuinely head-free demonstration.
- Replace walking the feet toward the hands with the demonstrated weight shift and left-foot/right-foot sequence.
- Specify left post, right-to-right waist-hand control, right back-pocket clearance, and left facing turn.
- Keep this source variant distinct from B17/B21/A14's right-turn escape.
- Define release, a low facing endpoint, a limited receiver reaction, and resets for lost posture or captured wrists.

### Evidence limits

Inspected S1's complete auto transcript and the sampled frames listed below, not uninterrupted playback. S2's official article was retrieved directly after the web reader returned 403; both support variants were read. S3/S4 passages were inspected independently. S1 supplies the exact sequence; the others corroborate principles or distinguish variants. Whole-hand contact, the final low stance, resistance limits, and dosage are coaching design. S1's head-post recovery and locked-hands/mat-return branches remain outside this card.

### Sources inspected

**S1: [Quad Pod | Wrestling Moves](https://www.youtube.com/watch?v=c7QKJ1VBnTA)** - Iron Faith Wrestling, official coaching YouTube channel; accessed 2026-09-26.

**Inspected:** Full auto-generated English transcript, 0:02-12:12. Technique review concentrated on 1:29-3:58, 5:08-5:47, and 6:47-8:08. Browser playback frames inspected around 3:05, 3:15, 3:20, 3:40, 3:51, 3:56-4:01, 5:23, 5:28, and 7:25; the 3:57-3:59 finish was inspected with paused-frame stepping.

**Supports:** A head-free quad-pod stand-up with the rider on the left; Hands shift left, weight moves over right hip, left foot plants before the right-foot rise; Circle during the rise; left hand posts while right hand attacks the waist hand; Right back-pocket hand clearance followed by left turn into the rider; Low hips, bent knees, head and chest up, and avoiding trapped wrists

**Limits:** Auto captions can mistranscribe terms such as sealing. Sampled frames supplement the spoken sequence. Finger-peeling language, head-post recovery, locked-hands branches, early-start advice, percentage claims, and rule shorthand are not adopted.

**S2: [Chain Wrestling from Bottom](https://www.themat.com/news/2002/november/26/chain-wrestling-from-bottom)** - Ted Witulski, USA Wrestling; accessed 2026-09-26.

**Inspected:** Official article text retrieved through HTTP, especially the Tripod and Head Post/Shrug sections. Published November 2002. Article author metadata inspected.

**Supports:** Four-point support on two hands and two feet is described as a bear-crawl or tripod position; Head-post shrug is a separate position with a different support and pivot mechanism

**Limits:** Teaches motion into switches, not this stand-up's foot sequence, hand grip, or finish. Historical terminology is useful for distinguishing variants, not current rules.

**S3: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF text pages 2-3, including Push Back Drill and the Hip-Heist Drill at the printed video interval 23:48-24:21. Referenced video not watched.

**Supports:** Inside hand control during the rise; Isolate a hand away from the hips; Create hip separation before escape motion

**Limits:** Independent support for general clearance principles, not the exact quad-pod entry or left-turn finish.

**S4: [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/)** - Bill Welker, The Wrestling Drill Book; Human Kinetics excerpt on Coaches Insider; accessed 2026-09-26.

**Inspected:** Full Setup, Action, Coaching Points, and Common Error article text. Illustration not inspected.

**Supports:** B17/B21's distinct inside-leg variant uses right-hand capture, forward hip clearance, and right turn; The right-turn version retains the captured hand through facing

**Limits:** Comparison source only for the difference from previously audited cards; it does not establish the quad-pod's left-turn mechanics. Its broad safety superlative is not adopted.

<a id="a19"></a>

## A19 - Spiral Ride to Near Wrist

**Tier:** Advanced | **Previous name:** Spiral Ride To Wrist Control

### Technical review

The original's shoulder-area hold, hip hold, unspecified circle, and unspecified posted wrist cannot identify a reproducible spiral-to-wrist transition. A new post is not required: College Park collects the near wrist when the near elbow lowers. B24 already ends in near-wrist control, so A19 is not a new breakdown. Its distinct lesson is maintaining an established ride, timing the grip change without losing pressure, and retaining B25 control through a rebuild. Advanced describes this integrated practice demand, not a novel hold.

### Selected variant

The same left-side, under-upper-arm and far-inner-thigh spiral taught in B24, changing to left-hand-to-left-wrist control. Start after the spiral contacts are established, rather than reteaching the referee-position entry. Finish in B25's belly-down one-on-one, with the right arm around the waist. No claw, cross-wrist transfer, leg insertion, tilt, or half is added.

### Mechanics and evidence

- Spealler's spiral remains useful when a receiver resists full flattening. In his left-side example, top's right hand contacts bottom's right inner thigh, the left arm enters beneath the left arm, and chest pressure rises on the back. Feet circle left while arm and thigh pressures oppose each other. Thus top can continue riding before capture becomes available. [S1]
- Amine's published instruction places the base of the left hand beneath the biceps. That makes the draft's vague shoulder-area contact concrete and matches B24. Only this entry detail is borrowed; Amine's subsequent leg insertion is a different continuation. [S2]
- College Park collects the near wrist when bottom reaches the near elbow and defines near-wrist control as same-side hand to same-side wrist. Thus the left hand leaves upper-arm support for the left wrist. Retaining the other contact until capture is a teaching sequence chosen to preserve connection, not a separately quoted transfer instruction. [S3]
- Winning Wrestling Moves defines the controlling arm as underneath the receiver's arm and over the wrist. Its preferred way to bring that wrist underneath is to advance the receiver's body using leg drive. The card applies that B25 action after the change, rather than pulling the hand behind the receiver. [S4]
- Gable describes near-wrist capture during base building or following a jam; forward drive traps the wrist and circling retains it. This supports practicing a knee-under rebuild, but does not establish a compulsory post caused by the spiral. [S5]
- Kolat lists a spiral finish by circling to one-on-one and separates riding instruction for knees, belly, and transitions. This confirms the curricular connection; it does not independently verify hand placement. [S6]

### Teaching progression

- Check B24 and B25 separately first. Demonstrate from the receiver's left, naming both left arms and the right far thigh. Freeze at upper-arm support, wrist capture, and waist support so the hand change can be inspected.
- For cooperative receiving, bottom starts on hands and knees, lets the near elbow bend and lower with the pressure, and follows belly-down with the face clear. Top keeps the chest connected while changing one hand at a time. This yielding is a rehearsal role, not a claimed defensive tactic.
- Then bottom keeps the knees underneath or rebuilds after capture. Top follows without sitting back or increasing wrist torque. Success is a connected transition and retained belly-down ride; clearance or standing ends the attempt. The rounds, repetitions, and restricted reactions are coaching design.

### Common mistakes and corrections

- Chasing either posted wrist turns a defined sequence into an unsupported reach. Wait for the near elbow to lower and identify the left wrist; if it remains unavailable, retain the taught ride rather than manufacture the opening.
- Losing the chest during the change removes the pressure that made capture possible. Rehearse a pause with right-thigh contact retained until the left grip is established.
- Pulling only with the wrist hand while the receiver rebuilds can twist the arm. Advance with the feet and reconnect the shoulder pressure; release and reset if alignment is lost.

### Readiness and rules

Require competent pressure receiving, both prerequisite skills, and immediate release before adding resistance. Keep the thigh hand away from the groin, the arm path away from the throat, and the captured forearm in front of or underneath the torso. This drill excludes turns and arm-on-back work. No scoring, riding-time entitlement, or current legality conclusion is drawn from the historical manuals; competition applications remain subject to the event's rules.

### What changed

- Named the destination Near Wrist rather than unspecified wrist control.
- Replaced hip contact with the far inner-thigh contact and specified the upper-arm support, circle, releasing hand, and target wrist.
- Removed the invented requirement to create and catch a new hand post.
- Separated A19's timing and following lesson from B24's initial breakdown, retaining compatible B25 control.
- Specified cooperative receiving, the base-rebuilding response, the belly-down endpoint, and release.

### Evidence limits

Inspected prose and PDF text, not video playback or book photographs. Spealler's neck-contact option is excluded; College Park's combined spiral/claw entry requires variant selection. Amine corroborates arm support only. The exact transfer order and free-hand-to-waist sequence synthesize the cited controls. Evidence supports linked skills, not an advanced technique separate from B24/B25.

### Sources inspected

**S1: [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf)** - Chris Spealler / CrossFit Journal, Issue 69, May 2008; accessed 2026-09-26.

**Inspected:** Original PDF downloaded into memory and text extracted from pages 3-4; spiral paragraphs on page 3 and author biography on page 4.

**Supports:** Left-side arm and far-thigh relationship; Chest pressure, feet, circle direction, and opposing arm/thigh pressure; Spiral can retain value when a receiver resists full breakdown

**Limits:** Historical instruction. Neck-contact branch, scoring statements, and other moves excluded. Does not specify the wrist finish.

**S2: [How To Spiral Ride With Malik Amine](https://fanaticwrestling.com/blogs/news/how-to-spiral-ride-with-malik-amine)** - Fanatic Wrestling, publisher of Malik Amine's instruction; accessed 2026-09-26.

**Inspected:** Accessible article text, How To Spiral Ride section, especially lines 53-60 and the under-biceps hand-placement paragraph.

**Supports:** Base of left hand beneath the biceps; Forward arm and body pressure in the spiral entry

**Limits:** Publisher's written account rather than inspected video. Its leg-riding continuation is outside this card.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 26-28: TOP, SPIRAL/CLAW, NEAR WRIST, CROSS WRIST, and continuation context; original PDF also opened.

**Supports:** Far inner-thigh contact; Near-wrist collection when the near elbow lowers; Same-side wrist definition and shoulder pressure; Top position and waist support principles

**Limits:** Combined spiral/claw entry requires variant selection. Historical rules and advanced continuations are not adopted. Exact transfer order is a teaching synthesis.

**S4: [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis, and Brooks Simpson / Human Kinetics, 1994; transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Authorship and publication text; printed page 156, NEAR-WRIST CONTROL and The Near Wrist, web lines 8760-8784.

**Supports:** Under-arm, over-wrist definition of one-on-one; Leg drive moves the receiver's body over the captured wrist

**Limits:** Primary coaching text accessed through third-party OCR. Photographs not inspected. No thumb orientation or historical scoring claim adopted.

**S5: [Coaching Wrestling Successfully, Figure 7.20: Near wrist ride drill](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730)** - Dan Gable / Human Kinetics; transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Printed page 103, Figure 7.20 near-wrist caption, web lines 4690-4695; preceding jam-drill caption for context.

**Supports:** Near-wrist capture during base building or following a jam; Forward drive traps the wrist and circling retains it

**Limits:** Caption text inspected, not photographs. Does not specify a spiral entry or a compulsory defensive post.

**S6: [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf)** - Cary Kolat / KOLAT.COM, 2011; accessed 2026-09-26.

**Inspected:** PDF page 6, Top breakdown and riding listings, web lines 240-268.

**Supports:** Curriculum links spiral ride finish to circling into one-on-one; Riding curriculum includes following positional transitions

**Limits:** Curriculum listing only; not evidence for exact grips, footwork, or receiver response.

<a id="a20"></a>

## A20 - Claw Breakdown to Near Wrist

**Tier:** Advanced | **Previous name:** Claw Control To Wrist Ride

### Technical review

The draft's aim of progressing from upper-body control to a wrist ride was useful, as were separate hands, following the hips, and immediate release for throat pressure. Its defining claw instruction was not supported by the inspected coaching material: it reached over the near shoulder and cupped the far armpit. The selected claw instead enters under the near armpit and crosses the chest to the far shoulder. The draft also treated any posting hand as the target and never said which hand takes it. Releasing the claw at that arbitrary moment can surrender the upper-body control before a wrist is available. The revision supplies an actual breakdown and a specified near-wrist endpoint.

### Selected variant

Left-side spiral claw breakdown to left-hand/left-wrist control, following College Park's explicit SPIRAL/CLAW-to-near-wrist instruction. This is a deliberate variant selection, not a claim that every claw ride releases to the same wrist. Cox's published breakdown retains the claw for its own follow-up. Here the near elbow reaching the mat is the transition trigger, and the claw hand itself changes to the near wrist. The right hand starts at the waist, moves to the far thigh for the breakdown, then returns to waist support at the B25 endpoint.

### Mechanics and evidence

- College Park distinguishes near-shoulder and far-shoulder contacts in its combined spiral/claw entry, assigning the far shoulder to the claw. Cox's publisher explicitly describes the elbow-side arm going under the arm to the opposite shoulder, with fingers and thumb together. In the selected left-side example, that is left arm under bottom's left armpit to bottom's right shoulder. The upper-chest route must leave the throat clear; a shallow neck squeeze is not the intended contact. [S1, S2]
- The separate rear hand does not stay at the waist throughout this variant. College Park sends it to the inside of the far thigh. Cox likewise describes thigh contact and the elbow against the hip. The card names the right thigh and excludes groin contact, eliminating the original vague instruction to maintain unspecified waist contact. [S1, S2]
- Pressure comes from footwork and chest contact. Spealler's independently inspected spiral instruction describes circling left with the right thigh hand pressing backward to lengthen the base. Cox describes staying on the toes and moving toward the head during the claw breakdown. These are the shared lower-body mechanics; the claw's shoulder contact remains distinct from B24's shallow upper-arm contact. [S2, S3]
- College Park explicitly says to obtain the near wrist as bottom goes to an elbow and defines near wrist as same-side hand to same-side wrist. That fixes the transfer: left claw hand leaves the far shoulder only when it can collect the left wrist. It is not B22's right-hand/left-wrist cross-wrist catch. [S1]
- The near-wrist arm remains under bottom's upper arm with an over-wrist grip. The book recommends advancing bottom's body over the wrist using the legs. Returning the free right arm to the waist is the selected teaching endpoint, consistent with College Park's general waist-support principle and audited B25. [S1, S4]

### Teaching progression

- Show the left/right contacts with no pressure, then have the receiver confirm unobstructed breathing. Rehearse the right hand's waist-thigh-waist sequence separately from the left hand's shoulder-wrist change.
- Bottom initially allows the left elbow to bend and the forearm to lower, without a rigid post. Top follows with the chest rather than trying to collapse a locked elbow. Pause at the wrist catch to verify left-to-left control before advancing the body over it.
- After cooperative entries, use one slow attempt to rebuild the base as the defined reaction. Retain the B25 ride by following; a cleared wrist ends the repetition. The repetitions, restricted reaction, deliberate unloading, and reset conditions are proposed coaching design, not a researched training dose.

### Common mistakes and corrections

- Over-shoulder entry or pressure migrating to the throat: stop, remove pressure, and rethread under the near armpit to the far shoulder. If the athlete cannot maintain that route, return to B24 rather than forcing a tighter claw.
- Early release or wrong wrist: wait for the near elbow to lower and identify the two left wrists aloud. Keep the thigh and chest connections while changing the claw hand.
- Wrist-only tugging or sitting back: shorten the reach, restore toe pressure, and advance the torso over the wrist. Unload before the receiver retrieves the arm.

### Readiness and rules

Advanced denotes readiness for changing controls under pressure, not an age permission. Require successful spiral receiving and near-wrist release first. The card stops at grounded control and excludes tilts, arm-on-back turns, standing returns, and submission continuations. Throat clearance and the stop conditions are explicit practice constraints. Historical scoring and legality statements in the older materials are not adopted; current event rules remain the competition authority.

### What changed

- Renamed the card Claw Breakdown to Near Wrist so its entry and endpoint are clear.
- Corrected the claw from over-near-shoulder/far-armpit contact to under-near-armpit/far-shoulder contact.
- Defined the far-thigh hand, foot-driven breakdown, near-elbow trigger, and same-side wrist transfer.
- Distinguished the selected release from claw-retaining continuations and B22 cross-wrist control.
- Added receiving, an observable B25 endpoint, and an orderly release.

### Evidence limits

Read the relevant College Park cached PDF text and the actual public Cox publisher article, not only search snippets. Cox's embedded YouTube instruction could not be fetched, so no viewing or frame inspection is claimed. College Park provides the claw-to-near-wrist chain; Cox corroborates the entry and pressure but does not verify this wrist transition. Spealler verifies the spiral footwork and thigh action, not the claw grip. The readable book OCR verifies the near-wrist route and forward finish; its photographs were not inspected. Precise pressure magnitude and resistance dosage are not established by these sources.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public Sport Ngin-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked extracted text, PDF pages 26-28: TOP principles, SPIRAL/CLAW breakdown, NEAR WRIST, CROSS WRIST, and neighboring continuation context.

**Supports:** Claw contact at the far shoulder and separate far-thigh pry; Spiral/claw breakdown to near wrist as bottom reaches an elbow; Same-side near-wrist versus opposite-hand cross-wrist distinction; Foot-driven pressure and tight-waist support

**Limits:** Concise coaching handbook without a viewed demonstration. Does not spell out every hand-transfer frame; the named left-side example applies its same-side definition. Historical rules and subsequent turns are excluded.

**S2: [Claw Your Way to Victory with J'Den Cox](https://fanaticwrestling.com/blogs/news/claw-your-way-to-victory-with-j-den-cox)** - Fanatic Wrestling, publisher of J'Den Cox instruction; accessed 2026-09-26.

**Inspected:** Complete public article text, especially Hand Placement and Finishing the Ride. Embedded video was unavailable during attempted access.

**Supports:** Under-arm route to far shoulder, fingers and thumb together; Separate thigh contact and hip pressure; Toe-supported movement toward the head; Cox retains the claw after the breakdown for his follow-up

**Limits:** Publisher explanation of Cox instruction, not a viewed video. Does not teach the selected near-wrist transfer. Submission and front-headlock continuations are excluded.

**S3: [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf)** - Chris Spealler / CrossFit Journal, Issue 69, May 2008; accessed 2026-09-26.

**Inspected:** PDF downloaded into memory and extracted with pypdf; page 3, Breakdowns and spiral-ride paragraphs.

**Supports:** Left-side start, right hand inside right thigh; Chest pressure, rising onto feet, circling left; Backward action of the thigh hand lengthens the base

**Limits:** Describes a spiral ride, not this claw-to-wrist chain. No historical scoring or legal-start claims used; photographs not inspected.

**S4: [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics, 1994; transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Authorship/title text and printed page 156, NEAR-WRIST CONTROL and The Near Wrist; web text lines 8761-8784.

**Supports:** Controlling arm under the upper arm and over the wrist; Use leg pressure to drive the body over the wrist

**Limits:** Primary coach-authored text accessed as third-party OCR. No photographs inspected; does not establish a claw entry and is not current rule authority.

<a id="a21"></a>

## A21 - Near Wrist Tilt

**Tier:** Advanced | **Previous name:** Near Wrist Tilt

### Technical review

The original correctly connected wrist control with hip movement and kept the waist hand separate. Its decisive instruction, however, was to sit on an unspecified outside hip and draw the partner across a lap. That does not identify which thigh is supported, what prevents the hips escaping, or how the legs create exposure. It also leaves the wrist hand unidentified, allowing the learner to substitute a cross-wrist grip and accidentally perform the neighboring two-on-one card. The revision makes A21 a continuation of B25 and supplies a complete load, turn, and return.

### Selected variant

One-on-one hip tilt from the receiver's left side. Winning Wrestling Moves provides an explicit left/right example; USA Wrestling demonstrates the same family through a pop-and-chop entry. This card starts after the wrist has been acquired, so the breakdown does not need to be retaught. It selects the book's far-thigh/hip control and omits its alternative between-the-legs reach and subsequent counter combinations.

### Mechanics and evidence

- The wrist relationship remains left hand to left wrist. College Park distinguishes this same-side ride from right-to-left cross-wrist control, then describes adding the free hand at the triceps or forearm to create a two-on-one. A21 does not make that transfer or add that second arm grip. [S3]
- The book specifies right-hand control at the far thigh/hip, the receiver's left thigh seated on top of the attacker's left hip, and the attacker's right foot underneath the receiver's left leg. Raising that leg and drawing the far hip turns the pelvis and shoulders together; retaining the wrist restricts the receiver's inward turn. [S1]
- USA Wrestling's demonstration stresses retaining hip coverage before committing and shows the elevated leg and a crosswise finishing angle. Its return frames show leg support lowering as the receiver rolls back toward the mat and the attacker follows above. The card deliberately teaches that return before adding live resistance. [S2]
- No knee planted in front of the receiver's knee is imported from A22. Here the relevant support is the near thigh on the attacker's hip plus the opposite foot elevating that leg. Calling both actions simply a lap pull hides this distinction. [S1]

### Teaching progression

- First identify both athletes' left wrists and the attacker's free right hand. Have the coach inspect the arm route without body weight. A partner who cannot maintain a relaxed bent elbow or communicate a stop is not ready for the turn.
- Rehearse the loaded side position with the coach assisting the receiver's torso. Pause before exposure so the pair can show a supported pelvis, an aligned wrist, and space for the head. The receiver yields with the torso instead of bracing on the trapped arm or trying to bridge through the neck.
- Add the short tilt and reverse it immediately. Rehearse unloading the arm only after the receiver is supported on the mat. This isolates the return as a skill instead of treating release as dropping the partner.
- For the defined reaction, bottom widens the base before top sits. Top must recognize that the pelvis has not loaded and retain the ride or reset. Do not turn this early drill into a contest of wrist grip strength. Repetition counts, timing, assisted pauses, and the early defensive response are proposed coaching design.

### Common mistakes and corrections

- A visible gap between the hips: stop before elevation, return to the ride, and rebuild the load. More arm pulling does not repair missing body support.
- A foot hooked at a fixed ankle while the torso rotates: move support beneath the thigh and let the whole leg travel with its hip. This exercise uses elevation, not a knee-twisting leg entanglement.
- Trying to finish a failed load anyway: coach calls a reset before top falls onto their own back or drags the receiver through a trapped shoulder. Readiness means recognizing the unavailable turn as well as completing the cooperative one.

### Readiness and rules

Advanced denotes demonstrated readiness, not blanket age permission. Use a matched partner and direct coaching for the first loaded repetitions. This is a back-exposure exercise, not a promised pin or a prescribed competition point count. Keep the waist and wrist hands separate throughout. Current event rules govern scoring and officiating; the historical book's near-fall values and its more forceful neighboring arm-pry instructions are not adopted.

### What changed

- Kept the familiar Near Wrist Tilt name.
- Specified left-to-left wrist control and assigned the free right hand to far-thigh/hip control.
- Replaced the vague outside-hip/lap pull with left-hip loading and right-foot elevation of the receiver's left leg.
- Added a supported return and release, plus a blocked-load decision.
- Kept this one-hand wrist tilt mechanically distinct from A22's cross-wrist two-on-one.

### Evidence limits

The book's readable instructional prose was inspected through a third-party OCR transcription; its photographs were not inspected. USA Wrestling's actual video was checked using its exported auto-caption transcript and paused frames, not merely its curriculum label. Captions are imperfect, so the book supplies exact hand and leg assignments. The video supports the hip coverage, leg elevation, finish angle, and return principles; its pop-and-chop entry is not copied. College Park independently verifies grip terminology rather than the entire selected tilt. The slow unloading sequence and restricted partner drill are editorial teaching choices.

### Sources inspected

**S1: [Winning Wrestling Moves: Near-Wrist Control and Hip Tilt](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics, 1994; accessible transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Authorship and Using This Book orientation; printed pages 156-157, Near-Wrist Control, The Near Wrist, and Hip Tilt prose, including hip contact and leg-elevation details. Neighboring alternatives read for differentiation.

**Supports:** Exact left/right relationships; Far-thigh/hip hand control; Near thigh loaded on the attacker's hip; Opposite foot elevates the controlled-side leg

**Limits:** Primary coach-authored text reached through third-party OCR. Photos not inspected. Historical point values and unrelated arm-pry variants excluded.

**S2: [Level 2 - Folkstyle Core Curriculum - Pop & Chop to a Near Wrist Cheap Tilt](https://www.youtube.com/watch?v=jelOYSlTKtI)** - USA Wrestling, verified official YouTube channel; linked from its Folkstyle Level 2 curriculum; accessed 2026-09-26.

**Inspected:** Full exported auto-caption transcript, 0:04-2:39; paused demonstration frames at 0:48, 1:20, 1:36, 1:41, 1:46, 1:51, 2:01, 2:06, 2:11, 2:16, and 2:31. Curriculum page link independently inspected at https://www.usawmembership.com/usa_wrestling_core_curriculum/2.

**Supports:** Same-side near-wrist cheap-tilt family; Hip coverage before turning; Leg elevation and crosswise finish; Lowering support and following the receiver back toward base

**Limits:** Auto-captions contain errors. Paused frames and transcript were inspected; continuous audiovisual viewing is not claimed. The demonstrated breakdown is omitted from this continuation card.

**S3: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public Sport Ngin-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 26-28: Top principles, Near Wrist, Cross Wrist, outside and inside two-on-one descriptions, and adjacent top-control material.

**Supports:** Same-side near-wrist definition; Cross-wrist and two-on-one distinctions; Separate tight-waist support in top control

**Limits:** Supports terminology and control distinctions, not independent verification of all hip-tilt steps. Historical rule and scoring statements are excluded.

<a id="a22"></a>

## A22 - Two-on-One Tilt

**Tier:** Advanced | **Previous name:** Near Side Two On One Tilt

### Technical review

The draft correctly selected an outside two-on-one and a near-side knee-block tilt. Its hand assignment matches B22 and the handbook, and its bent-arm and hip-connection emphasis was useful. However, 'across your lap' and 'right leg beneath their thighs' concealed the decisive lower-body arrangement. Those phrases could produce two legs lying underneath the opponent without an effective block or lift. The draft also combined the front knee and grounded heel before explaining the sit, and its return was only an endpoint. The revision separates the legs' jobs, places heel-down/knee-up after sitting, and explains the return.

### Selected variant

A left-side, grounded near-side tilt with an outside two-on-one: the right hand keeps the left cross-wrist, the left hand keeps the same arm's triceps, the front left knee blocks, and the rear right leg elevates the far right thigh. This retains the original move family. It is separate from B25/A21 same-side one-on-one control, the inside two-on-one, a far-side elbow-in-crotch roll-through, and an arm-on-back tilt. No half nelson or foot-hook stack is included even though those are the continuations in the inspected Kolat clips.

### Mechanics and evidence

- College Park defines a cross-wrist as right hand to left wrist and an outside two-on-one as the free hand controlling that arm's triceps. Its near-side tilt uses the front knee ahead of the opponent's knee, then an upright knee and grounded heel. The rear leg provides elevation. [S1]
- Kolat's first clip shows the left-side entry and tilt. The front left leg remains bent with its foot on the mat; the rear right leg threads between the receiver's legs and raises the far thigh. The near hip remains supported close to the rider's seated hip while the opposite thigh lifts. These are observed limb relationships, not a grip-pressure prescription. [S2]
- The second clip provides another view: the rider stays tight over the captured arm, then maintains a planted front foot and elevated rear leg. At 0:30, the right leg visibly supports the receiver's upper/far thigh. It corroborates the assignment but is the same coaching authority. [S3]
- At 0:42-0:47 in the first clip, the receiver turns toward the belly and Kolat follows into top pressure. The card stops at that follow instead of importing the subsequent half. Its explicit lower-leg, ease-block, stabilize-and-release sequence is a conservative cooperative reset based on that transition. [S2]

### Teaching progression

- Demonstrate both hands before tilting. Name each wrestler's left arm and contrast the cross-wrist with B25's left-hand-to-left-wrist ride. Do not substitute A21's one-on-one.
- Show the supported side position before entry: front heel down/knee up, hips touching, rear leg under the far thigh, captured arm folded against the torso. The receiver turns torso and hips together without posting the trapped arm.
- Rehearse knee placement, sit, small elevation, and return slowly. The pair must stop at each stage without the receiver falling through a gap or the rider tipping onto both shoulders. Match size and receiving ability.
- The first reaction is early knee widening. Top recognizes whether the block and hip support are available; an unavailable entry ends the attempt. Repetition counts, this restricted reaction, and the staged release are coaching design.

### Common mistakes and corrections

- Hip gap: shorten the sit before turning; stronger arm pulling cannot replace support.
- Both legs flat underneath: rebuild left heel-down/knee-up, then identify the far right thigh before adding elevation.
- Receiver rotates against an immobilized arm: move torso and hips together; release for wrist bending or shoulder strain.
- Top stays seated during turn-down: lower the support leg and follow chest-to-back with knees underneath. Rehearse this before resistance.

### Readiness and rules

Advanced is a readiness tier, not an age permission. Require a coach-checked two-on-one, reliable side receiving, and immediate release before resistance. This is a folkstyle exposure lesson with separate holds on the opponent's arm, not a torso handlock or submission. The card does not prescribe near-fall seconds, points, or pin criteria; those depend on current event rules. Historical scoring and rule statements in the handbook are not adopted. A painful wrist, trapped shoulder, neck-loaded return, or unsupported fall ends the repetition.

### What changed

- Shortened the name to the familiar Two-on-One Tilt; the card identifies the near-side knee-block variant.
- Retained actual cross-wrist plus triceps control and explicitly distinguished it from A21/B25.
- Replaced vague lap/thigh wording with near-hip support, a planted front heel and knee block, and rear-leg elevation of the far thigh.
- Added a belly-down return, top follow, stable release, and an early base-widening reaction.

### Evidence limits

S1 was read as cached PDF-page-marked text, including the full control and near-side tilt passages. S2 and S3 were inspected as paused public video frames; no transcript was available for S2 and no audio listening is claimed. The Kolat member-library page redirected to login, so its indexed titles were leads only, not mechanical evidence. The two public videos share an instructor; the independently authored handbook supplies the second coaching source. A separate one-on-one hip-tilt passage in Winning Wrestling Moves was inspected for comparison but not used to transplant its near-leg lift into this two-on-one card. Exact practice dosage and the deliberately cooperative return are editorial teaching choices.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; SportsEngine-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached page-marked PDF text: page 27 Basic Control Positions/Cross Wrist, and page 30 Tilts/Near Side; adjacent variant descriptions read to keep their entries separate.

**Supports:** Cross-wrist and outside two-on-one definition; Front knee block followed by heel-down/knee-up position; Rear-leg elevation and close hip support

**Limits:** Terse coaching text without inspected photographs. It says rear leg elevates the legs generally; the exact far-thigh assignment comes from the public Kolat frames. Historical rule/scoring language excluded.

**S2: [Wrestling Moves KOLAT.COM 2 on 1 Tilt to Half Nelson](https://www.youtube.com/watch?v=fdNfeIm9Afw)** - Cary Kolat, verified KOLATCOM YouTube channel; accessed 2026-09-26.

**Inspected:** Public paused video frames at 0:19, 0:24, 0:29, 0:37, 0:42 and 0:47. Channel identity and description inspected; attempted transcript export returned no transcript.

**Supports:** Left-side entry and two-on-one tilt position; Planted front foot and upright front knee; Rear-leg elevation beneath the far thigh; Follow when the receiver turns belly-down

**Limits:** Frame inspection only, not audio or a full continuous viewing. The later half-nelson continuation is outside this card.

**S3: [2 on 1 Tilt to Foot Hook Stack - Cary Kolat Wrestling Moves](https://www.youtube.com/watch?v=SSt9rSh4-Nk)** - Cary Kolat, verified KOLATCOM YouTube channel; accessed 2026-09-26.

**Inspected:** Public paused video frames at 0:15, 0:20 and 0:30, focusing on the pre-stack tilt; video title, instructor and description inspected.

**Supports:** Close upper-body connection before the tilt; Different jobs of planted front leg and elevated rear leg; Far-thigh support visible in the 0:30 frame

**Limits:** Same coaching authority as S2, not an independent second source. No audio transcription inspected and no stack mechanics included.

<a id="a23"></a>

## A23 - Arm Bar Turn

**Tier:** Advanced | **Previous name:** Short Bar Arm Walking Turn

### Technical review

The original identified the useful components of a short arm-bar turn: bent attacking elbow, fist on the back, opposite wrist, and circling toward the head. Its prerequisites did not explain what the coach must check, and its receiving role was missing. The phrase about keeping the defender's forearm near the back could invite a wrist-on-back hammerlock instead of the intended forearm-under-upper-arm bar. Naming also needed repair: College Park explicitly separates its 'ARM BARS' section from a wrist-on-back 'BAR ARMS' series. This review selects the short arm-bar family and calls it Arm Bar Turn. Most critically, a foot route toward the head must not become a direction for forcing the elbow toward the head. The NFHS arm-bar interpretation makes that distinction explicit. The original's automatic release into chest-to-chest was not independently established as the demonstrated competitive finish, so it is now clearly identified as a staged teaching finish.

### Selected variant

Left-side short arm bar with the attacker's left arm and far right wrist held by the attacker's right hand, starting after a breakdown. The attacker circles around the head toward the defender's right side while the body turns across its width. The first learning version stops on the right side and releases the bar before completing chest-to-chest receiving. This is an intentional drill modification, not a claim that every competitive arm bar must be released at that instant.

### Mechanics and evidence

- Kolat's inspected frames show a bent bar arm with a fist anchored on the defender's back, the other hand controlling the opposite wrist, and chest contact above the hips. The bar supports the bent upper arm; the attacker does not use two hands to raise the captured wrist. The card gives a left-side example matching the demonstrated orientation. [S1]
- College Park describes insertion beneath the arm, a fist on the back, a flexed biceps, weight maintained on the opponent, and circling the head. Its arm-bar text independently corroborates these components. Its separate wrist-on-back series is not combined with this variant. [S2]
- The route is a small-footstep arc around the head, with the opposite shoulder kept down as the torso turns. A foot moving toward the head does not authorize lengthwise force through the arm. NFHS's December 2025 interpretation identifies across-body pressure as the legal direction and requires intervention when the elbow is driven toward or over the head. [S1, S2, S4]
- Horaski and Garcia describe hooking the elbow, slipping the fist onto the back, circling, and finishing after the opponent turns. Their free-hand posting and head-and-arm finish differ from the far-wrist version; neither is silently substituted into this card. [S3]

### Teaching progression

- Demonstrate the bar unloaded first. The coach checks upper-arm contact above the elbow, bent attacking elbow, fist on the back, opposite wrist, and space for the defender's whole torso to turn. Demonstrate the release before any complete turn.
- Bottom supplies the bent arm without being pulled into it, keeps the neck relaxed, and rolls shoulders and hips together. Bottom must not plant the trapped hand, wrench out, or bridge against a fixed arm during these first repetitions. Top unloads and releases immediately on a verbal stop or tap.
- Rehearse insertion, one or two circling steps, side-position pause, release, and chest-to-chest separately before linking them. Both wrestlers must perform the receiving and release consistently before the announced elbow-closing reaction is added. The repetition counts and short attempts are coaching design, not a research-established dosage.
- Use a flat starting position before adding entries from a breakdown. Kolat's written critique specifically emphasizes defeating the opponent's base before running arm bars; a partner rebuilding base is a reset here, not permission to force the turn. [S5]

### Common mistakes and corrections

- If only the elbow moves while the chest and hips stay planted, release and restore the turning angle; do not increase pressure to obtain compliance.
- If the fist slides toward the neck or the attacker's elbow straightens, stop and rebuild the short bar. Keep the fist on the back and forearm beneath the upper arm rather than reaching over the shoulder. [S2]
- If the entry is blocked, return to the established top position. Pulling the wrist farther behind the back changes the action and can load the shoulder instead of moving the body.

### Readiness and rules

Advanced denotes demonstrated readiness, not an age allowance. A qualified coach must directly supervise this shoulder-sensitive turn. The NFHS interpretation inspected is dated December 17, 2025 and specifically addresses how an arm bar can change from legal to potentially dangerous to illegal as its direction changes. It is substantially stronger authority than a historical coaching manual. No universal 90-degree threshold or automatic legality is asserted. The original double-arm handlock exclusion is not repeated as a universal rule: the same NFHS interpretation depicts some double-bar applications as legal, depending on pressure direction. This card simply teaches one single-bar variant. Event and age-group rules still govern use. [S4]

### What changed

- Renamed to the standard, concise Arm Bar Turn.
- Separated forearm-under-upper-arm control from the handbook's wrist-on-back bar-arm family.
- Defined the opposite hand, around-head route, across-body force, receiving role, and denied-entry reset.
- Replaced an unsupported automatic competitive finish with an explicit staged release and chest-to-chest teaching finish.
- Grounded pressure-direction limits in a recent NFHS interpretation.

### Evidence limits

The Kolat video had no available transcript. I inspected paused browser frames at 0:12, 0:22, 0:32, 0:37, 0:42, 0:47, 0:52, 0:57, 1:02, 1:07, 1:12, and 1:17; I do not claim to have heard its instruction. The manuals were read as page-marked text, not as illustrations. College Park's wording about driving toward the neck is not adopted literally because the NFHS interpretation gives a more precise directional boundary. The USA Wrestling guide cache did not provide a directly relevant arm-bar instruction, so no USAW mechanics citation is claimed. The full 2026-27 NFHS rulebook was not inspected. The staged release and drill progression are original coaching design.

### Sources inspected

**S1: [Arm Bar Turn - Cary Kolat Wrestling Moves](https://www.youtube.com/watch?v=JIs3jqGceME)** - Cary Kolat, verified KOLATCOM YouTube channel; accessed 2026-09-26.

**Inspected:** Paused browser video frames at 0:12, 0:22, 0:32, 0:37, 0:42, 0:47, 0:52, 0:57, 1:02, 1:07, 1:12, and 1:17; visible title and publisher. Transcript export reported none available.

**Supports:** Bent short bar with fist on back; Opposite wrist control; Chest contact and circling turn

**Limits:** Visual frame inspection only; no transcript or audio inspection. Does not establish the card's staged release as the coach's competitive finish.

**S2: [College Park Wrestling Technique Handbook: Arm Bars and Bar Arms](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling, team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF page 29, ARM BARS, RUN TO FAR SHOULDER, and BAR ARMS sections.

**Supports:** Fist on back with flexed biceps; Body weight and far-shoulder control while circling; Terminology distinction between short bar and wrist-on-back series

**Limits:** Historical coaching source, not current rules authority. Its neckward pressure wording is not repeated as a literal force instruction; additional finishes are outside this card.

**S3: [Wrestling Unit Plan, Lesson 27: Arm Bar Pinning Combinations](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF pages 106-108, arm-bar insertion, circling instruction, defense, and situation practice.

**Supports:** Hook-and-thread insertion; Circling toward head; Demonstration and practice in both roles

**Limits:** Different free-hand and finishing variant. Its historical rule and resistance statements are not adopted as present-day permission.

**S4: [NFHS Wrestling Weekly Rule Interpretations, December 17, 2025: Arm Bar](https://www.wiaawi.org/Portals/0/PDF/Sports/Wrestling/Weekly_Interpretations_9.pdf?ver=FhexPUWIRK1EbGgMkuUehA%3D%3D)** - NFHS; hosted by Wisconsin Interscholastic Athletic Association; accessed 2026-09-26.

**Inspected:** Complete extracted text of the three-page PDF, particularly page 2 single-arm-bar frames and page 3 double-arm-bar notes.

**Supports:** Across-body versus toward-head pressure distinction; Potentially dangerous progression and illegal over-head elbow forcing; Need for close official monitoring

**Limits:** Specific December 2025 interpretation; full 2026-27 rulebook and every youth event's modifications were not inspected. Illustrations were not visually inspected.

**S5: [Critique of the Week 11/03/09](https://www.kolat.com/blog/critique-of-the-week-110309)** - Cary Kolat, KOLAT.COM; accessed 2026-09-26.

**Inspected:** Coach-authored page text, Top section item 2, published on page February 14, 2015.

**Supports:** Defeat the bottom wrestler's base before running an arm bar

**Limits:** Written critique supports the prerequisite; linked library drills were not inspected and supply no additional claimed mechanics.

<a id="a24"></a>

## A24 - Near Wrist to Half Nelson

**Tier:** Advanced | **Previous name:** Cross Wrist To Half Nelson

### Technical review

The draft recognized a useful goal: change from wrist control to a half when the defender's response creates an opening. Its unspecified 'opposite wrist' and 'other elbow' did not describe a reproducible grip. B22 finishes on bottom's left with top's RIGHT hand on bottom's LEFT wrist. B26 uses top's LEFT arm under bottom's LEFT arm. Merely combining those instructions does not produce the opposite-wrist-and-half finish of B28, and the draft never explained a release, hand transfer, side change, or actual arrival on the back. The revision replaces the unverified cross-wrist transition with a documented near-wrist escape-to-half change. Both College Park and Daryl Weber explicitly teach using a wrist-roll escape to enter the half on the same arm that was controlled. The name now discloses that changed entry.

### Selected variant

Left-side near-wrist roll to left half nelson. Initially top's LEFT hand controls bottom's LEFT wrist, with the right arm at the waist. When bottom rolls the wrist free and opens that elbow, top releases the original wrist and follows that SAME upper arm into a left half. The right hand then takes bottom's right wrist for the familiar opposite-wrist finish. This is not a direct continuation of B22's unchanged right-to-left cross wrist. Establish the new starting control separately; no undocumented handoff is taught. It also differs from College Park's static near-wrist/far-half branch, which retains the original wrist and attacks the other arm.

### Mechanics and evidence

- College Park distinguishes same-hand/same-wrist near control from right-hand/left-wrist cross control. That distinction is essential here: the hand that starts on the near wrist must become the half hand after the wrist is released. [S1]
- Weber's Step 10 says to exploit the near-wrist roll by hooking the elbow and inserting a half from that side. College Park independently describes following the escaping arm at the biceps and entering a high half. The card requires an actually opened elbow; it does not claim every wrist escape creates one. [S1, S2]
- The half passes under the previously wrist-controlled left upper arm to the back of the head. Once that hand leaves the wrist, right-hand control of the opposite right wrist is anatomically compatible with the left half. College Park documents wrist-and-half finishing, while Cejudo's published instruction explicitly identifies left-side riding with a left-arm half. [S1, S4]
- Feet travel out on the half side and toward the head, producing a perpendicular angle. Chest pressure then turns bottom away from the attacker, onto bottom's right side; this is not an instruction to circle across the head to the other side. Deepening the half during the turn and settling chest across chest with a broad base supplies an actual finish. [S2, S3, S4]

### Teaching progression

- First distinguish the B22 cross wrist from this card's left-to-left near wrist by showing both stationary grips. Rehearse the new starting position separately before joining it to another breakdown.
- Bottom cooperatively rolls the wrist free and opens the elbow slightly; top follows rather than wrenching it upward. Pause at release, underarm entry, opposite-wrist capture and arrival on the back. The receiver lets shoulder and torso rotate together.
- Then offer two early responses: wrist roll with an open elbow, or elbow kept against the ribs. Only the first invites this change. Stop after one turn or continued ride; broad live counters are unnecessary at this stage. The repetition count and two-response task are original coaching design.

### Common mistakes and corrections

- Retaining the initial wrist while inserting the same hand is impossible. Freeze and identify the release before the upper-arm catch; do not repair the error by reaching the free hand across into an unrelated half.
- Chasing the escaped hand loses the opening. Follow the rising elbow instead, but reset if it closes before insertion. [S1, S2]
- Remaining parallel turns the action into arm or head pressure. Restore the same-side foot angle and chest contact before continuing; a stuck torso is a stop, not a reason to lift the defender's elbow farther. [S3, S4, S5]

### Readiness and rules

Require reliable wrist release, cooperative receiving and the B26/B28 finish before adding the reaction. The Advanced label does not authorize force or age-specific participation. NFHS's officials sheet identifies a half becoming potentially dangerous when the defender's elbow is forced behind the head and when joints approach their normal-motion limit. [S5] This historical official sheet is not a complete current event rulebook; use the event's applicable rules and referee judgment. No pin count, universal youth permission or rule exception is claimed.

### What changed

- Renamed the card Near Wrist to Half Nelson to disclose the researched replacement.
- Replaced the unsupported 'other elbow' trigger with the escaping wrist's same-side elbow opening.
- Specified original wrist release, left half, right-wrist finish, same-side foot route and right-side receiving.
- Separated the start from B22's incompatible unchanged cross-wrist grip and matched B26/B28's left-half finish.
- Added an actual pinning position and a defined no-opening decision.

### Evidence limits

S1 and S3 were independently read in cached, page-marked primary instructional documents. S2 is Weber's coach-authored article; S4 is the instructional publisher's written explanation of Cejudo. No linked or embedded video was claimed as watched. S1 and S2 substantiate the wrist-roll change; S1, S3 and S4 support compatible half finishing details, not a verified B22 cross-wrist hand transfer. Strong source phrases about forcing the head under the arm, straight-arm levering, forehead posting and maximum pressure are not prescribed. The named-side rehearsal, conservative receiving, stop conditions and drill dose are coaching adaptations.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text: page 13, Turns/Half Nelson; page 27, Basic Control Positions/Near Wrist and Cross Wrist; surrounding pages 12 and 26-28 for context.

**Supports:** Near wrist and cross wrist are different hand relationships; Wrist-roll escape followed at the biceps into a half; Separate near-wrist/far-half branch retains the wrist; Chest-to-chest wrist-and-half finish with wide feet and low hips

**Limits:** Compact coaching notes with several distinct variants. Does not establish a cross-wrist handoff into the selected change. Historical rules and aggressive force language are not adopted.

**S2: [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/)** - Daryl Weber, Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full accessible coach-authored article text, especially Step 10 Near Wrist Roll Half Nelson and Steps 1-3; later variants read to distinguish them from the selected turn.

**Supports:** Hook elbow as the near wrist rolls free and enter a half from that side; Keep weight forward; Drive to the opposite side and deepen the half during the turn; Chest-to-chest position and broad foot base

**Limits:** Article text only, not the embedded video or paid course. Does not prescribe this card's exact initial tight-waist hand or practice dose. Ear gripping, forehead posting and power/sweep/spike variations are excluded.

**S3: [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, complete PDF pages 101-104, including demonstration, same-side leg movement, receiving and situation progressions.

**Supports:** Underarm entry to back of head; Move feet out on half side until perpendicular; Chest-to-chest finish; Demonstration and cooperative rehearsal before defensive situations

**Limits:** Historical PE teaching unit; no specific wrist-roll entry. Straight-arm force cue and historical scoring are not used.

**S4: [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo)** - Fanatic Wrestling, publisher of Angel Cejudo instruction; accessed 2026-09-26.

**Inspected:** Accessible article text, Half Nelson section, browser lines 52-56; surrounding breakdown and arm-bar sections read to distinguish the instruction.

**Supports:** Left-side ride uses left-arm half; Elbow elevation and feet walking toward head; Chest-to-chest rather than belly-to-chest finish; Head up and hips down

**Limits:** Publisher's written explanation, not inspected video. Does not establish the wrist-roll transition or exact far-wrist acquisition.

**S5: [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf)** - National Federation of State High School Associations; hosted by Iowa High School Athletic Association; accessed 2026-09-26.

**Inspected:** PDF text on both pages, especially page 1 example 2 and Rule 5-20 normal-range definition. No photograph-inspection claim.

**Supports:** Half nelson may become potentially dangerous; Defender's elbow forced behind head threatens shoulder; Stop holds at normal joint-range limits

**Limits:** Official instructional sheet hosted in 2024, not a fully inspected 2026-27 rulebook or blanket authorization for every youth event.

<a id="a25"></a>

## A25 - Far-Side Cradle

**Tier:** Advanced | **Previous name:** Far Side Cradle

### Technical review

The draft selected the far knee, but did not describe a recognizable far-side cradle. Its unspecified arm around the head, contact kept away from the face, generic body turn and 'supported shoulder turn' concealed the decisive crossface-to-far-arm connection and pinning position. Unlike B29's over-the-head near-side cradle and drive away across the far hip, this card uses a crossface, the opposite knee, an own-wrist lock and a pull back toward top. Both hands remain occupied; they cannot separately support the receiver's head and shoulders. The repair gives the entire capture, turn, pin and release while making the compact starting opportunity explicit.

### Selected variant

Grounded crossface cradle from the opponent's left side, using their right upper arm and right knee. The leg-side right hand grips the attacker's own left wrist while the left hand retains the far upper arm. Top returns the hips behind bottom and draws bottom back, finishing beside/behind the shoulders with a knee at the side and a hook on the free leg. College Park's first X-Face Cradle finish is the principal sequence [S1]; independent Bemidji instruction corroborates the wrist connection, hips-back turn, bottom-knee and head finish [S2]. Sonnen's publisher explains why the supporting leg and hips must be cleared [S3]. The card starts with an available compact position; it does not prescribe forcibly folding a resistant partner.

### Mechanics and evidence

- The head-side arm crosses the face and controls the far upper arm, rather than passing under the near armpit as a half nelson. The illustrated textbook's text specifies a left crossface controlling the right arm above the elbow [S4]. In this left-side teaching example the right hand posts behind the far right knee. This hand is a block and then a scoop, not an ankle handle for twisting the knee [S1].
- Circle toward the head with body pressure while the far knee remains available. The right hand passes beneath the right knee and closes around the left wrist; the left hand keeps its upper-arm grip. College Park and Bemidji explicitly describe this retained-arm wrist lock [S1, S2]. A palm-to-palm cradle is another option in some sources, but it is not the chosen connection.
- Once connected, shift the hips back behind the opponent and pull the captured body toward top [S1, S2]. From the selected left side, the receiver first reaches the left hip, then the back. The side label is an explicit directional translation, not a quotation. Clear the leg obstructing the receiver's descent; sliding hips and shoulder away allows the opponent's shoulder to reach the mat [S3, S4].
- The finishing controls are the retained arm-and-knee lock, bottom knee against the side, head contact at the temple, and upper/rear leg hooking the free leg [S1, S2]. These are positional contacts applied gradually, not a knee strike or headbutt. The knee must not remain underneath propping the receiver up [S3]. Do not transplant B29's chest-to-chest forehead-on-mat finish into this cradle.

### Teaching progression

- Demonstrate the crossface path and wrist lock without turning. The coach checks face contact, clear breathing, inclusion of the far upper arm, and an already reachable knee. If either partner cannot remain pain-free, this lesson is not ready regardless of tier or age.
- Rehearse the final position separately with very light contact. Then connect the capture to the hips-back turn. Bottom follows onto the near hip/back and keeps the captured knee moving with the pelvis; the receiver does not brace a straight arm against the roll.
- Top pauses as the shoulders approach the mat so the coach can check that neither the attacker's shoulder nor thigh props the receiver up. Stop short of adding pressure if head, hip or knee alignment is lost. Remove the leg hook and knee pressure, open the wrist lock, and only then let bottom extend and rebuild base.
- After cooperative turns, allow one early defensive choice: extend the far leg before the clasp. This teaches recognition and abandonment of an unavailable lock. Post-lock escape battles and roll-through alternatives are deferred. The repetition counts, receiving instructions and staged release are coaching design, not validated training doses.

### Common mistakes and corrections

- A far-away reach encourages arm pulling and forced folding. Close the chest position with footwork; reset when the knee is still unavailable.
- Releasing the upper arm to grab only around the neck changes the selected hold. Rebuild the crossface-to-upper-arm connection before attempting the wrist clasp.
- Pulling back while the attacker's leg or shoulder remains under bottom prevents the pin. Clear that support and move the hips away before adding finishing pressure.
- Driving straight across as in a near-side cradle mixes finishes. Return hips behind the opponent and rehearse the documented pull-back path.

### Readiness and rules

Use direct coaching and matched partners who can receive a grounded hip/back turn and release immediately. No throat compression, striking crossface, forced neck flexion, knee torque or forced split of the hooked free leg belongs in this drill. Do not insert a half nelson into the head-and-leg connection. The current 2027 USAW Kids Folkstyle event page specifies NFHS rules with USAW modifications [S5], but does not adjudicate this particular cradle. The technique references are not current rules authorities; this audit makes no universal age permission or scoring claim. Coaches must apply their event's current hold restrictions and potentially-dangerous judgment.

### What changed

- Kept the familiar name Far-Side Cradle.
- Specified left-side top position, left crossface hand on right upper arm, right hand behind right knee, and right-hand-to-left-wrist clasp.
- Replaced the generic supported turn with a hips-back pull onto the near hip and back.
- Added leg clearance, shoulder clearance, bottom-knee contact, temple contact and free-leg hook at the pin.
- Separated an available-position rehearsal from forcibly manufacturing head-to-knee proximity.
- Added a complete release sequence and a limited early defensive reaction.

### Evidence limits

Inspected actual text in the College Park cached PDF, Bemidji public PDF, Sonnen publisher's article, and a public transcription of Winning Wrestling Moves. The textbook transcription has OCR limitations and its photographs were not inspected. The Sonnen embedded YouTube fetch was throttled; no video viewing or transcript inspection is claimed. S4 is corroboration of the crossface arm and clearance details, not the source of a different standing or hop-over entry. Manuals sometimes instruct forceful head-to-knee action; this card retains the documented lock and finish but begins with a cooperative, reachable opportunity. B29 was read for distinction only and supplies no evidence for this far-side variant. The exact release choreography and receiver progression are original teaching design.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook - X-Face Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; public team coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached extracted PDF page 28: cradle introduction and X-Face Cradle, Head to Knee, first grounded finish; page 29's Inside Cradle read to distinguish the families.

**Supports:** Far-knee block and retained crossface-triceps wrist connection; Hips move behind the opponent before pulling toward top/back; Knee placement at the back/hip and rear-leg hook on the free leg; Other kneeling, hop-over and suicide finishes are separate alternatives

**Limits:** Terse school coaching notes, without inspected photographs; historical rule/scoring remarks are not adopted. Forceful head-to-knee wording is not the rehearsal prescription.

**S2: [Bemidji Elementary Wrestling - Basic Move Progression and Scoring](https://cdn1.sportngin.com/attachments/document/0139/5030/_Coaches_Page__elementary_move_progression.doc.pdf)** - Bemidji Elementary Wrestling; accessed 2026-09-26.

**Inspected:** PDF page 3, Top position, item 3: the complete ten-step Crossface cradle or Farside cradle text, with adjoining near-side description for comparison.

**Supports:** Maintain the far-arm grip while clasping own wrist; Swing hips back before rocking the opponent over; Bottom knee at ribs, head at temple and elbows close at the finish

**Limits:** Primary program handout with sparse explanation; elementary branding is not individual readiness or current event permission. Historical scoring omitted.

**S3: [Far Side Cradle by Chael Sonnen](https://fanaticwrestling.com/blogs/news/far-side-cradle-by-chael-sonnen)** - Fanatic Wrestling, publisher of Chael Sonnen's wrestling instruction; accessed 2026-09-26.

**Inspected:** Full public article text, specifically the crossface paragraph and finishing paragraph. Embedded video was not watched; YouTube embed retrieval was throttled.

**Supports:** Crossface from near shoulder across to far shoulder/upper arm; Move back leg out of the way before pulling opponent back; Remove bottom leg from beneath opponent's hips, then put knee at side; Forehead pressure contributes to preventing the shoulder turning away

**Limits:** Publisher's explanation of its coach's demonstration, not a verbatim transcript. Its painful-pressure rhetoric and forced folding are omitted.

**S4: [Winning Wrestling Moves - Far-Side Cradle and Cross Face Cradle](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics; public transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Text transcription of printed pages 158-160, especially Cross Face Cradle: If Your Opponent Is Flat on the Mat, and the preceding finish/shoulder-clearance paragraph. Also page 141's crossface definition.

**Supports:** Left crossface controls opponent's right upper arm above elbow; Right hand posts between legs and grips own left wrist while arm control remains; Allow the opponent's shoulder to slide off the attacker's shoulder onto the mat; Move hips and shoulder out from underneath to complete the pin

**Limits:** Coach-authored primary instruction reproduced on a third-party OCR site. Photographs were not inspected. Standing, hop-over and rolling alternatives were read but are not combined into the selected entry.

**S5: [2027 USA Wrestling Kids Folkstyle National Championship - Rules](https://usawrestlingevents.com/event/2700004502/rules)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Current public event rules page, Rules section specifying NFHS rules with USAW modifications and USAW age/weight/time precedence.

**Supports:** Event rules combine NFHS provisions with specific USAW modifications

**Limits:** One event's published rules, not a complete current NFHS rulebook or cradle-specific interpretation.

<a id="a26"></a>

## A26 - Near-Side Cradle Decision Drill

**Tier:** Advanced | **Previous name:** Cradle Finish And Early Defense Chain

### Technical review

The original blends prevention, finishing, and escape without a reliable transition rule. Turning a connected cradle while bottom continues wrist control invites an improvised locked-cradle escape. Choosing near or far cradles also changes the attacked leg, arm path, and finish. 'Supported turn' fails to identify support when both hands are occupied. The revision explicitly combines the audited B29 finish and B30 prevention into a coaching exercise with two separate outcomes and a release before resetting.

### Selected variant

Left-side near-side cradle, straight-over finish, and before-lock leg-back/hip-down defense. Facing the receiver's ribs makes top's left arm the head-side arm; the right arm encloses bottom's left knee. These labels apply the sources' relative positions to one teaching example. No A25 or far-side cradle dependency remains.

### Mechanics and evidence

- Weber locates the front elbow behind the neck and the rear elbow behind the knee and recommends a Gable lock [S3]. Human Kinetics places the clasp near the head [S1]. Hall defines palms together with the thumbs alongside the fingers [S5]. The head is held within the arm bend with the throat clear; the opposite loop contains the same-side knee.
- Applegate's early counter joins backward leg extension with lowering the inside hip, then requires hand control and the head up before returning to base. He specifically warns that extending the leg with the hip high exposes the other leg [S4]. The whole-hand/wrist catch on top's left arm is this drill's concrete implementation of hand control, consistent with B30, rather than a claimed verbatim grip prescription.
- The receiving branch keeps the near knee available without forcing head and knee together. Human Kinetics describes leg drive and chest action under the near shoulder [S1]; College Park directs the straight-over finish across the far hip into chest-to-chest contact, with the forehead posted and feet spread [S2]. Thus this left-side example moves bottom across the right hip, not backward into top's lap.
- Head clearance and knee clearance precede the defensive return to base. On the finishing branch, opening the clasp precedes unfolding. These separate release sequences prevent a defender from lengthening a leg while the head remains linked to it. No lock-breaking mechanism is taught.

### Teaching progression

- Demonstrate both outcomes separately. Name each athlete's left arm, hand, knee and hip. Confirm both recognize hands apart versus connected.
- For defense rehearsal, top offers one light reach. Bottom extends the foot close to the mat, keeps the other knee available for support, and catches the whole hand/wrist. After clearance, bottom posts and replaces the left knee. These support details are coaching implementation.
- For finish rehearsal, bottom cooperates. Coach checks neck and captured-leg alignment and top's learned forehead post. The torso and pelvis travel together without rigid arm posting. Stop if either wrestler loses the demonstrated contacts.
- In decision rounds, bottom gives the single early reaction or accepts the finish; top recognizes the available outcome. An unexpected connection triggers release. Counts, choices, and stop rules are original drill design, not a published standalone technique or tested dose. Mirror after consistency on the first side.

### Common mistakes and corrections

- Chasing the knee after it extends turns the drill into a different attack. Top releases both loops and resets rather than switching to the far leg.
- A high backward kick leaves the pelvis vulnerable. Rehearse a low foot withdrawal and near-hip lowering together before adding a hand catch.
- Pulling the head harder substitutes neck bending for body positioning. Move top's chest closer and use the documented leg-and-chest turn only when the clasp is readily available; otherwise reset.
- Rebuilding bottom base too soon puts the knee beside a still-wrapped head. Require the head and leg to clear first. On a locked finish, require top to open the hands before bottom extends.

### Readiness and rules

Advanced denotes demonstrated prerequisites, not an age-based permission. This exercise requires direct supervision and the B29 head-post readiness check. Top must release immediately for throat pressure, forced neck flexion, knee torsion or unstable neck loading. The stop at connection during attempted defense is a practice constraint; it is neither a claim that cradles are illegal nor a competition escape rule. No scoring, near-fall count, or universal event-legality claim is made. Historical coaching descriptions do not replace the governing event's current rules or an official's potentially-dangerous judgment.

### What changed

- Renamed the entry Near-Side Cradle Decision Drill to identify its actual role as a teaching exercise.
- Removed the near/far choice and dependence on an unspecified wrist-ride transition.
- Specified top's left head arm, right knee arm, bottom's left knee and hip, and the right-hip turning direction.
- Separated before-lock prevention from cooperative locked finishing, with an immediate reset for an unexpected clasp.
- Replaced the vague supported turn with the documented chest-to-chest finish and explicit release order.

### Evidence limits

Inspected Human Kinetics text and its nine-photo sheet, College Park page-marked text, Weber's article, Applegate's reproduced authored text, and Hall's grip explanation. No video was watched; Applegate's AI questions were excluded. Weber's separate defense PDF could not be retrieved and is not cited. Sources establish component mechanics, not this exact drill. Forceful entry wording, later locked-cradle counters, alternate finishes, and historical rules are excluded.

### Sources inspected

**S1: [Top Move: Cradle (Near-Side), Coaching Youth Wrestling Course](https://s3.amazonaws.com/my.llfiles.com/00224751/cradlens.pdf)** - Human Kinetics Publishers / American Sport Education Program, 2003; public course handout; accessed 2026-09-26.

**Inspected:** Complete cached one-page PDF text and the existing full-page rendered image, including all nine demonstration photographs and the final forehead-post/hip-adjustment frames.

**Supports:** Head-and-near-knee arm loops and clasp location; Leg drive, chest scoop and near-shoulder lift; Forehead post and hip adjustment at the finish

**Limits:** Historical instruction; does not verify current rules, precise left/right labels, or the decision drill. Forceful head-driven entry language is not adopted.

**S2: [College Park Wrestling Technique Handbook - Inside Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; coaching handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF pp. 28-29: cradle introduction, crossface-cradle distinction, and Inside Cradle / Bow and Arrow first finish.

**Supports:** Near-side head-and-leg capture; Direction over the far hip; Straight-over chest-to-chest finish with forehead post and wide feet

**Limits:** Terse team coaching notes with several different finishes. Only the first straight-over finish is used; no rule or scoring language is adopted.

**S3: [6 Step Near Side Cradle Series](https://www.attackstylewrestling.com/near-side-cradle-series/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Public article text, Steps 1-6; Step 1 supplies elbow placement and the recommended Gable lock. Embedded video not watched.

**Supports:** Front elbow behind neck and rear elbow behind knee; Gable lock for the cradle; Distinct finishes should not be conflated

**Limits:** Article's elbow-pounding entry language and barbell, crunch, high-leg, backbridge and elevated-leg finishes are not used.

**S4: [Basic Wrestling Fundamentals: Near Side Cradle Series; Countering a Nearside Cradle](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate)** - Warren Applegate; authored coaching text reproduced on Scribd; accessed 2026-09-26.

**Inspected:** Accessible authored text at printed pp. 58-59 and 62, web text lines 494-499 and 522-527, including the explicit before-lock subsection. Excluded the site's AI questions.

**Supports:** Early leg-back/hip-down defense; Hand control and head up before base recovery; High hips expose the other leg; Before-lock and completed-lock situations differ

**Limits:** Third-party text reproduction without inspected photographs. Exact two-hand catch is coaching implementation. Later locked-cradle escapes and forceful neck-loading instruction are excluded.

**S5: [Dubuque RTC 'Wrestling's Basic Truths' Part IV: Lifting](https://fivepointmove.com/greco-wrestling-training/hall-dubuque-rtc-volume-iv-lifting/)** - Dennis Hall's authored instruction, published by Five Point Move; accessed 2026-09-26.

**Inspected:** Article authorship statement and the Gable-grip paragraph under Lifting from the Stand Up Position.

**Supports:** Palm-to-palm grip with thumbs held alongside the fingers

**Limits:** Used only to define the shared hand grip; its lifts and mat returns do not support the cradle sequence.

<a id="a27"></a>

## A27 - Half Nelson Settle Drill

**Tier:** Advanced | **Previous name:** Pinning Control Angle Adjustment

### Technical review

The draft recognized that pinning depends on body position and responsive feet. However, it did not identify a hold, the retained arm, the receiver's anatomical turn direction, or foot travel. Generic instructions for turning toward and away could send top around a fixed head or across the receiver with high hips. This revision narrows the lesson to the documented low-hip half-nelson finish and one restrained roll-through attempt. It is a coaching drill, not a newly named canonical technique or an answer to every pin escape.

### Selected variant

A settling drill using B26/B28's left half and opposite-wrist finish. Receiver starts on the back and continues toward their own left side, slightly raising the right shoulder. Top retains both grips, widens the feet and lowers the hips back while preserving perpendicular chest contact. The receiving task and short backward steps operationalize the sources' finishing position; they are coaching design, not a published named counter.

### Mechanics and evidence

- College Park specifies a retained opposite wrist, perpendicular chest-to-chest position, wide feet and lowered hips. Those are the fixed checkpoints inherited from B28. Anatomical names remain constant after the turn: top's left arm includes receiver's left upper arm; top's right hand controls receiver's right wrist. The hands remain separate. [S1]
- The Human Kinetics illustrated sheet specifically connects lowering the hips on arrival at the back with preventing a roll-through. Its middle photographs show the top wrestler settling behind the chest, rather than continuing to carry the hips across the receiver. Later panels change to a reverse half; that additional grip change is not borrowed here. [S2]
- Cejudo's publisher distinguishes chest-on-chest placement from mistakenly putting the belly on the receiver's chest, and instructs the wrestler to keep the head up while sinking the hips. This supplies a head-up finishing model without requiring a forehead post. [S3]
- In this drill the chest remains over the upper torso while the feet move backward and apart, one short step at a time. The hips descend behind the chest; the top does not back so far that chest contact breaks. This makes the low, wide finish observable. It is a conservative rehearsal choice, not a source-verified guarantee against a forceful roll.
- The receiver makes one small whole-body rotation toward their anatomical left; the right shoulder rises first. They stop at initial resistance. There is no planted-head bridge, explosive roll or opposite-direction escape. If they reach their side, the repetition has exceeded its intended problem and ends.

### Teaching progression

- Demonstrate B28's finish and identify all four arms before movement. Let the receiver feel a light settlement, then fully release. The coach checks that the torso bears the chest pressure and the shoulder can move with the body.
- First rehearse the foot-and-hip adjustment with a cooperative receiver. Then add the specified gentle leftward turn. Horaski-Garcia supports demonstration and cooperative repetitions before defensive situations; these particular repetitions and five-second rounds are editorial practice doses. [S4]
- Advance only after top can preserve chest contact without yanking either arm, and receiver can stop the drill promptly. Match partners by size and skill. Revisit B28 if the arm connection or basic finish is inconsistent.

### Common mistakes and corrections

- Carrying the hips across the receiver makes the top easier to roll. Restore the wide base and lower the hips behind the chest. [S2]
- Backing away until the chest peels off defeats the drill. Shorten the steps; the adjustment ends as soon as the stable chest-to-chest position returns.
- Trying to stop the roll by pulling the half harder can isolate the shoulder. Stop and reset if the receiver's trapped elbow is driven behind their head. NFHS specifically identifies that position as dangerous. [S5]

### Readiness and rules

Advanced is a readiness tier, not age permission or a reason to increase neck loading. This drill ends at a stable settlement or lost position, not a purported competition pin count. NFHS's illustrated sheet identifies normal-range limits and the half-nelson shoulder hazard. The current USAW Kids Folkstyle event uses modified NFHS rules; local youth restrictions still govern. A full current NFHS rulebook was not inspected. [S5, S6]

### What changed

- Replaced an abstract adjustment name with Half Nelson Settle Drill.
- Kept the audited left-half and opposite-wrist orientation.
- Replaced two unspecified defensive turns with one small anatomical-left roll attempt.
- Specified chest contact, backward/wider foot movement, hip settlement, unchanged arms and full release.
- Removed any implication that a new hold, reverse half, neck bridge or head post must be invented to finish the drill.

### Evidence limits

Read College Park and Horaski-Garcia page-marked manual text, the accessible Cejudo publisher article, the official rules material, and Human Kinetics' full one-page captions and nine photographs rendered in memory. No embedded video was viewed. The sources support the finishing components, not the draft's two-direction following rule. The restrained receiver response, small stepping sequence, stop threshold and dose are original coaching design. Human Kinetics' reverse-half conversion and head-lifting cues are not added as new actions.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook, Turns: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, PDF page 13, section 2(a); original public PDF also opened. Read retained-wrist, chest-to-chest, perpendicular, wide-feet and hips-down instructions.

**Supports:** Opposite-wrist half-nelson finish.; Perpendicular chest contact with a wide foot base and lowered hips.

**Limits:** Compressed coaching notes. Its reverse-half response to rolling out is a separate technique and is not silently merged into this drill.

**S2: [Top Move: Half-Nelson and Reverse Half-Nelson](https://s3.amazonaws.com/my.llfiles.com/00224751/halfnelson.pdf)** - Human Kinetics, Coaching Youth Wrestling Course, 2003; accessed 2026-09-26.

**Inspected:** Full one-page PDF text and all nine photographs; downloaded to memory, rendered with pypdfium2 and visually inspected. Middle row establishes hip lowering during arrival on the back; later row introduces reverse half.

**Supports:** Lowering hips while reaching chest-to-chest position helps prevent roll-through.; Low hips, head up, spread feet and perpendicular chest contact as finishing principles.; Half and reverse half are distinct actions.

**Limits:** Later photographs use a reverse half. They do not independently establish the selected wrist grip or the designed receiver response and backward stepping drill.

**S3: [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo)** - Fanatic Wrestling, publisher of Angel Cejudo instruction; accessed 2026-09-26.

**Inspected:** Accessible article text, Half Nelson section, lines 52-56 in current browser extraction.

**Supports:** Same-side underarm half-nelson route.; Chest-to-chest rather than belly-to-chest finish.; Head-up position while lowering hips.

**Limits:** Publisher explanation inspected; embedded video was not viewed. Does not prescribe this drill or its reaction.

**S4: [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia, PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 101-104; demonstration, half-nelson mechanics and cooperative-to-defensive practice instructions.

**Supports:** Underarm route and perpendicular chest-to-chest finish.; Demonstration and cooperative repetition precede defensive situations.

**Limits:** Historical PE curriculum, not current rules. Its stronger head-lever language and live-practice doses are not adopted.

**S5: [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf)** - National Federation of State High School Associations; hosted by Iowa High School Athletic Association; accessed 2026-09-26.

**Inspected:** PDF page 1 text, example 2 and Rule 5-20 normal-range definition; page 2 general dangerous-position text.

**Supports:** Half nelson becomes dangerous when the trapped elbow is forced behind the head.; Legal holds can become potentially dangerous at joint-range limits.

**Limits:** Official instructional sheet hosted in 2024; not a complete 2026-27 rulebook. Text inspected, no claim of inspecting its photographs.

**S6: [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Rules section, including 2026-2027 girls provision and NFHS rules with USAW modifications, lines 37-54.

**Supports:** Current event-specific folkstyle framework uses modified NFHS rules.

**Limits:** Does not replace a complete event rulebook or establish universal youth permission for a hold.

<a id="a28"></a>

## A28 - Cross-Wrist Clear

**Tier:** Advanced | **Previous name:** Two On One Clear To Base

### Technical review

The draft recognized the correct goal, early timing, compact elbow and broad base, but its decisive grip break was missing. Covering an unspecified controlling wrist, moving the hips away and sliding the captured hand toward a hip does not explain how the cross-wrist plus triceps restraint opens. It also combined an early clearance with an undeveloped late tilted recovery. Those omissions matter because the rider can load the hips while bottom changes height or rotates against the trapped arm. Retherford's public instruction supplies an actual early elbow scrape from the matching near-side two-on-one setup. The revision keeps the same defense family, names both wrestlers' limbs, replaces the unsupported hip-away slide, and finishes by sealing the freed elbow rather than exposing the wrist again on a straight post.

### Selected variant

Early cross-wrist elbow scrape on the knees against a left-side outside two-on-one. Top's right hand holds bottom's left wrist and top's left hand cups the left elbow/triceps area. Bottom's free right elbow/adjacent forearm attacks the gripping right wrist; the bent left arm returns to the left side and seals palm-up. This is before top sits into the A22 tilt. It is not a roll-out, a defense after exposure, an inside-bar escape, or Sioredas's opposite-side cross-wrist variation.

### Mechanics and evidence

- College Park defines the outside two-on-one as a cross-wrist, specifically right hand to left wrist, plus the free hand on the same arm's triceps. That identifies the B22/A22 restraint being defended and distinguishes a same-side near-wrist hold. [S1]
- Retherford's transcript at 0:25-0:59 rejects getting extended or letting the opponent load the hips. It prescribes a broad, low base and positioning the free elbow in front of the gripping wrist before the roll. Frames at 0:40, 0:50 and 0:55 show the left-side rider, bent captured left arm and free right arm. [S2]
- The right elbow comes back from its forward support position to the gripping wrist. The adjacent forearm makes the contact; the release is a short scrape while the left arm remains bent. Frames at 1:00-1:01 and 2:00-2:01 show the captured left hand returning toward its own side as the right grip opens, followed by the left elbow returning inside. This is not a forceful elbow blow or an isolated wrist twist. [S2]
- At 1:03-1:23 Retherford explicitly keeps the elbow seal and palm up to discourage recapture. At 1:49-2:00 he repeats the low, wide-knee position and warns that rising to reach the wrist lets top roll. The knees stay grounded during the clearance; there is no standing step or deliberate hip escape before the grip opens. Exact toe angle is not a documented requirement. [S2]
- Sioredas independently uses the free elbow/forearm against the gripping wrist in a push-pull cross-wrist release and warns against letting the captured arm extend. His demonstrated rider has switched to the opposite side and bottom briefly turns toward the side, so those positioning details are not imported here. [S3]

### Teaching progression

- First demonstrate the B22 hand assignments without pressure. Have bottom identify the free right arm and point to the rider's right wrist. Check the difference between attacking that wrist and merely grabbing the triceps hand.
- Rehearse low, wide knees and a bent captured arm. Top stays kneeling and supplies a light whole-wrist grip. Bottom establishes elbow/forearm contact before applying the small scrape; top allows the grip to open without wrenching the shoulder.
- Pause immediately after release to check left palm up, left elbow at ribs, and top's left arm outside. The endpoint is improved bottom position, not a scored escape. Progress to an already learned escape only after hand control returns.
- The proposed reaction is grip tightening or one attempted recapture. Stop and reset when top begins loading a tilt. This isolates the verified early defense; three repetitions and the limited reactions are coaching design, not research-established doses.

### Common mistakes and corrections

- Chest rises while the right elbow searches: set the elbow contact from the low knee base first. Do not solve the reach problem by climbing onto the rider's hips.
- Captured arm straightens: reset the left elbow bent and close before the scrape. Pulling a long arm harder gives top more leverage and loses the compact position.
- Bottom escapes the grip but immediately posts the left palm down far ahead: return palm-up elbow seal first, then hand fight. An immediate extended post gives the rider another wrist target.
- Bottom turns the trunk away while the left arm remains trapped: remove the hip-away instruction. In this variant the gripping wrist is cleared before the freed arm and posture are recovered.

### Readiness and rules

Require a coach-checked wrist/triceps setup and the ability to stop under light pressure. Advanced describes readiness, not an age exemption. This card does not teach a joint lock or prescribe competition scoring. Retherford's later finger-control and stand-up continuation is outside the card; use whole-hand/wrist control in this drill. Stop for wrist bending, shoulder discomfort, loss of a low stable base, or an initiated tilt. The already-tilted position needs a separately coached defense and is not solved by twisting the arm.

### What changed

- Renamed the move Cross-Wrist Clear and identified the outside two-on-one elbow-scrape variant.
- Specified top's right-to-left wrist grip, top's left triceps hold, and bottom's free right elbow/forearm.
- Replaced hips-away/hand-to-hip wording with a verified low-base elbow scrape before loading or rolling.
- Added bent-arm recovery and palm-up elbow sealing to prevent immediate recapture.
- Removed the unsupported late-tilt recovery and replaced timed live tilt rounds with one defined early reaction.

### Evidence limits

S2 was inspected through an exported auto-generated transcript and public paused frames, not claimed continuous audio listening. The transcript's occasional 'tail' transcription is understood from the title and visible tilt demonstration. S3 was likewise inspected as transcript and frames; it corroborates a scrape mechanism but uses a different riding side. S1 supplies the exact hold definition, not clearance mechanics. The Henry Ford coaching page was read for its Elbow point/peel hand and Elbow scrape labels only; its outline does not verify execution. Public Kolat Countering Chop 2 on 1 and Clearing Wrist Drill frames were also explored, but no transcript was available and their partially obscured actions were not used to invent grip details. The primary source's finger-control continuation is intentionally omitted; the short drill and reset rules are editorial coaching choices.

### Sources inspected

**S1: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; SportsEngine-hosted team handbook; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, page 27: Tight Waist Elbow Chop and Basic Control Positions/Cross Wrist; page 31 Bottom principles also read.

**Supports:** Right-hand-to-left-wrist cross-wrist definition; Outside two-on-one adds same-arm triceps control; Distinction from same-side near-wrist control

**Limits:** Verifies the rider's hold, not the elbow-scrape defense. Historical rules/scoring language excluded.

**S2: [Breaking Out of Tilts by Zain Retherford](https://www.youtube.com/watch?v=EVHyXbOG3Og)** - Fanatic Wrestling, official instructional YouTube channel; accessed 2026-09-26.

**Inspected:** Complete exported auto-generated English transcript, 0:00-2:11. Paused public video frames at 0:40, 0:50, 0:55, 1:00, 1:01, 1:05, 2:00 and 2:01, including frame advances through the release.

**Supports:** Matching near-side wrist-and-elbow two-on-one setup; Stay low with wide knees and avoid hip loading; Free elbow slides in front of gripping wrist before the roll; Short elbow/forearm scrape opens grip; Bent left arm recovers to its own side and seals with palm up

**Limits:** No continuous audio listening claimed. The instruction later uses finger control and a stand-up; those continuations are not copied into this card. Does not prescribe an exact toe angle or defend an already completed tilt.

**S3: [Inside Bar and Cross Wrist Defense - Wrestling Bottom Technique](https://www.youtube.com/watch?v=O4_tHVaUJQg)** - Jon Sioredas, coach's official YouTube channel; accessed 2026-09-26.

**Inspected:** Complete exported auto-generated English transcript, 0:00-1:43, with cross-wrist passage at 0:49-1:43. Paused public frames at 0:52, 1:02, 1:12, 1:22 and 1:37.

**Supports:** Keep captured arm short rather than extended; Free elbow/forearm contacts controlling wrist; Push-pull release of a cross-wrist

**Limits:** Rider switches to the opposite side and receiver briefly turns sideways; this is independent corroboration of the wrist-scrape mechanism, not proof of identical positioning. Its inside-bar hands-together extension is a separate technique and excluded.

**S4: [Grind Ride Part 2: Cross Wrist-Defense](https://www.coachmackenzie.com/grind-ride-part-2.html)** - Henry Ford College Wrestling; Coach MacKenzie's coaching site; accessed 2026-09-26.

**Inspected:** Accessible page text, Cross Wrist-Defense section, listing Elbow point/peel hand, Elbow scrape, and collapse variations.

**Supports:** Familiar coaching label elbow scrape within cross-wrist defense

**Limits:** Outline only; no linked demonstration or precise mechanics inspected. Not counted as mechanical verification.

<a id="a29"></a>

## A29 - Double Leg to Tight Waist Chop

**Tier:** Advanced | **Previous name:** Takedown To Breakdown Chain

### Technical review

The original had the right overall priorities: finish the takedown, settle, read the base, and stop instead of inventing an untrained return. It was not sufficiently specific to perform as a chain. 'Turn the corner' omitted the shot orientation and drive direction, while 'place the tight waist' skipped the change from two knee grips to a left-side ride. That omission could encourage chopping while the receiver was still falling or while the legs remained gathered. The revision retains the deliberate landing checkpoint, makes the hand and foot changes explicit, and finishes with cross-wrist control rather than an unspecified belly-down position.

### Selected variant

A proposed teaching chain using B07's right-lead double-leg angled finish and B22's left-side tight waist chop to an outside two-on-one. Directions belong to the attacker/top unless bottom or receiver is named. The landing does not guarantee the selected riding side: the drill explicitly includes a belly-down turn and repositioning behind to bottom's left.

### Mechanics and evidence

- Will describes the basic double entry with a lead step between the feet, outside head, separate grips behind both knees, and an outside trail-foot step. This card orients those connections as right lead, head to the attacker's left, left hand on the receiver's right knee, and right hand on the left knee. His high-double elevation is not copied. [WILL]
- Horaski and Garcia direct the shuffle toward the original lead-leg side; for this orientation that is the attacker's right. College Park's basic 'flair' finish pairs angled head drive with drawing the legs inward and sideways to a hip landing. The rightward drive and leftward knee gather preserve B07's selected finish. [HORASKI_GARCIA, COLLEGE_PARK]
- The pause, receiver's belly-down turn, hip contacts, and shuffle behind to the left are this drill's transition design. They are not attributed to an inspected source as a prescribed match sequence. Freeing both legs before the base rebuild prevents the drill from asking bottom to rotate or kneel against retained knee grips.
- USAW specifies the near-arm chop with the back knee advancing the buttocks, and identifies chest pressure and leg drive in top motion. Madison's lesson describes simultaneous toe drive, a snug waist, and arm collapse toward the belly. In the left ride the right waist arm, left folding forearm, and rear right knee implement that combination. [USAW_SKILLS, MADISON]
- College Park explicitly links the chop to cross-wrist control: the former waist hand takes the opposite wrist, with the free hand on that arm's triceps for the outside two-on-one. Here that means right hand to bottom's left wrist and left hand to left triceps. [COLLEGE_PARK]

### Teaching progression

- Check B07 and B22 separately before joining them. Demonstrate the full chain, then freeze after the hip landing, after moving to the left ride, and at wrist control. Ask both partners to identify which grips were released and which were added.
- At low resistance the receiver accepts a low left-side landing, turns belly-down after settling and release of the leg grips, then rebuilds a base with elbows able to bend. The attacker follows without dropping weight. During the chop, bottom bends the left elbow and lowers through forearms to belly.
- Progress from three cooperative chains each to one clear choice after landing: bottom rebuilds or stands. The rider follows and chops only the rebuilt base; standing or escape ends the repetition. Counts, checkpoints, and this limited reaction are coaching design, not validated training doses.

### Common mistakes and corrections

- Driving left around the head side changes the selected double finish. Freeze the entry and identify the rightward path before resuming.
- Reaching for the elbow while still holding a knee skips the transition. Restore stable landing, release both leg grips, and use the hip contacts while moving behind.
- An arm-only sideways pull or sitting back leaves the base intact. Rehearse a short elbow fold synchronized with forward toe pressure and rear-knee hip advance.
- Bottom locks the arm or a leg remains trapped: stop and reset alignment. Do not solve either obstruction by chopping harder.

### Readiness and rules

Advanced denotes readiness to connect already reliable skills. Both partners must receive, rebuild, release, and stop predictably. The chain uses separate hands around the waist and stops at a simple wrist ride; no locked torso grip, lift, or mat return is taught. It makes no scoring or competition-start claim, and historical points references in the manuals are excluded. Keep wrist and shoulder alignment free of forced rotation.

### What changed

- Use the familiar component name Double Leg to Tight Waist Chop.
- Specify compatible shot directions and left-hip receiving.
- Add an explicit settled landing, leg-grip release, and move behind to the left ride.
- Specify right waist arm, left elbow fold, forward drive, rear right knee, and right-hand cross-wrist catch.
- Label the connection and reaction drill as teaching design; remove the unsupported timed-round prescription.

### Evidence limits

The cited mechanics were independently inspected in source text, not inferred solely from B07 or B22. No video viewing is claimed. Will supplies entry connections in a submission-grappling context; the low landing comes from the chosen practice adaptation. College Park's chop says 'near knee,' whereas USAW expressly says back knee; this card follows the latter to match B22. No source inspected establishes this exact double-to-left-ride chain as a canonical combination.

### Sources inspected

**COLLEGE_PARK: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; team handbook hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached page-marked PDF text, page 9 double position; page 23 DOUBLE / FLAIR and separate TURN CORNER LIFT; page 27 TIGHT WAIST ELBOW CHOP and CROSS WRIST / OUTSIDE 2 ON 1.

**Supports:** Angled double-leg drive with inward-sideways leg gathering and hip finish.; Forward tight waist chop followed by cross-wrist control.; Right hand to left wrist and free-hand triceps control.

**Limits:** Terse team handbook, not current rule authority. Its chop knee wording differs from USAW; the selected rear-knee version follows USAW. The exact transition chain is not supplied.

**HORASKI_GARCIA: [Wrestling Unit Block Plan, Lesson 3: Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia; PElinks4u; accessed 2026-09-26.

**Inspected:** Cached page-marked text of PDF pages 11-14, especially original-lead-leg-side angle and cross-body shuffle on pages 12-13, and finish above hips on page 14.

**Supports:** Direction toward the original lead-leg side.; Separate entry rehearsal before completing the takedown.

**Limits:** Older PE unit contains awkward penetration wording and instructions not adopted here. Not used for current rules, exact impact instructions, or the transition to riding.

**WILL: [How to set up wrestling's double leg from the classic Thai clinch](https://www.grapplearts.com/Clinch%26MMATakedowns.pdf)** - John B. Will; authored PDF hosted by Grapplearts; accessed 2026-09-26.

**Inspected:** Accessible PDF page text on pages 2-3, The Takedowns / The Basic entry, including lead step, outside head, knee grips, trail step and far-hand action.

**Supports:** Lead foot between the opponent's legs, head outside, and separate grips behind both knees.; Outside trail-foot step and far-hand action to prevent hopping away.

**Limits:** Submission-grappling article teaching a high double; the card does not adopt elevation or its clinch setups. Text inspected, not photographs or video.

**USAW_SKILLS: [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf)** - USA Wrestling; accessed 2026-09-26.

**Inspected:** Cached page-marked PDF text, page 2 Get Set Drills - Arm Chop and Belly to Base; page 3 base-building continuation and Top Motion.

**Supports:** Near-arm chop with rear knee advancing the buttocks.; Chest pressure and leg drive in top wrestling.; Bottom base-building as a distinct skill.

**Limits:** Study guide only; referenced video not inspected. Does not establish the full A29 chain or the exact forearm contact surface.

**MADISON: [Pre-season Clinic: Top Wrestling Part 6 - The Tight Waist Near Arm Chop and Roll Through Tilt, November 2, 2025](https://madisonyouthwrestling.club/)** - Madison Youth Wrestling; accessed 2026-09-26.

**Inspected:** Accessible instructional webpage text in the November 2 entry, particularly the paragraph describing back-knee drive, waist-arm tightening, arm collapse toward the belly, and toe drive.

**Supports:** Simultaneous waist connection, rear-knee hip advance and toe drive.; Near arm folds diagonally toward the belly.

**Limits:** Club lesson notes; individual technical author not fully identified. Linked Kolat video not watched. Later roll-through tilt is outside this card.

<a id="a30"></a>

## A30 - Near Wrist Tilt or Half

**Tier:** Advanced | **Previous name:** Wrist Tilt Or Half Decision

### Technical review

The draft correctly made reaction reading its goal and allowed the wrestler to decline a closed attack. However, its narrow-base/tilt and wide-base/free-elbow/half rule did not establish an actual grip-compatible system. Base width alone does not identify either opportunity. It also omitted the hand release needed to change attacks and treated exposure, escape and standing as equivalent endpoints. The revision is explicitly a coaching-drill synthesis of audited B25, A21 and A24, not a claim that a source teaches this exact three-choice sequence. Each turn has its own completed endpoint, while standing and lost control stop this restricted exercise.

### Selected variant

Start belly-down with B25's left-to-left near wrist. A knee rebuild can supply A21's loaded position while the wrist remains captured. A belly-down wrist-roll escape opening the same elbow supplies A24. These are separate early reactions, not a switch while suspended in a tilt. The card uses A24's researched near-wrist replacement rather than an unverified B22 cross-wrist handoff.

### Mechanics and evidence

- College Park identifies near wrist as same-hand/same-wrist and cross wrist as the opposite relationship. The right waist hand is initially separate. The decision therefore starts before transferring or adding a second wrist grip. [S2]
- For the tilt, the book places bottom's left thigh on top's left hip, with top's right hand at the far thigh/hip and right foot elevating bottom's left leg. It explicitly requires retaining the left arm and close hip support. Neither a visibly narrow stance nor wrist grip alone proves the load is available. [S1]
- For the half, College Park and Weber independently identify the escaping near wrist and the same arm's opening as the opportunity. Top releases the left wrist and follows underneath that upper arm with the left arm. This is different from retaining the near wrist and applying a far-side half, another variant found in the sources. [S2, S3]
- A24's right hand can now leave the waist and collect bottom's right wrist. The half-side foot route creates the perpendicular angle; bottom turns onto the opposite, right side before chest-to-chest control. The teaching unit and Weber substantiate these half-finishing principles. [S3, S4]

### Teaching progression

- Demonstrate both prerequisite turns separately, including supported finish and release. Identify left and right on both partners, then freeze the common ride to explain the three permitted reactions.
- For the first branch, bottom slowly rebuilds onto the knees and cooperatively permits loading. Top checks support before sitting. For the second, bottom stays belly-down and rolls the held wrist while opening that elbow. The receiver lets torso and shoulder travel together rather than posting against the trapped arm.
- For the third, bottom denies the load or clears the wrist while keeping the elbow closed. Top continues a secure ride or resets. A widened base is one possible way to obstruct loading, not an automatic signal to apply a half. Recognizing no turn is a successful repetition.
- After two announced repetitions of each branch, use six receiver-selected attempts. Pause at the decision if necessary and ask top to identify the actual grip or opening. Once a turn starts, bottom receives cooperatively; late counters and midair changes are excluded. This dose and reaction menu are original coaching design.

### Common mistakes and corrections

- Choosing from knee width: return to the grip and actual hip support or elbow opening. Weber supports reading available reactions, but does not establish a universal width-based rule. [S5]
- Keeping the left wrist while trying to insert a left half: pause before the turn and rehearse release, upper-arm follow, then half. Chasing a wrist that has escaped without an open elbow ends the attempt. [S2, S3]
- Changing after a failed turn is already loaded: complete the rehearsed supported return, then reset. Do not make the receiver absorb an improvised arm change under body weight.

### Readiness and rules

Require matched partners and demonstrated A21/A24 receiving before adding choice. Keep the tilt's hands separate and release before trapped-arm strain. NFHS's instructional sheet identifies danger when the half drives the defender's elbow behind the head and when joints reach their normal-motion limit. [S6] It is a historical officials resource, not a complete current event rulebook. No current scoring count, youth-age permission or blanket legality claim is made.

### What changed

- Renamed the drill Near Wrist Tilt or Half and fixed the common same-side grip.
- Replaced narrow/wide-base selection with retained wrist plus available load, or wrist roll plus same-elbow opening.
- Specified different right-hand destinations and the left-wrist release before the left half.
- Added separate exposure-and-return and chest-to-chest endpoints, plus a valid ride/reset outcome.
- Made the synthesis, receiver menu and practice dose explicit coaching choices.
- Clarified that the tilt and half are alternative attempts from the original ride, not a consecutive tilt-then-half sequence.

### Evidence limits

Independently read the cited book's relevant prose, cached handbook and teaching-unit pages, Weber's accessible articles, and the NFHS PDF text. No book photographs, embedded videos or locked courses were inspected. The book verifies the tilt's load, not this drill's knee-rebuild trigger; the half sources verify the wrist-roll change, not a narrow/wide-base dichotomy. Strong arm-pry, head-posting and force cues in adjacent material are excluded. Source language on historical scoring is not carried forward.

### Sources inspected

**S1: [Winning Wrestling Moves: Near-Wrist Control and Hip Tilt](https://studylib.net/doc/27230226/winning-wrestling-moves)** - Mark Mysnyk, Barry Davis and Brooks Simpson / Human Kinetics, 1994; transcription hosted by StudyLib; accessed 2026-09-26.

**Inspected:** Authorship, orientation, and printed pages 156-157: Near-Wrist Control, The Near Wrist, Half Nelson and Hip Tilt prose; neighboring Arm Pry read to distinguish the variant.

**Supports:** Far-thigh hand control; Near-thigh hip load; Opposite-foot leg elevation; Retained wrist and close hip contact

**Limits:** Primary coach-authored prose via third-party OCR. Photographs uninspected; historical scores and neighboring forceful counters excluded. Does not prescribe this decision drill.

**S2: [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf)** - College Park Wrestling; hosted by SportsEngine; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, pages 13 and 26-28: Half Nelson, Top principles, Near Wrist and Cross Wrist, with adjacent variants for context.

**Supports:** Same-side wrist definition; Wrist-roll escape followed under the same upper arm into a half; Separate retained-near-wrist/far-half variant; Wrist-and-half chest-to-chest finish

**Limits:** Compact coaching notes; aggressive head and arm-force wording excluded. Does not teach this exact tilt-or-half menu.

**S3: [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Entire accessible article text, especially Steps 1-3 and Step 10 Near Wrist Roll Half Nelson; other steps distinguished from the selected branch.

**Supports:** Hook the opening elbow as near wrist rolls free; Half enters from that same side; Turn to the opposite side and deepen half; Chest-to-chest endpoint

**Limits:** Written coaching instruction only; embedded video not inspected. Ear grip, forehead post and power/sweep/spike variants excluded.

**S4: [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf)** - Brian Horaski and Jon Garcia / PElinks4u; accessed 2026-09-26.

**Inspected:** Cached PDF-page-marked text, complete pages 101-104, including half mechanics, defensive response and teaching progression.

**Supports:** Underarm entry to back of head; Feet move out on half side to perpendicular; Chest-to-chest control; Demonstration and cooperative practice before situations

**Limits:** Historical PE unit without the selected wrist-roll entry. Straight-arm levering and historical score language not adopted.

**S5: [Near Wrist Ride](https://www.attackstylewrestling.com/near-wrist-ride/)** - Daryl Weber / Attack Style Wrestling; accessed 2026-09-26.

**Inspected:** Full short public article, including the paragraph on forward pressure, wrist/shoulder control and reading available reactions.

**Supports:** Reaction-based continuation from near-wrist control; Forward pressure and shoulder control

**Limits:** Brief principles, not exact grip or turn instruction. Embedded video uninspected; does not validate a base-width rule.

**S6: [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf)** - National Federation of State High School Associations; hosted by Iowa High School Athletic Association; accessed 2026-09-26.

**Inspected:** Both pages' extracted text, especially page 1 half-nelson example and normal-range-of-motion definition.

**Supports:** Half-nelson danger when defender's elbow is forced behind head; Stop at joint range limits

**Limits:** Historical official instructional sheet, not a complete current rules review. Photographs not inspected; no universal event or age permissions inferred.
