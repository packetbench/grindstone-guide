# Grindstone Wrestling 30 Practice Plans Ages 7-10

Mat Rats | Wrestling foundations | 60 minutes

Thirty foundation practices for children ages 7 to 10. Each session gives the coach a timed sequence, specific partner tasks, clear cues, an easier option and an observable learning check.

Two practices each week make a fifteen-week sequence. An optional extra practice should revisit familiar work. Repeat a plan when the group needs it; dates and practice numbers never override readiness.

All times are elapsed minutes. Demonstration, rest, rotations and feedback are included within each block. Water remains available throughout.

## Coach operating guide

### Choose the right pace

Two practices each week make a fifteen-week sequence. An optional extra practice should revisit familiar work. Repeat a plan when the group needs it; dates and practice numbers never override readiness.

### Prepare the space

Have a clean wrestling mat, clear margins, timer, personal water bottles and the listed equipment ready. Flat markers must not slide. Confirm staffing, emergency contacts, medical restrictions and the venue emergency plan before arrivals.

### Read the clock

The left column shows elapsed time from the start of practice. Demonstration, turns, rest and feedback belong inside each block. Short rounds repeat only while both partners remain controlled. Water is available throughout, beyond the planned break.

### Give a clear task

Read the focus and prerequisite first. Demonstrate briefly, give one cue, let athletes try and offer one correction. Tell partners exactly which actions are allowed. Rehearse stopping and releasing before increasing resistance.

### Match and supervise

Pair by size, maturity, skill, confidence and control. Coaches assign and observe partners. Stop for pain, distress, unsafe pressure, loss of control or crowding. Reduce simultaneous activity if every pair cannot be supervised.

### Adjust without excluding

The easier and harder options change the task, not the child's place on the team. Offer observation, individual movement or cooperative rehearsal. Children may ask to stop at any time. Breaks remain supervised.

### Progress the wrestling

Teach receiving, legal position and release before each new finish or turn. Progress from cooperative repetitions to the stated positional resistance after both partners show control. Entry-only drills stop at entry. Use only taught finishes and turns; no lifts, throws or mat returns. Stop at the task objective or signal.

## Practice 01 Space Stop And Belong

**Goal:** Share mat space, stop promptly, and ask for a break.

**Set up:** Flat nonslip markers, individual movement squares, water area, and a clearly marked supervised rest space.

**Before you begin:** Athletes can understand a spoken or visual stop cue with support.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Traffic lights | Give each athlete a personal square. Demonstrate walking, slowing, and freezing for two minutes. Run six rounds of 45 seconds moving and 15 seconds frozen. Use both spoken colors and a visible hand signal. |

| 13-23 | Find your space | Show a safe arm's length gap without touching anyone. For eight one-minute rounds after a two-minute demonstration, athletes walk to an empty marker, stop, and check nearby space. Reassign crowded markers; nobody races for a place. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Stop and ask | Demonstrate saying or signaling stop, stepping back, and asking for help. In pairs without touching, alternate leader and follower every minute for eight minutes. The leader stops once each round; both freeze and acknowledge the signal. |

| 35-45 | Follow a route | Spend two minutes showing separate walking lanes and the rest area. Run eight one-minute rounds: follow one lane for 40 seconds, then return and reset for 20 seconds. Athletes choose walking or comfortable side steps. |

| 45-55 | Find a free island | Place more flat islands than children. Explain that everyone succeeds by finding open space. Use eight 45-second walking rounds with 15-second pauses after a two-minute demonstration. Children may stay on an island rather than move. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Follow a coach inside one personal square; use a visual stop cue.

**Add challenge:** Change direction after stopping while maintaining the same safe spacing.

**Stop or change:** Stop for collisions, boundary confusion, or distress; simplify the space before restarting.

**Look for:** Athlete stops on cue and finds space without touching another child.

**Ask:** What helped you feel comfortable on the mat?

## Practice 02 Balance In Every Direction

**Goal:** Move forward, backward, and sideways while staying balanced and aware of nearby athletes.

**Set up:** Flat markers forming individual short lanes, with clear space behind each lane and a visible stop sign.

**Before you begin:** Athletes stop on cue and stay inside their assigned movement space.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Compass walking | Show forward, backward, left, and right inside separate lanes. Spend two minutes checking space, then run six 45-second movement rounds with 15-second rests. Call only one direction at a time; backward travel stays slow. |

| 13-23 | Step and settle | Demonstrate small steps with feet comfortably apart, knees soft, and eyes forward. After two minutes, use eight one-minute rounds: move for 30 seconds, settle for 30 seconds. Children pause whenever they need to regain balance. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Mirror without contact | Pair athletes in neighboring squares with a clear gap. Demonstrate for two minutes, then use eight rounds of 30 seconds leading and 30 seconds resting. Alternate leaders each round; the follower copies steps without approaching. |

| 35-45 | Change direction safely | Lay three markers within each athlete's area. Explain the route for two minutes. For eight one-minute rounds, athletes move between markers for 40 seconds and rest for 20 seconds. Call stop before every direction change. |

| 45-55 | Balance statues | Invite children to choose a stable two-foot pose. After a two-minute demonstration, run eight 45-second movement rounds and 15-second statue pauses. Partners notice balance without judging appearance; no pushing, one-foot contests, or elimination. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use forward and sideways walking only with a coach nearby.

**Add challenge:** Respond to an unexpected direction cue after a complete balanced stop.

**Stop or change:** Stop for repeated stumbling, pain, or movement outside the personal lane.

**Look for:** Athlete changes direction without crossing feet excessively or entering another athlete's space.

**Ask:** Which direction needed your smallest, most careful steps?

## Practice 03 Build A Comfortable Wrestling Stance

**Goal:** Maintain a balanced stance while taking short steps and keeping eyes forward.

**Set up:** Individual mat squares, flat direction markers, and enough room for coaches to observe every athlete.

**Before you begin:** Athletes move and stop with control without colliding or needing partner support.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Ready position freezes | Spend two minutes showing a comfortable athletic position. Run six rounds of 45 seconds walking and 15 seconds freezing. Athletes soften knees, keep feet apart, and hold hands loosely forward without crouching into discomfort. |

| 13-23 | Stance and short steps | Demonstrate feet comfortably apart, one foot slightly forward, knees bent, and head upright. Use two teaching minutes and eight one-minute rounds of 30 seconds stepping and 30 seconds rest. Keep steps small; never force deep crouching. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Follow the stance leader | Use pairs in separate facing squares with no contact. Demonstrate for two minutes, then alternate leaders through eight one-minute rounds: 30 seconds stance movement, 30 seconds feedback and rest. Followers preserve space rather than chasing. |

| 35-45 | Protect your balance | Give each athlete front, side, and rear markers within a small area. After a two-minute demonstration, call routes through eight 40-second movement rounds with 20-second resets. Athletes pause and rebuild stance whenever balance slips. |

| 45-55 | Stance traffic lights | Explain green means short stance steps, yellow means slow steps, and red means freeze. Demonstrate for two minutes, then run eight 45-second rounds with 15-second rests. Everyone stays in personal space and chooses comfortable depth. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use a taller stance and shorter movement rounds.

**Add challenge:** Change lead foot during the reset, then maintain balance using the other stance.

**Stop or change:** Stop for knee or back discomfort, head-down posture, or uncontrolled crossing into another square.

**Look for:** Athlete takes several short steps and stops with feet apart and head upright.

**Ask:** What helped your stance feel strong without feeling stiff?

## Practice 04 Lower Your Level With Control

**Goal:** Bend through hips and knees while keeping the head upright and movement comfortable.

**Set up:** Personal mat squares, flat foot markers, and a coach-visible station for each small group.

**Before you begin:** Athletes can hold a comfortable stance and stop their movement independently.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Tall and ready | Show standing tall and settling into a comfortable stance. For six one-minute rounds after two demonstration minutes, alternate 30 seconds easy walking with 30 seconds stance resets. Keep head upright and avoid bouncing deeply. |

| 13-23 | Slow level changes | Demonstrate lowering slightly by bending hips and knees while keeping eyes forward. After two minutes, complete eight one-minute rounds: three slow changes, then relax until the next cue. No knee drops, lunging, or partner contact. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Shadow the level | Assign partners separate facing squares. Spend two minutes showing slow up-and-down movement. Run eight rounds of 30 seconds copying and 30 seconds rest, swapping leaders each round. Followers choose their own comfortable depth rather than matching exactly. |

| 35-45 | Level then step | Show a small level change followed by one short forward step and a balanced stop. After two minutes, use eight 30-second work and 30-second reset rounds. Return to the starting marker between attempts; remain entirely noncontact. |

| 45-55 | High middle ready | Demonstrate three comfortable positions: tall, slightly lowered, and ready stance. Run eight 45-second rounds with 15-second rests after two instruction minutes. Children choose the correct position from visual cards; everyone succeeds through controlled movement. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Make a very small knee bend and omit the forward step.

**Add challenge:** Choose whether to lower or step first in response to a visual cue.

**Stop or change:** Stop for painful bending, knee impact, diving, or loss of balance.

**Look for:** Athlete lowers and rises with head upright and feet under control.

**Ask:** How did you lower your body without dropping your head?

## Practice 05 Be A Trustworthy Practice Partner

**Goal:** Practice consent, immediate release, light contact, and predictable partner roles.

**Set up:** Clearly separated partner stations, flat markers, supervised rest area, and visible stop signal.

**Before you begin:** Both athletes willingly accept the task and can stop on spoken or visual cues.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | No contact mirrors | Explain that partners keep a clear gap and copy easy stepping. After two minutes, run six rounds of 30 seconds movement and 30 seconds reset. Swap leaders every round; no athlete must approach an uncomfortable distance. |

| 13-23 | Ask touch release | Demonstrate asking permission for one light open-hand shoulder touch, then removing the hand immediately. Use two teaching minutes and eight one-minute rounds: one touch each, then discuss comfort. A no-contact pointing version is equally successful. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Practice both stop signals | Demonstrate a spoken stop and raised open hand. Use eight one-minute rounds after two teaching minutes. One athlete briefly rests an open hand on the other's shoulder; either signal means release and step apart immediately. |

| 35-45 | Predictable partner roles | Explain one athlete leads a single side step while the other follows without touching. After two minutes, run eight 30-second practice and 30-second rest rounds. Swap roles each round and ask whether the pace felt comfortable. |

| 45-55 | Partner movement puzzle | Show a three-action puzzle: step sideways, freeze, then turn toward your own marker. After two minutes, use eight one-minute rounds. Partners copy together for 40 seconds and choose a new comfortable sequence during the 20-second reset. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use no contact and practice signals with a coach.

**Add challenge:** Respond to either partner's stop signal at an unpredictable moment during noncontact movement.

**Stop or change:** Stop for pressure, grabbing, unwanted contact, teasing, or any failure to release.

**Look for:** Athlete asks before contact and removes the hand immediately when either partner signals stop.

**Ask:** What did your partner do that helped you trust them?

## Practice 06 Prepare For Safe Receiving

**Goal:** Explore controlled floor lowering and rebuilding balance before any partner takedown work.

**Set up:** Clear mat stations, one qualified coach observing each active lowering station, and separate noncontact waiting activities.

**Before you begin:** No partner takedowns; a qualified coach screens each athlete's controlled floor movement individually.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Walk kneel stand | Demonstrate slow walking, stopping, and lowering to comfortable kneeling using hands for support. After two minutes, use six 30-second movement and 30-second rest rounds. Athletes may remain standing if kneeling hurts or feels uncertain. |

| 13-23 | Low side lowering | A qualified coach demonstrates from side-sitting: lower gently onto the side and return seated, keeping head clear of the mat. Use eight one-minute individually observed turns after two teaching minutes. No standing falls or partner pushing. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Build your base | Demonstrate moving from side-sitting onto hands and knees, then pausing balanced. After two minutes, use eight one-minute rounds: one careful transition, a return to sitting, and rest. Coaches watch head clearance and comfortable joint positions. |

| 35-45 | Individual receiving check | Explain that this is preparation, not permission for takedowns. During eight one-minute turns after two instruction minutes, each athlete shows a controlled floor lowering and return. The qualified coach records readiness or assigns continued solo practice. |

| 45-55 | Choose your safe route | Set separate markers for standing, seated, and hands-and-knees positions. After two minutes, run eight 40-second movement rounds with 20-second pauses. Athletes choose comfortable transitions inside their station; nobody pushes, pulls, rolls over, or races a partner. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Remain seated and practice a small supported lean with direct coach supervision.

**Add challenge:** Link two coach-approved floor transitions while maintaining head clearance and a calm pace.

**Stop or change:** Stop for head contact, discomfort, sudden dropping, fear, or any attempt to push a partner.

**Look for:** Athlete lowers and returns with control under direct observation; coach identifies the next appropriate task.

**Ask:** How can you tell a coach that a movement does not feel safe yet?

## Practice 07 Build The Double Leg Entry

**Goal:** Learn a balanced double-leg entry before adding any finish.

**Set up:** Separated partner stations, flat lead-foot markers, fitted ear guards for contact, and coach-visible boundaries.

**Before you begin:** Review B03 and the entry steps of B07. This lesson stops after leg collection; receiving must be taught before any finish.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Step and lower | Demonstrate a comfortable stance, small knee bend, and short forward step. After two minutes, run six rounds of 30 seconds practicing and 30 seconds resting. Athletes work alone and return to their own marker after each attempt. |

| 13-23 | Learn - Double-Leg Entry | Show a right-foot level change and step between their feet; right knee touches softly. Head stays on your left at their right ribs; left hand cups their right knee and right hand their left knee. Bring the left trail foot up. Pause, release and reset without a finish. After two teaching minutes, use eight one-minute turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Build the entry shape | After two teaching minutes, alternate roles through eight 30-second rehearsal and 30-second rest rounds. Receiver stays balanced; attacker changes level, steps in, and brings the trailing foot underneath. Coach checks head position and knee comfort; no finish is introduced yet. |

| 35-45 | Check before connecting | After two teaching minutes, use eight one-minute turns. Attacker enters only after receiver signals ready, then pauses with hands behind the thighs. Coach checks balance, head position, and comfortable contact. Release and reset; athletes needing support use empty-space footwork. |

| 45-55 | Entry checkpoint partners | After two teaching minutes, run eight 40-second rehearsal and 20-second rest rounds. Partners alternate one entry and identify three checkpoints: level changed first, head upright beside torso, and feet underneath. Successful repetitions finish with controlled release, not a takedown. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Rehearse level change and entry footwork toward floor markers without contact.

**Add challenge:** Connect level change and trailing-foot recovery smoothly while the receiver remains stationary.

**Stop or change:** Stop for crown-first contact, knee impact, lifting, loss of balance, or an attempted finish before it is taught.

**Look for:** Athlete enters with head upright, hands behind the thighs, and both partners balanced.

**Ask:** How did you know your partner was ready for your entry?

## Practice 08 Build A Controlled Single Entry

**Goal:** Rehearse a light single-leg collection with the partner's foot remaining on the mat.

**Set up:** Wide partner stations, flat foot markers, fitted ear guards, and qualified coaches close enough to interrupt contact.

**Before you begin:** Use B08 only to check head-inside position and grips. The foot stays down for this entry lesson; release without pulling or turning.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Stance step reset | Demonstrate a small level change, short entry step, and immediate return to stance without a partner. Use six 30-second work and 30-second rest rounds after two minutes. Athletes keep eyes forward and their movements unhurried. |

| 13-23 | Learn - Single-Leg Entry | For their right leg, level-change and step close with your head inside, left temple beside their right ribs. Left arm wraps outside, right arm inside, hands lightly meet behind the knee. Keep their foot down and do not pull or turn. Release before stepping away. After two teaching minutes, use eight one-minute cooperative turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | One calm entry | Spend two minutes checking head position and receiver comfort. Run eight rounds of 30 seconds rehearsal and 30 seconds rest, swapping roles each round. Attempt one light collection at a time, release, and rebuild separate balanced stances. |

| 35-45 | Stop before imbalance | Demonstrate that either partner can stop the entry before the arms surround the leg. Use eight one-minute rounds after two instruction minutes. Receiver remains still; attacker approaches slowly, collects lightly if comfortable, and releases before any balance changes. |

| 45-55 | Entry accuracy stations | Mark a starting point and return point at each pair's station. After two minutes, use eight 40-second practice and 20-second rest rounds. Partners earn a shared point for permission, upright posture, gentle entry, and a balanced return. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use one open-hand thigh touch; omit the arm collection.

**Add challenge:** Alternate the receiver's lead leg between attempts while keeping the task cooperative and stationary.

**Stop or change:** Stop for head-down posture, gripping near the knee joint, squeezing, pulling, lifting, or any receiver imbalance.

**Look for:** Athlete collects lightly above the knee and releases while both remain balanced and comfortable.

**Ask:** What kept your partner comfortable during the collection?

## Practice 09 Double Leg Takedown

**Goal:** Complete a low-amplitude double-leg takedown with controlled receiving and balanced top position.

**Set up:** Spaced receiving lanes, flat foot markers, fitted ear guards, and qualified coaches.

**Before you begin:** Review B07. Individually confirm a low side-hip landing without a straight-arm post before adding a standing entry.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Prepare to enter and receive | After two demonstration minutes, alternate six 30-second movement and 30-second rest rounds. Rehearse entry footwork separately from low side-lowering onto the hip and side. Receivers keep the head clear and avoid a locked-arm post; coaches check each athlete individually. |

| 13-23 | Learn - B07 | Demonstrate from a low right-foot entry: head on your left at their right ribs, hands behind both knees. Step the left trail foot outside their right foot. Drive diagonally right while gathering knees left; receiver lowers onto their left hip and side. Follow without dropping weight. After two teaching minutes, use eight one-minute cooperative turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Receive before standing finishes | After two teaching minutes, use eight one-minute turns. Coach checks each receiver's low-start descent before approving cooperative standing finishes. Attacker turns the corner without lifting or dumping; receiver lowers with the action. Stop, settle balanced top control, release, and swap. |

| 35-45 | Finish against one early step | After two teaching minutes, use twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved defenders may take one early retreat step; once legs are secured, receive the controlled finish. Stop at balanced top control. Novices rehearse entries or low-start finishes. |

| 45-55 | Complete the control checklist | After two teaching minutes, use eight 40-second rehearsal and 20-second rest rounds. Partners complete one coach-approved finish each, then identify upright head, controlled descent, and balanced top control. Receiving quality matters equally; repeat from the lower start whenever control deteriorates. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use entry-only work or a coach-guided low-start finish with a cooperative receiver.

**Add challenge:** Adjust to one early retreat, then finish through the balanced opening.

**Stop or change:** Stop for head or neck compression, locked-arm posting, airborne lifting, slamming, knee twisting, or uncontrolled descent.

**Look for:** Pair completes a coached double-leg finish with controlled receiving and balanced top position.

**Ask:** What helped partners control the finish?

## Practice 10 Keep Your Legs Out Of Reach

**Goal:** Use a short retreating step and a balanced stance to defend an entry touch.

**Set up:** Separate partner lanes with rear safety space, flat start markers, fitted ear guards, and visible stop signal.

**Before you begin:** Athletes can step backward under control and keep their eyes forward.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Backward stance lanes | Demonstrate one short backward step followed by a balanced pause. After two minutes, use six 30-second movement and 30-second rest rounds. Athletes work alone, check rear space first, and stop before reaching their lane boundary. |

| 13-23 | See and step back | Demonstrate an attacker slowly reaching toward the front thigh while the defender takes one short step back. After two minutes, use eight one-minute turns. Keep hands open and heads apart; stop after the reach, whether it touches or misses. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | One reach one response | Spend two minutes assigning attacker and defender roles. Use eight 30-second work and 30-second reset rounds, alternating roles. Attacker makes one slow thigh-touch attempt; defender retreats once and resets. No pursuit, pushing the head, or sprawling onto partners. |

| 35-45 | Defend without fleeing | Mark a comfortable backstop line well inside the station. After two minutes, run eight one-minute rounds: one slow entry attempt, one controlled defensive step, then reset forward together. Defender stops immediately at the line rather than backing farther. |

| 45-55 | Protect the marker | Give each athlete a personal rear marker. Demonstrate for two minutes, then use eight 40-second rounds with 20-second rests. Partners take turns making one slow reach; defender preserves balance before the marker. Count controlled responses, not misses. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Attacker points from outside touching distance; defender practices the single retreating step.

**Add challenge:** Attacker varies the start moment within a slow agreed count; still allow only one reach.

**Stop or change:** Stop for blind retreating, pursuit, head contact, pushing, or movement near another pair.

**Look for:** Defender takes one controlled step and remains facing the partner inside the assigned area.

**Ask:** How did you make space without running away?

## Practice 11 Move Around To The Hips

**Goal:** Practice a grounded go-behind route without pulling the head or pushing a partner.

**Set up:** Separated grounded partner stations, fitted ear guards, flat side markers, and a qualified coach overseeing every active pair.

**Before you begin:** Both athletes tolerate hands-and-knees positioning; the receiver can remain still and request immediate release.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Hands knees stand | Demonstrate moving from comfortable kneeling to hands and knees, then returning slowly to standing. After two minutes, run six 30-second practice and 30-second rest rounds. Work individually; use hands for support and keep head clear of the mat. |

| 13-23 | Circle outside the arms | Demonstrate the receiver holding a comfortable hands-and-knees base. The mover begins beside one shoulder, travels slowly outside the arm line to the hip, and touches the waist lightly. Use eight one-minute turns after two teaching minutes. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Touch hip and release | Spend two minutes checking space around each base. Run eight 30-second practice and 30-second rest rounds, swapping roles. Mover circles on knees without climbing over arms, touches the waist with an open hand, then releases and returns. |

| 35-45 | Pick the open side | Place a flat marker beside either side of the receiver. After two minutes, use eight one-minute rounds. Coach points to the open route; mover travels outside the arms to that hip. Receiver remains still; no head holds or driving. |

| 45-55 | Grounded route puzzle | Demonstrate a start marker, outside route, and finish marker beside the hip. After two minutes, run eight 40-second rounds with 20-second resets. Partners complete one controlled route, release, swap, and praise safe spacing; nobody races or blocks. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Circle around a foam pad or flat marker instead of a partner.

**Add challenge:** Choose the other side after each reset while keeping the receiver completely cooperative.

**Stop or change:** Stop for pressure on the head or neck, crossing over arms, climbing, knee collisions, or receiver discomfort.

**Look for:** Mover reaches the hip by an outside route without disturbing the receiver's stable base.

**Ask:** Which route let you reach the hip without pushing your partner?

## Practice 12 Choose Attack Or Safe Defense

**Goal:** Apply the double-leg entry and finish against one controlled early retreat.

**Set up:** Separated standing lanes, flat lead-foot markers, fitted ear guards, and two visible role cards.

**Before you begin:** Coach approves entries, receiving, and controlled finishes before resistance; other athletes keep entry-only roles. Use B07 for the double-leg finish.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Color cue stance | Assign one color to forward stance stepping and another to a single backward step. Demonstrate for two minutes, then run six 40-second movement and 20-second rest rounds. Athletes stay in personal squares and freeze before changing direction. |

| 13-23 | Read attack and defense | After two teaching minutes, use eight one-minute cooperative turns. Attacker rehearses the double-leg pathway; defender shows one early retreat step, then receives if the entry connects. Coach distinguishes a safe opening from a closed target that requires an immediate reset. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Swap after every reset | After two teaching minutes, alternate roles through eight 30-second rehearsal and 30-second rest rounds. Use one early defensive step before contact. Approved attackers finish only from a balanced entry; others stop at entry. Receivers cooperate with every descent and release. |

| 35-45 | One defense one attack | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved attackers seek the double-leg finish; defenders may retreat once before contact, then receive safely. Stop on top control or a closed entry. Novices use entry-only versions. |

| 45-55 | Attack defense and reset | After two teaching minutes, run eight 40-second rehearsal and 20-second rest rounds. Partners alternate a coach-approved attack and defense, naming whether the opening supported finishing or resetting. Each athlete practices both roles; receiving and sensible resets receive equal attention. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Announce the early retreat and keep the attack entry-only.

**Add challenge:** Choose whether to finish or reset after the same early retreat, without chasing.

**Stop or change:** Stop for crown-first contact, joint pressure, uncontrolled descent, lifting, slamming, or pursuit after a closed entry.

**Look for:** Athlete chooses a controlled finish or appropriate reset after one permitted early defense.

**Ask:** What helped you remember whether you were attacking or defending?

## Practice 13 Find A Strong Bottom Base

**Goal:** Build and recover a comfortable hands-and-knees base without loading the head or neck.

**Set up:** Individual floor stations, flat hand and knee markers if helpful, fitted ear guards for any partner proximity.

**Before you begin:** Athletes can move onto hands and knees comfortably and communicate pain or uncertainty.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Floor position choices | Demonstrate comfortable side-sitting, kneeling, and hands-and-knees positions with head clear of the mat. After two minutes, run six 30-second movement and 30-second rest rounds. Athletes choose two positions and move slowly between them without rolling over. |

| 13-23 | Build the base | Show hands under shoulders, knees under hips, fingers relaxed, and head upright. After two minutes, use eight one-minute turns. Athletes settle into base briefly, sit back to rest, then rebuild without locking elbows or dropping the head. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Recover from side sitting | Demonstrate returning from side-sitting onto hands and knees using comfortable hand support. After two minutes, run eight 30-second practice and 30-second rest rounds. Partners observe from separate spaces and name one stable feature without touching or correcting forcefully. |

| 35-45 | Base after a small move | Show shifting one hand a short distance and replacing it while the other supports remain comfortable. After two minutes, use eight one-minute rounds. Athletes make one small adjustment, rebuild base, and rest; coaches check control rather than speed. |

| 45-55 | Base picture match | Show cards for seated, kneeling, and stable base positions. Demonstrate for two minutes, then use eight 40-second rounds with 20-second rests. Athletes choose a card, assume its comfortable version, and let a partner identify it without contact. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Use seated and kneeling positions only, or shorten time bearing weight through the hands.

**Add challenge:** Recover base after two small self-directed hand or knee adjustments.

**Stop or change:** Stop for wrist or knee pain, elbow locking, head contact, or a partner attempting to push the base.

**Look for:** Athlete rebuilds a balanced base with head clear of the mat and comfortable hand support.

**Ask:** Which parts of your base helped you feel balanced?

## Practice 14 Inside-Leg Stand-Up Footwork

**Goal:** Rehearse B17 stand-up footwork solo, then turn into a balanced stance.

**Set up:** Separate floor-to-standing lanes, flat foot markers, clear overhead space, and a qualified coach observing rises.

**Before you begin:** Review B17. This inside-leg version starts with the left foot for a rider on the left; it differs from P08 outside-leg footwork.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Kneel step balance | Show kneeling, placing one foot flat forward, and pausing in a comfortable half-kneel. After two minutes, run six 30-second practice and 30-second rest rounds. Athletes alternate the forward foot and use hands for balance when necessary. |

| 13-23 | Learn - Solo B17 Footwork | Imagine a rider on the left. From base, plant the left foot beside the right knee and lift the chest; left elbow comes back without swinging. Rise with bent knees, rehearse hand control at the belly, move hips forward, and turn right with both feet free. After two teaching minutes, use eight one-minute solo turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Rise then face | Place a partner several steps away as a visual target only. After two demonstration minutes, use eight 30-second work and 30-second rest rounds. Athlete stands from base, balances, then turns toward the partner without twisting while rising. |

| 35-45 | Wait for clear space | Demonstrate checking that the standing lane is empty before starting. After two minutes, run eight one-minute rounds. Athletes complete one controlled stand-up and balanced turn while partners observe from outside the lane; swap after each round. |

| 45-55 | Stand up sequence | Display pictures for base, planted foot, standing, and facing forward. After two minutes, run eight 40-second rounds with 20-second rests. Athletes complete the sequence once, identify the easiest step, and repeat only while movement stays comfortable. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Start from a comfortable half-kneel or practice only the planted-foot position.

**Add challenge:** Use either lead foot while maintaining the same slow, balanced rise.

**Stop or change:** Stop for backward head throwing, loss of balance, joint pain, dizziness, or anyone entering the standing lane.

**Look for:** Athlete rises without contact, pauses balanced, and turns only after standing securely.

**Ask:** Where did you place your foot to help yourself stand?

## Practice 15 Inside-Leg Stand-Up Escape

**Goal:** Control the waist wrist, rise with balance, clear contact, and face the opponent.

**Set up:** Matched stations, clear standing lanes, fitted ear guards, and qualified coaches.

**Before you begin:** Check B14-B15 starts before B17. Partner follows lightly without a mat return; confirm hand control, hip clearance and a balanced right turn.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Base and free stand | Demonstrate stable base, a planted foot, slow standing, and a balanced turn. After two minutes, run six 30-second work and 30-second rest rounds. Athletes practice alone; waiting partners remain outside the standing lane and offer one supportive observation. |

| 13-23 | Learn - B17 | With rider on the left, plant the left foot beside the right knee and lift the chest. Right hand controls the rider's right hand near its wrist; left elbow stays close. Rise, hold the hand away, move hips forward and turn right to face. After two teaching minutes, use eight one-minute cooperative turns; no finger grips. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Follow without returning | After two teaching minutes, use eight 30-second practice and 30-second reset rounds. Top maintains light waist contact while bottom controls the wrist and rises. Top follows without locking hands or pulling backward, then releases at standing; no mat return is allowed. |

| 35-45 | Clear then complete the escape | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved bottom athletes control the waist wrist and rise; top maintains light contact while grounded, releasing at standing. Bottom clears and faces. Novices separate clearing from solo rising. |

| 45-55 | Hand control escape checklist | After two teaching minutes, run eight 40-second rehearsal and 20-second rest rounds. Partners alternate the coached stand-up, checking whole-hand wrist control, balanced foot placement, and a clear facing finish. Top releases at standing; coach reduces resistance if bottom loses balance. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Clear cooperatively, have top release, then rise unsupported.

**Add challenge:** Control the wrist while top follows the grounded phase with light waist contact.

**Stop or change:** Stop for finger gripping, wrist twisting, locked hands, backward pulling, loss of balance, or any attempted mat return.

**Look for:** Bottom controls the wrist, rises balanced, clears contact, and faces.

**Ask:** How did hand control help your balance during the escape?

## Practice 16 Learn A Safe Top Position

**Goal:** Use a controlled top starting position with open hands and immediate release.

**Set up:** Separate grounded partner stations, fitted ear guards, current event starting-position card, and qualified coach supervision.

**Before you begin:** Review B14-B15 and the event starting procedure. Check light contacts, legal leg placement and stillness before any whistle response.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Side kneeling routes | Demonstrate moving on knees around a flat marker while leaving room for imaginary arms and legs. After two minutes, run six 30-second practice and 30-second rest rounds. Keep head upright, move slowly, and stop before entering another station. |

| 13-23 | Learn - B14 and B15 | Bottom sets legally and becomes still. On the referee cue, top starts left: left knee outside bottom's left knee, right foot behind the feet on that side. Left palm rests lightly behind the left elbow; right palm covers the belly button. Keep legs clear and head above mid-back. After two teaching minutes, use eight one-minute setup/release turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Start on the signal | Use two minutes to demonstrate stillness before the start cue and release on stop. Run eight 30-second practice and 30-second rest rounds. Top assumes the checked position with light contact; bottom remains comfortable. No squeezing, locked hands, or breakdowns. |

| 35-45 | Follow one base adjustment | Demonstrate bottom moving one hand or knee a few inches while top stays beside the hips. After two minutes, use eight one-minute rounds. Top follows with open-hand waist contact only, then releases; bottom never rises during contact. |

| 45-55 | Correct the safe start | After a two-minute demonstration, use eight 40-second rounds and 20-second rests. Partners assemble a comfortable checked start, freeze briefly, and ask the coach to observe one feature. Both release and swap; children do not physically reposition each other. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Practice top knee placement beside a foam pad without touching another athlete.

**Add challenge:** Use a slower or delayed start cue while keeping both athletes still and relaxed.

**Stop or change:** Stop for locked hands, neck contact, heavy downward pressure, squeezing, or discomfort in the bottom athlete.

**Look for:** Top places hands lightly in the checked start and releases immediately without disturbing the bottom athlete.

**Ask:** How can a top wrestler show control without using unnecessary force?

## Practice 17 Tight Waist Chop

**Goal:** Use a tight-waist and near-arm chop breakdown, then maintain balanced legal top control.

**Set up:** Spaced grounded stations, fitted ear guards, and qualified coaches checking contact.

**Before you begin:** Review B22. Confirm a bent-elbow descent, gentle rear-knee hip drive and cross-wrist capture before adding a rebuild response.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Slow base travel | Show one small hand-and-knee advance followed by a stable pause. After two minutes, run six 30-second movement and 30-second rest rounds. Athletes work individually inside a short lane; travel stops before the head lowers or supports become crowded. |

| 13-23 | Learn - B22 | From a left-side start, snug the right waist arm. Left forearm folds their left elbow toward the belly as toes drive forward and the rear right knee moves their hips forward. Bottom lowers through forearms to belly. Right hand catches their left wrist across the belly; left hand controls that upper arm. After two teaching minutes, use eight cooperative turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Receive and Catch the Wrist | After two teaching minutes, use eight one-minute turns. Coordinate a short elbow fold with forward foot and rear-knee drive. Bottom yields through a bent elbow to forearms and belly. Catch the left wrist with the right hand, keep it below the chest, and follow the hips. Release and swap; no striking or arm wrenching. |

| 35-45 | Breakdown versus base adjustment | After two teaching minutes, run twelve 20-second rounds with 20-second feedback/rest, alternating roles. Approved top athletes seek the taught breakdown; bottom resists by small base adjustments only, keeping elbows unlocked. Stop at controlled belly-down position, standing, or discomfort. Novices cooperate. |

| 45-55 | Breakdown and rebuild challenge | After two teaching minutes, use sixteen 15-second rounds with 15-second feedback/rest. Approved top athletes use the taught chop; bottom maintains base through small adjustments. Stop at controlled breakdown, then release so bottom rebuilds. Swap roles; novices keep the receiving task cooperative. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Practice hand placement and receiving separately before combining.

**Add challenge:** Read one small base adjustment before coordinating the same waist draw and chop.

**Stop or change:** Stop for straight-arm wrenching, joint pain, neck pressure, trapped fingers, uncontrolled collapse, or any mat return.

**Look for:** Top completes a controlled breakdown while bottom receives onto forearms and both release promptly.

**Ask:** How did timing help more than pulling harder?

## Practice 18 Escape From Controlled Top Contact

**Goal:** Rebuild base after a controlled breakdown and use hand control to stand and clear.

**Set up:** Matched stations, clear standing lanes, fitted ear guards, and qualified coaches.

**Before you begin:** Coach approves breakdown receiving, base recovery, and hand-controlled rising before resistance; novices use separate cooperative steps. Rebuild base using B16: outside knee up, hips back, other knee underneath. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Base clear rise solo | Demonstrate base, an imaginary wrist clear, planting a foot, standing, and facing forward. After two minutes, use six 30-second work and 30-second rest rounds. Athletes move independently and pause between steps rather than rushing the whole sequence. |

| 13-23 | Learn - B16 to B17 | After a cooperative breakdown, bottom brings the outside knee alongside, shifts hips back and brings the other knee under to build base (B16). With rider left, use B17: left foot up, right hand controls their right hand, rise, clear hips and turn right. After two teaching minutes, use eight cooperative turns with a pause between skills. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | One top action then escape | After two teaching minutes, use eight 30-second practice and 30-second reset rounds. Top performs one controlled breakdown, then maintains light waist contact while bottom rebuilds and controls the wrist. Top follows lightly without a mat return; neither athlete adds a new counter or return. |

| 35-45 | Base and escape rounds | After two teaching minutes, run twelve 20-second rounds with 20-second feedback/rest, alternating roles. Approved bottom athletes rebuild base and seek the hand-controlled stand-up; top follows with light waist contact only. Stop at standing or clearance, with no returns. Novices cooperate. |

| 45-55 | Three stage escape circuit | After two teaching minutes, run eight 40-second rehearsal and 20-second rest rounds at staffed stations: controlled breakdown receiving, rebuilding base, and hand-controlled stand-up. Alternate partners' roles; connect stages only after coach approval, and reduce to cooperative work whenever control deteriorates. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Practice base recovery alone, then clear cooperative waist contact before an unsupported rise.

**Add challenge:** After one controlled breakdown, choose when to control the wrist and rise.

**Stop or change:** Stop for wrist twisting, finger gripping, neck pressure, backward pulling, loss of balance, or any attempted mat return.

**Look for:** Bottom rebuilds base and uses hand control to reach a balanced standing escape.

**Ask:** How did rebuilding base help?

## Practice 19 Go Behind And Establish Control

**Goal:** Connect a grounded go-behind to a stable, legal top-control position against a limited response.

**Set up:** Separated grounded stations, fitted ear guards, flat start markers, and qualified coaches able to interrupt each pair.

**Before you begin:** Coach approves both partners' legal contact, balance, control, and immediate release before resistance; novices rehearse cooperatively.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Circle a floor target | Demonstrate slow knee travel around a flat marker without crossing over it. After two minutes, use six 30-second movement and 30-second rest rounds. Keep eyes up and knees clear of imaginary partner arms; change direction only during rest. |

| 13-23 | Route into control | Show receiver holding base while mover circles outside the arms to behind the hips. Place one open hand at waist and one at upper arm without locking. After two minutes, use eight one-minute turns; coach checks legal control, then release. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | One permitted pivot | After two minutes demonstrating roles, use eight one-minute rounds containing a five-second attempt each way and rest. Receiver may make one small kneeling pivot; mover seeks the outside route and stable hip control. No grabbing the head or climbing. |

| 35-45 | Earn controlled position | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved movers seek legal hip-and-near-arm control; defenders pivot to face. Stop on control, standing, or lost safety. Novices use cooperative routes. |

| 45-55 | Control or face challenge | After two teaching minutes, repeat twelve 20-second rounds and 20-second feedback/rest periods. Coach-approved pairs challenge hip control against facing pivots. Recognize controlled objectives and immediate release; alternate roles, while novices rehearse cooperative routes without a contested outcome. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Receiver remains still; mover completes the outside route cooperatively.

**Add challenge:** After a defended first route, change direction while preserving safe space and legal hip-and-near-arm control.

**Stop or change:** Stop for neck holds, joint pressure, limb tangling, uncontrolled scrambling, standing, or failure to release.

**Look for:** Mover reaches stable coach-confirmed legal control without head pressure and releases immediately.

**Ask:** What made the finish controlled rather than simply touching the hips?

## Practice 20 Stand Clear And Face Your Partner

**Goal:** Complete the hand-controlled stand-up against light, limited top resistance.

**Set up:** Matched partner stations, open standing lanes, fitted ear guards, and qualified coaches overseeing contact-to-standing transitions.

**Before you begin:** Review B17. Confirm inside-leg rise, retained hand control and hip clearance before the right turn; top follows without a mat return.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Rise turn balance | Demonstrate a solo rise from base, a balanced pause, then turning to face a distant marker. After two minutes, run six 30-second work and 30-second rest rounds. Keep the neck neutral and feet under control throughout. |

| 13-23 | Learn - B17 With a Follower | Demonstrate B17 with rider left: left foot up, chest lifted, right hand controls their right hand near the wrist. Rise, hold that hand away, clear hips forward and turn right to face. Top follows lightly and lets the hand clear without twisting. After two teaching minutes, use eight one-minute cooperative turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Follow without returning | After two teaching minutes, alternate roles through eight 30-second practice and 30-second reset rounds. Top follows the controlled rise without locking hands or pulling backward. Bottom maintains whole-hand wrist control; top follows lightly without a mat return before bottom clears and faces. |

| 35-45 | Stand against light contact | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved bottom athletes seek the taught stand-up; top maintains light waist contact while grounded, then releases at standing. Stop on escape or standing. Novices cooperate. |

| 45-55 | Hand control escape challenge | After two teaching minutes, use sixteen 15-second attempts with 15-second feedback/rest, alternating roles. Approved pairs use controlled waist contact and the taught stand-up, stopping at standing or escape. Discuss which hand-control adjustment helped; novices clear first and rise without contact. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Top releases before the rise; bottom practices standing and facing separately.

**Add challenge:** Keep wrist control while rising as top follows lightly, then clear and face without losing balance.

**Stop or change:** Stop for finger grips, wrist twisting, backward pulling, lost balance, locked hands, or attempted mat returns.

**Look for:** Bottom controls the wrist, rises balanced, clears contact, and faces the partner.

**Ask:** Why should the turn happen after you have found your balance?

## Practice 21 Connect A Takedown To Top Control

**Goal:** Finish a controlled double leg and establish balanced top control.

**Set up:** Wide receiving lanes, fitted ear guards, and qualified coaches supervising transitions.

**Before you begin:** Coach approves entry, controlled receiving, and top control before standing finishes; novices use low starts. Use B07 for the double-leg finish.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Two stance steps and stop | Show two small stance steps, a slight level change, and a balanced freeze. After two minutes, use six 40-second work and 20-second rest rounds. Athletes work individually and return slowly to their start markers after each sequence. |

| 13-23 | Finish and settle | Demonstrate an upright double-leg entry, gather behind thighs, and step around to steer a controlled hip-and-side descent. Follow into balanced top control without crossing the head. After two teaching minutes, use eight one-minute turns; novices begin low or rehearse separately. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Check both landing roles | After two teaching minutes, use eight one-minute turns. Receiver practices controlled descent without a locked-arm post; attacker stays balanced and follows the hips. Coach approves each pair before standing starts. Pause at top control, release completely, and alternate roles. |

| 35-45 | Finish against one retreat | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved defenders may retreat once before contact, then receive cooperatively. Attackers finish only balanced entries and settle legal top control. Stop there; novices use low-start repetitions. |

| 45-55 | Takedown and control team task | After two teaching minutes, use eight 40-second rehearsal and 20-second rest rounds. Partners alternate a controlled double-leg finish and top-control pause, checking entry balance, receiver descent, and head clearance. Choose low or standing starts according to coach approval; reset whenever control fades. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Start low for the finish, or rehearse entry and top control separately.

**Add challenge:** Read an early retreat, finish through a balanced opening, and settle top control.

**Stop or change:** Stop for crown-first entry, uncontrolled descent, locked-arm posts, lifts, slams, knee twisting, or compressed head or neck.

**Look for:** Pair completes a controlled double-leg descent and balanced top control with immediate release.

**Ask:** How did your finish help you arrive in balanced top control?

## Practice 22 Defend A Grounded Go Behind

**Goal:** Use controlled kneeling pivots to prevent a grounded opponent from reaching hip control.

**Set up:** Wide grounded stations, flat markers, fitted ear guards, and qualified coaches.

**Before you begin:** Coach approves both partners' legal contact, balance, control, and immediate release before resistance; novices rehearse cooperatively.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Small base pivots | Demonstrate moving one hand and one knee slightly to turn a stable base. After two minutes, use six 30-second work and 30-second rest rounds. Athletes work alone, keep head clear, and stop before hands or knees become tangled. |

| 13-23 | Turn toward the route | Show mover beginning beside the shoulder and slowly circling outside the arms. Defender makes one small base pivot toward the mover without grabbing. After two minutes, use eight one-minute turns; stop before either athlete loses balance or crowds the head. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | One route one pivot | Spend two minutes confirming roles and the single-pivot limit. Run eight one-minute rounds with a five-second attempt per role and rest. Mover seeks hip-and-arm control; defender turns once to stay facing. No head blocking, diving, or repeated scrambling. |

| 35-45 | Face versus go behind | After two teaching minutes, run twelve 20-second rounds with 20-second feedback/rest, alternating roles. Approved movers seek hip-and-near-arm control; defenders use small grounded pivots to stay facing. Stop at control, standing, or unsafe crowding; novices announce routes and cooperate. |

| 45-55 | Defend either outside route | After two teaching minutes, use sixteen 15-second rounds and 15-second feedback/rest, alternating roles. Approved movers choose either outside route; defenders pivot to face without grabbing the head. Stop on control or standing, discuss the useful reaction, and keep novices cooperative. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Announce the route and practice the pivot without any top contact.

**Add challenge:** Read either outside route and use repeated small facing pivots within the same round.

**Stop or change:** Stop for neck contact, limb tangling, joint pressure, uncontrolled scrambling, standing, or delayed release.

**Look for:** Defender preserves a grounded facing position against an outside route and releases promptly when the round ends.

**Ask:** What did you notice before choosing which way to turn?

## Practice 23 Choose A Bottom Escape Response

**Goal:** Rebuild base when necessary, then control the waist wrist and stand to escape.

**Set up:** Matched stations, clear standing lanes, fitted ear guards, and qualified contact supervision.

**Before you begin:** Coach approves base recovery and hand-controlled rising before light resistance; top releases at standing and never returns bottom. Rebuild base using B16: outside knee up, hips back, other knee underneath. Use B17 for the inside-leg stand-up.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Base adjust and settle | Show a small hand or knee adjustment followed by a stable pause, then an optional solo stand-up. After two minutes, run six 30-second movement and 30-second rest rounds. Athletes choose only comfortable transitions and keep the head upright. |

| 13-23 | Learn - Base or Stand-Up | Show belly-down and stable-base starts. From belly, use B16: outside knee up, hips back, other knee under. From base with rider left, use B17: left foot up, control their right hand with yours, rise, clear hips and turn right. After two teaching minutes, use eight cooperative turns; pause whenever the position becomes unclear. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Recover before rising | After two teaching minutes, use eight one-minute turns. Top supplies light waist contact while bottom rebuilds base and controls the wrist. Once balanced, bottom rises and clears; top follows lightly without a mat return. Novices separate recovery, clearing, and an unsupported rise. |

| 35-45 | Choose base then stand | After two teaching minutes, run twelve 20-second rounds with 20-second feedback/rest, alternating roles. Approved bottom athletes rebuild base and seek the taught stand-up; top follows with light waist contact only. Stop at standing or escape; novices rehearse separate cooperative steps. |

| 45-55 | Escape decision challenge | After two teaching minutes, use sixteen 15-second attempts with 15-second feedback/rest. Alternate stable-base and cooperative belly-down starts. Approved bottom athletes rebuild, control the wrist, and rise; top follows lightly and releases at standing. Novices cooperate, pausing between each step. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Coach announces the first action; top provides completely cooperative contact.

**Add challenge:** Recover from the taught controlled breakdown, then choose the moment to control the wrist and rise.

**Stop or change:** Stop for painful pressure, wrist twisting, finger grips, uncontrolled collapse, backward pulling, or attempted mat returns.

**Look for:** Bottom rebuilds base when needed, then completes a balanced hand-controlled escape.

**Ask:** When was rebuilding your base more useful than trying to stand immediately?

## Practice 24 Link Your Safe Wrestling Choices

**Goal:** Choose familiar top breakdown, grounded go-behind, or hand-controlled escape objectives.

**Set up:** Three separate skill stations, fitted ear guards, and qualified coaches supervising every contact pair.

**Before you begin:** Coach approves both partners' legal contact, balance, control, and immediate release before resistance; novices rehearse cooperatively. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Movement choice lanes | Demonstrate stance stepping, a stable base, and a solo stand-up in separate lanes. After two minutes, run six 40-second work and 20-second rest rounds. Athletes choose one comfortable movement per round and avoid changing levels near another athlete. |

| 13-23 | Show three wrestling objectives | Demonstrate grounded go-behind against facing pivots, tight-waist chop against base adjustments, and stand-up against light waist contact. After two teaching minutes, use eight one-minute cooperative turns. Identify each endpoint: hip control, controlled breakdown, or standing with release and escape. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Rehearse station roles | After two teaching minutes, use eight one-minute turns at staffed stations. Partners rehearse the go-behind, chop, or stand-up cooperatively; coach checks receiving and control before resistance. Explain the station's single permitted defense and endpoint, then swap roles with full release. |

| 35-45 | Choose a positional objective | After two teaching minutes, use twelve 20-second rounds with 20-second feedback/rest. Approved pairs choose go-behind versus facing pivots, chop versus base adjustments, or stand-up versus light waist contact. Alternate roles; release at control, breakdown, or standing. Novices rehearse cooperatively. |

| 45-55 | Break down or keep base | After two teaching minutes, run sixteen 15-second rounds with 15-second feedback/rest, alternating roles. Approved top athletes seek the tight-waist chop; bottom maintains base with small adjustments and unlocked elbows. Stop at controlled breakdown or standing. Novices rehearse receiving cooperatively. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Complete one station cooperatively for the entire block, with additional explanation and rest.

**Add challenge:** Choose between two taught objectives across rounds and adapt to each task's permitted defense.

**Stop or change:** Stop for unclear roles, unpracticed counters, neck pressure, joint pain, uncontrolled descent, or attempted mat returns.

**Look for:** Athlete chooses a taught objective, adapts to its permitted defense, and releases at the agreed endpoint.

**Ask:** Which wrestling choice feels most reliable for you now?

## Practice 25 Half Nelson and Early Defense

**Goal:** Apply a controlled half nelson and recognize its early defense.

**Set up:** Position cards, spaced mat stations, fitted ear guards, and qualified coaches for grounded tasks.

**Before you begin:** Review B26-B27. Confirm cooperative shoulder rotation; defense is taught only while the neck remains free and before turning pressure.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Position picture walk | Show pictures of standing neutral, hands-and-knees bottom, and a kneeling top beside the hips. After two minutes, use six 40-second walking and 20-second rest rounds. Athletes identify pictures from their own spaces; no rushing toward shared cards. |

| 13-23 | Learn - B26 | From the left side, left arm threads under their left armpit, palm on the back of the head. Right hand blocks the far elbow beneath the chest. Lift the half elbow and walk feet left toward the head to a T. Drive chest to turn the torso onto its right side and settle. After two teaching minutes, use eight cooperative turns. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Rehearse Turn and Defense Separately | After two teaching minutes, use eight one-minute turns. First rehearse B26 with a cooperative receiver. Separately teach B27 against a loose left half: left elbow and shoulder stay low, look right while the neck is free, and left hand clears the whole hand. Rebuild base after clearing. Stop a tight hold for top to release. |

| 35-45 | Turn or Clear | After two teaching minutes, use twelve 20-second attempts with 20-second rest. Coach calls Turn for a cooperative B26 turn, or Clear for one loose B27 insertion and early defense. Swap roles. Clear rounds stop before turning pressure; Turn rounds have a cooperative receiver. Reset any blocked or uncomfortable position. |

| 45-55 | Recognize turn or reset | After two teaching minutes, use eight 40-second rehearsal and 20-second rest rounds. Partners announce an open arm or early elbow-closing defense. Top chooses controlled half-nelson turn or reset; coach checks palm placement and neck clearance. Novices demonstrate placement without turning. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Rehearse arm and palm placement without turning; practice the early defense separately.

**Add challenge:** Reset against early elbow closure; turn only through a controlled opening.

**Stop or change:** Stop for head or neck compression, painful shoulder pressure, forced bridging, trapped limbs, distress, or any full nelson.

**Look for:** Athlete uses checked palm placement and shoulder rotation for a controlled turn and prompt release.

**Ask:** When should you reset?

## Practice 26 Respect Boundaries And Restart Safely

**Goal:** Notice practice boundaries, stop before entering the buffer, and restart from an agreed position.

**Set up:** Flat inner boundary markers, wide clear buffer areas, fitted ear guards, and central restart markers.

**Before you begin:** Coach approves half-nelson palm placement, shoulder rotation, controlled receiving, and prompt release before resistance; novices rehearse placement. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Find the safe middle | Demonstrate moving inside an inner marker line with a clear unused buffer outside. After two minutes, use six 40-second movement and 20-second rest rounds. Athletes take short stance steps and stop before the line, then walk back centrally. |

| 13-23 | Stop before the buffer | Explain that these practice rounds stop before the inner line, regardless of different event rules. After two minutes, use eight one-minute turns. Partners move without contact, freeze on the cue, separate, and walk to central markers before restarting. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Turn within safe space | After two teaching minutes, run eight 30-second practice and 30-second rest rounds. Rehearse the half nelson cooperatively: checked palm, lifted elbow, and circling shoulder rotation. Coach stops before the inner line; release completely and return separately to the center. |

| 35-45 | Turn or boundary stop | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved pairs use half nelson versus early elbow closure; reset if blocked and receive cooperatively once secured. Stop on controlled turn or inner line. Novices rehearse placement. |

| 45-55 | Contested round clean restart | After two teaching minutes, use sixteen 15-second grounded rounds with 15-second feedback/rest, alternating roles. Approved movers seek hip control while defenders pivot to face. Either athlete calls boundary before the buffer; both release, reset separately, and check readiness. Novices cooperate. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Practice walking routes and restarts without contact.

**Add challenge:** Recognize a blocked half, reset, and restart without forcing the neck or chasing boundaries.

**Stop or change:** Stop before buffers or crowds, for head or neck compression, or full nelsons; release completely before repositioning.

**Look for:** Both athletes release and return to the middle separately before restarting.

**Ask:** What should happen before a new attempt begins after a boundary stop?

## Practice 27 Try A Restricted Mock Match

**Goal:** Try a supported event using taught takedown or escape objectives.

**Set up:** Marked practice areas, qualified referee-coaches, fitted ear guards, timer, and supervised waiting space.

**Before you begin:** Participation is voluntary; coaches approve both partners' task-specific technique, controlled receiving, and prompt release before each restricted bout. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Choose a familiar preparation | Show three choices: short stance steps, solo base recovery, or a free stand-up from base. After two minutes, run six 40-second work and 20-second rest rounds. Athletes choose comfortable movements and privately tell a coach whether they want contact. |

| 13-23 | Explain the restricted event | Demonstrate two choices: upright double-leg entry with corner turn and controlled descent, or wrist-controlled stand-up with top following lightly without a mat return. After two teaching minutes, use eight one-minute cooperative turns. Coaches approve readiness; these restricted bouts do not establish full-match readiness. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Practice the referee routine | After two teaching minutes, use eight one-minute turns. Practice approaching the marker, confirming readiness, starting, and stopping. Double-leg defenders may retreat once before contact, then receive; escape partners maintain light waist contact, releasing at standing. Rehearse cooperatively before contested attempts. |

| 35-45 | Supported positional mini bouts | After two teaching minutes, referee-coaches run twelve 20-second bouts with 20-second feedback/rest, alternating roles. Approved athletes choose double-leg versus early retreat or stand-up versus light waist contact. Stop at top control, standing, or boundary. Novices choose cooperative demonstrations or low starts. |

| 45-55 | Process goal replay | After two teaching minutes, use sixteen 15-second rounds with 15-second feedback/rest, alternating roles. Repeat the chosen double-leg or stand-up objective against its permitted defense, tracking balanced entry or wrist control. Release at top control or standing; cooperative demonstrations remain equally welcome. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Complete the event routine and a fully cooperative demonstration without a contested attempt.

**Add challenge:** Adapt to the permitted early retreat or light waist-contact response while maintaining control.

**Stop or change:** Stop for distress, unfamiliar counters, uncontrolled descent, head or neck compression, lifts, slams, or attempted mat returns.

**Look for:** Athlete completes a restricted attempt and follows the event routine.

**Ask:** What felt comfortable, and what would you change?

## Practice 28 Explore The Wrestling Skills Festival

**Goal:** Explore taught takedown, breakdown, turn, and escape stations with suitable challenge.

**Set up:** Four staffed stations, task cards, fitted ear guards, and qualified coaches.

**Before you begin:** Coaches approve station-specific contact, control, and immediate release before resistance; unstaffed stations remain supervised and noncontact. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Festival movement tour | Walk through four staffed stations: double-leg finish, tight-waist chop, half nelson, and stand-up. After two demonstration minutes, use six 30-second solo movement and 30-second rest rounds. Rehearse entry footwork, base recovery, circling, or rising without contact during the tour. |

| 13-23 | See every station task | After two teaching minutes, use eight one-minute cooperative turns. Demonstrate double-leg corner and controlled descent, bent-arm chop to forearms, half-nelson shoulder rotation with checked palm, and wrist-controlled rise. Explain the endpoint at each station: top control, breakdown, turn, or standing. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Supported station practice | After two teaching minutes, use eight one-minute cooperative turns at staffed stations. Rehearse each chosen technique and receiving role. Coach checks readiness before allowing its defense: early retreat, small base adjustment, early elbow closure, or light waist contact. Novices stay cooperative. |

| 35-45 | Choose your challenge level | After two teaching minutes, run twelve 20-second attempts with 20-second feedback/rest at staffed stations. Approved pairs contest their rehearsed technique against its single taught defense. Alternate roles; stop at top control, breakdown, turn, or standing. Cooperative repetitions and low starts remain available. |

| 45-55 | Objective and partner care | After two teaching minutes, use sixteen 15-second rounds with 15-second feedback/rest, alternating roles. Repeat the station's taught objective and permitted defense. Release at its agreed endpoint, name one useful adjustment and one caring action, and reduce resistance whenever receiving loses control. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Remain at a solo movement station, use a low start, or complete contact tasks cooperatively.

**Add challenge:** Adapt to the station's permitted defense while preserving controlled receiving and its endpoint.

**Stop or change:** Stop for unstaffed contact, unsuitable pairings, crowding, unfamiliar counters, or attempts beyond demonstrated readiness.

**Look for:** Athlete chooses a suitable station version and identifies a partner's helpful action.

**Ask:** Which station would you most like to visit again?

## Practice 29 Solve One Wrestling Problem

**Goal:** Choose one achievable improvement in a taught takedown, breakdown, turn, or escape.

**Set up:** Staffed skill areas, flat markers, fitted ear guards, and coach observation cards.

**Before you begin:** Coach approves both partners' legal contact, balance, control, and immediate release before resistance; novices rehearse cooperatively. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Choose and prepare | Demonstrate short stance steps, a comfortable base recovery, and a solo stand-up. After two minutes, run six 40-second movement and 20-second rest rounds. Athletes choose preparation matching their goal and tell the coach which movement feels easiest today. |

| 13-23 | Make the goal visible | After two teaching minutes, use eight one-minute cooperative turns. Choose one visible goal: upright double-leg corner, bent-arm chop with controlled receiving, half-nelson shoulder rotation with checked palm, or wrist-controlled rise. Coach supplies one cue and confirms the endpoint before contact. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Repeat with one cue | After two teaching minutes, use eight one-minute turns: attempt, release, feedback, and rest. Rehearse the chosen double-leg, chop, half, or stand-up cooperatively. Coach checks the receiving role and allows only previously taught resistance when both partners maintain control and immediate release. |

| 35-45 | Test your repair under resistance | After two teaching minutes, use twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved pairs test their chosen technique against early retreat, base adjustment, elbow closure, or light waist contact as appropriate. Stop at its agreed endpoint, assess the cue; novices cooperate. |

| 45-55 | Teach a helpful cue | Under direct coach supervision, run eight 40-second rounds and 20-second rests after two instruction minutes. Partners alternate demonstrating a chosen familiar task and offering one helpful cue. Children speak or point; they never physically reposition, pressure, or rank each other. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Choose one solo movement goal and receive feedback directly from the coach.

**Add challenge:** Keep the same improvement cue while adapting to the chosen technique's single taught defense.

**Stop or change:** Stop for peer pressure, physical correction by children, unapproved resistance, unsafe contact, or loss of confidence.

**Look for:** Athlete identifies one change that improves their chosen task and demonstrates it safely.

**Ask:** Which change helped your wrestling today?

## Practice 30 Celebrate Your Wrestling Toolbox

**Goal:** Demonstrate safe familiar skills, recognize progress, and choose a next learning goal.

**Set up:** Spaced stations, flat markers, fitted ear guards, observation cards, and qualified contact supervision.

**Before you begin:** Coach approves both partners' legal contact, balance, control, and immediate release before resistance; novices rehearse cooperatively. Use B07 for the double-leg finish. Use B17 for the inside-leg stand-up. Use B22 for the chop and wrist capture. Use B26-B27 for the half and early defense.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-05 | Welcome and readiness | Greet athletes, assign matched partners, and state today's task. Rehearse the spoken and visual stop signals twice. Confirm immediate release and offer a supervised noncontact option or observation to anyone needing it. |

| 05-13 | Favorite movement choices | Show stance stepping, island walking, base recovery, and solo stand-up options. After two minutes, run six 40-second activity and 20-second rest rounds. Athletes select a favorite comfortable movement inside their own area and may change choices during resets. |

| 13-23 | Show your useful sequence | After two teaching minutes, use eight one-minute cooperative turns. Choose a double-leg corner and controlled descent, bent-arm chop to forearms, half-nelson shoulder rotation with checked palm, or wrist-controlled rise. Coaches confirm receiving and each endpoint: top control, breakdown, turn, or standing. |

| 23-25 | Water and partner check | Use personal bottles and keep the rest area supervised. Ask partners about comfort and pace; adjust pairings before restarting. Water is freely available throughout practice, beyond this planned two-minute break. |

| 25-35 | Polish one familiar task | Use two minutes for each athlete to choose one useful cue with the coach. Run eight one-minute rounds containing one attempt per role, full release, feedback, and rest. Contact remains cooperative unless both athletes demonstrate readiness for the stated restricted response. |

| 35-45 | Choose a progress challenge | After two teaching minutes, use twelve 20-second attempts with 20-second feedback/rest, alternating roles. Approved pairs choose double-leg, chop, half, or stand-up against its taught defense. Release at top control, breakdown, turn, or standing. Novices choose cooperative showcases; introduce no new technique. |

| 45-55 | Partner appreciation collection | Under direct supervision, run eight 40-second rounds and 20-second rests after two teaching minutes. Partners choose a familiar cooperative task, complete one safe repetition each, and name a helpful action they noticed. Everyone receives equal turns without awards based on winning. |

| 55-60 | Reflect and finish | Gather in personal spaces and ask the closing question. Invite athletes to show or describe the success check. Recognize safe partnering, check belongings, and release children only through supervised pickup. |

**Make it easier:** Choose solo movement, observe, or share a favorite activity.

**Add challenge:** Explain an adjustment to a taught defense, then test the same controlled skill again.

**Stop or change:** Stop for pressure to perform, unfamiliar counters, uncontrolled descent, head or neck compression, or attempted mat returns.

**Look for:** Athlete shows a familiar skill safely and names or indicates a next learning goal.

**Ask:** What are you proud of? What comes next?

## References

These are original coaching designs. Use the current rules for your actual league or event, qualified instruction, and the club's medical and safeguarding procedures. Practice numbers do not certify tournament readiness.

[Grindstone Wrestling Club and Mat Rats](https://www.grindstonewrestling.org/mat-rats)

[Westminster Mat Rats Wrestling on Facebook](https://www.facebook.com/WestminsterMatRats/)

[USA Wrestling Folkstyle Level 1 technique demonstrations](https://www.usawmembership.com/usa_wrestling_core_curriculum/1)

[NFHS folkstyle rules resources; confirm youth event modifications](https://www.nfhs.org/sports/wrestling/rules)

[American Academy of Pediatrics sports readiness](https://www.healthychildren.org/English/healthy-living/sports/Pages/Is-Your-Child-Ready-for-Sports.aspx)

[CDC concussion response](https://www.cdc.gov/heads-up/response/index.html)

[CDC infection prevention for athletes](https://www.cdc.gov/mrsa/prevention/athletes.html)

## Coach reminders

Keep water available. Children participate at their normally nourished and hydrated weight. Remove suspected concussion from activity and obtain medical evaluation; no same-day return. Suspected contagious skin concerns need evaluation before contact. Follow actual club reporting and emergency procedures.

## After practice

Which task helped the group learn? Who needs a different partner or an easier version? What should be repeated? Record private health or safeguarding matters through the club's secure process.
