# Grindstone Wrestling - Quick Coaching Cues, Ages 4-6

Use these reminders with the shared Coach Moves Reference. Full teaching steps, prerequisites, corrections and research are organized there by move ID. Follow the current practice task; an entry-only lesson does not authorize a finish.

## Stance and Footwork

**Full instruction:** P01: Wrestling Stance, p. 6 / P02: Stance Steps, p. 6

**P01 cues:** Knees bent, eyes ahead. / Hands forward, elbows in.

**P02 cues:** Step, follow, feet apart. / Eyes ahead, knees bent.

**Coach check:** Feet line up like a tightrope, or the child bends only at the waist.

**Fix:** Restore sideways foot space, then show a smaller bend through both knees and hips.

**Original practice links:** 3, 12, 29, 30

## Level Change

**Full instruction:** P03: Level Change, p. 7

**P03 cues:** Knees bend, hips lower. / Back to your stance.

**Coach check:** Bowing at the waist while the hips stay high, or straightening the legs on the return.

**Fix:** Use a smaller knee bend. Show the starting stance and finish at that same height.

**Original practice links:** 4, 12, 23, 29, 30

## Level Change and Step

**Full instruction:** P04: Level Change and Step, p. 7

**P04 cues:** Lower, then step. / Keep your feet apart.

**Coach check:** Reaching the front foot far ahead while the hips stay behind, then gathering the feet together.

**Fix:** Bring the marker closer and finish with the same foot spacing as the starting stance.

**Original practice links:** 5, 23, 29, 30

## Bottom Base

**Full instruction:** P05: Bottom Base, p. 8

**P05 cues:** Chest off the mat. / Move a hand, rebuild your base.

**Coach check:** Reaching a hand far forward until the chest drops or the body rolls sideways.

**Fix:** Keep the hand close to its starting spot; first practice a small weight shift with both palms down.

**Original practice links:** 6, 14, 18, 27, 29, 30

## Solo Sprawl

**Full instruction:** P07: Solo Sprawl, p. 9

**P07 cues:** Legs back, hips low. / Feet under, back to stance.

**Coach check:** Stopping in a high plank or dropping onto the knees.

**Fix:** Slow down: extend the legs, lower the hips briefly, then recover. Avoid a long hold.

**Original practice links:** 14

## Solo Stand-Up

**Full instruction:** P08: Solo Stand-Up, p. 9

**P08 cues:** Chest up, foot under. / Clear hips, turn and face.

**Coach check:** A long first step leaves the chest folded over the thigh.

**Fix:** Shorten the step and pause with chest lifted before rising.

**Original practice links:** 8, 27, 30

## Solo Sit-Out

**Full instruction:** P09: Solo Sit-Out, p. 10

**P09 cues:** Foot out, leg through. / Sit low, chest up.

**Coach check:** Sitting down before the left leg clears, trapping that knee under the hips.

**Fix:** Rehearse the foot step and small hip lift; slide the leg clear before lowering your seat.

**Original practice links:** 18, 27, 29, 30

## Mirror Footwork

**Full instruction:** P02: Stance Steps, p. 6

**P02 cues:** Step, follow, feet apart. / Eyes ahead, knees bent.

**Coach check:** The following foot catches the first foot, making the stance narrow or crossed.

**Fix:** Shorten the first step and stop the following foot at the original stance width.

**Original practice links:** 12, 29, 30
