# Grindstone Wrestling Coach Moves Reference

72 teaching entries | Pup / Beginner / Advanced

## Coach guide

### Use the tiers

Pup is a voluntary movement bank for the youngest children. Beginner is the starting technical pathway for a new wrestler at any older youth age. Advanced means the specific prerequisites, receiving, release and decision skills are established; it is not an age label.

### Keep the lesson small

Choose one main technique and one related response. Demonstrate both roles, name the finish position, give one cue, then let pairs work. The numbered steps are coach notes; athletes need one useful cue at a time.

### Progress the resistance

Rehearse the movement, complete cooperative repetitions, add one announced defensive response, then use a short positional problem. Use the card's drill as a starting dose, with rest and role changes. Progress only while both partners stay controlled.

### Match and supervise

Pair for size, maturity, skill and control. Teach the receiving pathway before a finish or turn. Stop on the coach's signal, pain, distress, unsafe joint position or loss of control. Advanced cards need a coach who can demonstrate and correct that technique.

### Use with the practice books

The 90 practice plans provide the session clock. This larger library expands the available techniques; many entries are new extensions. Substitute only after teaching their prerequisites. The binder index gives exact pages for every move, practice and support document.

### Read the research

Move-specific source keys such as P07-S1 link to inspected source material. The separate Grindstone Move Research report records the chosen variant, evidence, corrections and teaching decisions for each ID. Practice doses and simplified progressions are coaching designs. Apply the actual event rules.

### Remember the terms

Each card uses a specific right/left example; mirror the entire sequence together. Near means the side closest to the demonstrated top or attacking position; far means the opposite side. Underhook and overhook name arm position. A ride maintains control, a turn exposes shoulders, an escape reaches neutral, and a reversal gains top control.

## Pup

### P01 Wrestling Stance

**Purpose:** Build a balanced stance with hands in front, ready to move or defend.

**Before teaching:** Child can stand independently, copy a small knee bend, and stop on the coach's signal.

1. Face the coach in your own mat space. Set feet about shoulder-width apart, with your right foot a little ahead of your left. Leave space sideways between the feet.

2. Bend your knees and hips enough to lower slightly. Keep your back long, chest slightly forward, and eyes ahead; do not sit into a deep squat.

3. Bring both hands in front of your body, fingers relaxed and elbows bent close to your sides. Keep shoulders and hips facing the coach.

4. Balance across both feet with pressure toward the balls of the feet. Keep heels near the mat; do not stand on tiptoe or lean onto your hands.

5. Pause for one easy breath, then stand and relax. Rebuild on the coach's signal. Try left foot forward after a full reset.

**Cues:** Knees bent, eyes ahead. / Hands forward, elbows in.

**Common error:** Feet line up like a tightrope, or the child bends only at the waist.

**Correction:** Restore sideways foot space, then show a smaller bend through both knees and hips.

**Drill / progress:** Copy three stance-and-relax repetitions. Then play statues: coach raises a hand for stance and lowers it for standing rest. Keep each pause brief; change lead foot after successful repetitions.

**Watch / stop:** Solo only. Stop for pain or repeated loss of balance; use a smaller bend and more space.

**Resources:** P01-S1, P01-S2, P01-S3

### P02 Stance Steps

**Purpose:** Move toward, away from, and beside a target without losing your wrestling stance.

**Before teaching:** Can hold the stance from P01, take a short step, and stop on a signal.

1. Face the coach in a clear lane. Put your left foot slightly ahead, feet apart, knees bent, hands forward and elbows near your sides. Keep eyes ahead.

2. Go forward: take a small step with your left foot, then bring your right foot forward enough to restore the starting space between your feet.

3. Go backward: move your right foot back first, then follow with your left. Finish with the left foot still slightly ahead.

4. Go sideways: left foot first to your left; right foot first to your right. Follow with the other foot without touching or crossing feet. Keep facing forward.

5. Pause balanced after each pair of steps, keeping knees bent. Stand to rest, then rebuild the stance before repeating.

**Cues:** Step, follow, feet apart. / Eyes ahead, knees bent.

**Common error:** The following foot catches the first foot, making the stance narrow or crossed.

**Correction:** Shorten the first step and stop the following foot at the original stance width.

**Drill / progress:** Copy one direction at a time without contact. Then play follow-the-arrow for 20-30 seconds: the coach signals one direction, the child takes one step-and-follow, and freezes. Rest before repeating.

**Watch / stop:** Use clear mat space, including behind the child. Stop for pain, stumbling or crowding; no pushing or racing.

**Resources:** P02-S1, P02-S2, P02-S3

### P03 Level Change

**Purpose:** Lower the hips in wrestling stance while staying balanced, ready for a later step-in entry.

**Before teaching:** Can hold the P01 stance briefly and make a small, pain-free knee bend.

1. Start alone in a staggered stance, with feet apart and one foot slightly ahead. Keep hands in front and elbows close.

2. Keep both feet in place. Bend the knees a little more and lower the hips between the feet; the head lowers with the hips.

3. Keep the back firm and eyes forward. Use a small range that preserves balance, without folding the chest toward the mat or tipping the chin up.

4. Return to the starting stance height with knees still bent. Pause balanced, then relax fully before the next repetition.

**Cues:** Knees bend, hips lower. / Back to your stance.

**Common error:** Bowing at the waist while the hips stay high, or straightening the legs on the return.

**Correction:** Use a smaller knee bend. Show the starting stance and finish at that same height.

**Drill / progress:** Copy two slow level changes, then rest. Next, lower when the coach lowers an open hand and return to stance when it rises. Coach stays out of reach; no contact or racing.

**Watch / stop:** Do not push a child lower. Stop for pain or loss of balance; reduce the depth before retrying.

**Resources:** P03-S1, P03-S2

### P04 Level Change and Step

**Purpose:** Prepare for a leg-attack entry by lowering the hips and moving forward in balance. This is a standing preparation drill, not a complete penetration step.

**Before teaching:** Can hold a staggered stance, take short stance steps, and lower through the hips and knees.

1. Start with your right foot slightly ahead of your left, feet apart and hands in front. Place a flat marker one short step ahead of the right foot.

2. Bend your knees and lower your hips a little, keeping your eyes forward and chest from folding toward the mat.

3. Push gently from the left foot and step the right foot toward the marker. Move your hips forward with the step; both knees stay off the mat.

4. Slide the left foot forward enough to restore your starting stance. Keep it behind and to the left of the right foot; do not bring the feet together.

5. Pause balanced, then relax and walk back. Practice the other lead only after a fresh reset.

**Cues:** Lower, then step. / Keep your feet apart.

**Common error:** Reaching the front foot far ahead while the hips stay behind, then gathering the feet together.

**Correction:** Bring the marker closer and finish with the same foot spacing as the starting stance.

**Drill / progress:** Copy three slow repetitions and rest. Then react to the coach lowering one hand: lower, step, recover stance, and freeze.

**Watch / stop:** Solo only; no grabbing, diving, or knee contact. Stop if balance or comfort is lost.

**Resources:** P04-S1, P04-S2, P04-S3

### P05 Bottom Base

**Purpose:** Support yourself on hands and knees so you can move without falling onto your belly.

**Before teaching:** Can lower to the mat, support weight on hands and knees, and stop on the coach's signal.

1. Kneel in clear mat space. Put both palms down about shoulder-width apart, beneath your shoulders.

2. Keep knees apart beneath your hips and your back roughly level. Press through your palms to support your chest; do not let your belly sag.

3. Look a little ahead with your head clear of the mat. Keep elbows facing back and able to bend; breathe normally.

4. Shift a little toward your left hand and both knees. Briefly lift your right palm, then replace it beneath your shoulder. Rebuild your base before trying the other hand.

5. Finish with both palms and knees supporting you. Sit up on your knees to rest, then rebuild when asked.

**Cues:** Chest off the mat. / Move a hand, rebuild your base.

**Common error:** Reaching a hand far forward until the chest drops or the body rolls sideways.

**Correction:** Keep the hand close to its starting spot; first practice a small weight shift with both palms down.

**Drill / progress:** Build, breathe, rest twice. Then the coach names one hand: shift, lift that palm briefly, replace it, and freeze in base. Alternate hands with rests.

**Watch / stop:** Solo practice. No one sits or pushes on the back. Stop for wrist or knee pain, arm collapse, or head contact.

**Resources:** P05-S1, P05-S2, P05-S3

### P06 Solo Belly to Base

**Purpose:** Recover from lying on the belly to a wrestling base, ready for the next bottom move.

**Before teaching:** Can lower to the belly and support a hands-and-knees base without pain or head contact.

1. Start alone on the belly, legs behind you. Bring forearms beside the chest, elbows close and head clear of the mat.

2. For a right-side recovery, slide your right knee forward along your right side. Keep your chest facing the mat; do not roll onto your back.

3. Press through your forearms and shift your hips back over the right knee. Slide your left knee underneath as your belly leaves the mat.

4. Come onto your palms with hands beneath shoulders and knees apart beneath hips. Keep elbows slightly bent and hips back, then pause balanced.

5. Lower gently through your forearms to reset on your belly. Repeat with your left knee coming forward first.

**Cues:** Knee up the side. / Hips back, build your base.

**Common error:** Pushing the chest up while both knees stay behind, leaving the belly stuck down.

**Correction:** Pause after bringing one knee alongside; shift the hips back before bringing in the other knee.

**Drill / progress:** Do two slow solo recoveries. Then the coach stands beside one hip without touching: bring the knee farther from the coach forward first. Reset and change sides.

**Watch / stop:** Solo on a wrestling mat. No jumping, neck support, or partner weight. Stop for pain or collapsing arms.

**Resources:** P06-S1, P06-S2, P06-S3

### P07 Solo Sprawl

**Purpose:** Learn the legs-back, hips-low action of a sprawl and recover to stance, using a slow step-back first.

**Before teaching:** Balanced stance, a small level change, and steady, pain-free hand support on the mat.

1. Start in stance on a wrestling mat with empty space behind you. Coach demonstrates from the side.

2. Bend hips and knees; place both palms on the mat in front of your feet, about shoulder-width apart. Keep your head clear.

3. Support your upper body and step one foot back, then the other. Keep feet apart and extend both legs behind you.

4. Lower your hips toward the mat, keeping them square and knees off the mat. Let elbows bend as needed; keep chest and head clear without forcing a back arch. Pause only briefly.

5. Lift hips enough to step feet forward underneath you, one at a time. Lift hands when your feet support a balanced crouch, then return to stance.

**Cues:** Legs back, hips low. / Feet under, back to stance.

**Common error:** Stopping in a high plank or dropping onto the knees.

**Correction:** Slow down: extend the legs, lower the hips briefly, then recover. Avoid a long hold.

**Drill / progress:** Copy two slow repetitions, then rest. When consistent, react to the coach's open-hand signal with one sprawl and a balanced reset.

**Watch / stop:** Solo only. Stop for pain, head contact, arm collapse, or uncontrolled dropping; return to stance practice.

**Resources:** P07-S1, P07-S2, P07-S3

### P08 Solo Stand-Up

**Purpose:** Rehearse stand-up footwork from base. This solo stage prepares for escaping a rider; actual hand control comes later.

**Before teaching:** P05 base, a steady half-kneeling rise, and a balanced stance.

1. Start on hands and knees, toes tucked, with an imaginary wrestler on your left. All directions describe your own body.

2. Lift your chest as your right foot steps forward under you. Bring your left forearm up across your chest and your right hand to your belly; avoid a long lunge.

3. Push through your right foot, bring your left foot underneath, and stand with knees bent and hips under your shoulders. Bring both hands to your waist to rehearse protecting that area.

4. Step your right foot slightly forward to clear your hips. Step your left foot back and around, turning left to face the imaginary wrestler; let both feet move with the turn.

5. Finish in stance with hands up. Walk back and lower into base for a fresh repetition; practice the mirror image after this side is steady.

**Cues:** Chest up, foot under. / Clear hips, turn and face.

**Common error:** A long first step leaves the chest folded over the thigh.

**Correction:** Shorten the step and pause with chest lifted before rising.

**Drill / progress:** Do two slow repetitions and rest. Then react to the coach's raised hand: rise, turn, and freeze in stance.

**Watch / stop:** Solo only. No pulling, pushing, head posting, or mat returns. Stop for pain or loss of balance.

**Resources:** P08-S1, P08-S2, P08-S3

### P09 Solo Sit-Out

**Purpose:** Learn to bring a leg and the hips through from base into a sit-out, preparing for later escapes.

**Before teaching:** P05; can step one foot up and briefly support a small hip lift without wrist pain or a trapped knee.

1. Begin on hands and knees in clear mat space. The coach demonstrates with the right foot leading; all directions refer to your own body.

2. Cross your left hand in front of your right hand and plant that palm on the mat. Lift your right hand beside your right thigh, keeping that elbow close.

3. Step your right foot a short distance forward and outward. Press through that foot and your left hand to make room beneath your hips.

4. Slide your left leg under the raised right knee and forward. Bring your hips through into a low seat, with your right knee bent and chest up.

5. Reposition your supporting hand beside your hip as needed. Pause balanced, then reset separately to hands and knees. Mirror the sequence after learning this side.

**Cues:** Foot out, leg through. / Sit low, chest up.

**Common error:** Sitting down before the left leg clears, trapping that knee under the hips.

**Correction:** Rehearse the foot step and small hip lift; slide the leg clear before lowering your seat.

**Drill / progress:** Copy two slow repetitions, then rest. When consistent, sit out on the coach's open-hand signal and hold base on a closed-hand signal.

**Watch / stop:** Solo only. Stop for pain, a trapped leg, head contact, or falling onto a straight arm.

**Resources:** P09-S1, P09-S2, P09-S3, P09-S4, P09-S5

### P10 Hip-Heist Preparation

**Purpose:** Learn the hip lift and leg-through that turn a seated wrestler toward the mat; this solo preparation does not teach a complete escape.

**Before teaching:** Can sit with bent knees, support a brief hip lift on a hand and opposite foot, and return to base without pain.

1. Sit with knees bent and feet apart. For this right-side turn, place your right palm beside and slightly behind your right hip; keep your left hand free.

2. Press through your right hand and left foot. Lift your seat enough to free your right leg; keep your head off the mat.

3. Thread your right leg underneath your left leg and back as you turn your chest toward your right hand. Let the left foot turn with your hips.

4. Place your left palm on the mat. Once the leg is clear, settle both knees into base facing back toward where you started sitting.

5. Pause, then reset separately to sitting. Learn the opposite side only after this side is smooth.

**Cues:** Lift, then thread your leg. / Turn your foot with your hips.

**Common error:** Walking in a circle without lifting and passing a leg underneath.

**Correction:** Practice only the small hip lift, then add one leg-through; reset if the foot catches.

**Drill / progress:** Rehearse two slow repetitions and rest. Then complete one repetition on the coach's signal, finishing still in base.

**Watch / stop:** Solo only. Stop for wrist pain, a trapped foot, knee twisting, or arm collapse. No head posts or partner pushing.

**Resources:** P10-S1, P10-S2, P10-S3, P10-S4

### P11 Go-Behind Footwork

**Purpose:** Practice circling from in front to behind imagined hips. This is preparation for a go-behind, without contact or a takedown.

**Before teaching:** Can take short stance steps and stop balanced on a signal.

1. Mark an oval on the mat with flat tape or markers. Identify its head end and hip end. Put a start spot outside the head end and a finish spot beyond the hip end.

2. Begin on the start spot in a shallow stance, hands in front and eyes looking along the route. The oval stays empty.

3. Circle to your right: step your right foot right, then bring your left foot along without crossing or touching feet together.

4. Continue around the outside with small stance steps, gradually turning to face the oval. Keep both feet outside it; do not cut through the imagined head or arms.

5. Stop beyond the hip end, facing toward the head end. Stand and walk outside the station to reset. Repeat left, with the left foot leading.

**Cues:** Small steps around. / Finish behind the hips.

**Common error:** Crossing feet or stopping beside the hip marker.

**Correction:** Slow down and follow the outside arc all the way to the finish spot.

**Drill / progress:** Rehearse once each way. Then the coach points right or left before each start; circle that way and freeze behind the hips.

**Watch / stop:** No partner inside the oval, crawling, grabbing, or racing. Stop if balance or spacing breaks down.

**Resources:** P11-S1, P11-S2, P11-S3

### P12 Side Breakfall Prep

**Purpose:** Rehearse the side-breakfall position from the floor, without a drop or partner.

**Before teaching:** Child willingly rolls on a wrestling mat and can briefly keep the head clear while the coach watches.

1. Lie on your back in a clear mat space, feet apart and knees slightly bent. Gently bring your chin toward your chest and lift your head clear.

2. To practise your right side, bring your right hand toward your left shoulder. Rest your left hand near your belly.

3. Slowly turn your shoulders and hips toward your right, rolling across your right shoulder blade onto your side. Keep your legs uncrossed and head clear.

4. As you turn, open your right arm diagonally away from your body toward your feet. Gently tap the mat with the palm and length of the arm together; do not prop yourself on the elbow or hand.

5. Pause on your side, return slowly to your back, and rest. Reverse the instructions for your left side.

**Cues:** Chin in, head clear. / Roll and tap together.

**Common error:** Propping on an elbow or reaching behind with a stiff hand.

**Correction:** Stay on your side and rehearse the open, relaxed arm tap before rolling again.

**Drill / progress:** Copy one slow roll each way. Then respond to the coach pointing right or left; pause and reset after every turn.

**Watch / stop:** Stop for head contact, pain, fear, or loss of head control. Floor practice only; no pushing, drops, or standing takedowns.

**Resources:** P12-S1, P12-S2, P12-S3

## Beginner

### B01 Wrestling Stance

**Purpose:** Build a stance you can move, attack, and defend from.

**Before teaching:** Can bend knees and hips, follow a stop signal, and maintain personal space.

1. Face your partner outside touching distance. Set feet about shoulder-width apart, with your own right foot slightly ahead. Keep sideways space between your feet.

2. Bend knees and hips; keep your back long, chest slightly forward, and eyes ahead. Keep shoulders and hips facing your partner.

3. Hold relaxed hands in front with elbows close to your sides. Balance over both feet with pressure toward the forefeet; keep heels near the mat.

4. Take one small step: move the foot nearest that direction first, then follow with the other foot. Restore your spacing without crossing feet or standing tall.

5. Stop in stance without a recovery step. Stand to reset, then repeat with your left foot leading.

**Cues:** Knees bent, eyes ahead. / Hands forward, elbows in.

**Common error:** Athlete folds at the waist, rocks onto heels, or narrows the feet.

**Correction:** Reset the foot spacing, bend knees and hips less, then test one small step and stop.

**Drill / progress:** Rebuild stance three times solo. Partners then mirror small steps for 20 seconds and swap leaders. After successful turns, the leader adds unexpected stops; the follower stops in stance while preserving the gap. Rest and reset between turns.

**Watch / stop:** No contact or attacks. Reset if balance, spacing, or attention breaks down.

**Resources:** B01-S1, B01-S2

### B02 Motion and Level Change

**Purpose:** Adjust distance and lower for an attack or defense while keeping your balance.

**Before teaching:** B01: can hold stance, step, and stop without a recovery step.

1. Face a partner outside touching distance in staggered stance. Keep hands forward, elbows close, and eyes forward.

2. Step front foot first going forward, back foot first going backward, right foot first going right, and left foot first going left. Follow with the other foot, preserving space between them.

3. Circle both ways with short steps, keeping the partner in front and the same lead foot. Never cross or join your feet.

4. First practice lowering in place: bend your knees and hips so your body drops without folding your chest toward the mat. Keep your knees off the mat.

5. Link a short step, level change, and another step. Stay mobile at the lower level; recover stance height without standing upright.

**Cues:** Step, follow, keep your base. / Hips down; eyes forward.

**Common error:** Feet come together, or the head dives while the hips remain high.

**Correction:** Shorten the steps; rehearse lowering in place, then take one balanced step from the lower position.

**Drill / progress:** Rehearse three solo sequences. Partners mirror for four 20-second rounds, resting and swapping leaders each round. Begin slowly; then the leader chooses an unannounced direction or level change and the follower matches while keeping space.

**Watch / stop:** No contact or shots in this drill. Reset if partners crowd each other or lose balance.

**Resources:** B02-S1, B02-S2, B02-S3

### B03 Penetration Step

**Purpose:** Practice a leg-attack entry and bring the feet back underneath you.

**Before teaching:** B01-B02; can lower, kneel, and rise without knee pain on a wrestling mat.

1. Start alone with your right foot forward and hands in front. Bend both knees; lower your hips with chest lifted and eyes forward.

2. Push from your left toes and step your right foot into the imaginary opponent's stance. Bring your hips forward.

3. Continue forward over your right toes until your right knee touches the mat lightly. Your knee travels forward; do not jump or fall onto it.

4. As the right knee comes down, bring your left foot forward and plant it to the left of that knee. Keep your left knee up and your hips underneath your chest.

5. Push through your left foot, lift your right knee, and step your right foot underneath you into a low stance. Reset; reverse sides for left-leg practice.

**Cues:** Lower, then go forward. / Lead knee down, trail foot up.

**Common error:** The wrestler drops straight onto the lead knee and leaves the trail leg behind.

**Correction:** Lower first, shorten the step, and bring the trail foot up as the lead knee touches.

**Drill / progress:** Do three slow solo repetitions each side. Then a partner outside the entry lane either holds or retreats: enter when they hold; close distance and reset when they retreat. No contact.

**Watch / stop:** Use a wrestling mat. Stop for knee pain, heavy knee impact, or loss of balance.

**Resources:** B03-S1, B03-S2, B03-S3, B03-S4, B03-S5

### B04 Wrist and Inside Tie

**Purpose:** Control both arms briefly and move the partner's feet to prepare an attack.

**Before teaching:** B01-B02; partners can keep balance during light hand fighting and release on command.

1. Face your partner in stance at bent-arm reaching distance. The partner keeps both elbows bent and hands in front.

2. With your left hand, grip their right wrist just above the hand. Close your fingers and thumb around the wrist, keeping their hand aligned with the forearm.

3. Keep that wrist grip. Slide your right hand inside their left forearm, then cup high on their left upper arm, fingers curling behind the triceps. Your right forearm contacts the inside of their biceps and your elbow points down.

4. Keep your head up and both elbows bent. Circle a short step to your right, right foot then left, guiding the upper arm so your partner steps to keep facing you.

5. Finish balanced with one wrist and the opposite upper arm controlled. Release both hands and reset; if either arm becomes stretched or blocked, release sooner. Mirror the sides next.

**Cues:** Wrist on one side, inside on the other. / Elbows down; feet move.

**Common error:** Reaching across to the wrist-controlled arm or pulling with straight elbows.

**Correction:** Reset closer; identify their opposite upper arm and keep your elbows bent.

**Drill / progress:** Take 3 cooperative repetitions each. Then use 4 x 20-second rounds, alternating roles with 20-second rests. Receiver may retract the free elbow before entry; attacker gains the tie and one step, or releases and resets. No takedowns.

**Watch / stop:** No finger grips, wrist bending, arm wrenching, or forcing a closed elbow open. Release for discomfort.

**Resources:** B04-S1, B04-S2, B04-S3, B04-S4, B04-S5, B04-S6

### B05 Arm Drag to Go Behind

**Purpose:** Clear an arm and get behind while both stay standing.

**Before teaching:** B01-B02 and B04; can follow a pull with the feet and release promptly.

1. Face your partner in stance. Take their right wrist with your left hand, keeping their wrist straight.

2. Guide that wrist down and across; reach your right hand under their right upper arm and cup the triceps just above the elbow.

3. Step your left foot just outside their right foot as your right hand draws their elbow across your front toward your right hip. Keep your head up and your own elbows close.

4. Bring your right foot around and follow their right shoulder toward their back. Release the wrist and reach your left arm around their waist to the far hip.

5. Continue behind their hips, release the triceps, and place both hands lightly at the waist. Freeze balanced, then release and reset.

**Cues:** Elbow across; feet around. / Catch the hip, then let the arm go.

**Common error:** Pulling the wrist while staying in front.

**Correction:** Rehearse the triceps pull and outside step together before adding the go-behind.

**Drill / progress:** Take three slow repetitions each; receiver steps with the pull. Then alternate four attempts each while the receiver may take one step to square up. Reset if the angle closes.

**Watch / stop:** No wrist twisting, backward arm pulls, lifts, trips, or mat returns; release for joint pain or lost balance.

**Resources:** B05-S1, B05-S2, B05-S3

### B06 Elbow Pop

**Purpose:** Clear both arm posts and enter a double leg.

**Before teaching:** B03; can enter, pause, release both legs, and recover without a takedown.

1. Start right foot forward. Partner rests both hands on your upper arms with elbows slightly bent. Place your palms beneath their upper arms just above the elbows: left hand under their right arm, right under their left.

2. Give a small forward push through the tie. Partner presses back while staying balanced.

3. As that pressure returns, briefly lift both elbows while lowering your hips. Lift with open palms; do not strike or straighten their joints.

4. Release the arms and step your right foot between their feet. Put your head outside against their right ribs, on your left. Reach behind both knees with separate hands and bring your left foot up.

5. Pause at the leg capture without driving or lifting. Release, back out, and recover stance. Reset if their hands close the lane before entry.

**Cues:** Elbows up, hips down. / Pop and step together.

**Common error:** Lifting at the wrists or pausing after the pop.

**Correction:** Place palms above the elbows and connect the lift directly to the level change and step.

**Drill / progress:** Take 3 slow entries each. Then alternate 4 x 20-second rounds, resting 40 seconds. Partner either presses back or withdraws the posts; attack the returning pressure and reset on withdrawal.

**Watch / stop:** No face contact, shoulder wrenching, lifts, or takedown finishes in this entry drill.

**Resources:** B06-S1, B06-S2, B06-S3

### B07 Double Leg Takedown

**Purpose:** Finish a double leg by driving across the opponent and covering the hips.

**Before teaching:** B03; can receive a low side landing without posting a straight arm.

1. From a right-foot lead, clear their hands, lower your hips, and step your right foot between theirs. Touch your right knee softly down.

2. Keep your chest up and head on your left, snug against their right ribs. Cup their right knee with your left hand and their left knee with your right hand.

3. Step your left trail foot forward and outside their right foot. Push from it to bring your right knee off the mat.

4. Take short driving steps diagonally to your right across their stance. Press with your head and shoulder while gathering their knees toward your left; keep their far knee from escaping.

5. Receiver lowers onto their left hip and side without straight-arm posting. Follow above their hips, settle without dropping your weight, and reset on the coach's call.

**Cues:** Chest up, trail foot up. / Drive right; knees left.

**Common error:** Attacker circles left around the head side or keeps driving straight.

**Correction:** Freeze at entry; point out the right-hand corner, then step across it.

**Drill / progress:** Alternate three cooperative finishes each. Then receiver may retreat one step before entry; attacker closes distance or resets. Add resistance after reliable landings.

**Watch / stop:** Stop for head-down pressure, trapped-knee twisting, or straight-arm posting. No standing lift or dump.

**Resources:** B07-COLLEGE_PARK, B07-JOHN_WILL, B07-HORASKI_GARCIA, B07-USAW_GUIDE

### B08 Single Leg Run the Pipe

**Purpose:** Finish a head-inside single by lowering the captured-leg hip.

**Before teaching:** B03; coach-taught single-leg pickup and side-hip receiving.

1. For their right leg, keep your head inside, left temple at their right ribs. Wrap left arm outside and right arm inside; clasp behind the knee.

2. Stand with knees bent and their leg between your thighs, foot off the mat. Keep elbows close and your head up.

3. Your right foot is inside their captured leg. Step your outside left foot back and left, pivoting on the right.

4. Lower your hips as you turn left. Bring your left shoulder over their thigh and draw the held leg inward, guiding their right hip down.

5. Receiver turns hips and leg together and lowers onto the right side without a straight-arm post. Follow beside the hip, cover behind, and change from leg clasp to hip/arm control.

**Cues:** Head inside; leg close. / Step back, turn, hips down.

**Common error:** Attacker circles upright and the receiver keeps hopping.

**Correction:** Slow down; combine the backstep with lowering hips and shoulder pressure over the thigh.

**Drill / progress:** Take 3 cooperative finishes each. Then take 3 each with the receiver making one small balancing step; finish or reset if alignment is lost.

**Watch / stop:** Release for a planted or twisting captured leg, knee pressure, head-down collapse, or loss of landing control. No body lifts.

**Resources:** B08-S1, B08-S2, B08-S3, B08-S4

### B09 Sweep Single

**Purpose:** Sweep outside one leg and finish by collecting the far knee.

**Before teaching:** B03-B04; coach teaches the outside swing step and side-hip receiving.

1. Lead right. Cup inside their right upper arm with your left hand; circle left and draw the arm until their left foot steps forward.

2. Lower, step your right foot outside their left foot, and wrap your right arm behind their left knee. Keep your head up, inside the thigh.

3. Touch your right knee softly and sweep your left leg around the outside toward their left rear corner. Release the arm tie; post your left hand for balance.

4. Keep your right shoulder behind their thigh, below the buttock. Transfer their lower leg to your left hand at the ankle; briefly post your right hand, then reach it between their legs behind their right knee.

5. Drive forward and draw the far knee toward you. Receiver bends and turns with the hips onto a side hip, without a stiff-arm post.

6. Follow behind their hips, release the leg grips, and settle into the taught top position.

**Cues:** Sweep to the backside. / Shoulder tight; catch the far knee.

**Common error:** Attacker stops beside the leg and pulls sideways.

**Correction:** Circle farther behind before reaching the far knee.

**Drill / progress:** Do three slow finishes each from the backside, then three complete entries. Next, receiver may take one squaring step; finish only if the corner remains open, otherwise reset.

**Watch / stop:** Stop for a planted, twisting knee, trapped foot, or lost head position.

**Resources:** B09-S1, B09-S2, B09-S3, B09-S4

### B10 Snap-Down Go-Behind

**Purpose:** Pull a leaning opponent onto their hands, then get behind their hips.

**Before teaching:** B01-B02; partner can lower from stance onto hands and knees and release on command.

1. Put your right palm behind their head and your left hand around their right triceps, above the elbow. Keep your elbows bent.

2. As they lean into you, step back and lower your hips, pulling their head and arm toward you and down together.

3. Receiver lowers onto hands and knees with elbows able to bend and head clear of the mat. Keep your chest over their shoulders and feet back.

4. Release the right-hand collar tie. Turn your left hand to block their right triceps with the back of that hand, keeping chest contact.

5. Circle left around their right side. Reach your right hand to cup their right thigh; continue behind their hips and cover with hands separate.

**Cues:** Step back and pull together. / Block the arm; circle behind.

**Common error:** Athlete lets go and races around while the partner turns to face.

**Correction:** Keep chest contact and replace the arm grip with the block before circling.

**Drill / progress:** Do 3 slow repetitions each from kneeling, then 3 from stance. Next, receiver may turn to face after touching the mat; attacker finishes or resets without increasing neck pressure.

**Watch / stop:** Stop for neck pain, throat pressure, locked-arm landing, or head contact with the mat.

**Resources:** B10-S1, B10-S2, B10-S3, B10-S4

### B11 Sprawl and Go-Behind

**Purpose:** Stop a leg attack, clear the hands, and take control behind the hips.

**Before teaching:** B01-B03; solo sprawl, stable receiving base, and coach-demonstrated top control.

1. On their low double-leg entry, extend both legs backward and lower your hips. Keep your chest over their upper back, head up.

2. Stay square and scoot back until both legs clear their hands. Keep knees off the mat and pressure through their shoulders, not their neck.

3. To go right, slide your right hand between your chest and their head; block their left triceps with the back of your hand.

4. Take short steps right around their left shoulder, maintaining chest contact. Reach your left hand to cup their left thigh above the knee.

5. Continue behind their hips, release the arm block, and settle with separate waist-and-arm control. Bring knees underneath after reaching the rear.

**Cues:** Clear the legs first. / Block the arm; circle to the hips.

**Common error:** Defender circles early or lifts the chest, allowing another leg grab.

**Correction:** Pause with legs free and chest connected; establish the arm block before stepping around.

**Drill / progress:** Take 3 slow entries each; shooter releases and builds a base. Then use 4 x 15-second turns: shooter may circle on the knees to face; defender seeks rear control. Reset at control or separation.

**Watch / stop:** No jumping onto the partner, head driven into the mat, forced arm twisting, or circling on a trapped leg.

**Resources:** B11-S1, B11-S2, B11-S3, B11-S4

### B12 Down Block and Circle

**Purpose:** Keep a single-leg entry away from your leg and recover facing the attacker.

**Before teaching:** B01-B03: balanced stance, circling, and a partner who can stop a slow entry.

1. Start with your right foot forward. Your partner makes a slow single-leg entry toward that leg.

2. As the partner reaches, bend your knees and lower your hips. Drop your right hand toward the mat between the reaching arms and your right leg, making your forearm a barrier.

3. Simultaneously send your right leg straight back, balancing on your bent left leg. Keep your head up and left hand forward.

4. Once the leg is clear, set your right foot down with space between your feet. Lift the blocking hand and circle left with short steps, left foot first, turning to keep your chest facing your partner.

5. Finish in stance, both hands forward. The partner stops reaching and recovers stance; switch roles. Mirror the sequence later.

**Cues:** Hand down, same leg back. / Circle and face.

**Common error:** The hand reaches down while the threatened foot stays planted.

**Correction:** Rehearse the hand drop and leg withdrawal together before adding the partner.

**Drill / progress:** Do three slow entries each. Then alternate one fake or one slow single; defend the entry and reset facing.

**Watch / stop:** No striking or locked-elbow impact. If the attacker catches the leg, stop this rehearsal instead of twisting free.

**Resources:** B12-S1, B12-S2, B12-S3, B12-S4

### B13 Peek-Out Recovery

**Purpose:** Clear your head after a stopped shot and recover an attacking position.

**Before teaching:** B03, B07 and B11; partner can receive a low double-leg finish.

1. Start on hands and knees after releasing a stopped shot. Partner faces you with light chest pressure over your shoulder blades and separate hands behind your upper arms; no locked head grip.

2. Keep your left palm on the mat. Step your right foot up outside your right elbow, shortening your stretched position.

3. Draw your right elbow back toward your hip. Slide your left knee underneath as your head comes out to your right, beneath partner's left upper arm.

4. Keep your left hand posted until your head clears. Bring your hips underneath and raise your chest; do not pull your neck upward against pressure.

5. Turn back toward partner and collect both knees, head on your right at their left ribs. Bring your right trail foot up and use B07's mirrored finish: drive left while gathering knees right.

6. Receiver follows onto the right hip and side without a straight-arm post. Settle above the hips and reset together.

**Cues:** Post, step, elbow back. / Head clear, hips in.

**Common error:** Trying to stand while the head remains trapped.

**Correction:** Return to the light starting cover; shorten your base and clear the head sideways first.

**Drill / progress:** Take three cooperative repetitions each. Then use four 15-second rounds, swapping roles; partner adds one light sprawl and follows the recovery. Reset if the head cannot clear.

**Watch / stop:** No elbow strikes, locked front headlocks, neck pressure, or forced twisting through a trapped arm.

**Resources:** B13-S1, B13-S2, B13-S3

### B14 Referee's Bottom Start

**Purpose:** Set up correctly for a folkstyle bottom start and wait for the whistle.

**Before teaching:** Can support a hands-and-knees base; coach confirms the event's starting procedure.

1. At the center marks, place both knees on the mat behind the rear starting line, with the knees parallel to that line.

2. Place the heels of both hands on the mat beyond the forward starting line. Keep both elbows off the mat.

3. Spread your supports for balance. Keep your head in line with your back and leave room for top to start legally on either side.

4. Become still before top takes position. Keep your hands and knees set through the referee's check; move only on the whistle.

5. For setup practice, top releases at the whistle and you rise to kneeling and reset. Later, connect the start to a taught escape.

**Cues:** Knees behind; hand heels ahead. / Still until the whistle.

**Common error:** Fingertips cross the line but the heels of the hands stay behind it, or bottom rocks before the whistle.

**Correction:** Check the base of each palm, then rehearse a still pause with an unpredictable whistle.

**Drill / progress:** Make three solo setups, then three with a partner on each side. Top stays loose until the whistle. Progress to one taught escape action while top follows lightly; stop and reset.

**Watch / stop:** Correct the setup before adding resistance. No pushing or squeezing before the whistle.

**Resources:** B14-S1, B14-S2, B14-S3, B14-S4, B14-S5

### B15 Referee's Top Start

**Purpose:** Take the standard folkstyle top start legally and respond to the whistle.

**Before teaching:** B14; partner can stay still in bottom position; coach confirms event rules.

1. Let bottom establish a legal, still base. Wait for the referee to direct you to take top; this example starts on bottom's left.

2. Put your left knee outside their left knee. Plant your right foot behind their feet, also on their left side. Keep your legs and feet clear of their body.

3. Rest your left palm lightly on the back of their left elbow. Wrap your right arm loosely across their waist, with your right palm covering the belly button.

4. Hold your head above the middle of their back. Support yourself without squeezing, pushing down or gripping the elbow.

5. Become still for the referee's check and 'set' command. Wait through the pause; move only on the whistle.

6. For setup practice, release both hands on the whistle and reset. Later, connect the whistle to a separately taught breakdown.

**Cues:** Light palms; legs clear. / Still until the whistle.

**Common error:** Top touches bottom with a knee or foot, or squeezes before the whistle.

**Correction:** Leave a visible gap around the legs and soften both hands before the coach checks the start.

**Drill / progress:** Make three checked setups, then mirror on the right. Vary the whistle delay. Once consistent, bottom takes one small knee-slide after the whistle while top follows lightly; stop and reset.

**Watch / stop:** No straddling or foot between bottom's legs. Reset early pressure or movement; stop for pain.

**Resources:** B15-S1, B15-S2, B15-S3, B15-S4, B15-S5, B15-S6, B15-S7, B15-S8

### B16 Belly to Base

**Purpose:** Rebuild a wrestling base beneath a rider after being flattened.

**Before teaching:** B14 and solo belly-to-base recovery; partner can apply light pressure and release immediately.

1. Start belly down, arms free. Partner rides on your left with a loose waist hand and other palm on your upper back, supporting most weight on their knees.

2. Draw your elbows beside your ribs and place forearms beside your chest. Keep your face clear; do not reach backward for the rider.

3. Slide your right knee, away from the rider, forward alongside your hip. Keep your chest facing the mat.

4. Press through your forearms and move your hips back over that knee. Slide your left knee underneath as your belly lifts, then come onto your palms.

5. Finish with knees apart beneath hips and hands beneath shoulders, elbows slightly bent. Keep hips underneath and pressure back into the rider; reset or continue an already-taught escape.

**Cues:** Outside knee up. / Hips back; knees underneath.

**Common error:** Pushing the chest up with straight arms while both legs trail behind.

**Correction:** Reduce rider pressure; bring the outside knee forward before shifting hips back.

**Drill / progress:** Do three cooperative recoveries each side. Then use four 15-second turns: top follows the hips with light forward pressure; bottom rebuilds base. Reset on recovery and swap roles.

**Watch / stop:** Keep arms free and hands unclasped in this drill. No turns or leg rides. Release for face pressure, trapped limbs, or pain.

**Resources:** B16-S1, B16-S2, B16-S3

### B17 Inside-Leg Stand-Up

**Purpose:** Escape by controlling the waist hand, clearing your hips, and facing.

**Before teaching:** B14-B15; stable base and balanced rise/turn; partner can follow without a mat return.

1. Start in referee's position with the rider on your left. Your left leg is the inside leg; directions below are yours.

2. On the signal, plant your left foot beside your right knee. Lift your chest and bring your left elbow back toward their chest without striking.

3. At the same time, grasp their right hand at your belly with your right hand. Hold the whole hand near the wrist, not individual fingers.

4. Drive through your left foot and rise onto both feet, knees bent. Keep your left elbow close. Hold their hand away from your waist as you move your hips forward away from theirs.

5. Retain hand control and turn right to face, moving both feet with the turn. Finish in a low stance; release after separation and reset.

**Cues:** Foot and chest up together. / Control the hand; hips clear, face.

**Common error:** Turning while the rider's arm still hugs your waist.

**Correction:** Rehearse from standing: isolate the hand, create hip space, then turn.

**Drill / progress:** Take three slow turns each. Then top follows one step toward your hips with light, separate-hand contact; regain space and face. Reset if stuck.

**Watch / stop:** No finger peeling, wrist twisting, elbow strikes, lifting, or mat returns.

**Resources:** B17-S1, B17-S2, B17-S3, B17-S4, B17-S5

### B18 Sit-Out

**Purpose:** Create hip space and hand control for a later escape.

**Before teaching:** B14-B15 and P09; can sit gently without trapping a leg.

1. From base, top starts on your left, left hand at your elbow and right hand at your waist. Directions are yours; move on signal.

2. Cross your left hand in front of your right and plant that palm, clearing their elbow contact. Bring your right hand beside your right thigh, elbow close.

3. Step your right foot forward and outward. Push through that foot and left palm; slide your left leg underneath the raised right knee into a low seat.

4. Bring both knees into a bend, heels on the mat and chest up. Cover their right wrist at your waist with your right hand; bring your left elbow against your ribs. Keep light shoulder pressure back into the rider.

5. Pause balanced. Both release, then reset separately to base. Sitting alone is not an escape; B19 adds the finish.

**Cues:** Foot out, leg through. / Elbows in, chest up.

**Common error:** Reaching back with a straight arm while falling into the seat.

**Correction:** Shorten the step and lower slowly; return the posting hand to your side once balanced.

**Drill / progress:** Alternate three cooperative repetitions. Then top lightly follows and reaches toward the left ribs; bottom closes that elbow and keeps the waist wrist in front. Freeze and reset each repetition.

**Watch / stop:** No chops, pullbacks, rolls, or head posts. Release for trapped knees, shoulder strain, or loss of balance.

**Resources:** B18-S1, B18-S2, B18-S3, B18-S4

### B19 Hip-Heist Escape

**Purpose:** Clear a waist ride and escape facing your partner.

**Before teaching:** B18 short sit; pain-free solo hip heist and hand clearing.

1. Start in a short sit, knees bent and feet close. Top kneels behind with light, unlinked waist contact.

2. Use both hands to control the whole waist hand near its wrist and move it off your abdomen. Keep elbows close; press shoulders back as your hips gain space.

3. Once the waist hand is clear, release it. For a left heist, post your left palm beside and slightly behind your hip and plant your right foot. Keep your head off the mat.

4. Lift your hips enough to sweep your left leg underneath. Turn left, stepping your right leg over the sweeping leg; turn chest toward the mat without a shoulder roll.

5. Reposition your hands as you turn and bring your knees underneath, facing your partner. Move backward until free of their hands, then rise into stance with hands forward. If they keep control, rebuild base and reset.

**Cues:** Clear hands, then heist. / One leg under, one over.

**Common error:** Turning while the waist hand still holds, or rolling across a shoulder.

**Correction:** Clear the hand first; rehearse the low leg sweep slowly before adding a partner.

**Drill / progress:** Do 3 solo turns each side, then 3 cooperative escapes each. Progress to 4 x 15 seconds: top follows on knees and tries to retain waist contact; bottom clears and faces. Rest 30 seconds and swap roles.

**Watch / stop:** No finger peeling or head-supported turn. Top releases at separation. Stop for a trapped leg or wrist/shoulder strain.

**Resources:** B19-HK, B19-WEBER, B19-MAL, B19-HG, B19-USAW

### B20 Switch

**Purpose:** Reverse from bottom to control behind the rider.

**Before teaching:** B18-B19; can sit and scissor the hips without a locked-arm post.

1. Start on hands and knees with the rider on your left, their right arm around your waist and left hand at your left elbow.

2. Sweep your left hand across to clear their elbow contact. Step your right foot up and slide your left leg through into a short sit on your right buttock.

3. Catch their right wrist at your belly with your left hand. Reach your right arm over their right upper arm and between their legs; cup inside their right thigh above the knee.

4. Keep your chest over your hips. Raise your hips and turn right toward their right hip, moving your hips away as your right upper arm presses their right shoulder downward.

5. Scissor your left leg over your right and come onto your knees behind their hips. Release the wrist as their waist arm clears; replace the thigh grip with a waist-and-arm ride, hands separate.

**Cues:** Thigh, not back. / Hips away; turn behind.

**Common error:** Bottom reaches over the back or stays seated and pulls on the arm.

**Correction:** Reset the inside-thigh grip; lift and turn the hips before adding pressure.

**Drill / progress:** Do three slow switches each. Rider follows onto knees and frees the waist arm. Then rider may circle to stay behind; reset at rear control or a blocked turn.

**Watch / stop:** Stop for a trapped shoulder or knee. Never twist the wrist or force the arm behind the back.

**Resources:** B20-S1, B20-S2, B20-S3, B20-S4, B20-S5, B20-S6

### B21 Stand-Up Finish

**Purpose:** Clear rear waist contact and finish the stand-up facing your opponent.

**Before teaching:** B17's balanced standing position; both partners can follow and release on command.

1. Start standing after B17 with the rider behind you. Directions are yours. Keep knees bent, feet apart, and your weight over your own feet.

2. Keep your right hand around their right hand near the wrist, as in B17. Keep your left elbow close; the rider's hands remain separate.

3. Hold their captured hand away from your waist and move your hips forward away from theirs. Clear their right arm from your right hip before turning; do not wrench the wrist.

4. Retain the hand and turn right to face, moving your feet with your hips. Keep the left hand available to protect your legs.

5. Finish in a low stance facing the rider. Once rear contact is gone, release the hand and reset. The rider follows on their feet without pulling the arm back.

**Cues:** Hand off; hips clear. / Keep the hand; turn right.

**Common error:** Spinning while the rider's arm still surrounds the hip.

**Correction:** Pause standing; isolate the hand and restore hip space before turning.

**Drill / progress:** Take three slow finishes each. Then rider follows one step with light waist contact; bottom regains space and faces. Reset if stuck.

**Watch / stop:** No finger peeling, wrist twisting, lifting, or mat returns. Stop for lost balance.

**Resources:** B21-S1, B21-S2, B21-S3

### B22 Tight Waist Chop

**Purpose:** Break bottom's base, then secure wrist control.

**Before teaching:** B14-B15; bottom can lower onto forearms and belly without stiff-arm posting.

1. Start legally on bottom's left: left hand at their left elbow, right hand at their navel. Wait for the whistle.

2. Draw your right waist arm snug around their belly. Keep hands separate and your chest behind their shoulders.

3. Bring your left forearm against the outside of their left arm at the elbow. Fold that elbow inward toward their belly with a short motion, without striking.

4. Simultaneously drive forward from your toes; bring your rear right knee against their buttocks to move their hips over the folding arm.

5. Bottom bends the elbow and lowers onto forearms, then belly. Follow with your feet and chest.

6. Catch their left wrist with your right waist hand across the belly; your left hand controls their left upper arm. Keep the wrist below their chest and follow their hips. Release on command.

**Cues:** Drive forward as the elbow folds. / Chop, catch the wrist, follow.

**Common error:** Top pulls the elbow sideways while sitting back.

**Correction:** Reset; use a small arm fold with forward toe pressure and the rear knee moving the hips.

**Drill / progress:** Take three slow repetitions each. Then bottom may rebuild once; top follows with wrist control. Stop and switch.

**Watch / stop:** Release for elbow or shoulder pain. No blows, forced straight-arm collapse, wrist twisting, or neck pressure.

**Resources:** B22-S1, B22-S2, B22-S3, B22-S4, B22-S5

### B23 Near Ankle Breakdown

**Purpose:** Break bottom's base with a tight waist, ankle control, and forward pressure.

**Before teaching:** B15 top start and B16 base recovery; both partners can lower to their belly and release on signal.

1. Start on bottom's left side in referee's top position. Wait for the signal.

2. Keep your right arm snug around the waist, palm across the belly. Move your left hand from their elbow to cup their left ankle just above the heel.

3. Step around behind their hips. Lift the ankle forward toward their seat while driving forward from your toes, chest on their back and head behind their shoulders.

4. Keep the ankle aligned with its knee as their body moves forward. Bottom bends the elbows and lowers through forearms to belly, keeping the face clear.

5. As their hips settle, lower and release the ankle. Follow their hips, collect a wrist without wrenching the arm, and reset on signal.

**Cues:** Ankle forward; chest forward. / Flat: release and control.

**Common error:** Top pulls backward with the arm while the feet stop moving.

**Correction:** Reset the grip, move behind the hips, and use short forward driving steps.

**Drill / progress:** Do three cooperative repetitions each. Then alternate four 15-second rounds: bottom slowly rebuilds the base; top attempts one breakdown. Reset if the ankle slips free.

**Watch / stop:** No toe twisting, sideways knee pressure, forced heel-to-seat bending, or lifting the thigh against a flat pelvis. Release for pain.

**Resources:** B23-S1, B23-S2, B23-S3, B23-S4

### B24 Spiral Breakdown

**Purpose:** Stretch the base and capture the near wrist.

**Before teaching:** B14-B16; receive chest pressure onto a forearm without locking the elbow.

1. Start on your partner's left in referee's top position. Apply pressure after the signal.

2. Slide your left forearm under their left armpit, with the base of your hand supporting the upper arm. Move your right hand from the waist to the inside of their right thigh, away from the groin.

3. Rise onto your feet, knees off the mat. Keep chest contact high on their back, head behind their shoulders, and hips following your chest.

4. Walk your feet outward to the left and around toward their head. Drive their left upper arm forward and press their right thigh backward while maintaining chest pressure.

5. As their left elbow lowers, capture their left wrist with your left hand. Return your right arm to waist control and follow as they settle belly-down. Release on the coach's signal.

**Cues:** Arm forward, far thigh back. / Feet circle; chest stays heavy.

**Common error:** Top pulls with the arms while sitting on both knees.

**Correction:** Rise onto the toes, reconnect the chest, and circle before adding arm pressure.

**Drill / progress:** Do three slow repetitions each, bottom yielding onto a forearm. Then bottom may widen the knees and rebuild base; top has ten seconds to capture the wrist. Switch roles.

**Watch / stop:** Keep contact off the throat and groin. Stop for a locked elbow, shoulder pain, trapped knee, or face pressure.

**Resources:** B24-S1, B24-S2, B24-S3, B24-S4

### B25 Near Wrist Ride

**Purpose:** Keep one arm trapped under the body while maintaining top control.

**Before teaching:** B15 and a taught breakdown; both can receive pressure and release immediately.

1. Start on their left after a breakdown. Partner lies belly-down, arms forward. Face their head; keep yours behind their shoulders.

2. Reach your left arm under their left upper arm and take an overhand grip around their left wrist. Your left hand controls their left wrist; keep the hand and forearm aligned.

3. Keep your right arm around their waist, hands separate. Stay chest-to-back and use your feet to drive their body forward over the held wrist, bringing it beneath their belly.

4. Maintain shoulder pressure and a wide base. Take small following steps as they move their hips; keep the wrist underneath rather than pulling the arm behind their back.

5. Finish with them belly-down and you balanced above. Ease pressure, open your grip, and let them bring the arm forward before resetting.

**Cues:** Left hand, left wrist. / Drive the body over the wrist.

**Common error:** Top yanks the wrist backward while leaving their own weight behind.

**Correction:** Shorten the grip distance and advance with the feet and chest.

**Drill / progress:** Take three cooperative captures each. Then use four 15-second rounds: bottom slowly brings knees underneath to rebuild; top follows and maintains the ride. Reset if the wrist clears; swap roles.

**Watch / stop:** Release for wrist bending, trapped-arm strain, or stop signals. No finger pulling, arm-on-back turn, or forced roll.

**Resources:** B25-S1, B25-S2, B25-S3, B25-S4

### B26 Half Nelson

**Purpose:** Turn a belly-down opponent onto their back and settle chest to chest.

**Before teaching:** B22; both partners can stop, release, and receive a slow shoulder turn.

1. Start beside their left shoulder after the breakdown, facing the same direction, chest on their upper back.

2. Slide your left arm under their left armpit, palm on the back of their head. Reach your right hand beneath their chest to block their far, right elbow from posting.

3. Lift your left elbow beneath their upper arm while keeping their head down. Walk your feet out to their left and toward their head until your bodies make a T.

4. Drive from your toes through your chest to turn them onto their right side. Shoulder and torso must rotate together; stop if the body cannot turn.

5. As they turn, slide the half deeper behind their head. Settle chest to chest, hips low and feet wide. Release on the coach's signal.

**Cues:** Elbow up; feet to the head. / Chest across; hips down.

**Common error:** Top stays parallel and tries to win by pushing harder on the head.

**Correction:** Reset the half, step out to a T, and move the torso with chest pressure.

**Drill / progress:** Trade three slow turns, receiver following the roll. Then bottom may close the near elbow before insertion; top resets a blocked attempt.

**Watch / stop:** Release for neck or shoulder pain, a trapped body, or the defender's elbow being forced behind their head. Never add a second half.

**Resources:** B26-S1, B26-S2, B26-S3, B26-S4, B26-S5, B26-S6, B26-S7

### B27 Early Half Nelson Defense

**Purpose:** Stop a basic half before the opponent establishes turning pressure.

**Before teaching:** B16 base recovery; coach demonstrates a loose half and immediate release.

1. Start belly-down. Your partner begins threading a loose half under your left armpit. All left/right directions below are yours.

2. Draw your left elbow toward your ribs, closing the armpit. Keep that shoulder and hip low instead of letting the upper arm rise.

3. While your neck is still free, keep your head clear of the mat and look right, away from the half. Do not force the head against pressure.

4. If their hand reaches your head, use your left hand to cup and peel their whole hand off. Avoid individual fingers; return your left elbow close to your side.

5. Keep their hand away while bringing one knee, then the other, beneath your hips. Once the threading arm is clear, recover forearms or hands beneath your shoulders and reset in base.

**Cues:** Elbow in; look away early. / Same hand peels; then build.

**Common error:** Defender lifts the half-side elbow high while reaching to peel.

**Correction:** Rehearse closing the armpit first; make a short peel with the upper arm close.

**Drill / progress:** Do 3 slow repetitions each side. Then top chooses either side for one light insertion; bottom clears and builds base. Reset before turning pressure develops.

**Watch / stop:** If the half is tight or the head cannot move freely, stop and have top release. No forced neck rotation.

**Resources:** B27-S1, B27-S2, B27-S3

### B28 Half Nelson Pin Finish

**Purpose:** Keep both shoulders near the mat after a half nelson turn.

**Before teaching:** B26 half nelson turn and receiving; immediate release on stop or tap.

1. Begin just after the turn. For a left-arm half, keep your left arm under their left upper arm and your palm behind their head. Their upper arm stays inside the half.

2. Hold their right wrist with your right hand and keep that arm close to their trunk. Keep your hands separate; do not clasp around the head.

3. Set your chest across their upper chest, with your body perpendicular to theirs. Spread your feet, extend your legs back and lower your hips gradually; keep your head up.

4. As they make a small shoulder turn, adjust your feet to keep your chest over their shoulders. If the arm slips out or the neck twists, release and reset.

5. On stop, ease chest pressure, release the wrist, slide the half arm out and move clear. Mirror the grips for a right-arm half.

**Cues:** Arm stays in the half. / Chest across; feet wide.

**Common error:** High hips and a narrow base let the receiver roll the top wrestler over.

**Correction:** Spread the feet and settle the hips back while keeping chest contact.

**Drill / progress:** Alternate three cooperative placements, then three five-second holds each. Receiver makes one gentle turn toward the belly, without a neck bridge; top follows with the feet. Reset after every hold.

**Watch / stop:** Release immediately for a tap, stop call, throat pressure, breathing difficulty or neck/shoulder pain.

**Resources:** B28-S1, B28-S2, B28-S3, B28-S4, B28-S5

### B29 Near-Side Cradle

**Purpose:** Connect the head and near knee, then turn the opponent over the far hip.

**Before teaching:** B15; coach verifies receiving, palm-to-palm grip, and a stable, pain-free forehead post with the neck aligned.

1. Start beside their left side, facing their ribs. Bottom holds a compact base with the left knee already within reach of the head.

2. Reach your left arm over their head, elbow bend behind the neck. Scoop your right arm behind their left knee; keep the throat clear.

3. Move chest and head close to their left side. Join palms near their head, thumbs alongside fingers. If you cannot connect without forcing the bend, reset.

4. Push from your feet toward their right hip, away from you. Scoop their left shoulder upward with your chest; bottom turns onto the right hip and back without stiff-arm posting.

5. Follow chest to chest with feet wide and hips low. Post the center of your forehead on the mat, keeping the cradle connected and pressure on the shoulders.

6. Pause for the coach's check; open your hands before bottom unfolds and rebuilds base.

**Cues:** Head and near knee; palms together. / Drive away; chest follows.

**Common error:** Pulling the head toward the knee while the feet stay still.

**Correction:** Close your body position and drive with the legs; reset if the lock requires forcing.

**Drill / progress:** Three cooperative turns each. Then four attempts each: bottom may extend the near leg before the clasp; top connects or resets.

**Watch / stop:** Release for throat pressure, forced neck bending, knee twisting, or either wrestler bearing weight on a bent neck.

**Resources:** B29-S1, B29-S2, B29-S3, B29-S4

### B30 Early Cradle Defense

**Purpose:** Prevent a near-side cradle and recover your bottom base.

**Before teaching:** B16 base recovery; B29 attack recognition and immediate release on command.

1. Start on hands and knees with the attacker on your left. They reach around your head and behind your left knee; their hands are still apart.

2. Send your left foot backward as you lower your left hip toward the mat. Keep your right knee bent for support and your face off the mat.

3. During that action, catch their head-arm hand in front of your chest with both hands around the whole hand and wrist. Keep elbows close and their hands separated.

4. Keep hand control and raise your head and chest as the loose head wrap clears. Once your head and left knee are free, post one hand and bring the left knee underneath to rebuild base.

5. If their hands connect, freeze and have the attacker release for this drill. Mirror the same sequence on the other side.

**Cues:** Near leg back, near hip down. / Catch the hand; head up.

**Common error:** Kicking backward with the hips high, or bringing the knee back before clearing the head.

**Correction:** Rehearse leg-back and hip-down together; regain head clearance before rebuilding.

**Drill / progress:** Do 3 slow repetitions each. Then alternate 4 x 15-second rounds, resting 30 seconds. Top makes one light reach to connect; bottom prevents the lock and rebuilds. Stop at connection or recovered base.

**Watch / stop:** Before-lock defense only. No force against a locked cradle, neck bridge, or twisting a trapped knee.

**Resources:** B30-S1, B30-S2, B30-S3, B30-S4

## Advanced

### A01 Russian Tie to Single Leg

**Purpose:** Use a two-on-one to collect the near leg.

**Before teaching:** B08; wrist control, single-leg pickup, and side-hip receiving.

1. Partner posts right hand on your left shoulder. Grip their wrist with your right hand, palm down; roll their forearm down until your palm faces up.

2. Cup beneath their right armpit with your left palm up. Step left beside their right side; keep the arm against your chest and head inside.

3. Place your left foot, toes up, behind their right ankle. Keep your right foot underneath; press their ribs away with your left forearm to lighten that leg.

4. Lower, release the wrist, and scoop behind their right knee with your right arm from inside. Unhook your foot; release their upper arm and wrap your left arm outside the thigh.

5. Clasp behind their knee; collect the leg between your thighs, foot low. Keep your left temple at their right ribs.

6. Finish B08: left foot back-left, pivot on right, lower hips and left shoulder over the thigh. Receiver turns onto the right hip; follow behind and cover.

**Cues:** Block, shift, collect. / Free the foot before turning.

**Common error:** Lifting a loaded leg with the arms.

**Correction:** Shift weight onto their left leg before collecting.

**Drill / progress:** Three cooperative entries each, then three finishes. Next, defender may withdraw the near foot before the block; attacker collects only if available, otherwise resets.

**Watch / stop:** No wrist cranking, ankle kicking, planted-knee twisting, stiff-arm landings, or body lifts.

**Resources:** A01-S1, A01-S2, A01-S3, A01-S4, A01-S5

### A02 Underhook Knee Pick

**Purpose:** Move the opponent's torso past a blocked far knee and finish on top.

**Before teaching:** Underhook control, level changes, side landings, and covering from top.

1. Your right arm underhooks their left arm, hand curled over their left shoulder from behind. Keep your head inside beside their left temple; your left hand controls their right elbow.

2. Start angled at their left side, their right knee within reach. Bend your knees, head against their chest.

3. Release the elbow. Cup the outside of their right knee with your left hand, fingers around the back. Block; do not lift.

4. Step your right foot across their front toward that knee. Keep the underhook; drive your shoulder across toward their right side. Follow with short steps, feet apart.

5. Partner yields onto the right hip without a stiff-arm post. Follow beside their hips and release the knee. As they turn belly-down, circle behind to waist and near-arm control, hands apart.

**Cues:** Block the knee; move the body. / Step across and keep driving.

**Common error:** Reaching from too far away and pulling the knee.

**Correction:** Reset closer with an angle; lower before reaching and drive with the feet.

**Drill / progress:** Alternate three cooperative finishes. Then partner may withdraw the target leg before contact; attacker resets if it escapes. Once blocked, partner yields and turns belly-down for the cover.

**Watch / stop:** Do not pin the foot, twist the knee, or crank the shoulder.

**Resources:** A02-S1, A02-S2, A02-S3

### A03 Underhook Duck Under

**Purpose:** Use an underhook to get behind; this drill stops standing.

**Before teaching:** Pummeling, balanced level changes, and releasing a blocked shoulder.

1. Start over-under: your left arm under their right armpit, palm on upper back; your right arm overhooks their left upper arm. Left foot leads; head starts on your right side.

2. As they swim their right arm inside for an underhook, raise your left elbow to open space beneath their right upper arm.

3. Lower your hips through bent knees. Step your left foot past the outside of their right foot toward their back; pass your head under their right arm, staying close.

4. Bring your head up behind their right shoulder. Release your right overhook, circle your right foot behind, and bring both arms around their waist.

5. Stop chest-to-back with both wrestlers balanced on their feet. Make light palm-to-palm waist contact, release, and face each other.

**Cues:** Hips down, step behind. / Head through, then up.

**Common error:** Trying to lift a closed arm without lowering the hips.

**Correction:** Reset; wait for the pummel and lower as the opening appears.

**Drill / progress:** Three slow repetitions each. Then four 15-second rounds, resting 30 seconds: partner either pummels or keeps the elbow closed. Attack the opening; otherwise reset. Alternate roles.

**Watch / stop:** No forced shoulder opening, neck compression, lift, trip, or mat return.

**Resources:** A03-S1, A03-S2, A03-S3, A03-S4

### A04 High Crotch to Double

**Purpose:** Change a head-outside high crotch into a double-leg finish.

**Before teaching:** B03 and B07, including B07's mirrored finish and right-side receiving.

1. Use a left-foot lead. From a cleared tie, lower and step your left foot between theirs, bringing your left knee softly down.

2. Shoot your left arm between their thighs around their left leg, behind the knee. Join your right hand from outside. Keep your head up on your right, outside their left hip, with your shoulder tight.

3. Step your right trail foot forward outside their left foot. Drive up off your knee with hips underneath; keep both hands on their left leg until it becomes light.

4. Keep your right hand behind their left knee. Release your inside left hand and catch behind their far right knee; keep elbows close.

5. Drive diagonally left across their stance and gather their knees right. Receiver lowers onto their right hip and side without a straight-arm post. Follow over their hips, settle, and reset.

**Cues:** Drive up before changing hands. / Left hand changes; drive left.

**Common error:** Reaching for the far knee while stretched on the mat.

**Correction:** Recover the trail foot, bring hips in, and unload the near leg first.

**Drill / progress:** Alternate three cooperative conversions from a low high-crotch start. Then defender retreats one step before entry; close distance or reset.

**Watch / stop:** Stop for neck compression, trapped-knee twisting, or rigid posting. No standing body lift or dump.

**Resources:** A04-USAW_INSIDE, A04-USAW_CHANGE, A04-HORASKI_GARCIA, A04-COLLEGE_PARK

### A05 Single Leg to Double

**Purpose:** Finish when the defender moves the captured leg outside your legs.

**Before teaching:** B08 single-leg position; B07 receiving; coach-checked leg support.

1. Hold their right leg between your thighs, hands clasped above the knee, head inside at their right ribs, left foot forward.

2. Receiver moves their right foot outside your left thigh, turning the whole leg together. Follow without twisting it.

3. Raise their right thigh against your left hip with your left arm. Unclasp your right hand; their weight settles onto their left leg.

4. Bend your knees, keep your head up against their chest, and reach your right hand around the outside of their left knee to block it.

5. Push from your left foot; step your right foot through past their left-leg side. Drive across their stance that way, head and chest together; keep supporting their right leg.

6. Receiver lowers onto their left side without straight-arm posting. Follow beside the hips, lower the held leg, then release and cover.

**Cues:** Leg outside: lift and block. / Right foot through; chest follows.

**Common error:** Reaching for the far knee while leaving the hips behind.

**Correction:** Freeze at the knee block; bring the right foot and hips through before adding speed.

**Drill / progress:** Take 3 cooperative conversions each. Then alternate 4 attempts: receiver either leaves the leg inside for B08 or moves it outside for this finish.

**Watch / stop:** Stop for trapped toes, knee twisting, head-down pressure, or loss of receiving control. No separate body lift or dump.

**Resources:** A05-TRASSO, A05-COLLEGE_PARK, A05-FUJI, A05-USAW_GUIDE

### A06 Backside Single Finish

**Purpose:** Shelf one leg and collect the other to finish behind the hips.

**Before teaching:** B09 on both sides; secure thigh control and cooperative hands-and-knee receiving.

1. Start behind their right hip. Partner supports on both hands and left knee; your left arm hugs their right thigh, with your head up beside their hip.

2. Put your left knee behind their right knee and plant your right foot. Cup their right ankle with your right hand and guide their foot onto your right thigh.

3. Once your thigh supports the foot, release the ankle and wrap your right arm around their far, left thigh. Keep the near thigh with your left arm.

4. Press your shoulder into their buttocks and move forward through their hips, gathering both thighs. Partner bends their elbows and lowers toward their belly.

5. Lower the supported leg as their hips settle. Follow behind into top control, free the shelf, then release and reset.

**Cues:** Shelf first, then far thigh. / Shoulder pressure; follow the hips.

**Common error:** Reaching for the waist before controlling the far leg.

**Correction:** Keep the shelf and collect the far thigh before covering.

**Drill / progress:** Three cooperative repetitions each. Then four 15-second rounds: defender takes one small squaring step before the shelf; attacker finishes or resets if the corner closes. Rest 30 seconds; alternate roles.

**Watch / stop:** Release for a twisting knee, trapped foot, or head loading. No body lift.

**Resources:** A06-S1, A06-S2, A06-S3

### A07 Sweep Single Recovery

**Purpose:** Recover an angle and finish when a sprawl stops your sweep single.

**Before teaching:** B09 on both sides; hand-supported circling and the A06 backside finish.

1. Against a sprawl on their right leg, keep your head inside and left arm behind their right knee. Open the handlock; post your right palm.

2. Push through your toes, lift your knees, and circle around their right leg to their right hip. Keep the knee attached; move your feet instead of reaching.

3. Set your left knee behind their right knee and plant your right foot. Partner supports on both hands and their left knee.

4. Your right hand cups their right ankle and guides their foot onto your right thigh. Their knee travels with the leg.

5. Release the supported ankle and collect their far thigh. Keep the near thigh with your left arm; press your shoulder into their buttocks and follow forward. Lower the leg as their hips settle; cover behind and release.

**Cues:** Feet circle; knee stays close. / Shelf first, then cover.

**Common error:** Pulling upward while stretched beneath the sprawl.

**Correction:** Post the free hand and circle to the hip before shelving.

**Drill / progress:** Three light repetitions each. Then four 15-second rounds: defender sprawls and takes one squaring step; attacker finds the corner or resets. Rest 30 seconds; alternate roles.

**Watch / stop:** Reset if the corner closes, the knee twists, or the neck bears weight. No body lift.

**Resources:** A07-S1, A07-S2, A07-S3, A07-S4

### A08 Down Block to Ankle Reattack

**Purpose:** Turn a blocked sweep single into an ankle entry.

**Before teaching:** B12 on the left side; balanced circling and stoppable sweep-single entries.

1. Lead with your left foot, left hand low. Partner makes a slow sweep single toward your left leg.

2. Lower your hips, drop your left forearm between their reach and your leg, and withdraw that leg. Your right palm checks their left shoulder to keep space.

3. Plant your left foot under your hips, feet apart. As they keep pressing, guide their left shoulder across your front and step right around that shoulder; keep facing them.

4. Release the blocking arm and follow their turn. Lower beside their left hip, cup their left ankle with your right hand, and place your left palm on their back. Stay close rather than reaching.

5. Stop at the ankle catch, head lifted and partner on hands and knees. Release, regain stance, and swap roles. This drill stops before the takedown finish.

**Cues:** Block, plant, redirect. / Follow the ankle with your feet.

**Common error:** Reaching for the ankle while the withdrawn leg remains stretched behind.

**Correction:** Slow down and restore the foot underneath before stepping around.

**Drill / progress:** Three cooperative entries each. Then partner either keeps pressing or withdraws: reattack the pressure; recover stance on withdrawal.

**Watch / stop:** Stop for a caught leg, tangled knees, or neck pressure. No ankle twisting or kick-out resistance.

**Resources:** A08-MARTINEZ, A08-USAW_SKILLS, A08-COLLEGE_PARK

### A09 Standing Whizzer Defense

**Purpose:** Stop a standing head-inside single and regain stance when the grip opens.

**Before teaching:** Single-leg balance, a coach-checked overhook, and immediate partner release.

1. Partner holds your right thigh above the knee, head inside at your ribs, captured foot low between their legs.

2. Your right arm overhooks their left upper arm; keep your elbow near your ribs, forearm hooked behind their arm.

3. Move your bent right leg as a unit outside their left leg, resting your shin against their outer thigh above the knee.

4. Your left hand grips their right wrist. Keep your head up at their head's height.

5. Hop toward them from your left foot, bringing your right hip into contact. Partner steps with you and releases before losing balance.

6. When the grip opens, lower your foot underneath, release the whizzer, and recover stance. If it stays closed, hold balance and reset.

**Cues:** Shin outside; head up. / Drive from the free foot.

**Common error:** Pulling the arm while the hips hang away.

**Correction:** Rebuild shin contact and move your whole body with the supporting foot.

**Drill / progress:** Three cooperative starts each; then four 10-second rounds. Attacker takes one slow circling step with light grip; reset on release or the whistle.

**Watch / stop:** No shoulder wrench, planted-knee twist, high lift, kick, or throw.

**Resources:** A09-S1, A09-S2, A09-S3

### A10 Limp Arm

**Purpose:** Slip a whizzer from the mat and circle behind.

**Before teaching:** B09; coach-checked low seatbelt position, light whizzer, and immediate release.

1. Start beside their right side, both facing almost the same way. Your left arm passes under their right armpit across their back; their right arm overhooks it. The leg is released.

2. Keep your left knee down, right foot wide, and hips slightly apart. Partner posts their right knee, left foot, and left hand. Keep your head beside their shoulder, off the mat.

3. Reach your right hand underneath to hold their right wrist. Press gently into them; partner gives light pressure back.

4. Turn your left palm up and draw your left elbow forward out of their armpit, letting the hand trail along your side. Move your torso with the elbow.

5. Keep their right wrist directed forward as the elbow clears. Circle around their right hip, bring your left hand to their waist, and settle behind their hips with separate hands. Partner follows onto hands and knees; release on reset.

**Cues:** Outside foot up. / Wrist forward; elbow free.

**Common error:** Trying to circle behind while the elbow remains caught.

**Correction:** Pause at the clearance; shorten the arm path and lower resistance.

**Drill / progress:** Three slow clears each, then three go-behinds. Next, partner either gives light inward pressure or squares early; clear the first, reset the second.

**Watch / stop:** Stop for shoulder strain; no jumping over an intact whizzer or straight-arm pulling.

**Resources:** A10-S1, A10-S2, A10-S3

### A11 Single Leg Kickout

**Purpose:** Free a low standing single by lifting the elbows and returning the foot to the mat.

**Before teaching:** Coach-taught single-leg pickup, one-leg balance, and immediate partner release.

1. Partner holds your right leg just above the knee, head inside at your right ribs, captured foot low between their thighs.

2. Cup behind their left elbow with your right hand and behind their right elbow with your left. Hold the upper arms, not the fingers.

3. Keep your head up and chest facing them. Bend your supporting left knee; take small balance hops if needed.

4. Pull both elbows upward while lowering your right leg down and back through the opening. Let the knee straighten naturally; do not yank sideways.

5. Once the foot clears, set it behind your left foot. Push away at their upper arms, release, and recover a staggered stance facing them.

6. If the leg stays trapped or either wrestler loses balance, stop and reset. Do not keep kicking against a closed grip.

**Cues:** Elbows up, leg down. / Foot back; face them.

**Common error:** Pulling the leg sideways before creating an opening.

**Correction:** Use a lighter grip; coordinate the elbow lift with the downward leg action.

**Drill / progress:** Three cooperative clears each. Then three attempts with one slow circling step by the holder. Clear or reset; swap roles each attempt.

**Watch / stop:** No knee twisting, strikes, finger peeling, or high-leg starts.

**Resources:** A11-S1, A11-S2, A11-S3

### A12 Front Headlock Drag-Out

**Purpose:** Escape an opponent's front headlock and work behind their hips.

**Before teaching:** Coach-checked chin-and-arm control, kneeling balance, head clearance, and top control.

1. Start kneeling with your head under their right armpit. Their right hand cups your chin; their left holds your right triceps. Keep the practice grip loose.

2. Reach your right hand under their left forearm and across to cup their right triceps above the elbow. Keep your pulling elbow close.

3. Plant your left foot outside their right knee. Draw their right arm across your chest while moving left around their right leg and turning your hips.

4. Let your head slip outside their right elbow as your body turns. Once clear, reach your left hand around their right thigh above the knee; stay close.

5. Continue behind their hips, release the elbow, and establish separate waist-and-arm control. Reset if your head or right arm remains trapped.

**Cues:** Step outside; drag across. / Clear the head; collect the thigh.

**Common error:** Pulling with the arms while both knees stay planted.

**Correction:** Pause at the outside step, then move your hips with the drag.

**Drill / progress:** Three loose-grip repetitions each. Then four 15-second turns: holder may follow to face but releases the chin as the head clears. Reset at rear control or a blocked exit; alternate roles.

**Watch / stop:** No throat pressure, neck twisting, arm wrenching, or forced escape through a closed grip.

**Resources:** A12-S1, A12-S2, A12-S3

### A13 Russian Tie Clear to Underhook

**Purpose:** Clear a Russian and gain an underhook; stop standing.

**Before teaching:** Russian ties, pummeling, balanced footwork, and release.

1. Partner holds your right arm in a Russian: their right palm supports your wrist; their left palm cups beneath your upper arm. They stand beside your right side with light grips.

2. Put your free left hand beneath their right elbow - the wrist-gripping arm. Lift that elbow up and away from their body.

3. As the wrist grip loosens, draw your right hand down and across toward their left armpit. Swim your right arm under their left upper arm, placing your hand near the middle of their back.

4. Move your feet to face them, knees bent and feet apart. Bring your head inside beside their left temple. Release your left-hand elbow contact once your right arm is clear.

5. Pause in the underhook, then release and return to stance. If the grip stays locked or the elbow is unavailable, stop and reset instead of wrenching the shoulder.

**Cues:** Lift the elbow; free your wrist. / Hand free, then underhook.

**Common error:** Lifting the arm at your shoulder while your wrist stays trapped.

**Correction:** Find the hand holding your wrist and follow that arm to its elbow.

**Drill / progress:** Three slow clears each. Then partner either leaves the right elbow accessible or tucks it early; clear or reset. Stop standing.

**Watch / stop:** No sudden yanks, finger peeling, shoulder cranking, lift, or throw.

**Resources:** A13-S1, A13-S2, A13-S3, A13-S4, A13-S5

### A14 Stand-Up Hand Fighting

**Purpose:** Deny a new waist grip and finish your stand-up facing the rider.

**Before teaching:** B17 Inside-Leg Stand-Up and B21 Stand-Up Finish; balanced standing and prompt partner release.

1. Start standing after B17, rider behind you. Bend your knees, keep feet apart, and support your own weight.

2. Retain your right-hand grip around their right hand near the wrist. Keep their hand off your waist and left elbow close.

3. The rider reaches their free left hand under your left arm toward your belly. Respond before they secure a grip.

4. Keep your left elbow near your ribs. Sweep your left palm and forearm across the reaching hand, guiding it outward past your left hip; close your elbow against your side. Keep the right-hand grip.

5. Move your hips forward away from theirs and clear their right arm from your right hip. Retain the hand and turn right, moving both feet.

6. Finish low and facing. Release after rear contact is gone. Reset if the rider secures a wrist or body lock.

**Cues:** Elbow in; sweep the reach out. / Keep the hand; hips clear, face.

**Common error:** Reaching backward and opening the left elbow to chase the hand.

**Correction:** Bring the clear back beside your ribs; sweep only the incoming arm.

**Drill / progress:** Take three slow clears each. Then rider follows and reaches once without warning. Add B17's left-foot rise last.

**Watch / stop:** No strikes, finger peeling, wrist twisting, lifts, trips, or mat returns.

**Resources:** A14-S1, A14-S2, A14-S3, A14-S4

### A15 Sit-Out to Stand-Up

**Purpose:** Use forward riding pressure to rise from a short sit and escape.

**Before teaching:** B18's compact seat and B21's hand-controlled finish; painless squat and safe partner following.

1. Begin in B18's short sit, rider behind your left side. Directions are yours. Keep shoulders over hips, knees bent, and feet planted close to your seat.

2. Grasp their right waist hand near the wrist with your right hand. Draw it forward and down toward your right hip; keep your left elbow against your ribs.

3. As the rider presses forward, press your shoulders back into them and drive through both feet. Lift your hips directly into a squat.

4. Rise with knees bent and stagger your feet. The rider follows upward on their own feet.

5. Hold the hand away from your waist and move your hips forward to clear their arm. Turn right to face, moving both feet. Finish low; release after rear contact is gone and reset.

**Cues:** Feet planted; pressure back. / Hips clear; keep the hand and face.

**Common error:** Throwing the shoulders backward while the hips stay on the mat.

**Correction:** Bring the feet closer and lift the hips with the legs; stop if balance is lost.

**Drill / progress:** Take three slow repetitions each. Then rider adds gentle forward pressure after the sit; bottom rises and faces. Reset if pulled backward or stalled.

**Watch / stop:** Separate-hand contact only. No finger peeling, wrist twisting, pullbacks, lifts, or mat returns.

**Resources:** A15-S1, A15-S2, A15-S3, A15-S4

### A16 Short Sit to Switch

**Purpose:** Reverse when a rider follows your short sit with a tight waist.

**Before teaching:** B18 Sit-Out and B20 Switch; balanced short sit, wrist control, and hip scissor.

1. Start in B18's low short sit, feet planted and chest over hips. Rider follows behind-left, right arm around your waist. Your right hand covers their right wrist; your left elbow hugs your ribs.

2. When they retain that waist arm and their right thigh is reachable, transfer their right wrist to your left hand at your belly. Keep your left elbow in.

3. Turn right; carry your right elbow over their right upper arm. Reach between their legs and cup inside their right thigh above the knee.

4. Push through your feet, raise your hips, and move them away. Turn toward their right hip as your right upper arm presses their right shoulder down.

5. Scissor your left leg over your right; circle onto your knees behind their hips. Release the wrist as their waist arm clears, then replace the thigh grip with separate waist-and-arm control.

**Cues:** Wrist, then thigh. / Hips up; scissor behind.

**Common error:** Reaching over the back while sitting still.

**Correction:** Find the inside thigh, then lift and turn your hips.

**Drill / progress:** Alternate three cooperative repetitions. Then rider follows with the tight waist or withdraws that arm. Switch on the first response; stop and reset on the second.

**Watch / stop:** Release for trapped shoulders or knees. Never twist the wrist or force an immobilized arm.

**Resources:** A16-S1, A16-S2, A16-S3, A16-S4, A16-S5, A16-S6

### A17 Reswitch

**Purpose:** Counter a switch while your waist arm can still reach the opponent's leg.

**Before teaching:** B20 Switch; both partners can support on one hand, scissor the hips, free their arms, and stop mid-turn.

1. Start riding on their left: your right arm around their waist and left hand at their left elbow. All directions below are yours.

2. Partner starts a right-side switch, reaching their right hand inside your right thigh. Follow the turn while your right arm remains mobile at their waist.

3. As they begin coming around behind, slide your right hand inside their right thigh above the knee. Post your left hand beside you; sit your left leg through onto your right hip.

4. Lift your hips, move them away from your partner, and turn right toward the captured thigh. Scissor your left leg over your right to come onto your knees behind them.

5. Let their right arm slide clear of your waist. Release the thigh and settle into a waist-and-arm ride, hands separate. Partner follows onto knees and frees the turning arm.

**Cues:** Catch the thigh as they come around. / Hips away; clear the arm.

**Common error:** Waiting until the wrist or shoulder is pinned, then pulling harder.

**Correction:** Reset earlier; the counter needs a mobile arm and reachable thigh.

**Drill / progress:** Do three slow exchanges each. Then bottom varies the switch timing and tries to clear your waist arm. Allow one reswitch; reset at rear control or a missed counter.

**Watch / stop:** Release for a trapped shoulder, straight-arm post, or planted knee that cannot turn.

**Resources:** A17-S1, A17-S2, A17-S3, A17-S4, A17-S5

### A18 Quad-Pod Stand-Up

**Purpose:** Get to your feet, clear the waist hand, and face the rider.

**Before teaching:** Stable base, painless hand support, and partner stand-up practice. This version turns left.

1. Start in base with the rider on your left: their right hand at your belly, left hand at your left elbow. Directions are yours.

2. On signal, shift both palms left, keeping them apart. Push weight back over your right hip; point left toes outward and plant that foot.

3. Bring your right foot out and rise onto both feet. Circle as you rise so the rider stays beside your left hip.

4. Keep feet wide, knees bent, hips low, head and chest up. Leave your left palm posted. Your right hand grasps their whole right hand near the wrist and guides it behind your right hip.

5. Lift your left palm and turn left toward the rider, moving both feet. Release as waist contact clears; finish facing in a low stance.

**Cues:** Left hand posts; right hand clears. / Head up; turn toward the rider.

**Common error:** Straightening the legs and dumping weight onto the hands.

**Correction:** Bend the knees, lower the hips, and recover foot support.

**Drill / progress:** Three cooperative escapes each. Then rider adds one gentle forward push while following. Reset for a trapped wrist, secure lock, or lost posture.

**Watch / stop:** No head posting, finger peeling, wrist twisting, chops, lifts, or mat returns.

**Resources:** A18-S1, A18-S2, A18-S3, A18-S4

### A19 Spiral Ride to Near Wrist

**Purpose:** Keep top pressure through a wrist capture and rebuild.

**Before teaching:** B24 Spiral Breakdown and B25 Near Wrist Ride.

1. Start in an established left-side spiral: left forearm under their left armpit, base of hand under biceps; right hand inside their right thigh.

2. Keep chest high on their back, head behind shoulders. Knees off mat, circle left toward their head: guide their left arm forward and their right thigh backward.

3. When their left elbow lowers, release your left upper-arm contact and grip their left wrist from above. Keep thigh contact and chest pressure.

4. With wrist secured, move your right arm around their waist, hands separate. Drive their body forward over the wrist into a belly-down near-wrist ride.

5. Follow their knee-under rebuild with small steps and shoulder pressure. Finish belly-down, ease pressure, release the wrist, and reset.

**Cues:** Elbow down, left hand to left wrist. / Feet and chest keep control.

**Common error:** Releasing both spiral contacts to chase a posted hand.

**Correction:** Keep thigh and chest pressure while the left hand changes grips.

**Drill / progress:** Three cooperative changes each; bottom bends the elbow and yields. Then four 15-second rounds: bottom maintains or rebuilds base; top captures and follows. Reset at wrist clearance or standing.

**Watch / stop:** No throat/groin contact, finger grips, or arm-behind-back pull. Release for wrist bending, trapped-arm strain, or stop signals.

**Resources:** A19-S1, A19-S2, A19-S3, A19-S4, A19-S5, A19-S6

### A20 Claw Breakdown to Near Wrist

**Purpose:** Break the base with a claw, then secure same-side wrist control.

**Before teaching:** B15, B24, B25; coach-checked claw placement and immediate release.

1. Start on bottom's left, facing their head. Bottom supports on hands and knees; your right arm controls the waist.

2. Pass your left arm under their left armpit, across the upper chest, and cup their right shoulder. Keep fingers together and forearm off the throat.

3. Move your right hand from the waist to the inside of their right thigh, away from the groin; keep hands separate.

4. Stay on your toes with chest pressure. Walk left and around toward their head, pressing their right thigh back while retaining the claw.

5. As their left elbow lowers, move your left hand from their shoulder to an overhand grip on their left wrist, underneath their left arm. Return your right arm to the waist.

6. Drive their body forward over the wrist into B25. Finish belly-down with balanced top control; unload and release before resetting.

**Cues:** Under the arm, far shoulder. / Elbow down; left hand takes left wrist.

**Common error:** Releasing the claw before the near elbow lowers.

**Correction:** Keep chest pressure and circle until the wrist is reachable.

**Drill / progress:** Three cooperative repetitions each. Then bottom slowly rebuilds once; top follows in the wrist ride. Reset if the wrist clears; swap roles.

**Watch / stop:** Release for throat pressure, restricted breathing, joint pain, or trapped knees. No arm-on-back turn.

**Resources:** A20-S1, A20-S2, A20-S3, A20-S4

### A21 Near Wrist Tilt

**Purpose:** Expose the back by turning the hips while retaining one-hand wrist control.

**Before teaching:** B25, supported side receiving, and coach-checked hip loading and release.

1. Partner is on their knees. Ride their left side: your left arm goes under their left upper arm, and your left hand holds their left wrist beneath their chest.

2. Keep that elbow bent. Your right arm crosses their waist; cup their right upper thigh beside the hip. Keep your hands separate.

3. Bring your left hip beneath their left hip and sit onto your left side, loading their left thigh on your hip. Slide your right foot under their left thigh.

4. Elevate their left leg with your right foot while drawing their far hip toward you. Expose their back with your body angled across theirs, keeping their hips supported.

5. Lower the elevated leg and guide them through their left side to belly-down. Follow above their hips, unload the trapped arm, then release.

**Cues:** Left wrist, left hip. / Lift the leg; turn the hips.

**Common error:** Sitting away and pulling only the wrist.

**Correction:** Reload their thigh onto your hip before turning.

**Drill / progress:** Three slow repetitions each. Then four 15-second turns: bottom permits loading or widens their base early. Reset a blocked load; alternate roles.

**Watch / stop:** Release for wrist bending, shoulder strain, knee twisting, or neck stacking. No hands locked around the trunk.

**Resources:** A21-S1, A21-S2, A21-S3

### A22 Two-on-One Tilt

**Purpose:** Expose the back using two-on-one control and a near-side knee block.

**Before teaching:** B22 cross-wrist control, supported side receiving, and following a turn-down.

1. Start on their left as they rebuild to knees after a breakdown. Your right arm wraps their waist to hold their left wrist; your left hand cups their left triceps.

2. Hold their bent arm against their belly, wrist straight. Stay chest-to-back behind their left shoulder, hips close.

3. Put your left knee in front of their left knee. Sit close onto your left hip, bringing their left hip onto yours.

4. Plant your left heel and keep that knee upright against the front of their hip. Bring your right leg between their legs, supporting underneath their far right thigh.

5. Raise your right leg to tip their hips and expose their back. Keep the two-on-one snug, weight on your side, and head free.

6. Lower their thigh, ease the knee block, and let them turn belly-down. Follow chest-to-back onto your knees; release after both are stable.

**Cues:** Left knee blocks; right leg lifts. / Keep their hips on yours.

**Common error:** Sitting away and trying to pull them over by the wrist.

**Correction:** Move hips closer and rehearse the knee block before turning.

**Drill / progress:** Three cooperative tilt-and-return repetitions each. Then bottom may widen the knees before entry; top tilts only when the block fits, otherwise resets.

**Watch / stop:** Stop for wrist bending, shoulder strain, neck loading, or lost hip support.

**Resources:** A22-S1, A22-S2, A22-S3

### A23 Arm Bar Turn

**Purpose:** Turn a flat opponent with a short arm bar and far-wrist control.

**Before teaching:** Breakdown, side receiving, and coach-checked bar placement and immediate release.

1. Start beside their left side, partner belly-down, left elbow bent and hand beside their left hip. Do not force the arm behind their back.

2. Hook your left forearm beneath their left upper arm, just above the elbow. Bend your elbow and anchor your palm-down fist against mid-back.

3. Reach your right arm under their right armpit and hold their right wrist under their chest. Keep your chest over their shoulders.

4. On your toes, take short steps around their head toward their right shoulder. Carry the barred upper arm across the torso; shoulders and hips turn together.

5. For this drill, pause on their right side. Unthread the bar, let their left arm come forward, then follow chest-to-chest onto their back and reset.

**Cues:** Fist on back; elbow bent. / Circle the head; turn across.

**Common error:** Walking forward while driving the trapped elbow toward the head.

**Correction:** Stop, release, and rebuild the across-body angle with the coach.

**Drill / progress:** Alternate three cooperative turns, pausing for grip and side-position checks. Then four 10-second entries: bottom closes the left elbow early; top inserts only through an opening. Reset if denied.

**Watch / stop:** Release for shoulder strain, upward wrist lifting, elbow driven toward/over the head, a stand-up, or any stop signal.

**Resources:** A23-S1, A23-S2, A23-S3, A23-S4, A23-S5

### A24 Near Wrist to Half Nelson

**Purpose:** Turn a wrist escape into a half nelson.

**Before teaching:** B25 Near Wrist Ride, B26 Half Nelson, B28 finish, and slow turn receiving.

1. Ride a belly-down partner's left side. Your left hand holds their left wrist in front of their belly; your right arm holds a tight waist. Keep chest contact.

2. When they roll that wrist free and open their left elbow, let the wrist go. Catch their left upper arm from underneath with your left hand. If the elbow stays closed, keep riding.

3. Slide that same left arm under their left armpit, palm behind their head. Release the waist with your right hand and reach beneath their chest to hold their right wrist.

4. Lift your left elbow. Walk your feet out to their left and toward their head until perpendicular. Drive through your chest, turning their torso onto its right side.

5. Deepen the half as they turn onto their back. Settle chest to chest, hips low and feet wide; keep their right wrist near their trunk. Ease pressure and release both holds on stop.

**Cues:** Wrist goes; same elbow opens. / Feet out; chest across.

**Common error:** Top keeps the old wrist grip while trying to insert that hand as a half.

**Correction:** Pause: release left wrist, follow left elbow, then insert the half.

**Drill / progress:** Trade three slow announced wrist-roll changes. Then bottom either opens the elbow while clearing or keeps it closed; top turns or continues riding.

**Watch / stop:** Stop for trapped-body rotation, neck or shoulder pain, or the defender's elbow forced behind their head. Never force a closed elbow.

**Resources:** A24-S1, A24-S2, A24-S3, A24-S4, A24-S5

### A25 Far-Side Cradle

**Purpose:** Turn with a crossface and far-knee lock, then pin from behind.

**Before teaching:** Coach-checked crossface, wrist lock, side/back receiving and immediate release.

1. Start on their left, chest across their back; bottom is belly-down with the right knee drawn forward within easy reach.

2. Pass your left forearm across their cheek; hold their right upper arm above the elbow. Post your right hand behind their right knee.

3. Walk toward their head with chest pressure. Scoop under that knee; clasp your left wrist with your right hand, retaining the upper-arm grip.

4. Bring hips behind theirs and move your back leg clear. Draw them toward you onto their left hip and back; bottom rolls without stiff-arm posting.

5. Slide your hips and shoulder out from underneath. Place your bottom knee against their side, forehead at their temple, and hook their free left leg with your upper leg.

6. Hold for a shoulder check. Clear the leg hook and knee pressure, open the wrist lock, then let bottom unfold.

**Cues:** Far arm, far knee, own wrist. / Hips back; clear their shoulders.

**Common error:** Forcing the knee toward the head to reach the lock.

**Correction:** Move closer; reset if the clasp requires forced folding.

**Drill / progress:** Three cooperative turns each. Then four attempts each: bottom may extend the far leg before the lock; top connects or resets.

**Watch / stop:** No crossface strike, throat squeeze, neck crank, or knee twist; release immediately for pain or breathing restriction.

**Resources:** A25-S1, A25-S2, A25-S3, A25-S4, A25-S5

### A26 Near-Side Cradle Decision Drill

**Purpose:** Practice finishing an available near-side cradle or preventing its lock.

**Before teaching:** B29 and B30; coach-checked receiving, immediate release, and a stable forehead post with the neck aligned.

1. Top kneels beside bottom's left ribs, facing in. Bottom holds base. Top's left arm goes over the head, elbow behind neck; right arm scoops behind bottom's left knee.

2. Before hands connect, bottom may send the left foot back and left hip down, catching top's left hand/wrist with both hands. Raise head and chest as the loose wrap clears.

3. Top releases; bottom clears head and knee before rebuilding base. If this defense attempt becomes locked, stop: top opens the clasp before further motion.

4. If bottom stays cooperative, top closes chest position and joins palms near the head, thumbs alongside fingers. Reset if the lock requires forcing.

5. Top drives toward bottom's right hip, lifting the left shoulder with the chest. Bottom turns without stiff-arm posting. Top follows chest-to-chest, feet wide, hips low, with an aligned forehead post.

6. Pause for the coach; open the clasp before bottom unfolds. No escape attempts against the lock.

**Cues:** Clear before the clasp. / Lock, turn, pause, release.

**Common error:** Continuing the early defense after top connects the hands.

**Correction:** Freeze that repetition, open the clasp, and restart earlier.

**Drill / progress:** Coaching exercise: two announced finishes and two clearances each. Then four attempts each; bottom chooses early defense or cooperative receiving. Stop an unexpected lock; alternate roles.

**Watch / stop:** Release for throat pressure, forced neck bending, knee twisting, or an unstable head post.

**Resources:** A26-S1, A26-S2, A26-S3, A26-S4, A26-S5

### A27 Half Nelson Settle Drill

**Purpose:** Keep chest-to-chest control as the receiver starts to roll through a half nelson.

**Before teaching:** B26 and B28; slow receiving, separate hand controls and immediate release.

1. Start after the left-half turn: left arm under their left upper arm, palm behind their head. Hold their right wrist beside their ribs with your right hand.

2. Place your chest across their upper chest, bodies making a T. Keep your head up, hips back and feet spread on the toes.

3. Receiver slowly turns toward their own left side, raising their right shoulder slightly. Their head turns with their chest; no bridge.

4. Widen your feet and take small steps backward, away from their torso. Settle your hips toward the mat while keeping your chest across their upper chest and knees off the mat.

5. Keep both arm controls. Stop when their shoulders settle; reset if they reach their side. Ease chest pressure, release the wrist, withdraw the half and move clear.

**Cues:** Chest stays; hips back. / Wide feet; head up.

**Common error:** Top climbs across the receiver with high hips and gets carried into the roll.

**Correction:** Reset; move the feet back and wider before lowering the hips.

**Drill / progress:** Three cooperative settlements each, then three five-second attempts with the single small turn above. Swap roles; stop at lost control.

**Watch / stop:** No neck bridge, head post or hand clasp. Release for pain, breathing trouble, or a trapped elbow moving behind the head.

**Resources:** A27-S1, A27-S2, A27-S3, A27-S4, A27-S5, A27-S6

### A28 Cross-Wrist Clear

**Purpose:** Break the cross-wrist before a two-on-one tilt and recover inside elbow position.

**Before teaching:** B22 wrist control, A22 setup recognition, and keeping a bent arm close under pressure.

1. Start on your knees with top on your left. Their right hand holds your left wrist across your belly; their left hand controls your left triceps.

2. Widen your knees and keep your hips and chest low. Keep your left elbow bent; do not rise onto their hips or reach the captured arm out.

3. Bring your free right elbow back close to your ribs, directly in front of their gripping right wrist. Set the forearm beside your elbow against that wrist.

4. Use that elbow/forearm to scrape their right wrist off as you bring your bent left arm back to your left side. Keep both knees grounded.

5. Immediately turn your freed left palm up and tuck that elbow against your ribs, leaving their left arm outside. Settle over your knees and recover hand control before your next escape.

**Cues:** Stay low; knees wide. / Scrape the wrist, seal the elbow.

**Common error:** Lifting the chest to reach the gripping wrist.

**Correction:** Move the free elbow to the wrist while keeping the hips low.

**Drill / progress:** Three slow clears each. Then top may tighten the grip or reach to recapture it; bottom clears and seals. Stop if top starts loading the tilt.

**Watch / stop:** Clear before the roll. No elbow strike, finger stripping, wrist bending, or turning against a trapped shoulder.

**Resources:** A28-S1, A28-S2, A28-S3, A28-S4

### A29 Double Leg to Tight Waist Chop

**Purpose:** Link a double-leg finish to a left-side ride and breakdown.

**Before teaching:** B07 and B22; reliable side receiving and bottom base-building.

1. From a cleared right-lead stance, lower hips; step right foot between theirs and touch right knee down. Head stays left at their right ribs; left hand cups their right knee, right hand their left.

2. Step left foot outside their right foot; lift your right knee. Drive diagonally right, gathering knees left. Receiver lowers onto left hip and side without straight-arm posting. Settle above the hips.

3. Pause. Release knees and transfer hands to hips. Receiver turns belly-down as you shuffle behind to their left, facing their head; keep chest contact over their hips.

4. Bottom rebuilds hands-and-knees. Wrap your right arm around their belly, hands separate. Place left forearm outside their left elbow, chest behind shoulders and toes planted.

5. Fold their left elbow inward while driving forward from toes; bring rear right knee against their buttocks. Bottom bends the elbow and lowers onto forearms, then belly. Follow their hips.

6. Catch their left wrist across the belly with your right waist hand; left hand controls their left triceps. Hold without twisting, then release and reset.

**Cues:** Finish, settle, find the left ride. / Drive forward; fold and catch.

**Common error:** Chopping during the landing or before releasing the legs.

**Correction:** Pause, free the legs, then establish the left-side ride.

**Drill / progress:** Cooperate for three chains each. Then bottom chooses one base rebuild or stand-up; top chops the rebuild, but releases and resets for standing or escape.

**Watch / stop:** No lifts, locked-arm chopping, trapped-leg twisting, or mat returns. Release for pain or lost alignment.

**Resources:** A29-COLLEGE_PARK, A29-HORASKI_GARCIA, A29-WILL, A29-USAW_SKILLS, A29-MADISON

### A30 Near Wrist Tilt or Half

**Purpose:** Choose one turn per attempt.

**Before teaching:** B25, A21 and A24; dependable tilt and half-nelson receiving.

1. Ride a belly-down partner's left: your left hand under their left arm holds their left wrist beneath the belly; right arm at waist, hands separate.

2. Tilt option - wrist held, knees rebuilding, load available: right hand cups their right upper thigh. Sit left, loading their left thigh onto your left hip; right foot lifts their left leg (A21).

3. Finish that tilt: expose their back, then lower the leg. Guide them through their left side to belly-down; follow above their hips, unload the arm, then release.

4. Half option from the original ride: wrist rolls free and left elbow opens. Release your left grip. Thread that left arm under their left armpit, palm behind head; right hand leaves waist for their right wrist (A24).

5. Finish that half: lift left elbow and walk out left toward their head. Turn them through their right side to chest-to-chest, hips low, feet wide. Ease pressure and release.

6. No opening: maintain a secure ride or reset. Stop for standing, lost wrist without a half, or failed alignment.

**Cues:** Wrist held: check the load. / Wrist rolls: follow that elbow.

**Common error:** Choosing the half because bottom spreads their knees.

**Correction:** Find the wrist release and same-side elbow opening first.

**Drill / progress:** Rehearse each branch twice. Then six attempts: bottom chooses rebuild, wrist-roll opening, or blocked opening. Top names the choice; alternate roles.

**Watch / stop:** No forced elbow opening, wrist bending, knee twisting, neck stacking, or elbow behind head. Release on stop.

**Resources:** A30-S1, A30-S2, A30-S3, A30-S4, A30-S5, A30-S6

## Resources

**USAW1** [USA Wrestling Folkstyle Level 1](https://www.usawmembership.com/usa_wrestling_core_curriculum/1) - Fundamental technique families and linked demonstrations.

**USAW2** [USA Wrestling Folkstyle Level 2](https://www.usawmembership.com/usa_wrestling_core_curriculum/2) - Finishes, short-sit responses, wrist tilts and bar-arm families.

**USAW3** [USA Wrestling Folkstyle Level 3](https://www.usawmembership.com/usa_wrestling_core_curriculum/3) - Hand control, single-leg reactions and riding families.

**USAWG** [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Detailed coaching instruction and technique illustrations. Check current rules separately; this is a historical coaching manual.

**KOLAT** [Cary Kolat technique library and clinic example](https://www.kolat.com/practice-plans/youth-clinic-half-nelson-cradle) - Public technique catalog and a youth clinic example; some demonstrations require membership.

**NFHS** [NFHS wrestling rules resources](https://nfhs.org/sports/wrestling/rules) - Folkstyle rules resources. Confirm the actual youth league and event modifications.

**AAP** [AAP sports readiness guidance](https://www.healthychildren.org/English/healthy-living/sports/Pages/Is-Your-Child-Ready-for-Sports.aspx) - Developmental context for voluntary movement and individual readiness.

**CLUB** [Grindstone Wrestling / Mat Rats](https://www.grindstonewrestling.org/mat-rats) - Club identity and the Pup program context.

**P01-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF extracted text, page 1: Skill 1 Position and the separate staggered/square stance descriptions; page 2: Skill 2 Motion.

**P01-S2** [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm) - Full webpage text, specifically section I-A, Stance, Motion, Changing Level, and Making Contact.

**P01-S3** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf) - PDF extracted text, page 1: How the Levels Should Be Approached; page 4: Level 1 Feet, Stance teaching note and two stance listings.

**P02-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Extracted PDF text on pages 1-2: Skill 1 Position and Skill 2 Motion, including stance features and multidirectional movement. Did not view the linked video.

**P02-S2** [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm) - Opened webpage text, section I-A, Stance and Motion entries.

**P02-S3** [Methodological Development of Wrestling Shuttle Test](https://academy.uww.org/app/uploads/2019/06/METHODOLOGICAL-DEVELOPMENT-OF-WRESTLING.pdf) - Extracted PDF text on PDF pages 2 and 4 (printed pages 22 and 24), especially Description of side-stepping movement and its key points.

**P03-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF text, page 1 stance/position section and page 4 Skill 3 of 7 Level Change (25:42-28:14) and level-change drills.

**P03-S2** [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm) - Full page text, especially I.A Basic Skills for Wrestling in Neutral Position: Stance, Motion, Changing Level and Penetration.

**P04-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Extracted PDF text, pages 1-2 for stance and motion and pages 4-5 for level change and penetration (zero-based pages 0-1 and 3-4).

**P04-S2** [Bemidji Elementary Wrestling: Basic Move Progression and Scoring](https://cdn1.sportngin.com/attachments/document/0139/5030/_Coaches_Page__elementary_move_progression.doc.pdf) - Extracted PDF text, page 1, Stance and Penetration step sections.

**P04-S3** [Brandon Slay: 3 x 5 System Penetration](https://www.pennsylvaniartc.org/video-gallery/view/145) - Public page's written explanatory paragraph describing coach Slay's penetration sequence.

**P05-S1** [Basic Wrestling Fundamentals: Bottom Position Wrestling Skills and Table Top Stance](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate) - Accessible page text containing the manual's Bottom Position Wrestling Skills section around printed pages 40-41 and Table Top Stance before printed page 44; browser text lines 365-390. Also inspected the base/tabletop glossary definitions.

**P05-S2** [Wrestling 101, Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf) - PDF extracted text, PDF page 3 of 4, Chapter 5: Bottom Wrestling, lines 115-123; author information on PDF page 1.

**P05-S3** [7 Basic Skills: Coach and Athlete Guide, Bottom Motion](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF extracted text on PDF pages 2-3 of 9, Bottom Motion section labeled 15:52-20:18, especially Belly to Base and Starting Position/Base to Feet.

**P06-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Extracted PDF text, printed pages 2-3 (zero-based pages 1-2), Bottom Motion, especially Belly to Base and Starting Position/Base to Feet.

**P06-S2** [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm) - Full public page text, particularly II - Mat Wrestling, Bottom Man, Basic Skills for Mat Wrestling, and Defensive Mat Wrestling.

**P06-S3** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers by Cary Kolat](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat) - Public page text, Level 1 Bottom: introductory teaching note, Holding Base, Base Building, and Bottom Drills/Base Drills.

**P07-S1** [Avoid a Takedown with a Good Sprawl! - Eric Akin, Sprawl Drill](https://www.championshipproductions.com/news/2014/09/01/avoid-a-takedown-with-a-good-sprawl/) - Published lesson-summary text, particularly the Sprawl Drill paragraphs; embedded video not viewed.

**P07-S2** [How to use takedown counter drills to your advantage - excerpt from The Wrestling Drill Book, 2nd Edition, Bill A. Welker](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage) - Takedown Counter Drills introduction and Snap-Down Redirect setup, action, coaching point, and common error sections.

**P07-S3** [Techniques by Age - Matt Krumrie, with coaches Nate Engel and Kevin Roberts](https://www.themat.com/news/2019/october/10/techniques-by-age) - Full article body retrieved from the official URL as HTML using Invoke-WebRequest; inspected introduction, Ages 5-8, Ages 9-12, Ages 13 and older, and Focus on skill and experience level sections.

**P08-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Extracted text of PDF pages 8, 14, and 31: Wall Standup; Basic Bottom and backward teaching progression; Standup execution table.

**P08-S2** [Preston Mat Club Syllabus: Defensive Mat Wrestling](https://www.wvmat.com/preston/syllabu.htm) - Full HTML text, particularly Defensive Mat Wrestling, Inside Leg Stand Up, and the syllabus teaching goals.

**P08-S3** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat) - Page text of Level 1 bottom section, including the Stand-Up teaching note and listed hand-capture, lock-breaking, and cutaway skills.

**P09-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text extracted in memory; printed pages 14 and 32, Basic Bottom and SIT OUT/TURN OUT.

**P09-S2** [Wrestling Unit Block Plan, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - PDF page text, pages 83-85 (zero-based 82-84), especially the solo sit-out instruction on page 84; authorship on page 2.

**P09-S3** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://attackstylewrestling.com/sit-series/) - Complete page text, particularly Basic sit out position and Seal off, hip heist away.

**P09-S4** [Wrestling Drills: Sit out/Scoot Drill](https://coaches.levelupwrestling.com/wrestling-drills/) - Actual page text in the Sit out/Scoot Drill section.

**P09-S5** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf) - PDF page text, pages 1 and 8-9: progression principles, First Move Techniques, and Sit-Out Drills.

**P10-S1** [Hip Heist by Mike Malinconico](https://www.youtube.com/watch?v=qi-crQ-Kwec) - Read the complete available English auto-generated transcript, 0:00-4:42. Visually inspected seated-drill frames at approximately 1:03, 1:33-1:37, and 1:42, including intermediate frames through the leg switch. The detailed seated coaching is at 1:02-1:46.

**P10-S2** [Changeover Series - Hip Heist Drills](https://www.coachmackenzie.com/changeover-series.html) - Read the live page text, especially Hip Heist Drills / On the mat and the separate wall/partner drill listings.

**P10-S3** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/) - Read coach-authored article text, especially Step 1: Basic sit out position and Step 2: Seal off, hip heist away.

**P10-S4** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Read extracted PDF text on page 3 (zero-indexed page 2), including Starting Position/Base to Feet and 23:48-24:21 Hip-Heist Drill.

**P11-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Extracted PDF text, pages 1-2, especially Skill 2 of 7 Motion at video-reference time 12:42-15:52; no linked video watched.

**P11-S2** [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage) - Full accessible page text under Takedown Counter Drills and Snap-Down Redirect: Setup, Action, Coaching Point, and Common Error.

**P11-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Extracted PDF text, PDF page 25 (zero-based page 24), Short Offense table: Backhand and Short Drag; also Spin Drills on PDF page 9. Screenshot retrieval failed.

**P12-S1** [Breakfalls Instruction Guide (September 1, 2023)](https://judocanada.org/wp-content/uploads/2023/07/Guide-Chutes_2023_EN.pdf) - Parsed PDF text, printed pages 3, 6-7 and 9-11; especially page 9, Yoko-ukemi, Progression and learning stages, Lying down.

**P12-S2** [Obukan Judo Dojo Teacher's Manual: Beginner Course, May 31, 2011 draft](https://obukanjudo.org/wp-content/uploads/2011/09/BeginnerCourseTeacherManual.pdf) - Parsed PDF text, cover and PDF pages 11-13: back fall, lying-down side fall, and side fall from squat/standing.

**P12-S3** [JudoKids 2nd Sho Syllabus](https://www.britishjudo.org.uk/wp-content/uploads/2024/10/JudoKids-2nd-Sho-Syllabus.pdf) - Parsed PDF text, PDF pages 4-6, assisted yoko-ukemi and Stage 2 yoko-ukemi.

**B01-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF extracted text, page 1: Skill 1 Position and both stance descriptions; page 2: Skill 2 Motion, including maintaining position while moving in different directions.

**B01-S2** [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm) - Webpage text, section I-A: Stance, Motion, Changing Level, and Making Contact; closing source-attribution note.

**B02-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF text: page 1 stance; page 2, Skill 2 Motion (12:42-15:52); page 4, Skill 3 Level Change (25:42-28:14), including the following drill outline.

**B02-S2** [Preston Mat Club Syllabus: Basic Skills for Wrestling in Neutral Position](https://www.wvmat.com/preston/syllabu.htm) - Full page text, with emphasis on section I-A, items 1-5: Stance, Motion, Changing Level, Making Contact, and Penetration.

**B02-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text, printed pages 7-8: The Foundation, Gable Warmup Level 1 items Stance, Motion, Level Change/Set Your Feet, and Level 2 Shadow Drill.

**B03-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF page text, pages 4-5: level change, low attacking position, and penetration sections.

**B03-S2** [Preston Mat Club Syllabus: Neutral Position and Double Leg Takedown](https://www.wvmat.com/preston/syllabu.htm) - Page text, Basic Skills in Neutral Position and Double Leg Takedown sections.

**B03-S3** [Develop Your Inside Penetration Step with a 4x All American!](https://www.championshipproductions.com/news/2014/02/14/develop-your-inside-penetration-step-with-a-4x-all-american/) - Publisher's full accessible instructional summary beneath Inside Step Penetration; embedded video not watched.

**B03-S4** [How to Improve the Speed of Your Takedown](https://www.luchafit.com/articles/how-to-improve-the-speed-of-your-takedown) - Coach-authored page text: Back foot first, Penetration step, and Putting it together sections.

**B03-S5** [Wrestling Moves Questions: Penetration Step Question](https://www.kolat.com/technique-questions.html) - Coach's written answers in the Penetration Step Question section; embedded Vimeo material was not accessible through the web reader.

**B04-S1** [Controlling Ties - Wrist, Inside, and Elbow](https://www.playsportstv.com/wrestling/wrestling-moves_controlling-ties-wrist-inside-and-elbow) - Page description and public embedded Vimeo 116951855 video frames at player positions approximately 0:16, 0:21, 0:36, 0:51, 0:56, 1:01, 1:31, and 1:46. Wrist contacts and double inside arm positioning were visible.

**B04-S2** [How To Teach Takedown Setups](https://www.attackstylewrestling.com/teach-setups/) - Full article text and sampled frames of its inside_tie_setups_854x480 public Vimeo 513328959 video at about 0:00, 0:10, 0:40, 1:10, 1:40, and 2:10; the 1:10 frame showed partners moving from inside ties.

**B04-S3** [The Art of Hand Fighting](https://www.championshipproductions.com/cgi-bin/champ/p/Wrestling/The-Art-of-Hand-Fighting_WRD-04532A.html) - Public Features & Benefits description, especially the paragraphs naming the inside tie/wrist combination and hand-fighting positioning.

**B04-S4** [Coach's Guide to Excellence, Second Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - PDF text extracted directly from public PDF pages 151-158, particularly printed pages 151-152 (Contacts and Set-ups) and 155-157 (Clearing Ties).

**B04-S5** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text: printed page 8 motion guidance and printed page 16 Inside/Inside Collar introduction (PDF pages 8 and 16).

**B04-S6** [Rule Book & Guide to Wrestling, 2027 Edition](https://www.usawmembership.com/usa_wrestling_rule_book) - Public rulebook text, last updated September 13, 2026: scope statement; section 7.5 NO FINGERS; sections 18.1 and 18.3 on illegal and potentially dangerous holds.

**B05-S1** [Arm Drag Takedown; embedded Same Side Wrist Drag to Mat demonstration](https://www.attackstylewrestling.com/arm-drag/) - Public article text, including steps 1-3; sampled public preview frames from embedded Vimeo video 506474386, particularly solo footwork near 16-28 seconds and partnered grips/pivot near 224-248 seconds. No audio inspected.

**B05-S2** [The Four Simplest Armdrags for BJJ and Submission Grappling](https://www.grapplearts.com/four-simple-armdrags-for-bjj-and-submission-grappling/) - Full public article text; especially section 1, Armdrag from Wrist Control, and its distinction from section 2, Armdrag vs Wrist Control.

**B05-S3** [Offensive Neutral Position Move: Arm Drag](https://s3.amazonaws.com/my.llfiles.com/00224751/armdrag.pdf) - Extracted text of the entire one-page PDF.

**B06-S1** [USA Wrestling Coach's Guide to Excellence, 2nd Edition - Clearing Ties](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Official PDF downloaded in memory and read with pypdf: PDF pages 156-158, especially page 157 / printed page 156, Clearing Ties item 4A. Official educational-resources page inspected to verify its PDF link.

**B06-S2** [Wrestling Takedown Reference Library - Double Leg w/ dump](https://www.todayfitness.net/wrestling/takedowns/) - Full HTML instructional text, specifically the takedown introduction and Double Leg w/ dump paragraph. The parent wrestling page identifies the coach-authored demonstration project; the main site identifies Pete Mazzeo. Animated GIF not viewed.

**B06-S3** [Double Leg Basic Setup Elbow Pop - Heath Sims](https://evolve-university.com/library/wrestling/beginner/video-double-leg-basic-setup-elbow-pop/) - Public lesson title and descriptive paragraph. Page requires subscription for the demonstration; video not watched.

**B07-COLLEGE_PARK** [College Park Wrestling Technique Handbook: Double finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text for basic position on page 9 and finish descriptions on page 23; rendered page 23 inspected visually, especially DOUBLE / FLAIR and TURN CORNER LIFT rows.

**B07-JOHN_WILL** [How to set up wrestling's double leg from the classic Thai clinch](https://www.grapplearts.com/Clinch%26MMATakedowns.pdf) - PDF pages 2-3 text under The Takedowns / The Basic entry; rendered PDF page 3 inspected for the upper six-photo basic-double sequence and distinction from the lower high-crotch sequence.

**B07-HORASKI_GARCIA** [Wrestling Unit Block Plan: Lesson 3, Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Extracted PDF page text on pages 11-15, especially pages 12-14: angle toward the original lead-leg side, shuffle across the body, far/near knee actions, and finish above the hips.

**B07-USAW_GUIDE** [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached official PDF text and rendered PDF pages 154-155 (printed pages 153-154), plus rendered PDF page 242 (printed page 241), Bill Zadick thumb-block-to-double page containing only photo 1 of 5 in this export.

**B08-S1** [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Local official-source cached PDF extraction with page markers: PDF page 119 (printed 118) and PDF pages 154-156 (printed 153-155), plus origin metadata.

**B08-S2** [College Park Wrestling Technique Handbook: Single finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF extracted page text: PDF page 24 (printed 24), Single header and Run Pipe row; surrounding finish rows to distinguish dump and circle-to-hole variants.

**B08-S3** [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - PDF extracted text, authorship on PDF page 2; Lesson 10 on PDF pages 38-40, especially instruction on PDF page 39; Lesson 11 review on PDF page 42.

**B08-S4** [Running the Pipe](https://davidavellan.com/running-the-pipe/) - The accessible explanatory article text beneath the video embed; video not watched.

**B09-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text: page 8, Swing Step; page 17, Swing Single; pages 24-25, Circle to Hole and Rear Double (1-based PDF pages).

**B09-S2** [Coaching Wrestling Successfully, Figure 7.11: Sweep-single finish](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730) - Full page-labeled text around printed page 95, Figure 7.11, within Teaching Folkstyle Skills and Drills; illustrated frames not inspected.

**B09-S3** [Matt Pell's Method to Developing a Top Level Head Inside Single](https://www.flowrestling.org/articles/5024045-matt-pells-method-to-developing-a-top-level-head-inside-single) - Accessible article text: Day 1 inside-tie pull/lower-level sweep key points and Day 4 mat-finish key points; linked premium videos not inspected.

**B09-S4** [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached official PDF text, PDF pages 154-155 (printed pages 153-154), attack priorities and shot finishes.

**B10-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text: page 9 Spin Drill; page 10 Snap Down and counter-offense; page 16 Collar Tie / Snap Downs; page 19 short-offense backhand and arm-block instructions (one-based PDF pages). Root editorial cross-check additionally inspected PDF page 25 Short Offense / Backhand, which explicitly uses the near hand to block the near triceps; the final card selects that variant.

**B10-S2** [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage) - Complete accessible Snap-Down Redirect text: Setup, Action, Coaching Point, and Common Error. Linked illustration returned 404 and was not inspected.

**B10-S3** [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached official PDF text, PDF pages 152-153 (printed pages 151-152): Contacts and Set-ups, including snap, post, and block definitions.

**B10-S4** [Master Snap and Go Behind Drills with Dan Vallimont](https://fanaticwrestling.com/blogs/news/master-snap-and-go-behind-drills-with-dan-vallimont) - Full publisher article, specifically the kneeling start, collar/inside tie, weight-on-hands target, armpit-block explanation, and gradual drill-speed discussion. Embedded video not inspected.

**B11-S1** [College Park Wrestling Technique Handbook](https://cdn2.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text: title and mission pages 1-3; sprawl and spin descriptions pp. 8-9; Sprawl Butt Drag on p. 19; Backhand short-offense finish on p. 25. Retrieved directly and parsed in memory with pypdf.

**B11-S2** [How to use takedown counter drills to your advantage](https://us.humankinetics.com/blogs/excerpt/how-to-use-takedown-counter-drills-to-your-advantage) - Full relevant publisher webpage text: Takedown Counter Drills and Snap-Down Redirect, including Setup, Action, Coaching Point, and Common Error.

**B11-S3** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/blog/kolatcom-4-6-year-teaching-curriculum-for-new-to-novice-wrestlers-by-cary-kolat) - Accessible article text: How the Levels Should Be Approached and Level 1 Feet, especially Defense Key Points and Defend Double Leg.

**B11-S4** [USA Wrestling Core Curriculum: Folkstyle Level 1](https://www.usawmembership.com/usa_wrestling_core_curriculum) - Public curriculum page and its one-page Folkstyle Level 1 PDF; Counter Offense lists Sprawl & spin.

**B12-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF text, pages 1-2: stance and Skill 2 Motion, including the down/cross-block instructions; page 4: Neutral Defense - Performance Motions. Inspected the cached page-marked extraction and opened the official PDF.

**B12-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text, page 7 stance and page 8 Motion and Down Block/Cross Block in the Gable Warmup. Inspected the cached page-marked extraction and opened the original PDF.

**B12-S3** [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached official PDF text, PDF page 156 (printed page 155), Counter Offense, including down/cross blocks and the sequence of shot-defense barriers. Original URL confirmed from cache metadata; direct web reopening returned an error.

**B12-S4** [Defensive Based Warm Up With Zach Tanelli](https://fanaticwrestling.com/blogs/news/defensive-based-warm-up-with-zach-tanelli) - Full written instructional explanation, particularly paragraphs describing linked hands and feet and lead-hand/lead-leg withdrawal against a single (web lines 532-536).

**B13-S1** [Peekout](https://content.themat.com/CoachesCorner/technique/Peekout/default.php) - Full HTML captions for the 12-image lesson; still photographs 003.jpg, 004.jpg, 006.jpg, 007.jpg and 009.jpg. Retrieved directly after web fetch failure.

**B13-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked extraction: PDF page 9, drill 6 PEEK OUT/CUT BACK; PDF page 23, double-leg finish PEEK OUT/CUT BACK DOUBLE. Also read page 22 front-head counter section to distinguish alternate variants.

**B13-S3** [Shot Recovery and Low Single Leg Training Session](https://www.kolat.com/blog/shot-recovery-and-low-single-leg-training-session) - Public practice-plan text dated December 5, 2014, especially warm-up recovery and peek-out drills and conditioning-drill description.

**B14-S1** [2024-25 NFHS Wrestling Rules, Rule 5-19-2](https://nhwoa.org/wp-content/uploads/2024/11/24-25-NFHS-Wrestling-Rule-Book.pdf) - Printed page 27, Rule 5-19-2, on PDF page 12 of the 45-page scanned file. Both the upper and lower embedded page images were displayed and read, covering the entire defensive starting-position paragraph.

**B14-S2** [Wrestling Unit Plan, Lesson 17: Top and Bottom Starting Position](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF text, PDF pages 65-67: objectives, setup demonstration, bottom-position refinements and partner assessment.

**B14-S3** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF text, page 2, Get Set Drills - Arm Chop, listed video interval 12:14-12:36; page 3, Starting Position/Base to Feet. Only guide text was inspected, not the linked video.

**B14-S4** [Wrestling Rules Changes - 2025-26](https://nsaa-static.s3.amazonaws.com/textfile/ref/wrrules.pdf) - Entire one-page official change summary, dated September 26, 2025, opened and read as PDF text.

**B14-S5** [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf) - Entire three-page NFHS 2026-27 rules-change press release, opened and read as PDF text; rule-change discussion on pages 1-2.

**B15-S1** [2023-24 NFHS Wrestling Rules, Rule 5-19](https://www.scribd.com/document/758557564/NFHS-WR-RB-2023-24) - Opened full accessible document text; printed pages 27-28, especially Rule 5-19-5 and 5-19-9, and page 66-67 illustration captions. Read complete paragraphs, not only search snippets.

**B15-S2** [Wrestling Unit Plan, Lesson 17: Top and Bottom Starting Position](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF text, PDF pages 65-67: lesson objectives, top-position demonstration and partner checks.

**B15-S3** [2024-25 Wrestling Officiating Mechanics and Procedures Blue Book](https://www.mhsaa.com/sites/default/files/Wrestling/2024-25/2024-25-MHSAA-WRESTLING-OFFICIAL-BLUEBOOK-111824.pdf) - Opened PDF text; page 9, Referee's Position, and page 5 identifying the document as a supplement.

**B15-S4** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached text, PDF page 2: Get Set Drills - Arm Chop, guide's listed video interval 12:14-12:36.

**B15-S5** [Wrestling Rules Changes - 2024-25](https://nfhs.org/resources/sports/wrestling-rules-changes-2024-25) - Search service returned the full six-item change article with rationales; all listed rule references read. Direct page open returned an error.

**B15-S6** [Wrestling Rules Changes - 2025-26](https://nsaa-static.s3.amazonaws.com/textfile/ref/wrrules.pdf) - Entire one-page change summary, dated September 26, 2025, opened and read as PDF text.

**B15-S7** [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf) - Entire three-page release opened as PDF text; rule-change discussion on pages 1-2.

**B15-S8** [2027 USA Wrestling Kids Folkstyle National Championship - Rules](https://usawrestlingevents.com/event/2700004502/rules) - Opened Rules page, 2026-2027 girls rules and general rules/modifications list.

**B16-S1** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF-page-marked text, PDF pages 2-3: Bottom Motion, Belly to Base; page 4: Pressure Down Drill for Stand Ups.

**B16-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF/printed pages 31-32: Bottom, Escapes and Reversals, and Counters.

**B16-S3** [Preston Mat Club Syllabus](https://www.wvmat.com/preston/syllabu.htm) - Public page text, II - Mat Wrestling: Bottom Man, Basic Skills for Mat Wrestling and Defensive Mat Wrestling (retrieved lines 133-170).

**B17-S1** [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/) - Full article text, especially Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration was not visually inspected.

**B17-S2** [Wrestling Unit Plan, Lesson 18: Stand-up Escape](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF text, pages 68-71, with emphasis on the actual teaching instructions on pages 69-70.

**B17-S3** [Bottom Move: Standup to an Escape](https://s3.amazonaws.com/my.llfiles.com/00224751/turkstep.pdf) - Full one-page PDF text, from inside-leg entry through low facing finish; illustrations not visually inspected.

**B17-S4** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF text pages 2-3, particularly Push Back Drill and Hip-Heist Drill at the printed video timestamp 23:48-24:21. The referenced video was not watched.

**B17-S5** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF text pages 8, 14, and 31: Wall Standup, Basic Bottom, and Standup execution table.

**B18-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 14 and 31-32: Basic Bottom, Tripod, Sit Out/Turn Out, and Switch.

**B18-S2** [Wrestling Unit Block Plan, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, pages 83-88, especially partnered entry on page 85 and seated wrist relationship on page 86.

**B18-S3** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/) - Full authored page text, especially Steps 1, 2, and 5; embedded Vimeo video not inspected.

**B18-S4** [Sit Out, Turn In by Jon Morrison](https://www.youtube.com/watch?v=vkY16JCnNnQ) - Automatic English transcript 0:00-4:12 and paused demonstration frames at 1:55, 2:00, 2:15, 2:20, 2:25, 2:30, 2:40, 4:00, 4:05-4:07, and 4:09 through the browser.

**B19-HK** [Bottom Move: Hip Heist to an Escape](https://s3.amazonaws.com/my.llfiles.com/00224751/hipheist.pdf) - Complete PDF page 1 text and all nine photos, rendered in memory; enlarged final three photos inspected for the turn and facing finish.

**B19-WEBER** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/) - Article text, especially Step 1: Basic sit out position and Step 2: Seal off, hip heist away; surrounding alternatives read to distinguish variants.

**B19-MAL** [Hip Heist Drills by Mike Malinconinco](https://fanaticwrestling.com/blogs/news/hip-heist-drills-by-mike-malinconinco) - Full article text, especially Seated Hip Heist and Seated Wall Hip Heist; advanced drill sections read only to establish exclusions.

**B19-HG** [Wrestling Unit, Lesson 22: Sit Out Heist and Turn In](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked extraction, pages 85-87, with the heist sequence on PDF page 86 and the separate turn-in continuation on page 87.

**B19-USAW** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF-page-marked extraction, PDF page 3, Hip-Heist Drill section keyed to 23:48-24:21; relevant bottom-motion context on pages 2-3.

**B20-S1** [Escapes and Reversals - Switches, from The Wrestling Drill Book](https://coachesinsider.com/wrestling/escapes-and-reversals-switches-article/) - Public article text, standard SWITCH setup, action, coaching point, and common error; also distinguished its separately named variants.

**B20-S2** [Wrestling Unit Block Plan, sit-out switch lesson](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - PDF pages 90-92, cached page-marked text of sit-out review, switch instruction, and closing cues; original PDF opened online.

**B20-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF page 32, SWITCH row in Escapes and Reversals; cached page-marked text and original PDF opened online.

**B20-S4** [Winning Wrestling Moves, Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Coach-authored book transcription, printed pages 130-132: Switch From Referee's Position, Short Sit to a Switch, and adjacent reswitch/limp-arm explanations; Using This Book confirms left-side rider convention.

**B20-S5** [Learn a Technique that will Help Your Wrestlers Get a Quick Reversal!](https://www.championshipproductions.com/news/2014/11/01/learn-a-technique-that-will-help-your-wrestlers-get-a-quick-reversal/) - Public Switch coaching summary identifying excessive sit-out distance and leaning backward as errors.

**B20-S6** [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book) - Current online edition, section 25.5-25.8; page identifies last update as September 13, 2026.

**B21-S1** [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/) - Full article text, including Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration not visually inspected.

**B21-S2** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - PDF text pages 2-3, especially the Hip-Heist Drill on page 3 at the printed video timestamp 23:48-24:21. Referenced video not watched.

**B21-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF text page 14, Basic Bottom stand-up teaching progression, and page 31, Standup execution table.

**B22-S1** [Wrestling Moves KOLAT.COM Wrestling Chop & Tight Waist](https://www.youtube.com/watch?v=fnI_WjItbdI) - Paused video frames at 0:16, 0:36, 0:41, 0:43, 0:44, 0:46, 0:56, 1:04, 1:06, 1:09 and 1:14; particularly near-elbow contact and the folded forearm in 0:43-0:46. Channel identity and description inspected in browser.

**B22-S2** [Pre-season Clinic: Top Wrestling Part 6 - The Tight Waist Near Arm Chop and Roll Through Tilt, November 2, 2025](https://madisonyouthwrestling.club/) - Opened club page and read the November 2 instructional entry, specifically the paragraph explaining rear knee, waist elbow, diagonal arm collapse and toe drive.

**B22-S3** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached page-marked text, PDF page 2 Get Set Drills - Arm Chop and PDF page 3 Top Motion.

**B22-S4** [Breakdown Your Opponent with the Tight Waist Chop](https://www.championshipproductions.com/news/2014/10/01/breakdown-your-opponent-with-the-tight-waist-chop/) - Opened and read the complete accessible instructional paragraph below Tight Waist Chop, dated October 1, 2014.

**B22-S5** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached page-marked PDF text: page 12 Basic Top and Breakdowns; page 27 Tight Waist Elbow Chop and Basic Control Positions/Cross Wrist.

**B23-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked extraction, PDF pages 26-27: general TOP instruction, TIGHT WAIST ANKLE NEAR OR FAR, and subsequent control entries; web extraction also inspected.

**B23-S2** [Elementary School Physical Education: A Guide for Physical Education Teachers](https://files.eric.ed.gov/fulltext/ED093805.pdf) - PDF text, physical PDF pages 317-318 (printed pages 338-339), especially Tight Waist Near Ankle and Teaching Techniques.

**B23-S3** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF text, page 3, Top Motion section marked 20:18-21:14.

**B23-S4** [Granby Roll Defense With Hudson Taylor](https://fanaticwrestling.com/blogs/news/granby-roll-defense-with-hudson-taylor) - Accessible article text, especially the explanation of tight-waist ankle pressure moving weight toward the hands; embedded video not inspected.

**B24-S1** [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf) - PDF text, page 3, Breakdowns and spiral-ride paragraphs; page 4 author biography. Spealler identifies his Division I wrestling background at Lock Haven.

**B24-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 26-28: Top, Breakdowns, Spiral/Claw, Tight Waist Elbow Chop, Near Wrist, Cross Wrist, and opening control entries. Original PDF URL also opened.

**B24-S3** [How To Spiral Ride With Malik Amine](https://fanaticwrestling.com/blogs/news/how-to-spiral-ride-with-malik-amine) - Accessible article text under How To Spiral Ride, especially the hand-placement and forward-bump paragraphs, web lines 53-60.

**B24-S4** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF-page-marked text, pages 1-3, especially page 3 Top Motion, corresponding to the guide's 20:18-21:14 section; original PDF opened.

**B25-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached extracted PDF text, PDF pages 26-28: TOP principles; NEAR WRIST; CROSS WRIST, outside/inside 2-on-1; BAR ARM and TURK context.

**B25-S2** [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves) - Title/authorship text and printed page 156, NEAR-WRIST CONTROL and The Near Wrist; neighboring half-nelson continuation text on pages 156-157.

**B25-S3** [Coaching Wrestling Successfully, Figure 7.20: Near wrist ride drill](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730) - Printed page 103, Figure 7.20 caption and near-wrist ride drill text; preceding jam-drill caption for context.

**B25-S4** [Near Wrist Ride](https://www.attackstylewrestling.com/near-wrist-ride/) - Public coach-authored article text, especially the paragraph naming forward pressure, wrist control, shoulder control, and reaction-based continuation.

**B26-S1** [College Park Wrestling Technique Handbook, Basic Top: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF text, pages 12-13; especially page 13, Turns, Half Nelson, near-side half after flattening with far-elbow post.

**B26-S2** [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF text, pages 101-104, instructional tasks for the half and its early defense.

**B26-S3** [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo) - Full accessible article text, especially Half Nelson section, lines 535-539 in browser extraction.

**B26-S4** [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/) - Coach-authored article text; steps 1-3 and remaining variant headings to distinguish the basic half from later combinations.

**B26-S5** [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf) - PDF page 1 text, example 2 for half nelson and Rule 5-20 normal-range definition; page 2 text for general dangerous-position context.

**B26-S6** [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules) - Rules section specifying NFHS scoring rules with USAW modifications and the 2026-2027 girls provision.

**B26-S7** [Adjustment in Minimum Body Fat Percentage for Females Highlights High School Wrestling Rules Changes](https://www.miaa.net/sites/default/files/2026-04/2026-27-wrestling-rules-changes-press-release.pdf) - PDF pages 1-2, 2026-27 approved change announcement and current rulebook publication information.

**B27-S1** [Wrestling Unit: Lesson 25, Base Recovery; Lesson 26, Half-Nelson Pinning Combination and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text and public PDF text: PDF page 99 for belly-to-base recovery, pages 103-104 for half defense and the early situational start. Public extraction uses zero-based P98 and P102-P103 for these pages.

**B27-S2** [Wrestling 101, Chapter 6: Pinning; Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf) - Cached full text and public four-page PDF text; PDF page 2 half-nelson defense row and page 3 bottom-position discussion.

**B27-S3** [Half Nelson Technique: Defense to the Half Nelson](https://web.uvic.ca/~thopper/wrestling/WrestUnit/Gametasks2/tactical_awareness.htm) - Full page text, especially 'From the Prone Position,' steps 1-3. Linked photographs were inaccessible and were not visually inspected.

**B28-S1** [College Park Wrestling Technique Handbook, Turns: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF page 13, section 2(a), Half Nelson; independently read the wrist-retention and final pin-position instructions.

**B28-S2** [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, PDF pages 101-104, half-nelson objectives, demonstration instructions and partner progressions.

**B28-S3** [Top Move: Half-Nelson and Reverse Half-Nelson](https://s3.amazonaws.com/my.llfiles.com/00224751/halfnelson.pdf) - Full single-page PDF text and all nine photograph panels, rendered in memory and visually inspected; especially the transition onto the back and final position.

**B28-S4** [Illegal Headlock / Legal Headlock: Look Close, Rule 7-1-5d](https://iwcoa.net/wp-content/uploads/2024/12/NFHS-Head-Lock-2024-2025.pdf) - Full extracted text of PDF pages 1-3, including the rule citation and legal/illegal frame captions; screenshot fetch failed.

**B28-S5** [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules) - Current event-page rules text, specifically the 2026-2027 girls provision and NFHS rules with USA Wrestling modifications.

**B29-S1** [Top Move: Cradle (Near-Side), from Coaching Youth Wrestling Course](https://s3.amazonaws.com/my.llfiles.com/00224751/cradlens.pdf) - Complete one-page PDF text. Editorial review additionally rendered and inspected all nine demonstration photographs, including the last two forehead-post/hip-adjustment frames.

**B29-S2** [College Park Wrestling Technique Handbook - Inside Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached extracted PDF pages 28-29: cradle introduction, distinction from crossface cradle, and Inside Cradle / Bow and Arrow first finish. Page 13's inside-cradle grip note was also inspected.

**B29-S3** [6 Step Near Side Cradle Series](https://www.attackstylewrestling.com/near-side-cradle-series/) - Public article text, particularly Step 1's elbow locations and Gable lock, and the distinction between Steps 2-6's finishes. Embedded video was not watched.

**B29-S4** [Dubuque RTC 'Wrestling's Basic Truths' Part IV: Lifting](https://fivepointmove.com/greco-wrestling-training/hall-dubuque-rtc-volume-iv-lifting/) - Article attribution explaining Hall's authorship and the opening hand-lock paragraphs under Lifting from the Stand Up Position.

**B30-S1** [Basic Wrestling Fundamentals: Near Side Cradle Series; Countering a Nearside Cradle](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate) - Full page text, Near Side Cradle Series at printed pp. 58-59 and Countering a Nearside Cradle at printed p. 62; web text lines 494-499 and 522-527. Also read the glossary definition of two-on-one hand/wrist/arm control. Did not use the AI-generated question section.

**B30-S2** [Wrestling 101, Chapter 6: Pinning; Chapter 5: Bottom Wrestling](https://westhillswrestling.weebly.com/uploads/1/1/1/3/111374267/wrestling101rev121919.pdf) - Cached page-marked extraction, PDF pp. 2-3, including Near Cradle row under Stop This PIN and bottom-position principles; official host PDF also opened through web tool.

**B30-S3** [Winning Wrestling Moves, Near-Side Cradle and cradle counters, printed pp. 160-163](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Accessible book text at web lines 3331-3336 and 3367-3380, carrying printed page headings 160 and 163.

**B30-S4** [Escapes & Reversals Series, Cradle Defense](https://www.attackstylewrestling.com/wp-content/uploads/2014/04/escapes_and_reversals.pdf) - Actual four-page PDF text, PDF p. 4: near-side cradle catch-hand/head-up entry and separately listed break-lock and later defenses.

**A01-S1** [Two-On-One (Russian Tie), Lesson 6](https://www.sethciasulli.com/lessons/two-on-one-russian-tie) - Full accessible page text, particularly Offense paragraphs describing entry from a right-hand post and both palms-up grips.

**A01-S2** [Defend a Two-On-One / Russian Tie - Hook Ankle, Single (linked as Offense, High Single)](https://www.youtube.com/watch?v=lvG5CY-l81s) - The entire public video description in the watch-page response; linked from https://www.sethciasulli.com/lessons/two-on-one-russian-tie/offense/high-single. Video playback reports members-only and was not watched.

**A01-S3** [Fake Single To Ankle Pick With Dan Vallimont](https://fanaticwrestling.com/blogs/news/fake-single-to-ankle-pick-with-dan-vallimont) - Full accessible instructional article, especially initial Russian position, near-foot block, and the statement that the single remains available if the foot does not retreat.

**A01-S4** [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF extracted text, PDF page 39, finish demonstration and refinement columns; original URL metadata checked.

**A01-S5** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF extracted text, PDF page 18 Russian section and PDF page 24 Single/Run Pipe rows; original URL metadata checked.

**A02-S1** [Wrestling with Dan Henderson: Simple Takedown](https://library.crossfit.com/free/pdf/60_07_Simple_Takedown.pdf) - Both PDF pages: complete text and both rendered pages, including the starting clinch and four action/finish photographs.

**A02-S2** [College Park Wrestling Technique Handbook: Underhook - Cross Pick](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF page 17, Underhook introduction and Cross Pick execution; relevant cached extraction and original PDF text.

**A02-S3** [Winning Wrestling Moves: Underhook Offense and Knee Pick](https://studylib.net/doc/27230226/winning-wrestling-moves) - Book text pp. 57-60: Underhook Offense, Finishes to the Underhook, and Knee Pick; online OCR lines 3448-3594.

**A03-S1** [The Wrestling Drill Book, Chapter 1: Pummeling; Pummeling to a Duck-Under](https://pdfcoffee.com/88f82thewrestlingdrillbook-pdf-free.html) - Accessible book transcription: Chapter 1 attribution; printed pp. 9-11, drills 4 and 5, including Setup, Action, and Coaching Point. Photographs not inspected.

**A03-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text: PDF p. 9 Inside Pummel and PDF p. 17 Underhook; also reviewed p. 5 duck-under notes and pp. 16-17 drop-duck setup.

**A03-S3** [Greco-Roman Wrestling, Chapter 4: Duck Under](https://pdfcoffee.com/uilliah-h-hortell-pdf-free.html) - Accessible book transcription of printed pp. 44-47, including text referring to Figures 4.26-4.29; title, author, and publisher front matter. Figure images not inspected.

**A03-S4** [Duck Unders and High Crotches Via Nestor](https://fanaticwrestling.com/blogs/news/duck-unders-and-high-crotches-via-nestor) - Article text explaining inside/collar-tie contacts, pushing to elicit pressure back, level change, elbow clearance, and the standing back-access position. Embedded video not viewed.

**A04-USAW_INSIDE** [Level 2 - Folkstyle Core Curriculum - High Crotch Inside Step Penetration](https://www.youtube.com/watch?v=witUsu1OzX8) - Complete exported English automatic captions, 0:04-2:25, and browser still frames at approximately 0:35, 0:40, 1:27, and 2:02. Located through USA Wrestling's official Folkstyle Level 2 curriculum.

**A04-USAW_CHANGE** [Level 2 - Folkstyle Core Curriculum - High Crotch Change Off to Double](https://www.youtube.com/watch?v=ehtf3Y5g6BI) - Complete exported English automatic captions, 0:05-4:20; browser still frames around 0:40, 2:20, and 2:25. Key instruction at 0:27-1:41 and 2:04-2:54.

**A04-HORASKI_GARCIA** [Wrestling Unit Block Plan: High Crotch Shot and Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, pages 45-48, especially page 45 same-side penetration arm and page 47 inside-hand release to double; pages 12-14 for the angled double-leg finish.

**A04-COLLEGE_PARK** [College Park Wrestling Technique Handbook: Basic Offense and Finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text on pages 9 and 23: HIGH-C POSITION, DOUBLE / FLAIR, and HIGH CROTCH / DOUBLE rows.

**A05-TRASSO** [The Merge Ep. 39 - Single Leg Barzegar Finish To Side Control](https://www.youtube.com/watch?v=ohdmZoUmIsc) - Exported auto-generated English transcript, especially 0:23-1:38; actual paused browser video frames around 0:37, 0:50-0:55, 1:15, 1:25, and 1:38-1:40. The reactive explanation is 1:07-1:38.

**A05-COLLEGE_PARK** [College Park Wrestling Technique Handbook: Single finishes](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF extracted text for PDF page 24, especially SINGLE / BARZGAR, RUN PIPE, DUMP, and CUT BACK DOUBLE; page 23 DOUBLE / FLAIR and HIGH CROTCH rows also read to distinguish variants.

**A05-FUJI** [The Merge: Single Leg Barzegar Finish To Side Control](https://www.fujisports.co.uk/blogs/blog/the-merge-single-leg-barzegar-finish-to-side-control) - Accessible article text and named Michael Trasso biography, including the description of the captured leg being outside rather than between the attacker's legs.

**A05-USAW_GUIDE** [USA Wrestling Coach's Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Official-source cached text with page markers: PDF pages 119 and 154-156, printed pages 118 and 153-155.

**A06-S1** [College Park Wrestling Technique Handbook - Single finishes: Circle to Hole](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Downloaded the source in memory; extracted pages 23-25 and independently inspected the rendered page 24, including the Circle to Hole row.

**A06-S2** [Team USA Technique Tips: Improving Position in Neutral Attacks](https://www.auburntakedown.com/forms-and-documents/forms-2019-2020/201907---usa-wrestler.pdf) - Downloaded the source in memory; extracted page 36 and independently inspected its complete six-photo rendered technique page and captions.

**A06-S3** [The Technique Blog: Finishing a Single Leg on the Mat (Baseline)](https://coachayres.com/2020/12/11/the-technique-blog-finishing-a-single-leg-on-the-mat/) - Read public article text, particularly the introduction and Key Points to Finishing a Single Leg Backside. Embedded videos were not inspected.

**A07-S1** [College Park Wrestling Technique Handbook - Single finishes, Circle to Hole](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - PDF page 24: extracted full single-leg finishing text and inspected rendered page, especially the Circle to Hole row. Also read relevant surrounding pages 23 and 25.

**A07-S2** [Team USA Technique Tips: Improving Position in Neutral Attacks](https://www.auburntakedown.com/forms-and-documents/forms-2019-2020/201907---usa-wrestler.pdf) - PDF page 36, extracted captions and rendered full six-photo technique page.

**A07-S3** [2010 Washington State Coaches Clinic with Cary Kolat](https://www.kolat.com/blog/2010-washington-state-coaches-clinic-with-cary-kolat) - Public page text: single-leg sequence, discussion of drilling opponent defense, and rebuild-drill paragraph. Linked technique pages led to login.

**A07-S4** [Building Up on a Single Leg to Double Leg Finish](https://www.youtube.com/watch?v=2qod8qCChKw) - Public page description and paused video frames near 0:00, 0:02, 0:05, 0:06, 0:08, 0:09, 0:19, 0:20 and 0:21, using the browser player. No transcript or audio analysis.

**A08-MARTINEZ** [Downblock to a Reattack: Wrestling Technique with Isaiah Martinez](https://www.youtube.com/watch?v=q6FJeyfnxt4) - Complete auto-generated English transcript, 0:00-1:03 of the 1:10 clip, exported through the browser transcript tool; video frames sampled at about 0:20, 0:25, 0:30, 0:35, 0:40, 0:45, and 0:55.

**A08-USAW_SKILLS** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached official PDF page-marked text, pages 1-2 for stance and down/cross blocks, and pages 4-5 for simulated entries, level change, and attack-position principles.

**A08-COLLEGE_PARK** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF page-marked text, page 8: Motion, Down Block/Cross Block, and Level Change/Set Your Feet; pages 9 and 23 also read to check the distinct double-leg position and finish.

**A09-S1** [Single Leg Defense with Henry Cejudo](https://fanaticwrestling.com/blogs/news/single-leg-defense-with-henry-cejudo) - Full accessible page text, especially paragraphs explaining the short whizzer, outside shin, far wrist, supporting-foot drive, head height, and maintaining position when the continuation is unavailable (retrieved lines 37-50).

**A09-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text: PDF page 20, SINGLE introduction and WHIZZER/INSIDE TRIP; page 19 sprawl/short-offense instructions read for comparison.

**A09-S3** [Working on the Whizzer](https://www.themat.com/news/2001/april/30/working-on-the-whizzer) - Substantial indexed article body returned by targeted web search, including the right-leg/left-arm example and discussion separating basic counters from whizzers for distance. Direct open returned 403.

**A10-S1** [Limp Arm From Underhook by Bekzod Abdurakhminov](https://fanaticwrestling.com/blogs/news/limp-arm-from-underhook-by-bekzod-abdurakhminov) - Full accessible instructional article, especially paragraphs on parallel position, outside foot, wrist control, pressure response, and avoiding a step over an intact whizzer.

**A10-S2** [Limp Arm From Underhook by Bekzod Abdurakhminov](https://www.youtube.com/watch?v=KzRlNiNDalI) - Actual browser video frames at approximately 0:30, 0:50, 1:10, 1:30, 1:35, 1:36, 1:37, and 1:57 of the 3:03 clip, including front and reverse views of the low start, wrist grip, and arm clearance.

**A10-S3** [Basic Wrestling Fundamentals: Loose Arm and Limp Arm](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate) - Accessible page-labeled manual text around printed page 34: Loose Arm steps 1-7 and the note distinguishing the Limp Arm with the arm across the opponent's back; glossary definition also read.

**A11-S1** [Wrestling Unit Block Plan, Lesson 10: Single Leg Finishes and Defense](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text: PDF page 2 for authorship, page 39 for the standing head-inside single setup, and page 40 for the elbow/triceps lift, balance, foot recovery, and push-away defense. Original public PDF also opened successfully.

**A11-S2** [Single Leg Defense with Henry Cejudo](https://fanaticwrestling.com/blogs/news/single-leg-defense-with-henry-cejudo) - Full accessible page text, especially retrieved lines 41-50 describing the whizzer setup, squaring action, upper-arm grip, and simultaneous arm lift/leg withdrawal. Embedded YouTube fetch failed.

**A11-S3** [USA Wrestling Coach's Guide to Excellence, Second Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Official-source cache metadata and PDF-page-marked text: PDF page 119 (printed 118), plus pages 154-156 for attack, finish, and defensive teaching context.

**A12-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF page 22: FRONT HEAD/COW CATCHER introduction, FH-CROSS DRAG, and FH-NEAR SIDE DRAG. Also read page 25's offensive BACKHAND and SHORT DRAG entries to distinguish roles.

**A12-S2** [USA Wrestling Coach Guide to Excellence, 2nd Edition](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached PDF text: PDF pages 156-157, printed pages 155-156; Clearing Ties, item 6 Front head Locks, especially the two distinct elbow-pass and cross-hand drag options.

**A12-S3** [Countering a Front Headlock with Dave Crowell - Nazareth Area High School (PA)](https://coachesinsider.com/wrestling/countering-a-front-headlock-with-dave-crowell-nazareth-area-high-school-pa/) - Public article description and English auto-generated caption track for its embedded Vimeo video 772201057, duration 4:08; read full captions, using 0:20-1:25 for the drag-out and near-leg finish and 3:31-3:54 for elbow position.

**A13-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text: PDF p.22 Russian 2 on 1, Lift His Far Elbow to Near Underhook; PDF p.17 Underhook introduction.

**A13-S2** [USA Wrestling Coach Guide to Excellence, 2nd Edition: Clearing Ties](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/Coach-Guide-to-Excellence-2ndEdition.pdf) - Cached PDF-page-marked text, PDF p.157 / printed p.156, Two-on-one clearing options B-C and surrounding Clearing Ties introduction; official URL metadata checked.

**A13-S3** [Two-On-One (Russian Tie), Lesson 6](https://www.sethciasulli.com/lessons/two-on-one-russian-tie) - Full accessible lesson, especially Offense describing right wrist hand, left palm beneath the partner's right armpit, palms-up orientation, and outside angle.

**A13-S4** [Greco Roman Throw by with Pat Smith](https://fanaticwrestling.com/blogs/news/greco-roman-throw-by-with-pat-smith) - Full article. Selected paused frames around 0:19-0:20 and 0:49-0:50 of its public demonstration, https://www.youtube.com/watch?v=v_qe91aF3U8, including frame stepping near initial contact; no audio or transcript.

**A13-S5** [Lindland & Bisek Technique Series: Using a 2-on-1 Effectively](https://fivepointmove.com/greco-roman-technique-videos/lindland-bisek-technique-series-using-2-1-effectively/) - Full article, especially Establishing Position at 1:27 and Lindland's 5:07 distance-before-reaching explanation; original Bisek comments read. Embedded video not viewed.

**A14-S1** [Inside Control, from The Wrestling Drill Book, Second Edition](https://coachesinsider.com/wrestling/inside-control-article/) - Full article text, especially Inside Control in the Standing Position; linked image panels a-b (sitemgr_wr-insidecontrol1.jpg) and c (sitemgr_wr-insidecontrol3.jpg) visually inspected.

**A14-S2** [Getting Off The Bottom by Cary Kolat](https://www.kolat.com/blog/getting-off-the-bottom-by-cary-kolat) - Authored article text dated December 9, 2014, particularly sealing off and capturing hand control; linked videos were not inspected.

**A14-S3** [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/) - Full Setup, Action, Coaching Points and Common Error text; this article's illustration was not inspected.

**A14-S4** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached page-marked PDF text, pages 2-3, especially the Hip-Heist Drill at the printed video timestamp 23:48-24:21; video not watched.

**A15-S1** [Level 2 - Folkstyle Core Curriculum - Short Sit to a Stand Up](https://www.youtube.com/watch?v=hDrypwAVVaE) - Complete automatic English transcript, spoken material approximately 0:04-0:57 of the 1:06 clip; paused browser frames at 0:15, 0:20, 0:25, 0:30, 0:35, 0:40, 0:45, and 0:50. Official curriculum page also inspected to verify the link.

**A15-S2** [Winning Wrestling Moves: Short Sit Directly to a Stand-Up and Short Sit-Out](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Authored OCR text under printed page 116, Short Sit Directly to a Stand-Up and From a Short Sit-Out, Post Your Hand; printed pages 123-124, Short Sit-Out; compared printed page 117 stand-up finishes.

**A15-S3** [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/) - Full article text, Setup, Action, Coaching Points, and Common Error; published January 21, 2016. Linked illustration not visually inspected.

**A15-S4** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/) - Full authored article text, especially Step 5, Knee under stand up. Embedded Vimeo video not inspected.

**A16-S1** [Wrestling Unit Block Plan, Lesson 23: Sit Out Switch and Counters](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, pages 90-92: sit-out review, switch sequence, and closing cues; original 184-page PDF opened online.

**A16-S2** [College Park Wrestling Technique Handbook, Escapes and Reversals](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 31-32, especially the Switch and Sit Out/Turn Out rows; original 55-page PDF opened online.

**A16-S3** [Winning Wrestling Moves, Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Using This Book left-side rider convention and printed pages 130-132: Switch From Referee's Position, Short Sit to a Switch, and adjacent limp-arm/reswitch text.

**A16-S4** [Escapes and Reversals - Switches](https://coachesinsider.com/wrestling/escapes-and-reversals-switches-article/) - Public article text, standard Switch setup, action, coaching point, and common error; other named variants distinguished.

**A16-S5** [Wrestling Moves from Bottom: 5 Steps to a Sit Out Series](https://www.attackstylewrestling.com/sit-series/) - Full authored page text, especially Steps 1-2 and 5.

**A16-S6** [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book) - Current online edition, last updated September 13, 2026; sections 25.5-25.8.

**A17-S1** [Winning Wrestling Moves, Switches and Counters to Switches](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Printed pages 130-132 in the public text: right-side switch entry and leg scissor, Reswitch, Countering His Reswitch, and adjacent Limp-Arm-Out distinction.

**A17-S2** [The Wrestling Drill Book, Chapter 1, Drill 11: Switch-Reswitch](https://pdfcoffee.com/88f82thewrestlingdrillbook-pdf-free.html) - Printed pages 20-21: complete Setup, Action, and Coaching Point text; chapter attribution to Bill Archer also inspected.

**A17-S3** [College Park Wrestling Technique Handbook, Switch](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked extraction, PDF page 32, SWITCH row.

**A17-S4** [Switch / Re-Switch to a Step Over Chain Wrestling](https://attackstylewrestling.com/stepover/) - Public page and embedded Vimeo video 526241877, paused visual frames approximately 00:12-00:19, 00:22 and 00:37; slowed playback used for the initial exchange.

**A17-S5** [Rule Book & Guide to Wrestling, 2027 Edition: USAW Modification for Folkstyle Events](https://www.usawmembership.com/usa_wrestling_rule_book) - Current online edition, sections 25.5-25.8; page identifies update as September 13, 2026.

**A18-S1** [Quad Pod | Wrestling Moves](https://www.youtube.com/watch?v=c7QKJ1VBnTA) - Full auto-generated English transcript, 0:02-12:12. Technique review concentrated on 1:29-3:58, 5:08-5:47, and 6:47-8:08. Browser playback frames inspected around 3:05, 3:15, 3:20, 3:40, 3:51, 3:56-4:01, 5:23, 5:28, and 7:25; the 3:57-3:59 finish was inspected with paused-frame stepping.

**A18-S2** [Chain Wrestling from Bottom](https://www.themat.com/news/2002/november/26/chain-wrestling-from-bottom) - Official article text retrieved through HTTP, especially the Tripod and Head Post/Shrug sections. Published November 2002. Article author metadata inspected.

**A18-S3** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached PDF text pages 2-3, including Push Back Drill and the Hip-Heist Drill at the printed video interval 23:48-24:21. Referenced video not watched.

**A18-S4** [Stand-up Escape](https://coachesinsider.com/wrestling/stand-up-escape-article/) - Full Setup, Action, Coaching Points, and Common Error article text. Illustration not inspected.

**A19-S1** [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf) - Original PDF downloaded into memory and text extracted from pages 3-4; spiral paragraphs on page 3 and author biography on page 4.

**A19-S2** [How To Spiral Ride With Malik Amine](https://fanaticwrestling.com/blogs/news/how-to-spiral-ride-with-malik-amine) - Accessible article text, How To Spiral Ride section, especially lines 53-60 and the under-biceps hand-placement paragraph.

**A19-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 26-28: TOP, SPIRAL/CLAW, NEAR WRIST, CROSS WRIST, and continuation context; original PDF also opened.

**A19-S4** [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves) - Authorship and publication text; printed page 156, NEAR-WRIST CONTROL and The Near Wrist, web lines 8760-8784.

**A19-S5** [Coaching Wrestling Successfully, Figure 7.20: Near wrist ride drill](https://studylib.net/doc/28387558/coachingwrestlingsuccessfullypdfdrive1-241121045144-681c3730) - Printed page 103, Figure 7.20 near-wrist caption, web lines 4690-4695; preceding jam-drill caption for context.

**A19-S6** [KOLAT.COM 4-6 Year Teaching Curriculum For New To Novice Wrestlers](https://www.kolat.com/uploads/3/0/2/9/30299091/kolat.com_4-6_year_curriculm.pdf) - PDF page 6, Top breakdown and riding listings, web lines 240-268.

**A20-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked extracted text, PDF pages 26-28: TOP principles, SPIRAL/CLAW breakdown, NEAR WRIST, CROSS WRIST, and neighboring continuation context.

**A20-S2** [Claw Your Way to Victory with J'Den Cox](https://fanaticwrestling.com/blogs/news/claw-your-way-to-victory-with-j-den-cox) - Complete public article text, especially Hand Placement and Finishing the Ride. Embedded video was unavailable during attempted access.

**A20-S3** [Wrestling Escapes and Breakdowns](https://library.crossfit.com/free/pdf/69_08_Wrestling_Escapes.pdf) - PDF downloaded into memory and extracted with pypdf; page 3, Breakdowns and spiral-ride paragraphs.

**A20-S4** [Winning Wrestling Moves, Near-Wrist Control](https://studylib.net/doc/27230226/winning-wrestling-moves) - Authorship/title text and printed page 156, NEAR-WRIST CONTROL and The Near Wrist; web text lines 8761-8784.

**A21-S1** [Winning Wrestling Moves: Near-Wrist Control and Hip Tilt](https://studylib.net/doc/27230226/winning-wrestling-moves) - Authorship and Using This Book orientation; printed pages 156-157, Near-Wrist Control, The Near Wrist, and Hip Tilt prose, including hip contact and leg-elevation details. Neighboring alternatives read for differentiation.

**A21-S2** [Level 2 - Folkstyle Core Curriculum - Pop & Chop to a Near Wrist Cheap Tilt](https://www.youtube.com/watch?v=jelOYSlTKtI) - Full exported auto-caption transcript, 0:04-2:39; paused demonstration frames at 0:48, 1:20, 1:36, 1:41, 1:46, 1:51, 2:01, 2:06, 2:11, 2:16, and 2:31. Curriculum page link independently inspected at https://www.usawmembership.com/usa_wrestling_core_curriculum/2.

**A21-S3** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 26-28: Top principles, Near Wrist, Cross Wrist, outside and inside two-on-one descriptions, and adjacent top-control material.

**A22-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached page-marked PDF text: page 27 Basic Control Positions/Cross Wrist, and page 30 Tilts/Near Side; adjacent variant descriptions read to keep their entries separate.

**A22-S2** [Wrestling Moves KOLAT.COM 2 on 1 Tilt to Half Nelson](https://www.youtube.com/watch?v=fdNfeIm9Afw) - Public paused video frames at 0:19, 0:24, 0:29, 0:37, 0:42 and 0:47. Channel identity and description inspected; attempted transcript export returned no transcript.

**A22-S3** [2 on 1 Tilt to Foot Hook Stack - Cary Kolat Wrestling Moves](https://www.youtube.com/watch?v=SSt9rSh4-Nk) - Public paused video frames at 0:15, 0:20 and 0:30, focusing on the pre-stack tilt; video title, instructor and description inspected.

**A23-S1** [Arm Bar Turn - Cary Kolat Wrestling Moves](https://www.youtube.com/watch?v=JIs3jqGceME) - Paused browser video frames at 0:12, 0:22, 0:32, 0:37, 0:42, 0:47, 0:52, 0:57, 1:02, 1:07, 1:12, and 1:17; visible title and publisher. Transcript export reported none available.

**A23-S2** [College Park Wrestling Technique Handbook: Arm Bars and Bar Arms](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF page 29, ARM BARS, RUN TO FAR SHOULDER, and BAR ARMS sections.

**A23-S3** [Wrestling Unit Plan, Lesson 27: Arm Bar Pinning Combinations](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, PDF pages 106-108, arm-bar insertion, circling instruction, defense, and situation practice.

**A23-S4** [NFHS Wrestling Weekly Rule Interpretations, December 17, 2025: Arm Bar](https://www.wiaawi.org/Portals/0/PDF/Sports/Wrestling/Weekly_Interpretations_9.pdf?ver=FhexPUWIRK1EbGgMkuUehA%3D%3D) - Complete extracted text of the three-page PDF, particularly page 2 single-arm-bar frames and page 3 double-arm-bar notes.

**A23-S5** [Critique of the Week 11/03/09](https://www.kolat.com/blog/critique-of-the-week-110309) - Coach-authored page text, Top section item 2, published on page February 14, 2015.

**A24-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text: page 13, Turns/Half Nelson; page 27, Basic Control Positions/Near Wrist and Cross Wrist; surrounding pages 12 and 26-28 for context.

**A24-S2** [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/) - Full accessible coach-authored article text, especially Step 10 Near Wrist Roll Half Nelson and Steps 1-3; later variants read to distinguish them from the selected turn.

**A24-S3** [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, complete PDF pages 101-104, including demonstration, same-side leg movement, receiving and situation progressions.

**A24-S4** [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo) - Accessible article text, Half Nelson section, browser lines 52-56; surrounding breakdown and arm-bar sections read to distinguish the instruction.

**A24-S5** [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf) - PDF text on both pages, especially page 1 example 2 and Rule 5-20 normal-range definition. No photograph-inspection claim.

**A25-S1** [College Park Wrestling Technique Handbook - X-Face Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached extracted PDF page 28: cradle introduction and X-Face Cradle, Head to Knee, first grounded finish; page 29's Inside Cradle read to distinguish the families.

**A25-S2** [Bemidji Elementary Wrestling - Basic Move Progression and Scoring](https://cdn1.sportngin.com/attachments/document/0139/5030/_Coaches_Page__elementary_move_progression.doc.pdf) - PDF page 3, Top position, item 3: the complete ten-step Crossface cradle or Farside cradle text, with adjoining near-side description for comparison.

**A25-S3** [Far Side Cradle by Chael Sonnen](https://fanaticwrestling.com/blogs/news/far-side-cradle-by-chael-sonnen) - Full public article text, specifically the crossface paragraph and finishing paragraph. Embedded video was not watched; YouTube embed retrieval was throttled.

**A25-S4** [Winning Wrestling Moves - Far-Side Cradle and Cross Face Cradle](https://studylib.net/doc/26306790/winning-wrestling-moves-by-mark-mysnyk-barry-davi-2365328...) - Text transcription of printed pages 158-160, especially Cross Face Cradle: If Your Opponent Is Flat on the Mat, and the preceding finish/shoulder-clearance paragraph. Also page 141's crossface definition.

**A25-S5** [2027 USA Wrestling Kids Folkstyle National Championship - Rules](https://usawrestlingevents.com/event/2700004502/rules) - Current public event rules page, Rules section specifying NFHS rules with USAW modifications and USAW age/weight/time precedence.

**A26-S1** [Top Move: Cradle (Near-Side), Coaching Youth Wrestling Course](https://s3.amazonaws.com/my.llfiles.com/00224751/cradlens.pdf) - Complete cached one-page PDF text and the existing full-page rendered image, including all nine demonstration photographs and the final forehead-post/hip-adjustment frames.

**A26-S2** [College Park Wrestling Technique Handbook - Inside Cradle](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF pp. 28-29: cradle introduction, crossface-cradle distinction, and Inside Cradle / Bow and Arrow first finish.

**A26-S3** [6 Step Near Side Cradle Series](https://www.attackstylewrestling.com/near-side-cradle-series/) - Public article text, Steps 1-6; Step 1 supplies elbow placement and the recommended Gable lock. Embedded video not watched.

**A26-S4** [Basic Wrestling Fundamentals: Near Side Cradle Series; Countering a Nearside Cradle](https://www.scribd.com/document/114182524/Basic-Wrestling-Fundamentals-Warren-Applegate) - Accessible authored text at printed pp. 58-59 and 62, web text lines 494-499 and 522-527, including the explicit before-lock subsection. Excluded the site's AI questions.

**A26-S5** [Dubuque RTC 'Wrestling's Basic Truths' Part IV: Lifting](https://fivepointmove.com/greco-wrestling-training/hall-dubuque-rtc-volume-iv-lifting/) - Article authorship statement and the Gable-grip paragraph under Lifting from the Stand Up Position.

**A27-S1** [College Park Wrestling Technique Handbook, Turns: Half Nelson](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, PDF page 13, section 2(a); original public PDF also opened. Read retained-wrist, chest-to-chest, perpendicular, wide-feet and hips-down instructions.

**A27-S2** [Top Move: Half-Nelson and Reverse Half-Nelson](https://s3.amazonaws.com/my.llfiles.com/00224751/halfnelson.pdf) - Full one-page PDF text and all nine photographs; downloaded to memory, rendered with pypdfium2 and visually inspected. Middle row establishes hip lowering during arrival on the back; later row introduces reverse half.

**A27-S3** [Top Wrestling Fundamentals with Angel Cejudo](https://fanaticwrestling.com/blogs/news/top-wrestling-fundamentals-with-angel-cejudo) - Accessible article text, Half Nelson section, lines 52-56 in current browser extraction.

**A27-S4** [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, pages 101-104; demonstration, half-nelson mechanics and cooperative-to-defensive practice instructions.

**A27-S5** [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf) - PDF page 1 text, example 2 and Rule 5-20 normal-range definition; page 2 general dangerous-position text.

**A27-S6** [2027 USA Wrestling Kids Folkstyle National Championship: Rules](https://usawrestlingevents.com/event/2700004502/rules) - Rules section, including 2026-2027 girls provision and NFHS rules with USAW modifications, lines 37-54.

**A28-S1** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, page 27: Tight Waist Elbow Chop and Basic Control Positions/Cross Wrist; page 31 Bottom principles also read.

**A28-S2** [Breaking Out of Tilts by Zain Retherford](https://www.youtube.com/watch?v=EVHyXbOG3Og) - Complete exported auto-generated English transcript, 0:00-2:11. Paused public video frames at 0:40, 0:50, 0:55, 1:00, 1:01, 1:05, 2:00 and 2:01, including frame advances through the release.

**A28-S3** [Inside Bar and Cross Wrist Defense - Wrestling Bottom Technique](https://www.youtube.com/watch?v=O4_tHVaUJQg) - Complete exported auto-generated English transcript, 0:00-1:43, with cross-wrist passage at 0:49-1:43. Paused public frames at 0:52, 1:02, 1:12, 1:22 and 1:37.

**A28-S4** [Grind Ride Part 2: Cross Wrist-Defense](https://www.coachmackenzie.com/grind-ride-part-2.html) - Accessible page text, Cross Wrist-Defense section, listing Elbow point/peel hand, Elbow scrape, and collapse variations.

**A29-COLLEGE_PARK** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached page-marked PDF text, page 9 double position; page 23 DOUBLE / FLAIR and separate TURN CORNER LIFT; page 27 TIGHT WAIST ELBOW CHOP and CROSS WRIST / OUTSIDE 2 ON 1.

**A29-HORASKI_GARCIA** [Wrestling Unit Block Plan, Lesson 3: Double Leg Shot](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached page-marked text of PDF pages 11-14, especially original-lead-leg-side angle and cross-body shuffle on pages 12-13, and finish above hips on page 14.

**A29-WILL** [How to set up wrestling's double leg from the classic Thai clinch](https://www.grapplearts.com/Clinch%26MMATakedowns.pdf) - Accessible PDF page text on pages 2-3, The Takedowns / The Basic entry, including lead step, outside head, knee grips, trail step and far-hand action.

**A29-USAW_SKILLS** [USA Wrestling's 7 Basic Skills Study Guide](https://s3.us-east-2.amazonaws.com/usaw-public/CoachesCorner/7-Basic-Skills-Guide.pdf) - Cached page-marked PDF text, page 2 Get Set Drills - Arm Chop and Belly to Base; page 3 base-building continuation and Top Motion.

**A29-MADISON** [Pre-season Clinic: Top Wrestling Part 6 - The Tight Waist Near Arm Chop and Roll Through Tilt, November 2, 2025](https://madisonyouthwrestling.club/) - Accessible instructional webpage text in the November 2 entry, particularly the paragraph describing back-knee drive, waist-arm tightening, arm collapse toward the belly, and toe drive.

**A30-S1** [Winning Wrestling Moves: Near-Wrist Control and Hip Tilt](https://studylib.net/doc/27230226/winning-wrestling-moves) - Authorship, orientation, and printed pages 156-157: Near-Wrist Control, The Near Wrist, Half Nelson and Hip Tilt prose; neighboring Arm Pry read to distinguish the variant.

**A30-S2** [College Park Wrestling Technique Handbook](https://cdn1.sportngin.com/attachments/document/0e6c-2411143/Advanced_techbible.docx.pdf) - Cached PDF-page-marked text, pages 13 and 26-28: Half Nelson, Top principles, Near Wrist and Cross Wrist, with adjacent variants for context.

**A30-S3** [Half Nelson Wrestling In 10 Steps](https://attackstylewrestling.com/half-nelson-series/) - Entire accessible article text, especially Steps 1-3 and Step 10 Near Wrist Roll Half Nelson; other steps distinguished from the selected branch.

**A30-S4** [Wrestling Unit Plan, Lesson 26: Half-Nelson Pinning Combination](https://www.pelinks4u.org/naspeforum/discus/messages/1239/wrestling-3207.pdf) - Cached PDF-page-marked text, complete pages 101-104, including half mechanics, defensive response and teaching progression.

**A30-S5** [Near Wrist Ride](https://www.attackstylewrestling.com/near-wrist-ride/) - Full short public article, including the paragraph on forward pressure, wrist/shoulder control and reading available reactions.

**A30-S6** [NFHS Wrestling Officials: Potentially Dangerous, Mat A](https://www.iahsaa.org/wp-content/uploads/2024/10/NFHS_Wrestling-Officials-Potentially_Dangerous_Mat_A.pdf) - Both pages' extracted text, especially page 1 half-nelson example and normal-range-of-motion definition.
