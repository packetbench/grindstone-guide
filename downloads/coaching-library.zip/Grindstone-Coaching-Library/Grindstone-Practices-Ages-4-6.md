# Grindstone Wrestling 30 Practice Plans Ages 4-6

Mat Rats | Pup movement and play | 35 minutes

Thirty short, voluntary play sessions for children ages 4 to 6. Build comfort on the mat through moving, copying, choosing and cooperating. The aim is an enjoyable experience that children want to repeat.

Use these as a bank of choices for the once-weekly Pup program. Thirty plans do not require a thirty-week season. Select and repeat sessions to suit the children; observation, a familiar activity or an early finish with an authorized adult are valid options.

All times are elapsed minutes. Demonstration, rest, rotations and feedback are included within each block. Water remains available throughout.

## Coach operating guide

### Choose the right pace

Use these as a bank of choices for the once-weekly Pup program. Thirty plans do not require a thirty-week season. Select and repeat sessions to suit the children; observation, a familiar activity or an early finish with an authorized adult are valid options.

### Prepare the space

Have a clean wrestling mat, clear margins, timer, personal water bottles and the listed equipment ready. Flat markers must not slide. Confirm staffing, emergency contacts, medical restrictions and the venue emergency plan before arrivals.

### Read the clock

The left column shows elapsed time from the start of practice. Demonstration, turns, rest and feedback belong inside each block. Short rounds repeat only while both partners remain controlled. Water is available throughout, beyond the planned break.

### Give a clear invitation

Show one playful movement, give one short cue and invite children to try, adapt or watch. Rehearse stopping and making space before adding another movement choice. Use the shared Coach Moves Reference for the solo teaching steps.

### Make room and supervise

Give every child a clear mat space. Use separate markers for willing mirror partners. Pause for discomfort, distress, repeated imbalance or crowding. Reduce simultaneous activity or run fewer stations if every child cannot be supervised.

### Adjust without excluding

The easier and harder options change the task, not the child's place on the team. Offer observation, individual movement or cooperative rehearsal. Children may ask to stop at any time. Breaks remain supervised.

### Keep it play based

Offer activities as invitations. Do not require completing every station or demonstrating a skill to move on. No competitive live wrestling, forced contact, takedowns or conditioning punishments are included. Parents help only within the club's approved supervision arrangements.

## Practice 01 Our Mat and Our Space

**Goal:** Explore the room, find personal space, and recognize a shared stop signal.

**Set up:** Flat nonslip markers, a large stop card, and clearly marked movement, rest, and bottle areas.

**Before you begin:** Show children where to rest and how to find the supervising adult.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Find an empty island | Place markers well apart. Invite children to walk to an empty marker and look around before moving again. Hold up the stop card occasionally and model still feet. Children may watch or travel with an adult. |

| 10-17 | My movement space | Invite each child to choose a marker with open space around it. Demonstrate reaching sideways, making a small shape, and standing tall without touching others. Let children invent comfortable shapes while the coach copies their ideas. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Hello across the space | Offer pairs two separate markers facing one another. Invite one child to wave or make a small movement while the other responds from their own marker. Swap invitations frequently. Children may copy the coach instead of pairing. |

| 26-32 | Choose a home path | Offer a short walking path and a space for making shapes. Children choose either invitation, repeat it, or watch. Invite them to return to a nearby empty marker when the stop card appears; adults help preserve space. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay beside a familiar adult at one marker and copy any comfortable movement.

**Add challenge:** Choose a new empty marker after looking for a clear route.

**Stop or change:** Pause movement when children crowd a marker or cannot see a clear route.

**Look for:** Notice children finding space or responding to the stop cue with adult support.

**Ask:** Which place or movement did you like?

## Practice 02 Start Slowly and Stop Kindly

**Goal:** Experience moving, slowing, and stopping without chasing or racing.

**Set up:** Separate marker spaces, a green card, a yellow card, and a red stop card.

**Before you begin:** Demonstrate each color using movement and words; do not rely on color alone.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Traffic color walk | Show green and invite comfortable walking inside the marked area. Show yellow and model slower steps; show red and pause. Name each cue aloud. Keep changes unhurried, and invite children to watch or copy beside a coach. |

| 10-17 | Travel and park | Give each child a roomy marker space. Invite two or three steps away, then a gentle return and pause beside the marker. Offer forward or sideways travel. Repeat at each child's pace without scoring or calling anyone out. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Two separate traffic lanes | Create two nearby lanes for each willing pair. One child holds a movement card while the other walks or pauses within their own lane. An adult helps interpret cues. Swap roles, or let children follow the coach. |

| 26-32 | Pick the next signal | Invite children to select walking, slow walking, or stillness by pointing to a card. The coach shows the chosen cue to everyone. Children may follow, keep gentle movement in their own space, or use the supervised rest area. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use only walking and stopping with a coach demonstrating nearby.

**Add challenge:** Let a child choose between two clear movement cues for the group.

**Stop or change:** Stop the game if cues trigger sprinting, bumping, or sudden crowded turns.

**Look for:** Notice a child slowing before stopping, without comparing response speeds.

**Ask:** What helped your feet stop?

## Practice 03 Stance Along a Friendly Path

**Goal:** Explore a comfortable wrestling stance and short steps through playful marker routes.

**Set up:** Flat markers arranged in several short parallel paths with wide spaces between them.

**Before you begin:** Walk each route yourself and remove slippery markers or crossing paths.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Path explorers | Invite children to walk beside a short row of markers rather than on them. Show where each path begins and ends. Let each child repeat, change paths when clear, or observe. Adults prevent two children entering crowded routes. |

| 10-17 | Ready stance path | Show feet comfortably apart, one slightly forward, knees soft, and open hands in front. Invite short steps beside a marker path, keeping feet separated. Pause to rebuild the ready shape; children choose their own comfortable depth and pace. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Parallel stance journeys | Invite willing partners into separate neighboring paths. One shows a comfortable ready stance, then both take short steps toward their own end markers. Pause and wave before repeating. Children may follow the coach or use ordinary walking instead. |

| 26-32 | Choose a stance route | Offer straight and curved marker routes. Invite children to take small stance steps, keeping feet apart and hands comfortably forward. Stop before each gentle turn and rebuild balance. Children can repeat a favorite route or choose relaxed walking. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use two nearby markers and walk with a supervising adult.

**Add challenge:** Choose where to pause along a gentle curved route.

**Stop or change:** Pause when children cross lanes, crowd an entrance, or step onto a loose marker.

**Look for:** Notice short stance steps with feet apart and a comfortable pause.

**Ask:** Did you enjoy the straight or curved path?

## Practice 04 Tall Small and Comfortable

**Goal:** Explore a gentle wrestling level change by bending hips and knees while keeping the head comfortably up.

**Set up:** One roomy flat-marker space per child and pictures showing tall, small, and wide shapes.

**Before you begin:** Offer standing or seated choices; check that nobody is asked to move through discomfort.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Growing garden | Invite children to pretend they are plants, reaching comfortably upward and returning to an easy standing shape. Show a smaller shape with gently bent knees, without requiring a deep squat. Children choose their own range or watch nearby. |

| 10-17 | Level change garden | Show a comfortable ready stance with soft knees and hands forward. Bend hips and knees slightly to become a smaller plant, keeping eyes forward; grow back to the starting height. Invite children to choose shallow, unhurried movements without bouncing. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Garden movement mirrors | Place willing partners on separate markers. One shows a gentle level change by bending hips and knees, then returns to a comfortable stance. The other copies or chooses a smaller version. Swap leaders and use the stop cue for crowding. |

| 26-32 | Choose your shape story | Tell a short story about a plant growing, resting, and moving gently in a breeze. Invite children to choose movements for each part. Seated versions, quiet watching, and repeating one favorite shape are equally welcome throughout the game. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use one familiar standing or seated shape and return to it often.

**Add challenge:** Link two comfortable shapes slowly while keeping personal space.

**Stop or change:** Stop a movement if a child strains, loses balance, or reports discomfort.

**Look for:** Notice a small level change with bent hips and knees rather than a dropped head.

**Ask:** Which shape would you like to show?

## Practice 05 Step Into the Open Space

**Goal:** Rehearse a level change and lead-foot step while keeping the knees off the mat.

**Set up:** Several short routes of flat nonslip markers, spaced for ordinary steps rather than leaps.

**Before you begin:** Review P04 Level Change and Step. This is standing entry preparation; keep the feet staggered when resetting.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Shoreline walk | Invite children to walk around the outside of a marker island, then pause beside it. Demonstrate looking for a clear direction before leaving. Let children choose different islands without racing, while adults help avoid crowded landing spaces. |

| 10-17 | Level Change and Step - P04 | From stance, lower through hips and knees. Push gently from the rear foot and step the lead foot forward as the hips travel with it. Bring the rear foot forward enough to restore the staggered stance, not next to the lead foot. Both knees stay off the mat. Copy P04 slowly, then rest. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbors practice entry steps | Give willing partners separate lanes with an empty marker ahead. One demonstrates lowering slightly, stepping the lead foot forward, and bringing the trailing foot underneath. The neighbor tries at their own pace. Swap invitations; there is no partner target or contact. |

| 26-32 | Choose your entry island | Offer two nearby markers inside each personal lane. Invite children to choose one, lower slightly through hips and knees, and step toward it softly. Recover the trailing foot, pause, and walk back. Choose ordinary stepping when the pattern feels difficult. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use only two close markers or a clear unmarked walking lane.

**Add challenge:** Add an optional pause at each marker while looking toward the next space.

**Stop or change:** Stop for knee impact, lunging, loss of balance, or stepping toward another child.

**Look for:** Notice a small level change, soft forward step, and balanced recovery without knee impact.

**Ask:** Where did you choose to pause?

## Practice 06 Animal Ways to Travel

**Goal:** Explore hands-and-knees base and comfortable crawling through animal movement choices.

**Set up:** Wide individual lanes, flat end markers, and pictures of a bear, bird, and ordinary walking feet.

**Before you begin:** Demonstrate alternatives for children who prefer standing or seated movement.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Pick an animal idea | Show the pictures and invite children to choose comfortable walking, arm movements like wings, or an easy hands-and-knees crawl. Use short individual lanes. Children can change choices whenever they wish, with adults allowing plenty of space. |

| 10-17 | Build a small animal base | Show hands beneath shoulders and knees beneath hips on the mat, with relaxed elbows and head clear. Invite a short pause in this animal base, then one comfortable crawl step or rest. Keep lanes separate and offer upright animal play. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Animal neighbors | Give willing pairs separate lanes. One child chooses a picture, and both may try their own version while staying apart. Swap the picture chooser after a short turn. Nobody must copy crawling; comfortable walking always counts as participation. |

| 26-32 | Make a gentle journey | Invite children to imagine moving through a quiet forest, resting at a tree, and returning home. They choose their own movement for each part. Adults describe the story slowly and support children who prefer one repeated movement. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Choose walking or seated wing movements for the entire invitation.

**Add challenge:** Choose two comfortable movements and pause between them.

**Stop or change:** Stop crawling for wrist or knee discomfort, collapsing support, or crowding.

**Look for:** Notice comfortable hand-and-knee support with the head clear of the mat.

**Ask:** Which animal idea felt good to try?

## Practice 07 Turn Toward Open Space

**Goal:** Explore gentle direction changes while looking before moving.

**Set up:** Personal marker spaces and short paths with clear turnaround areas.

**Before you begin:** Show a slow standing turn and an alternative of pointing toward the new direction.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Point then walk | Invite children to stand beside a marker and point toward an open space before taking a few steps. Pause together, look around, and choose another direction. Adults model slow changes; children may point without traveling or watch nearby. |

| 10-17 | Gentle turn stations | Place two markers in each roomy lane. Invite walking toward one, stopping with room to spare, and turning slowly to face the other. Children choose how far to travel. Avoid spinning, hurried reversals, or instructions to turn sharply. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Show me the direction | Place willing partners on separate markers. One points left, right, or forward into clear space; the other points the same way or takes one small step. Swap roles often, with the coach available as a no-pressure partner. |

| 26-32 | Choose the next view | Invite children to choose something in the room they can safely face, such as a wall picture or empty marker. Turn gently and look together. Add a few optional walking steps only where every route remains clear. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay on one marker and point or turn the head comfortably.

**Add challenge:** Combine a pause, a gentle turn, and a few steps toward open space.

**Stop or change:** Pause if children spin, reverse into others, or become dizzy.

**Look for:** Notice children looking before making a gentle change of direction.

**Ask:** What did you turn to look at?

## Practice 08 Solo Stand-Up and Face

**Goal:** Rehearse the outside-leg stand-up from base, clear the hips, and turn to stance.

**Set up:** Clear personal mat spaces with optional flat markers and a nearby supervised observation space.

**Before you begin:** Review P08 Solo Stand-Up. Confirm a steady base and half-kneeling rise; demonstrate the turn with both feet free.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Moving at different heights | Invite comfortable walking, gentle knee bends, or seated arm movements in personal spaces. Show how a movement can be bigger or smaller without being faster. Children choose their own height and may remain seated or standing throughout. |

| 10-17 | Solo Stand-Up - P08 | Imagine a rider on your left. From base, step the right foot under you and lift the chest; left forearm rises across the chest, right hand comes to the belly. Rise on bent knees, hands at waist. Clear hips, then turn left with both feet moving. Finish in stance. Use P08 for the full demonstration. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Copy a Stand-Up | Partners stay in separate spaces. Copy one slow P08 stand-up, hip clearance and turn to face; then rest and swap. The coach checks short steps and chest lift. Children may rehearse just the first step or copy the coach upright. This is solo footwork; nobody adds a rider or pulls a child up. |

| 26-32 | Rise and Freeze | Show an open hand for one solo stand-up and turn; show a closed hand to stay in stance. Pause between invitations. Children can choose the short-step rehearsal or standing footwork. Celebrate balanced finishes and prompt releases into rest; this is a choice game without speed or elimination. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Rehearse the short foot step and chest lift, then reset; or copy stance footwork upright.

**Add challenge:** Link the rise, hip clearance and turn to face on a visual signal.

**Stop or change:** Stop for falling, pain, dizziness, pulling on another child, or a rushed backward lean.

**Look for:** Notice a short step under the body, chest lift, and a balanced turn with moving feet.

**Ask:** Which position felt comfortable today?

## Practice 09 Quiet Feet and Careful Steps

**Goal:** Explore controlled steps and gentle movement without evaluating noise sensitivity.

**Set up:** Flat markers forming short clear paths and several personal movement spaces.

**Before you begin:** Explain that quiet feet is a playful movement choice, not a demand for silence.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Soft step explorers | Invite children to try comfortable smaller steps along a short path, imagining a sleeping toy nearby. There is no contest for silence. Offer ordinary walking, seated foot taps, or watching, and praise children for noticing open space. |

| 10-17 | Step and settle | Give each child a personal marker. Invite one step away and a comfortable pause, then another step if space allows. Show how arms can help balance naturally. Repeat in different clear directions without requiring stillness for a fixed count. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Copy a careful step | Invite willing partners to stand on separate markers. One shows a small step and pause; the other may copy or choose a stationary version. Switch leaders frequently. Remind children that the aim is sharing ideas, not moving identically. |

| 26-32 | Gentle giant choice | Tell a story about a friendly giant choosing small careful steps or tall slow movements. Children choose their version in roomy spaces. Invite a favorite movement again, keeping ordinary walking and quiet observation available without calling out differences. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use seated foot taps or ordinary walking with a coach nearby.

**Add challenge:** Combine two careful steps in different directions with pauses.

**Stop or change:** Pause if children exaggerate tiptoeing, lose balance, or strain to move silently.

**Look for:** Notice children trying a controlled step and settling comfortably afterward.

**Ask:** What helped you move carefully?

## Practice 10 Our First Movement Celebration

**Goal:** Revisit favorite ways to move, stop, and choose space.

**Set up:** Three clearly separated areas for marker paths, body shapes, and comfortable animal movements.

**Before you begin:** Keep familiar options visible and explain that visiting every area is unnecessary.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Favorite movement parade | Invite children to choose walking, gentle arm movements, or another comfortable movement inside their own space. The coach celebrates each choice without ranking it. Show the familiar stop cue occasionally and offer nearby observation throughout the invitation. |

| 10-17 | Choose a discovery area | Open the path, shape, and animal areas with an adult watching each active space. Describe each invitation briefly. Children may stay, switch when routes are clear, or rest. Offer help choosing without requiring a rotation or completed task. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Show a neighbor | Invite willing pairs to remain on separate markers and show a favorite movement from today. The other child can respond by copying, waving, or showing something different. Swap invitations, and let children share with a coach instead. |

| 26-32 | Children choose the encore | Show pictures representing walking paths, shapes, and animal movements. Invite each child to point to a favorite, then offer the popular choices in separate spaces. Include quieter alternatives and repeat selected activities without choosing winners or awarding skill rankings. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay with one familiar activity beside a trusted supervising adult.

**Add challenge:** Invent a gentle two-movement sequence and invite the coach to copy it.

**Stop or change:** Pause station changes when travel routes crowd or children rush between areas.

**Look for:** Notice voluntary choices, comfortable participation, or a child sharing an activity they enjoyed.

**Ask:** What would you like to do again?

## Practice 11 Hello Helpful Neighbor

**Goal:** Practice offering movement ideas and responding without touching or pressure.

**Set up:** Pairs of flat markers several steps apart, plus individual spaces for children choosing solo play.

**Before you begin:** Offer a coach partner or solo option before assigning willing pairs.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Wave along the path | Invite children to walk a short clear path and wave toward a nearby coach or child if they wish. Nobody needs to return a wave. Pause at open markers and let children choose another journey or stationary movement. |

| 10-17 | Sending movement messages | Show how a wave, small reach, or gentle knee bend can be a movement message. Invite children to choose a message from their own space. The coach responds with a comfortable movement, accepting different responses without requiring exact copying. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbor invitations | Place willing partners at separate markers. Invite one to offer a movement message while the other watches, copies, or chooses a different response. Swap after a few invitations. Remind both children that declining or changing a movement is welcome. |

| 26-32 | Choose your greeting game | Offer movement messages with a coach, a short waving path, or solo shapes. Children choose where to play and may change when space is clear. Adults model asking before joining another child's activity and accept a no calmly. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Respond with a gesture or watch a coach offer simple movement messages.

**Add challenge:** Offer two different movements with a pause so the neighbor can choose a response.

**Stop or change:** Pause the pairing if a child touches, crowds, or pressures the other child.

**Look for:** Notice a child offering space or accepting a neighbor's different choice.

**Ask:** How did you share an idea?

## Practice 12 Mirror With Room Between Us

**Goal:** Explore wrestling stance, short steps, and gentle level changes through no-touch mirroring.

**Set up:** Separate paired markers with clear space around each pair and a visible stop card.

**Before you begin:** Demonstrate slow movements and show children that partners remain on their own markers.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Coach stance mirror | Invite children to copy a comfortable wrestling stance: feet apart, knees soft, hands forward. Show short steps and gentle level changes inside personal spaces. Pause between ideas; children choose their own depth or watch, with no need to match exactly. |

| 10-17 | Slow wrestling windows | Imagine each personal space is a window. Show a ready stance, one small sideways step, and a gentle level change with eyes forward. Invite children to choose one movement or combine two, then relax before the coach offers another idea. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Two quiet mirrors | Offer willing pairs separate markers facing each other. One child chooses a slow movement while the other follows if comfortable. Swap leaders after two or three ideas. Adults help keep movements small; solo children can mirror the coach instead. |

| 26-32 | Choose a mirror size | Invite children to choose small hand movements, whole-body shapes, or gentle steps within their spaces. They may mirror a coach, a willing partner, or move independently. Change the invitation when interest fades rather than requiring everyone to finish. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use only hand movements while seated or standing.

**Add challenge:** Link two slow movements and leave a pause for the follower.

**Stop or change:** Stop paired mirroring when spacing shrinks, movements become jerky, or a child feels pressured.

**Look for:** Notice a child slowing a movement so another person can comfortably respond.

**Ask:** Which movement was fun to copy?

## Practice 13 Your Turn My Turn

**Goal:** Experience brief shared turns while keeping waiting active and optional.

**Set up:** Movement picture cards, separate paired spaces, and nearby independent marker paths.

**Before you begin:** Prepare an independent movement option so no child must wait in a line.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Choose a movement card | Spread two or three picture choices where children can see them. Invite pointing to walking, reaching, or comfortable crawling, then trying a personal version. Coaches announce choices without collecting children into a queue or requiring them to copy others. |

| 10-17 | Coach takes a turn | Invite children to choose a movement for the coach, then offer one in return. Keep each turn to a single simple idea with time to respond. Children may decline the offered movement or choose an independent path nearby. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Shared chooser game | Give willing pairs two movement pictures and separate spaces. One chooses a picture, and both may try comfortable versions. Offer the other child the next choice after a short turn. Adults help without taking over or demanding equal performances. |

| 26-32 | Turn or travel choice | Offer the shared picture game and a nearby solo walking route. Children can move between them when the space is clear. If waiting becomes difficult, provide another set of cards or an adult partner rather than extending the wait. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use two pictures and let an adult guide a single exchange.

**Add challenge:** Invite each partner to suggest a new safe movement before choosing.

**Stop or change:** Pause if children grab cards, argue over turns, or crowd the same space.

**Look for:** Notice a child offering the next choice or choosing a comfortable independent alternative.

**Ask:** What did you choose on your turn?

## Practice 14 Solo Sprawl and Return to Stance

**Goal:** Send the legs back, lower the hips briefly, and recover the feet to stance.

**Set up:** Roomy personal mat spaces, a stance picture, and a nearby upright footwork area.

**Before you begin:** Review P07 Solo Sprawl. Confirm comfortable hand support before offering the slow step-back version.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Stance and Hand Support | Begin with short stance steps and pauses. In clear spaces, bend hips and knees to place both palms on the mat, then recover to stance. Keep the head clear and let the feet support the return. Children may remain upright and copy backward steps; alternate attempts with rest. |

| 10-17 | Solo Sprawl - P07 | From stance, bend to place palms in front. Step one foot back, then the other, keeping feet apart. Extend the legs and lower hips briefly with knees off and chest supported. Lift hips enough to step feet under you; lift hands and return to stance. Demonstrate P07 slowly from the side; no long holds. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Copy One Sprawl | Use separate spaces with no contact. One child shows a slow P07 step-back sprawl and returns the feet to stance; the other may copy or watch. Rest and swap after one attempt. Coach checks hips low rather than a high plank, and a standing reset rather than dropping to the knees. |

| 26-32 | Sprawl or Stance | Show an open hand for one slow solo sprawl and a return to stance; show a closed hand for small stance steps. Pause between signals and offer rest freely. Children may choose upright steps throughout. Keep the aim balanced movement, without jumping backward, racing, or holding the low position. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay upright and take small backward stance steps; or rehearse bending to supported palms and returning to stance.

**Add challenge:** Respond to a visual signal with one slow step-back sprawl and a balanced stance reset.

**Stop or change:** Stop for head contact, collapsing arms, back discomfort, sudden dropping, or lost balance. Solo only.

**Look for:** Notice legs extended behind, hips briefly low, knees off the mat, and feet returning under the body.

**Ask:** What helped you bring your feet back underneath you?

## Practice 15 Pause Together Move Together

**Goal:** Notice a partner's signals and choose a shared pace without physical contact.

**Set up:** Parallel walking lanes for pairs, clear end markers, and a large stop card.

**Before you begin:** Demonstrate that either child can pause and the other leaves space.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Pause with the coach | Invite children to walk in personal lanes while watching the coach's open hand. When the hand becomes still, the coach pauses too. Children can stop when ready, point instead of walking, or observe without being corrected for response speed. |

| 10-17 | Travel at a shared pace | Walk slowly beside a child in a separate lane and invite them to choose the pace. Model slowing or stopping when they do. Offer short journeys with rests, and avoid turning shared movement into a speed-matching challenge. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbor pause signals | Invite willing pairs into neighboring lanes. Either child may show a raised hand to suggest a pause; the other can respond by stopping or waving. Resume only when both choose. Adults help interpret signals, and solo travel remains available. |

| 26-32 | Follow a friendly pause | Offer a coach-led walking path and stationary hand-signal play. Children choose an invitation and may change when clear. Let different children suggest pauses by gesture, showing that a group's movement can slow to make participation comfortable for everyone. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Remain at markers and practice raising a hand, pausing, and waving.

**Add challenge:** Take turns suggesting when a short parallel journey begins or pauses.

**Stop or change:** Stop when one child pulls ahead to chase, crosses lanes, or ignores a partner's pause request.

**Look for:** Notice a child noticing and respecting another person's pause.

**Ask:** How could you ask for a pause?

## Practice 16 Roll and Welcome the Ball

**Goal:** Explore gentle object sharing while staying in separate spaces.

**Set up:** One large soft lightweight ball per pair, clear seated rolling lanes, and separate walking areas.

**Before you begin:** Check ball size and condition; keep rolling paths away from walking routes.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Rolling lane tour | Invite children to walk beside the empty rolling lanes and find where each begins and ends. Demonstrate sitting comfortably at one end and rolling a ball gently. Children may watch, use a standing movement area, or explore a ball alone. |

| 10-17 | Send to the empty marker | Invite each child with a ball to roll it gently toward an empty nearby marker. Retrieve it by walking only after it stops and the route is clear. Offer seated rolling or a coach-assisted return without requiring accurate aiming. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Roll to a willing neighbor | Seat willing partners comfortably at opposite ends of a clear short lane. Invite gentle rolls toward one another, allowing the receiver to stop or let the ball pass. Adults return stray balls. Solo rolling toward a marker remains available. |

| 26-32 | Choose a rolling journey | Offer short straight rolling lanes and solo target markers. Children choose partners or independent exploration, then decide whether to repeat or rest. Invite changing the target distance with adult help, keeping throws, hard pushes, and competitive scoring out of play. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Roll a short distance to a coach or explore stopping a stationary ball.

**Add challenge:** Choose between two nearby targets while keeping the roll gentle.

**Stop or change:** Stop rolling if balls become airborne, children chase into other lanes, or a receiver feels uncomfortable.

**Look for:** Notice a gentle roll or a child waiting until the lane is clear.

**Ask:** Where did you like sending the ball?

## Practice 17 Build a Path Together

**Goal:** Share route choices and respect another person's preferred way to travel.

**Set up:** Flat nonslip markers, several clear building areas, and an adult assigned to moving each set.

**Before you begin:** Explain that adults place markers while children point, choose, or watch from outside the route.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Explore two routes | Offer a short straight path and a gentle curved path. Invite children to try either at a comfortable walking pace, repeat, or watch. Coaches ask for preferences through pointing or words while protecting open entry and exit spaces. |

| 10-17 | Choose where it goes | Show two possible places for the next marker and invite children to point to one. An adult sets the marker while everyone pauses outside the route. Invite exploration afterward, accepting children who prefer the original path or a stationary option. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Partner route designers | Invite willing pairs to choose alternating marker locations by pointing from the edge of a clear space. An adult builds a short route, then children explore separately with space between turns. One may observe while the other tries the path. |

| 26-32 | Keep it or change it | Offer the completed routes and invite children to keep a favorite route or suggest one gentle change. Adults move markers only during a pause. Children may choose a solo path, watch the building, or repeat familiar movements nearby. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Choose between two ready-made routes without helping design one.

**Add challenge:** Suggest a pause point and explain it by pointing or demonstrating.

**Stop or change:** Pause when children move markers during travel or gather inside a route being rebuilt.

**Look for:** Notice a child contributing a choice or accepting a partner's route suggestion.

**Ask:** Where would you put a resting spot?

## Practice 18 Solo Sit-Out and Reset

**Goal:** Step a foot out, bring the other leg through, and settle into a low sit-out.

**Set up:** Separate mat spaces and a coach demonstration with a clear view of the feet and supporting hand.

**Before you begin:** Review P09 Solo Sit-Out. Confirm a small supported hip lift without wrist discomfort or a trapped knee.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Base, Step and Seat | Explore a steady hands-and-knees base and a separate low seated position. From base, rehearse stepping the right foot forward and outward while supporting the body. Keep attempts short with rests. Children may stay seated or observe. This prepares the foot placement before the leg-through action. |

| 10-17 | Solo Sit-Out - P09 | From base, cross-post the left palm in front of the right; lift the right hand beside the thigh. Step the right foot forward and out. Press through the foot and left hand, slide the left leg beneath the raised right knee, and settle into a low seat with chest up. Reset separately. Demonstrate the full P09 sequence. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Copy a Sit-Out | Partners stay in separate spaces. One copies the P09 cross-post, right-foot step and left-leg-through action, then pauses low; the other may copy or watch. Reset separately and swap. Coaches check that the left knee clears before sitting; do not add partner contact or force a turn back to base. |

| 26-32 | Sit-Out Signal Game | An open hand invites one solo sit-out; a closed hand invites holding a comfortable base. Offer the foot-step rehearsal or seated hip scoot as choices. Rest between attempts. Help children find a clear leg path and an upright chest; no racing, memory test or forceful hip twist. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Rehearse the cross-post and right-foot step without threading the leg; or copy a seated hip scoot.

**Add challenge:** Use a visual signal for one sit-out and a separate, unhurried reset to base.

**Stop or change:** Stop for wrist or knee discomfort, head contact, forceful twisting, or dropping backward.

**Look for:** Notice the left leg clearing before the hips lower, chest up, and a balanced low seat.

**Ask:** Which two ideas would you put together?

## Practice 19 Tell a Story With Movement

**Goal:** Cooperate through simple imaginative movement and shared choices.

**Set up:** Pictures of a tree, river, and home, plus open personal spaces and clear walking lanes.

**Before you begin:** Show that the story can be followed standing, seated, walking, or watching.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Visit the imaginary forest | Invite children to imagine a forest while walking comfortably in personal lanes or moving their arms in place. Offer trees to look at and clear places to pause. Let children suggest details by gesture or words without requiring participation. |

| 10-17 | Cross the pretend river | Mark short clear routes beside pictures of a river. Invite careful ordinary steps between nearby markers, then a comfortable rest. No jumping is needed. Children may choose a seated paddling motion or watch the coach act out the journey. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Share the story choice | Invite willing partners on separate markers to choose the next picture in the story. One points to a place; both may show their own movement for visiting it. Swap choices, with the coach available to share a solo child's story. |

| 26-32 | Choose the ending | Offer pictures for resting at home, growing like a tree, or walking back along a route. Invite children to choose their own ending and repeat a favorite part. Adults follow ideas that preserve clear space and comfortable movement. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Remain seated or standing and choose one familiar story movement.

**Add challenge:** Choose two story places and pause between the movements for each.

**Stop or change:** Stop any pretend action that becomes jumping across gaps, chasing, or climbing on another child.

**Look for:** Notice a child sharing a story choice while allowing a neighbor's different movement.

**Ask:** Where did your story go?

## Practice 20 Celebrate Being a Helpful Partner

**Goal:** Revisit shared choices, gentle signals, and no-touch cooperation.

**Set up:** Separate stations for mirror play, picture puzzles, and gentle ball rolling with appropriate clear lanes.

**Before you begin:** Offer solo and coach-supported options at every station before children choose.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Helpful movement welcome | Invite children to move comfortably inside personal spaces while the coach models making room, pausing, and asking before joining. Children can copy any idea or keep their own movement. Use the stop card calmly and acknowledge considerate actions specifically. |

| 10-17 | Choose a cooperation station | Explain the three invitations: copy slow movements, choose two picture actions, or gently roll a ball along a clear lane. Children select one, watch, or rest. Adults manage equipment and spacing while allowing repeated play at a preferred station. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Share one favorite invitation | Offer willing partners separate spaces at their chosen station. Invite each child to suggest one movement or target, with an adult helping them take short turns. Children can change partners through the coach or return to independent play anytime. |

| 26-32 | Our helpful encore | Invite children to point toward the activity they want again. Reopen the chosen stations with clear supervision and space. Notice concrete cooperation, such as leaving room or returning a gentle roll, without awarding a best-partner prize or ranking children. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Choose one familiar station with an adult as partner or nearby observer.

**Add challenge:** Help choose an activity and suggest one way to make room for a neighbor.

**Stop or change:** Pause station play when children crowd, grab equipment, or pressure another child to participate.

**Look for:** Notice a considerate action, shared choice, or child comfortably choosing an independent alternative.

**Ask:** What helped you play beside someone?

## Practice 21 Signals We Can See

**Goal:** Notice clear visual cues and choose a comfortable response.

**Set up:** Large pictures showing walk, reach, and pause; flat personal-space markers and clear short lanes.

**Before you begin:** Pair each visual cue with simple words and demonstrate without requiring quick reactions.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | See it and choose | Show a walking picture and invite a few comfortable steps, then a pause picture and a rest. Give plenty of time between signals. Children may point, move their hands, or observe instead of traveling, and nobody is eliminated. |

| 10-17 | Two ways to respond | Show a reaching picture and demonstrate both a standing reach and a seated arm movement. Invite children to choose a response that feels comfortable. Alternate reaching and pausing slowly, allowing children to stay with one idea or watch nearby. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbor signal choices | Offer willing pairs separate markers and two picture cards. One child selects a card while the other chooses a comfortable response. Swap roles after a few invitations. Adults help interpret signals; a coach can offer the pictures for solo children. |

| 26-32 | Choose the signal leader | Invite children to choose whether a coach or willing child shows the next movement picture. Everyone responds in their own space or observes. Keep cards visible, name the action aloud, and pause whenever the room needs more space. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use one movement picture and a clearly demonstrated pause.

**Add challenge:** Offer three visible pictures while keeping enough response time for everyone.

**Stop or change:** Pause if children react by sprinting, crowd the signal holder, or seem confused and distressed.

**Look for:** Notice a child noticing a cue and choosing any comfortable response.

**Ask:** Which signal was easiest to notice?

## Practice 22 Which Path Has Room

**Goal:** Look for an open route and pause when space is occupied.

**Set up:** Several short parallel marker paths with clear starts, ends, and roomy waiting or independent movement spaces.

**Before you begin:** Demonstrate checking a route before entering and offer a solo space instead of waiting.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Look before leaving | Invite children to stand beside a marker and look for an empty nearby space before taking a few steps. Coaches model pausing when someone passes. Children may remain stationary and point toward open space rather than travel. |

| 10-17 | Open route choices | Offer two clear walking routes per small group. An adult indicates when a route is occupied and models choosing another or pausing outside it. Children explore without racing, and a nearby shape-making space provides an immediate alternative to waiting. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbors plan separate trips | Invite willing pairs to stand at separate start markers and point toward different clear routes. Each takes a short walk when ready, then returns outside the routes with adult guidance. They may choose solo travel or remain at their markers. |

| 26-32 | Choose space or pause | Offer walking routes and personal shape spaces. Invite children to choose where there is room, showing that staying still is also a good choice. Adults keep traffic slow and add space rather than making children compete for an opening. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use one child per lane with an adult helping identify open space.

**Add challenge:** Choose between two clear routes and explain the choice by pointing.

**Stop or change:** Pause when children race for openings, enter occupied lanes, or return against moving traffic.

**Look for:** Notice a child choosing open space or pausing without being rushed.

**Ask:** How did you find room to move?

## Practice 23 Small Steps Big Shapes

**Goal:** Rehearse a level change and lead-foot step while keeping the knees off the mat.

**Set up:** Roomy personal marker spaces and pictures showing small steps, gentle reaches, and relaxed pauses.

**Before you begin:** Review P04 Level Change and Step. This is standing entry preparation; keep the feet staggered when resetting.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Small step trail | Invite children to take a few comfortable small steps beside a short marker trail, then pause. Offer ordinary walking or seated foot movements as alternatives. Coaches notice deliberate movement without asking children to make their feet perfectly quiet. |

| 10-17 | Level Change and Step - P04 | From stance, lower through hips and knees. Push gently from the rear foot and step the lead foot forward as the hips travel with it. Bring the rear foot forward enough to restore the staggered stance, not next to the lead foot. Both knees stay off the mat. Copy P04 slowly, then rest. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Partners offer an entry idea | Place willing partners on separate markers. One shows a gentle level change or a solo lead-foot step with trailing-foot recovery; the other chooses a comfortable version. Swap invitations and pause between attempts. No reaching toward, touching, or taking down a partner. |

| 26-32 | Movement size story | Tell a simple story about opening a tiny window, looking at a wide view, and resting. Children choose small or larger comfortable movements for each idea. Keep seated, standing, ordinary walking, and observation options available throughout the story. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Explore small hand movements from one seated or standing position.

**Add challenge:** Link a small movement and a larger comfortable movement with a pause.

**Stop or change:** Stop for knee impact, lunging, sudden dropping, or reaching into another child's space.

**Look for:** Notice controlled lowering followed by a soft entry step and balanced recovery.

**Ask:** Which size of movement felt comfortable?

## Practice 24 Around the Pretend Pond

**Goal:** Explore curved routes and choose a comfortable way around an obstacle.

**Set up:** Flat markers outlining several small pretend ponds, each with a wide clear walking route around it.

**Before you begin:** Keep pond markers flat and routes wide; explain that nobody jumps across or enters them.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Walk beside the water | Invite children to walk slowly beside a pretend pond outlined with flat markers. Show how to look ahead and pause where there is room. Children may explore a straight route instead, point from a marker, or watch nearby. |

| 10-17 | Choose a way around | Show two gentle routes around the same pretend pond. Invite children to choose one, walk it, and pause at an end marker. Adults manage one traveler per route and keep return paths separate; completing the whole circle is optional. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbor route watchers | Offer willing pairs separate nearby ponds. One child chooses a route while the other watches from a clear marker, then they swap invitations. Watching children may point toward open space or do stationary shapes without following closely or directing forcefully. |

| 26-32 | Add a story stop | Invite children to imagine a bird, tree, or resting bench beside their route. They choose where to pause and make a comfortable movement representing it. Coaches support imaginative choices while keeping feet on clear routes and allowing stationary participation. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Use a short straight path beside the pretend pond.

**Add challenge:** Choose a pause point before the curve and look toward the route beyond.

**Stop or change:** Stop when children jump across ponds, cut through markers, or crowd a curved route.

**Look for:** Notice a child selecting a route and turning gently around the marked space.

**Ask:** Where did you stop beside the pond?

## Practice 25 Choose the Helpful Response

**Goal:** Practice choosing space, a pause, or adult help during pretend situations.

**Set up:** Pictures for space, pause, and help; separate marker areas and a clearly identified supervising adult.

**Before you begin:** Use gentle pretend examples without staging collisions, distress, or unwanted touch.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Room to move | Invite children to make comfortable shapes on widely spaced markers. The coach points out empty neighboring spaces and models moving only when clear. Children can choose a new marker or stay, discovering that making room does not require touching anyone. |

| 10-17 | Picture choice stories | Describe simple situations, such as wanting a rest or seeing an occupied path. Show pictures for pausing, finding space, and asking an adult. Invite pointing or acting out a choice, accepting several sensible answers without treating the activity as a test. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Share a helpful idea | Place willing partners on separate markers and show a picture of a crowded path or a tired walker. Invite one child to choose a helpful picture, then the other. They may gesture instead of speaking or share ideas with a coach. |

| 26-32 | Practice a chosen helper action | Offer children a clear walking path, a supervised rest place, and a coach available for questions. Invite trying a chosen action: pause, find space, or signal for help. Adults respond warmly and never manufacture a problem to test children. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Show just two pictures and demonstrate both responses.

**Add challenge:** Invite a child to suggest another helpful response by movement, gesture, or words.

**Stop or change:** End any pretend situation that worries a child or becomes actual crowding or unwanted contact.

**Look for:** Notice a child choosing space, a pause, or help without needing to explain verbally.

**Ask:** How could you show that you want help?

## Practice 26 Find Your Comfortable Route

**Goal:** Choose a movement route that suits current comfort and interest.

**Set up:** Separate short walking, stepping, and stationary-shape areas with pictures identifying each invitation.

**Before you begin:** Explain that every option is equally valued and children can change their choice.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Try a starting choice | Invite children to choose ordinary walking, careful steps beside markers, or comfortable stationary shapes. Demonstrate each briefly, then allow exploration. Adults notice where children seem comfortable and offer support without directing everyone toward the same activity or difficulty. |

| 10-17 | Two ways to the marker | Show a straight path and a gentle stepping path that reach separate end markers. Invite children to choose based on comfort, then pause or repeat. A stationary option remains nearby, and no route is described as the better choice. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Partners choose differently | Invite willing partners to point toward their preferred separate routes or stationary spaces. Each explores their own choice while the other may watch. After a short turn, offer another choice, showing that partners can enjoy different activities without changing each other. |

| 26-32 | Change your mind game | Invite children to begin at a chosen movement area, then signal when they want another option. Adults help them change using clear routes. Celebrate communicating preferences, including choosing rest, rather than counting how many different areas each child completes. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Choose one familiar stationary activity and stay with it.

**Add challenge:** Try a second comfortable route and notice what feels different.

**Stop or change:** Pause transitions if children rush, become crowded, or feel pushed into an uncomfortable option.

**Look for:** Notice a child making or changing a choice that supports comfortable participation.

**Ask:** Which choice felt right for you today?

## Practice 27 Build a Wrestling Movement Journey

**Goal:** Choose and connect solo base, sit-out, and stand-up movements without speed or contact.

**Set up:** Pictures for base, seated sit-out, and standing; separate spacious areas with clear travel routes.

**Before you begin:** Review P05, P09 and P08. Teach each action separately first; a reset between moves is part of this lesson.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Visit Three Positions | Show a hands-and-knees base, a low seat, and a balanced stance. Invite children to explore one or more in separate spaces. These are starting and finishing positions; demonstrate the P09 and P08 transitions separately. Keep demonstrations brief and leave time to pause, choose another position, or watch. |

| 10-17 | Choose a Wrestling Sequence | Show P05 base, then P09 Solo Sit-Out: cross-post, foot out, opposite leg through, low seat. Reset separately to base before P08 Solo Stand-Up: short outside-foot step, chest up, rise, clear hips and turn to face. Children choose one action or two with a reset. Keep every attempt solo and unhurried. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Neighbors choose a journey | Offer willing partners separate spaces and the three pictures. One chooses base, sitting, or standing and shows a comfortable version; the other may watch or try independently. Invite a familiar hand-supported transition only when wanted, then swap who chooses. |

| 26-32 | Make your own finish | Invite children to end their journey in a comfortable base, upright seat, or balanced stand. They may repeat a small hip scoot or planted-foot rise before resting. Coaches follow choices, preserve clear spaces, and avoid judging a correct sequence. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay with a comfortable base, seated hip scoot, or planted-foot starting position.

**Add challenge:** Link two familiar movements with a pause and comfortable hand support.

**Stop or change:** Stop for collapsing support, forceful twists, rushed rises, head contact, or crowded travel.

**Look for:** Notice a child linking or choosing familiar solo movements with comfortable pauses.

**Ask:** How would your journey finish?

## Practice 28 Children Share the Next Idea

**Goal:** Offer movement ideas and practice inviting others without making participation compulsory.

**Set up:** Personal spaces, movement picture choices, and clear areas for independent walking or observation.

**Before you begin:** Explain that sharing an idea is optional and adults check space before the group tries it.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Greet each child by name and show the water and rest spaces. Invite walking between nearby markers or watching beside a supervising adult. Explain that joining, pausing, and changing activities are welcome throughout this gathering. |

| 04-10 | Coach follows an invitation | Invite children to show or point toward a comfortable movement such as reaching, stepping, or pausing. The coach tries a safe version from a separate space. Children may watch without offering an idea, and no public performance is required. |

| 10-17 | Choose a group invitation | Offer two movement pictures and invite a willing child to choose one for the group. Demonstrate it briefly, then invite everyone to try their own version or keep an independent activity. Rotate opportunities without requiring every child to lead. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Invite a willing neighbor | Place willing partners on separate markers. One asks by gesture or words whether the other wants a movement idea, then offers a simple action. The neighbor can copy, adapt, or decline. Swap roles; a coach supports children choosing solo play. |

| 26-32 | Our idea collection | Collect two or three safe movement suggestions through pictures, gestures, or words. Open separate spaces for those ideas and let children choose. Adults adapt suggestions that need more space, explaining changes simply while preserving the child's contribution and voluntary participation. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Point to a picture and let the coach demonstrate the invitation.

**Add challenge:** Offer two safe movement choices and let a willing partner decide.

**Stop or change:** Stop invitations that become commands, pressured performances, touching, or movements beyond available space.

**Look for:** Notice a child offering a choice or accepting another person's decision.

**Ask:** What idea would you like to share?

## Practice 29 Our Favorite Movement Menu

**Goal:** Choose and revisit wrestling movement games while planning shared use of space.

**Set up:** Pictures and separate areas for stance paths, solo entry steps, base-and-sit play, and no-touch mirroring.

**Before you begin:** Use P01-P02 for stance steps, P04 for the standing entry step, and P09 for the solo sit-out. Confirm each chosen prerequisite.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Welcome each child to Grindstone and offer a quiet marker path or observation beside an adult. Show the day's stop signal. Children may stay with a preferred activity, take a supervised break, or finish with an authorized caregiver. |

| 04-10 | Read the wrestling menu | Show pictures for ready stance, a soft solo entry step, hands-and-knees base, and a low seated finish. Demonstrate each briefly in separate spaces. Invite children to point toward a favorite, while adults help preserve clear routes and welcome observation. |

| 10-17 | Choose a Familiar Wrestling Skill | Offer stance-step paths (P01-P02), standing level-change and step lanes (P04), and solo sit-outs (P09). Demonstrate each complete action, including the reset; the sit-out uses a cross-post, foot-out step and opposite-leg-through action. Children choose one familiar skill or watch. Assigned adults manage separate spaces and offer rest. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Share a movement choice | Invite willing partners to choose separate stance spaces or individual floor areas. Each child shows a small stance step, gentle level change, or base position while the other may copy or watch. Coaches support different choices; partners never reposition one another. |

| 26-32 | Plan the next celebration | Invite children to point toward stance, entry-step, base, or seated-sit pictures they would enjoy again. Keep those movement areas open while adults note preferences. Children may change their minds, and resting or watching receives the same welcome as active movement. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Offer two familiar choices and a coach-supported version.

**Add challenge:** Help suggest where an activity could happen with enough space for everyone.

**Stop or change:** Pause for crowding, knee impact, collapsing support, rushed turns, or pressured participation.

**Look for:** Notice a child communicating a preference and participating comfortably in their chosen area.

**Ask:** What belongs on our next movement menu?

## Practice 30 Grindstone Movement Celebration

**Goal:** Celebrate chosen wrestling foundation movements, shared space, and each child's preferred participation.

**Set up:** Spacious stations for stance paths, solo entry steps, base-to-seat movement, and no-touch mirroring.

**Before you begin:** Use P01-P02 for stance steps, P04 for the standing entry step, and P09 for the solo sit-out. Confirm each chosen prerequisite.

| Time | Activity | Coaching instructions |

|---|---|---|

| 00-04 | Welcome and choose | Offer children a choice of gentle movement or watching with a supervising adult as they arrive. Point out water, rest space, and the stop signal. Joining activities is voluntary; children can change choices throughout the gathering. |

| 04-10 | Everyone's ready movement | Invite a comfortable ready stance with feet apart, knees soft, and hands forward. Show small steps and a gentle level change, then relax. Children choose their own version or watch; the coach welcomes each child without ranking skill or effort. |

| 10-17 | Choose a Familiar Wrestling Skill | Offer stance-step paths (P01-P02), standing level-change and step lanes (P04), and solo sit-outs (P09). Demonstrate each complete action, including the reset; the sit-out uses a cross-post, foot-out step and opposite-leg-through action. Children choose one familiar skill or watch. Assigned adults manage separate spaces and offer rest. |

| 17-19 | Water and reset | Invite everyone to pause for water in the supervised rest space. Help children find their own bottles, leave clear walking routes, and choose whether to rejoin. Water and supervised breaks remain available throughout the gathering. |

| 19-26 | Share a wrestling favorite | Invite willing children to show a favorite stance step, level change, base position, or slow solo stand-up to a coach or partner across separate spaces. The other person may copy, wave, or watch. No audience, contact, or demonstration is required. |

| 26-32 | Choose the final encore | Offer the group's favorite movement choices for another round of relaxed play. Let each child decide where to finish, including a quiet option. Coaches share specific observations of curiosity, kindness, or communicating needs without comparing skills, bodies, or competitive potential. |

| 32-35 | Reflect and goodbye | Gather whoever wants to join and invite pointing, showing, or saying a favorite movement. Thank children for making room for one another. Offer a calm walk or observation while staff complete pickup with authorized adults. |

**Make it easier:** Stay at one favorite activity with a supervising adult nearby.

**Add challenge:** Suggest a gentle variation and invite the coach to try it.

**Stop or change:** Pause celebration activities if excitement creates crowding, rushed movement, or pressured participation.

**Look for:** Notice a child choosing how to participate and leaving with a welcoming individual goodbye.

**Ask:** What would you like Grindstone to offer next?

## References

These are original coaching designs. Use the current rules for your actual league or event, qualified instruction, and the club's medical and safeguarding procedures. Practice numbers do not certify tournament readiness.

[Grindstone Wrestling Club and Mat Rats](https://www.grindstonewrestling.org/mat-rats)

[Westminster Mat Rats Wrestling on Facebook](https://www.facebook.com/WestminsterMatRats/)

[USA Wrestling Folkstyle Level 1 technique demonstrations](https://www.usawmembership.com/usa_wrestling_core_curriculum/1)

[NFHS folkstyle rules resources; confirm youth event modifications](https://www.nfhs.org/sports/wrestling/rules)

[American Academy of Pediatrics sports readiness](https://www.healthychildren.org/English/healthy-living/sports/Pages/Is-Your-Child-Ready-for-Sports.aspx)

[CDC concussion response](https://www.cdc.gov/heads-up/response/index.html)

[CDC infection prevention for athletes](https://www.cdc.gov/mrsa/prevention/athletes.html)

## Coach reminders

Keep water available. Children participate at their normally nourished and hydrated weight. Remove suspected concussion from activity and obtain medical evaluation; no same-day return. Suspected contagious skin concerns need evaluation before contact. Follow actual club reporting and emergency procedures.

## After practice

Which task helped the group learn? Who needs a different partner or an easier version? What should be repeated? Record private health or safeguarding matters through the club's secure process.
