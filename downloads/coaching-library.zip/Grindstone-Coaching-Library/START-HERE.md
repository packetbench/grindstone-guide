# Grindstone Wrestling Coach Binder

Start with **Grindstone-Coaching-Binder.pdf** for printing. It contains the master index, tab dividers, the researched 72-entry moves reference, 30 end-of-practice games, all 90 practice plans, the program blueprint, coach toolkit and quick coaching cues.

Print double-sided, flip on the long edge. The punch margin alternates left/right. Use Letter paper at Actual Size / 100%. The combined file has 208 pages, requiring 104 sheets. Follow the continuous BINDER page numbers in the master index; the index numbers refer to the combined binder, not the standalone files. Sections flow continuously without blank separator pages.

The separate PDFs let coaches print just a section. **Grindstone-Coach-Moves-Reference.pdf** is the comprehensive shared handout, tiered Pup / Beginner / Advanced. **Grindstone-End-of-Practice-Games.pdf** has the full game bank and its own finder. The three short handouts form the QUICK appendix: concise reminders linked to exact pages in the shared moves reference.

For the deep research, open **Grindstone-Move-Research.html** in a browser or read **Grindstone-Move-Research.md**. Search by move ID, old name or new name. Each of the 72 moves received a separate research-agent review of mechanics, teaching progression, corrections and source limits. The detailed report stays outside the print binder to save paper. **technical-research/** includes the individual structured reviews. These are documented coaching research and teaching adaptations, not a claim of coach certification or live technique assessment.

Editable Markdown and structured JSON are included. All logos are the existing Grindstone/Mat Rats assets.

Prepared September 26, 2026.
